package com.stevesarmy.respawn;

import com.stevesarmy.StevesArmyMod;
import com.stevesarmy.compat.VS2Compat;
import com.stevesarmy.entity.SoldierEntity;
import com.stevesarmy.squad.SquadData;
import com.stevesarmy.squad.SquadManager;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.network.protocol.game.ServerboundClientCommandPacket;
import net.minecraft.world.phys.Vec3;
import java.util.UUID;

public class RespawnCameraController {
    
    private static final int TRANSITION_TICKS = 40;
    private static final int TICKS_BEFORE_TELEPORT = 10;
    
    private static final java.util.Map<UUID, CameraState> activeTransitions = new java.util.concurrent.ConcurrentHashMap<>();
    
    public static void startTransition(ServerPlayer player, SoldierEntity targetSoldier, SquadManager squadManager, SquadData squad, ServerLevel level) {
        UUID playerId = player.getUUID();
        
        CameraState state = new CameraState(
            player.getUUID(),
            targetSoldier.getUUID(),
            // Seated crew live at shipyard coordinates on VS ships — store the
            // converted world position; tick() re-derives it live anyway.
            VS2Compat.getSoldierWorldPosition(targetSoldier),
            targetSoldier.getYRot(),
            targetSoldier.getXRot(),
            squadManager,
            squad,
            level,
            0
        );
        
        activeTransitions.put(playerId, state);
        
        StevesArmyMod.LOGGER.info("[CameraTransition] Started for player {} to soldier at {}", 
            player.getName().getString(), targetSoldier.blockPosition());
    }

    public static void cancelTransition(UUID playerId) {
        if (activeTransitions.remove(playerId) != null) {
            StevesArmyMod.LOGGER.info("[CameraTransition] Cancelled for player {}", playerId.toString().substring(0, 8));
        }
    }
    
    public static void tick() {
        activeTransitions.entrySet().removeIf(entry -> {
            CameraState state = entry.getValue();
            state.tickCount++;
            
            if (state.tickCount >= TRANSITION_TICKS) {
                ServerPlayer player = state.level.getServer().getPlayerList().getPlayer(state.playerId);
                if (player != null && !player.isAlive()) {
                    SoldierEntity soldier = findSoldierByUUID(state.level, state.soldierId);
                    if (soldier == null || !soldier.isAlive()) {
                        PlayerDeathHandler.clearPendingRespawn(state.playerId, state.soldierId);
                        StevesArmyMod.LOGGER.warn("[CameraTransition] Target soldier {} was lost before transition completed for player {}; using normal respawn",
                            state.soldierId.toString().substring(0, 8), player.getName().getString());
                    }

                    // Use the same handler as the client's Respawn button. Calling PlayerList.respawn
                    // directly leaves the player's connection bound to the old ServerPlayer instance.
                    player.connection.handleClientCommand(new ServerboundClientCommandPacket(
                        ServerboundClientCommandPacket.Action.PERFORM_RESPAWN
                    ));
                }
                return true;
            }
            
            if (state.tickCount >= TICKS_BEFORE_TELEPORT) {
                ServerPlayer player = state.level.getServer().getPlayerList().getPlayer(state.playerId);
                SoldierEntity soldier = findSoldierByUUID(state.level, state.soldierId);
                if (player != null && soldier != null && soldier.isAlive() && !player.isSpectator()) {
                    // Re-derive the position every tick so the dead body tracks a
                    // soldier seated on a moving VS ship, in world space.
                    Vec3 livePos = VS2Compat.getSoldierWorldPosition(soldier);
                    if (VS2Compat.isWorldPlausible(livePos)) {
                        player.setCamera(null);
                        player.teleportTo(livePos.x, livePos.y + 0.5, livePos.z);
                        player.setYRot(state.soldierYRot);
                        player.setXRot(state.soldierXRot);
                    }
                }
            }
            
            return false;
        });
    }
    
    private static SoldierEntity findSoldierByUUID(ServerLevel level, UUID soldierId) {
        net.minecraft.world.entity.Entity entity = level.getEntity(soldierId);
        return entity instanceof SoldierEntity soldier ? soldier : null;
    }
    
    private static class CameraState {
        final UUID playerId;
        final UUID soldierId;
        final Vec3 soldierPos;
        final float soldierYRot;
        final float soldierXRot;
        final SquadManager squadManager;
        final SquadData squad;
        final ServerLevel level;
        int tickCount;
        
        CameraState(UUID playerId, UUID soldierId, Vec3 soldierPos, float soldierYRot, float soldierXRot, 
                    SquadManager squadManager, SquadData squad, ServerLevel level, int tickCount) {
            this.playerId = playerId;
            this.soldierId = soldierId;
            this.soldierPos = soldierPos;
            this.soldierYRot = soldierYRot;
            this.soldierXRot = soldierXRot;
            this.squadManager = squadManager;
            this.squad = squad;
            this.level = level;
            this.tickCount = tickCount;
        }
    }
}
