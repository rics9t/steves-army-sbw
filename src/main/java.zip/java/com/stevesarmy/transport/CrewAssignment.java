package com.stevesarmy.transport;

import com.stevesarmy.StevesArmyConfig;
import com.stevesarmy.StevesArmyMod;
import com.stevesarmy.compat.AnalogWarfareCompat;
import com.stevesarmy.compat.SbwCompat;
import com.stevesarmy.compat.VS2Compat;
import com.stevesarmy.combat.StationGunnerAI;
import com.stevesarmy.entity.SoldierEntity;
import com.stevesarmy.entity.SoldierRole;
import com.stevesarmy.vehicle.VehicleBoardingManager;
import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;

import javax.annotation.Nullable;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

/**
 * Shared server-side logic for putting vehicle crew on ships: the crew assign stick,
 * the egg-on-seat shortcut, the wheel's MOUNT_CREW order, and the public
 * {@link com.stevesarmy.api.VehicleCrewApi} all route through {@link #mountCrewOnShip},
 * which mirrors the proven infantry MOUNT seating machinery
 * ({@code TransportOrderMessage.handleMount}). Everything is keyed by ship + anchor
 * position — ships hold SeatBlocks, not seat entities (Create discards an empty seat's
 * entity), so a raw seat-entity mount exists only as the tallyho fallback.
 */
public final class CrewAssignment {
    private CrewAssignment() {}

    /** Owned crew who are on foot, near the anchor, and not currently manning a station. */
    public static List<SoldierEntity> stationlessCrewNear(ServerLevel level, ServerPlayer owner,
                                                          Vec3 anchor, double radius) {
        return level.getEntitiesOfClass(SoldierEntity.class,
            new AABB(anchor, anchor).inflate(radius),
            s -> s.isOwnedBy(owner) && s.getRole() == SoldierRole.VEHICLE_CREW
                && !s.isPassenger() && !StationGunnerAI.soldierHasStation(s));
    }

    /**
     * Wheel/API path: seat nearby station-less crew on the given ship. Mirrors the
     * infantry MOUNT seating machinery; {@code tickSeatedCrewDuty} handles station
     * claims once seated.
     */
    public static int autoAssignNear(ServerPlayer owner, ServerLevel level, Object ship, Vec3 anchor) {
        List<SoldierEntity> crew = stationlessCrewNear(level, owner, anchor, 64);
        if (crew.isEmpty()) {
            return 0;
        }
        return mountCrewOnShip(level, ship, anchor, crew);
    }

    /**
     * Tiered mount routine shared by every crew entry point, in the same order as the
     * infantry MOUNT order:
     * <ol>
     *   <li>VSAW handle-linked seats,</li>
     *   <li>the ship's free SeatBlocks, scanned across the whole voxel AABB in shipyard
     *       space and taken nearest-to-anchor first, so aiming straight at a seat
     *       prefers it,</li>
     *   <li>raw seat-entity mounts for ships whose seats have no SeatBlock behind them
     *       (e.g. tallyho FlexibleSeatEntity) — the unreliable kind, so WARN-logged.</li>
     * </ol>
     *
     * @return the number of crew with a reserved seat and an active walk-up order
     */
    public static int mountCrewOnShip(ServerLevel level, @Nullable Object ship, Vec3 anchorWorld,
                                      List<SoldierEntity> crew) {
        if (crew.isEmpty()) {
            return 0;
        }
        Long shipId = VS2Compat.getShipIdOf(ship);
        if (shipId == null) {
            StevesArmyMod.LOGGER.warn("[Crew] cannot seat {} crew: ship unresolved at anchor {}",
                crew.size(), anchorWorld);
            return 0;
        }
        VS2Compat.logCrewMountDiagnostics(level, ship, anchorWorld);
        List<SoldierEntity> remaining = new ArrayList<>(crew);
        int seatedCount = 0;

        // Tier 1: handle-linked seats (mountViaHandles removes the soldiers it seats).
        if (StevesArmyConfig.VEHICLE_HANDLES_ENABLED.get() && AnalogWarfareCompat.isAvailable()) {
            seatedCount += AnalogWarfareCompat.mountViaHandles(level, ship, anchorWorld, remaining);
        }

        // Tier 2: Create's own contraption seats via the Create Interactive ship mapping —
        // the same path normal soldiers take on moving ships; no shipyard block access.
        if (!remaining.isEmpty()) {
            for (SoldierEntity soldier : new ArrayList<>(remaining)) {
                if (VS2Compat.seatSoldierOnShipContraption(level, shipId, soldier) != null) {
                    remaining.remove(soldier);
                    seatedCount++;
                }
            }
        }

        // Tier 3: the ship's free SeatBlocks, scanning the ship's whole voxel AABB
        // (shipyard space), nearest to the anchor first.
        if (!remaining.isEmpty()) {
            List<BlockPos> seats = VS2Compat.findFreeStaticSeats(level, ship, anchorWorld, remaining.size());
            if (seats.isEmpty()) {
                // No seat blocks anywhere on the ship — inventory its entities so the
                // log identifies any entity-based seats a block scan cannot see, and
                // name every station AI currently running a gun on this ship.
                VS2Compat.logShipEntityCensus(level, ship, anchorWorld);
                StationGunnerAI.logActiveStations(level);
            }
            for (SoldierEntity soldier : new ArrayList<>(remaining)) {
                if (seats.isEmpty()) {
                    break;
                }
                BlockPos seat = seats.get(0);
                if (seatStatic(level, ship, soldier, seat)) {
                    seats.remove(0);
                    remaining.remove(soldier);
                    seatedCount++;
                }
            }
        }

        // Tier 4: raw seat-entity mounts — ships whose seats have no SeatBlock behind
        // them (e.g. tallyho FlexibleSeatEntity) have no static path at all.
        if (!remaining.isEmpty()) {
            List<Entity> seatEntities = freeSeatEntitiesOnShip(level, shipId, anchorWorld, remaining.size());
            for (SoldierEntity soldier : new ArrayList<>(remaining)) {
                if (seatEntities.isEmpty()) {
                    break;
                }
                Entity seat = seatEntities.remove(0);
                prepareForMount(soldier);
                if (VS2Compat.seatSoldierOnSeatEntity(soldier, seat)) {
                    remaining.remove(soldier);
                    seatedCount++;
                    StevesArmyMod.LOGGER.info("[Crew] seated soldier={} via raw seat entity={} shipId={} (fallback tier)",
                        soldier.getId(), seat.getId(), shipId);
                }
            }
            if (!remaining.isEmpty()) {
                StevesArmyMod.LOGGER.warn(
                    "[Crew] {} of {} crew could not be seated on shipId={} at anchor {}: no free handle/static seats (last static scan: {}), {} raw seat entities in reach",
                    remaining.size(), crew.size(), shipId, anchorWorld,
                    VS2Compat.getLastStaticScanSummary(), seatEntities.size());
            }
        }

        return seatedCount;
    }

    /**
     * Seats crew on a plain world-space vehicle entity (Superb Warfare), the
     * entity analogue of {@link #mountCrewOnShip}: capacity is the vehicle's JSON
     * seat count, the first crew member reserves the driver seat when it is free,
     * and the remaining crew reserve passenger seats. Crew walk to the hull and
     * board on arrival. No handle/contraption tiers — an SBW vehicle has one
     * seating system.
     *
     * @return the number of crew seated
     */
    public static int mountCrewOnVehicle(ServerLevel level, Entity vehicle,
                                         List<SoldierEntity> crew) {
        if (crew.isEmpty() || !SbwCompat.isOperational(vehicle)) {
            return 0;
        }
        int seatedCount = 0;
        for (SoldierEntity soldier : crew) {
            if (!SbwCompat.isOperational(vehicle)) {
                break;
            }
            prepareForMount(soldier);
            if (VehicleBoardingManager.requestBoard(soldier, vehicle)) {
                seatedCount++;
            }
        }
        if (seatedCount < crew.size()) {
            StevesArmyMod.LOGGER.info("[Crew] {} of {} crew could not be seated on vehicle={} type={}: no free seats",
                crew.size() - seatedCount, crew.size(), vehicle.getId(),
                SbwCompat.getVehicleTypeName(vehicle));
        }
        return seatedCount;
    }

    /** Seat one crew member on a static SeatBlock via SeatBlock.sitDown (the infantry MOUNT path). */
    private static boolean seatStatic(ServerLevel level, Object ship, SoldierEntity soldier,
                                      BlockPos seatPos) {
        prepareForMount(soldier);
        if (VS2Compat.seatSoldierDirect(soldier, level, seatPos)) {
            StevesArmyMod.LOGGER.info("[Crew] seated soldier={} via static seat={} shipId={}",
                soldier.getId(), seatPos, VS2Compat.getShipIdOf(ship));
            return true;
        }
        return false;
    }

    /** Block-space tolerance for "the seat at the aimed/recorded block" (covers block-position rounding). */
    private static final double EXACT_SEAT_TOLERANCE = 1.5;

    /**
     * Mounts {@code soldier} on the seat exactly at the aimed/recorded block, tried
     * before the tiered {@link #mountCrewOnShip} fallback so an aimed-at seat is taken
     * literally instead of "first free handle/contraption seat on the ship". All
     * comparisons are block-space against {@code anchorBlock} (the VS2 clip block /
     * recorded support block), which is shipyard space on ships and world space on the
     * ground alike — no vector-space ambiguity. Every miss degrades to the tiered
     * fallback; nothing here changes how the fallback behaves.
     */
    public static boolean seatAtExactPosition(ServerLevel level, Object ship, BlockPos anchorBlock,
                                              SoldierEntity soldier) {
        Long shipId = VS2Compat.getShipIdOf(ship);
        if (shipId == null) {
            return false;
        }
        // 1. The exact SeatBlock under the crosshair / at the recorded position.
        if (VS2Compat.isValidStaticSeat(level, ship, anchorBlock)) {
            prepareForMount(soldier);
            if (VS2Compat.seatSoldierDirect(soldier, level, anchorBlock)) {
                StevesArmyMod.LOGGER.info("[Crew] exact mount: soldier={} static seat={} shipId={}",
                    soldier.getId(), anchorBlock, shipId);
                return true;
            }
        }
        // 2. A free seat entity at the recorded block (Create SeatEntity, tallyho
        //    FlexibleSeatEntity), only when it belongs to this ship. Full entity scan
        //    like the tier-4 fallback: seat entities live at raw (shipyard) positions,
        //    so a block-space AABB query is not reliable.
        Entity bestSeat = null;
        double bestDistance = EXACT_SEAT_TOLERANCE * EXACT_SEAT_TOLERANCE;
        for (Entity seat : level.getAllEntities()) {
            if (seat.isRemoved() || !seat.getPassengers().isEmpty()
                    || !VS2Compat.isCreateSeatEntity(seat)) {
                continue;
            }
            Long seatShip = VS2Compat.getShipIdOf(VS2Compat.getShipUnder(seat));
            if (!shipId.equals(seatShip)) {
                continue;
            }
            double distance = seat.blockPosition().distSqr(anchorBlock);
            if (distance < bestDistance) {
                bestDistance = distance;
                bestSeat = seat;
            }
        }
        if (bestSeat != null) {
            prepareForMount(soldier);
            if (VS2Compat.seatSoldierOnSeatEntity(soldier, bestSeat)) {
                StevesArmyMod.LOGGER.info("[Crew] exact mount: soldier={} seat entity={} shipId={}",
                    soldier.getId(), bestSeat.getId(), shipId);
                return true;
            }
        }
        // 3. A handle link whose seat sits at the recorded block.
        if (AnalogWarfareCompat.isAvailable()
                && AnalogWarfareCompat.mountViaHandleNear(level, ship, anchorBlock, soldier,
                    EXACT_SEAT_TOLERANCE)) {
            return true;
        }
        return false;
    }

    /** Stops duty AI and any current transport so the mount starts from a clean state. */
    private static void prepareForMount(SoldierEntity soldier) {
        StationGunnerAI.deactivateForSoldier(soldier);
        if (soldier.isPassenger()) {
            // No handle exit: the soldier is re-seated immediately by the mount.
            VS2Compat.releaseTransport(soldier, false);
        }
        soldier.getNavigation().stop();
        soldier.cancelCoverMovement();
        soldier.setDeltaMovement(Vec3.ZERO);
    }

    /**
     * Free Create seat entities on the ship with {@code shipId}, ordered nearest-first
     * from {@code originWorld}, capped at {@code max}. Persistent tallyho
     * FlexibleSeatEntity seats live here; unoccupied Create seats never do (their
     * entity self-discards).
     */
    private static List<Entity> freeSeatEntitiesOnShip(ServerLevel level, Long shipId,
                                                       Vec3 originWorld, int max) {
        List<Entity> candidates = new ArrayList<>();
        int createSeatEntitiesSeen = 0;
        for (Entity entity : level.getAllEntities()) {
            if (entity.isRemoved() || !VS2Compat.isCreateSeatEntity(entity)) {
                continue;
            }
            createSeatEntitiesSeen++;
            if (!entity.getPassengers().isEmpty()) {
                continue;
            }
            Long other = VS2Compat.getShipIdOf(VS2Compat.getShipUnder(entity));
            if (!shipId.equals(other)) {
                continue;
            }
            candidates.add(entity);
        }
        StevesArmyMod.LOGGER.info("[Crew] raw seat entity scan: create-seat entities in world={} free on shipId={}={}",
            createSeatEntitiesSeen, shipId, candidates.size());
        candidates.sort(Comparator.comparingDouble(
            seat -> VS2Compat.getSeatWorldPosition(seat).distanceToSqr(originWorld)));
        if (candidates.size() > max) {
            candidates.subList(max, candidates.size()).clear();
        }
        return candidates;
    }
}
