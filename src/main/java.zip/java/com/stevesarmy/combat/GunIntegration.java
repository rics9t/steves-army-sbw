package com.stevesarmy.combat;

import com.stevesarmy.StevesArmyMod;
import com.stevesarmy.combat.cover.GunBlockImpactHandlerTaCZ;
import com.stevesarmy.combat.cover.IncomingFireHandlerTaCZ;
import com.stevesarmy.debug.DiagnosticLogManager;
import com.stevesarmy.entity.SoldierEntity;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.ai.attributes.AttributeModifier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.common.capabilities.ForgeCapabilities;

import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.Optional;
import java.util.Map;
import java.util.UUID;

public class GunIntegration {
    private static boolean taczLoaded = false;
    private static boolean vpbLoaded = false;
    private static boolean sbwLoaded = false;

    private static final VpbGunHandler VPB_HANDLER = new VpbGunHandler();
    private static final ReflectionGunHandler TACZ_HANDLER = new ReflectionGunHandler();
    private static final FallbackGunHandler FALLBACK_HANDLER = new FallbackGunHandler();
    private static GunHandler sbwHandler = null;
    private static GunHandler gunHandler = FALLBACK_HANDLER;

    /**
     * Sim-harness-only override (see sim/SimGunHandler). Takes precedence over
     * the mod-selected handler so headless runs can fight without TaCZ; null
     * (the default, and after uninstall) restores the normal routing.
     */
    private static volatile GunHandler simHandler;

    public static void installSimGunHandler(GunHandler handler) { simHandler = handler; }
    public static void uninstallSimGunHandler() { simHandler = null; }
    public static boolean isSimGunsArmed() { return simHandler != null; }

    private static GunHandler handler() {
        GunHandler active = simHandler;
        return active != null ? active : gunHandler;
    }

    /** Observes shots fired through this facade; used by the headless sim renderer. */
    public interface ShotListener {
        void onShot(LivingEntity shooter, Vec3 aimPoint);
    }

    public static volatile ShotListener shotListener;

    private static void notifyShot(LivingEntity shooter, Vec3 aimPoint) {
        ShotListener listener = shotListener;
        if (listener != null && aimPoint != null) listener.onShot(shooter, aimPoint);
    }

    public static void init() {
        try {
            Class.forName("com.tacz.guns.api.entity.IGunOperator");
            Class.forName("com.tacz.guns.api.item.IGun");
            Class.forName("com.tacz.guns.api.TimelessAPI");

            taczLoaded = true;
            StevesArmyMod.LOGGER.info("TaCZ detected - enabling gun integration");
        } catch (ClassNotFoundException e) {
            StevesArmyMod.LOGGER.info("TaCZ not detected");
        }

        try {
            Class.forName("com.vicmatskiv.pointblank.item.GunItem");
            Class.forName("com.vicmatskiv.pointblank.item.FireModeInstance");
            Class.forName("com.vicmatskiv.pointblank.item.AmmoItem");

            vpbLoaded = true;
            StevesArmyMod.LOGGER.info("Vic's Point Blank detected - enabling VPB gun integration");
        } catch (ClassNotFoundException e) {
            StevesArmyMod.LOGGER.info("Vic's Point Blank not detected");
        }

        com.stevesarmy.compat.sbw.SbwCompat.init();
        if (com.stevesarmy.compat.sbw.SbwCompat.hasGuns()) {
            sbwHandler = new com.stevesarmy.compat.sbw.SbwGunHandler();
            sbwLoaded = true;
            StevesArmyMod.LOGGER.info("SBW detected - enabling Superb Warfare gun provider");
        }

        int availableProviders = (taczLoaded ? 1 : 0) + (vpbLoaded ? 1 : 0) + (sbwLoaded ? 1 : 0);
        if (availableProviders > 1) {
            gunHandler = new CompositeGunHandler();
        } else if (sbwLoaded) {
            gunHandler = sbwHandler;
        } else if (vpbLoaded) {
            gunHandler = VPB_HANDLER;
        } else if (taczLoaded) {
            gunHandler = TACZ_HANDLER;
        } else {
            gunHandler = FALLBACK_HANDLER;
        }

        if (taczLoaded) {
            registerTaCZEventHandlers();
        }
    }

    /**
     * TaCZ event handlers are registered manually instead of through
     * {@code @EventBusSubscriber}: automatic registration resolves every
     * handler method's parameter types during mod construction, so a TaCZ
     * build missing an event class (e.g. 1.1.8-hotfix dropped
     * AmmoHitBlockEvent) crashes the whole mod load. Each handler is only
     * registered when its event class is actually present.
     */
    private static void registerTaCZEventHandlers() {
        tryRegisterHandler("com.tacz.guns.api.event.common.GunShootEvent",
            GunshotDetectionHandlerTaCZ.class);
        tryRegisterHandler("com.tacz.guns.api.event.common.EntityHurtByGunEvent",
            IncomingFireHandlerTaCZ.class);
        tryRegisterHandler("com.tacz.guns.api.event.server.AmmoHitBlockEvent",
            GunBlockImpactHandlerTaCZ.class);
    }

    private static void tryRegisterHandler(String eventClassName, Class<?> handlerClass) {
        try {
            Class.forName(eventClassName);
            MinecraftForge.EVENT_BUS.register(handlerClass);
            StevesArmyMod.LOGGER.info("[TaCZ] Registered {} for {}", handlerClass.getSimpleName(), eventClassName);
        } catch (Throwable t) {
            StevesArmyMod.LOGGER.warn("[TaCZ] Skipping {} - event {} unavailable ({})",
                handlerClass.getSimpleName(), eventClassName, t.toString());
        }
    }

    public static boolean isTaczLoaded() { return taczLoaded; }
    public static boolean isVpbLoaded() { return vpbLoaded; }
    public static boolean isSbwLoaded() { return sbwLoaded; }
    public static boolean isGunModLoaded() { return taczLoaded || vpbLoaded || sbwLoaded; }
    public static boolean isAnyGunLoaded() { return isGunModLoaded() || simHandler != null; }

    public static boolean isVpbGun(ItemStack stack) {
        return VpbGunHandler.isVpbGun(stack);
    }

    public static boolean isGun(ItemStack stack) {
        if (stack == null || stack.isEmpty()) return false;
        return isTaczGun(stack) || isVpbGun(stack) || (sbwLoaded && com.stevesarmy.compat.sbw.SbwCompat.isGun(stack));
    }

    public static boolean isAnyGun(ItemStack stack) {
        return isGun(stack);
    }

    private static boolean isTaczGun(ItemStack stack) {
        if (!taczLoaded || stack.isEmpty()) return false;
        try {
            Class<?> gunInterface = Class.forName("com.tacz.guns.api.item.IGun");
            Method getIGunOrNull = gunInterface.getMethod("getIGunOrNull", ItemStack.class);
            return getIGunOrNull.invoke(null, stack) != null;
        } catch (Exception e) {
            return false;
        }
    }
    public static GunHandler handlerFor(ItemStack stack) {
        GunHandler sim = simHandler;
        if (sim != null) return sim;
        if (stack == null || stack.isEmpty()) return FALLBACK_HANDLER;
        if (sbwLoaded && com.stevesarmy.compat.sbw.SbwCompat.isGun(stack)) {
            return sbwHandler;
        }
        if (vpbLoaded && isVpbGun(stack)) {
            return VPB_HANDLER;
        }
        if (taczLoaded && isTaczGun(stack)) {
            return TACZ_HANDLER;
        }
        return FALLBACK_HANDLER;
    }

    public static GunHandler handlerFor(LivingEntity entity) {
        GunHandler sim = simHandler;
        if (sim != null) return sim;
        if (entity == null) return gunHandler;
        return handlerFor(entity.getMainHandItem());
    }

    public static void tick(LivingEntity entity) {
        handlerFor(entity).tick(entity);
    }

    public static boolean hasGun(LivingEntity entity) { return handlerFor(entity).hasGun(entity); }
    public static ShootResult shoot(LivingEntity shooter, LivingEntity target) {
        ShootResult result = handlerFor(shooter).shoot(shooter, target);
        if (result == ShootResult.SUCCESS) notifyShot(shooter, target != null ? target.getEyePosition() : null);
        return result;
    }
    public static ShootResult shootWithDeviation(LivingEntity shooter, ExposureCalculator.AimPointResult aimPoint, float pitchDeviation, float yawDeviation) {
        ShootResult result = handlerFor(shooter).shootWithDeviation(shooter, aimPoint, pitchDeviation, yawDeviation);
        if (result == ShootResult.SUCCESS) notifyShot(shooter, aimPoint != null ? aimPoint.position : null);
        return result;
    }
    public static ShootResult shootAtPosition(LivingEntity shooter, Vec3 targetPosition) {
        ShootResult result = handlerFor(shooter).shootAtPosition(shooter, targetPosition);
        if (result == ShootResult.SUCCESS) notifyShot(shooter, targetPosition);
        return result;
    }
    public static boolean canReload(LivingEntity entity) { return handlerFor(entity).canReload(entity); }
    public static void reload(LivingEntity entity) { handlerFor(entity).reload(entity); }
    public static void refillMagazine(LivingEntity entity) { handlerFor(entity).refillMagazine(entity); }
    public static void cancelReload(LivingEntity entity) { handlerFor(entity).cancelReload(entity); }
    public static void bolt(LivingEntity entity) { handlerFor(entity).bolt(entity); }
    public static void aim(LivingEntity entity, boolean isAiming) { handlerFor(entity).aim(entity, isAiming); }
    public static boolean isBolting(LivingEntity entity) { return handlerFor(entity).isBolting(entity); }
    public static boolean isReloading(LivingEntity entity) { return handlerFor(entity).isReloading(entity); }
    public static float getAimProgress(LivingEntity entity) { return handlerFor(entity).getAimProgress(entity); }
    public static long getShootCoolDown(LivingEntity entity) { return handlerFor(entity).getShootCoolDown(entity); }
    public static boolean isDrawing(LivingEntity entity) { return handlerFor(entity).isDrawing(entity); }
    public static double getEffectiveRange(LivingEntity entity) { return handlerFor(entity).getEffectiveRange(entity); }
    public static Optional<ItemStack> getGunStack(LivingEntity entity) { return handlerFor(entity).getGunStack(entity); }
    public static void initialData(LivingEntity entity) { handlerFor(entity).initialData(entity); }
    public static void draw(LivingEntity entity) { handlerFor(entity).draw(entity); }
    public static int getMagazineSize(LivingEntity entity) { return handlerFor(entity).getMagazineSize(entity); }
    public static int getCurrentAmmo(LivingEntity entity) { return handlerFor(entity).getCurrentAmmo(entity); }
    public static boolean hasAmmoInBarrel(LivingEntity entity) { return handlerFor(entity).hasAmmoInBarrel(entity); }
    public static boolean isManualBolt(LivingEntity entity) { return handlerFor(entity).isManualBolt(entity); }
    public static boolean useInventoryAmmo(LivingEntity entity) { return handlerFor(entity).useInventoryAmmo(entity); }
    public static String getGunId(LivingEntity entity) { return handlerFor(entity).getGunId(entity); }

    /**
     * Gun ID (e.g. {@code tacz:rpg7}) for any gun ItemStack, independent of
     * what the entity currently holds. Empty string when not a readable gun.
     */
    public static String getGunId(ItemStack stack) {
        if (stack == null || stack.isEmpty()) return "";
        if (sbwLoaded && com.stevesarmy.compat.sbw.SbwCompat.isGun(stack)) {
            ResourceLocation rl = net.minecraftforge.registries.ForgeRegistries.ITEMS.getKey(stack.getItem());
            return rl != null ? rl.toString() : "";
        }
        if (vpbLoaded && VpbGunHandler.isVpbGun(stack)) {
            return VPB_HANDLER.getGunId(stack);
        }
        if (taczLoaded && isTaczGun(stack)) {
            try {
                Class<?> iGunClass = Class.forName("com.tacz.guns.api.item.IGun");
                Method getIGunOrNull = iGunClass.getMethod("getIGunOrNull", ItemStack.class);
                Object iGun = getIGunOrNull.invoke(null, stack);
                if (iGun == null) return "";
                Method getGunIdMethod = iGunClass.getMethod("getGunId", ItemStack.class);
                Object gunId = getGunIdMethod.invoke(iGun, stack);
                return gunId != null ? gunId.toString() : "";
            } catch (Exception e) {
                return "";
            }
        }
        return "";
    }
    public static String getAmmoId(LivingEntity entity) { return handlerFor(entity).getAmmoId(entity); }
    public static int getCurrentAmmo(ItemStack gunStack) { return handlerFor(gunStack).getCurrentAmmo(gunStack); }
    public static String getAmmoId(ItemStack gunStack) { return handlerFor(gunStack).getAmmoId(gunStack); }
    public static int getAmmoCountForGun(ItemStack gunStack, ItemStack ammoStack) { return handlerFor(gunStack).getAmmoCountForGun(gunStack, ammoStack); }
    public static void lowCrouch(LivingEntity entity, boolean isLowCrouch) { handlerFor(entity).lowCrouch(entity, isLowCrouch); }
    public static boolean isLowCrouching(LivingEntity entity) { return handlerFor(entity).isLowCrouching(entity); }
    public static float[] getGunRecoil(LivingEntity entity) { return handlerFor(entity).getGunRecoil(entity); }
    public static float getCrawlRecoilMultiplier(LivingEntity entity) {
        return handlerFor(entity).getCrawlRecoilMultiplier(entity);
    }
    public static int getRPM(LivingEntity entity) { return handlerFor(entity).getRPM(entity); }
    public static float getBurstMinInterval(LivingEntity entity) { return handlerFor(entity).getBurstMinInterval(entity); }
    public static float getAimInaccuracy(LivingEntity entity) { return handlerFor(entity).getAimInaccuracy(entity); }
    /** Weapon-only ADS normalization; all unrelated live attribute modifiers remain intact. */
    public record MovementProfile(double adsNeutralAttribute, double adsRatio, boolean available) {}

    public static MovementProfile getMovementProfile(LivingEntity entity) {
        return handlerFor(entity).getMovementProfile(entity);
    }

    /** Conservative standard native dispersion estimate in degrees, added to our supplied shot envelope. */
    public static float getNativeInaccuracy(LivingEntity entity, boolean aiming) {
        return handlerFor(entity).getNativeInaccuracy(entity, aiming);
    }
    public static float getAimPitch(LivingEntity entity, Vec3 targetPosition) {
        return handlerFor(entity).getAimPitch(entity, targetPosition);
    }
    public static GunshotSignature getGunshotSignature(LivingEntity entity) {
        return handlerFor(entity).getGunshotSignature(entity);
    }
    public static String getGunTabType(LivingEntity entity) { return handlerFor(entity).getGunTabType(entity); }
    public static boolean isMachineGun(LivingEntity entity) { return handlerFor(entity).isMachineGun(entity); }

    public static boolean isSuppressiveMachineGun(LivingEntity entity) {
        String tabType = getGunTabType(entity);
        return "mg".equals(tabType) || "machine_gun".equals(tabType)
            || "lmg".equals(tabType) || "mmg".equals(tabType) || "hmg".equals(tabType);
    }

    public enum ShootResult {
        SUCCESS, NO_AMMO, COOLDOWN, NOT_GUN, NO_TARGET, OUT_OF_RANGE,
        NEED_BOLT, IS_BOLTING, IS_RELOADING, IS_DRAWING, NOT_DRAWN, 
        PATH_BLOCKED, UNKNOWN
    }

    public record GunshotSignature(boolean suppressed, int soundDistanceAdjustment) {
        public static final GunshotSignature UNSUPPRESSED = new GunshotSignature(false, 0);
    }

    public interface GunHandler {
        default void tick(LivingEntity entity) {}
        default MovementProfile getMovementProfile(LivingEntity entity) {
            return new MovementProfile(Math.max(0, entity.getAttributeValue(Attributes.MOVEMENT_SPEED)), 1, false);
        }
        default float getNativeInaccuracy(LivingEntity entity, boolean aiming) {
            float known = getAimInaccuracy(entity);
            return Float.isFinite(known) ? Math.max(aiming ? 0 : 6, known) : 6;
        }
        boolean hasGun(LivingEntity entity);
        ShootResult shoot(LivingEntity shooter, LivingEntity target);
        ShootResult shootWithDeviation(LivingEntity shooter, ExposureCalculator.AimPointResult aimPoint, float pitchDeviation, float yawDeviation);
        ShootResult shootAtPosition(LivingEntity shooter, Vec3 targetPosition);
        boolean canReload(LivingEntity entity);
        void reload(LivingEntity entity);
        void refillMagazine(LivingEntity entity);
        void cancelReload(LivingEntity entity);
        void bolt(LivingEntity entity);
        void aim(LivingEntity entity, boolean isAiming);
        boolean isBolting(LivingEntity entity);
        boolean isReloading(LivingEntity entity);
        float getAimProgress(LivingEntity entity);
        long getShootCoolDown(LivingEntity entity);
        boolean isDrawing(LivingEntity entity);
        double getEffectiveRange(LivingEntity entity);
        Optional<ItemStack> getGunStack(LivingEntity entity);
        void initialData(LivingEntity entity);
        void draw(LivingEntity entity);
        int getMagazineSize(LivingEntity entity);
        int getCurrentAmmo(LivingEntity entity);
        boolean hasAmmoInBarrel(LivingEntity entity);
        boolean isManualBolt(LivingEntity entity);
        boolean useInventoryAmmo(LivingEntity entity);
        String getGunId(LivingEntity entity);
        String getAmmoId(LivingEntity entity);
        int getCurrentAmmo(ItemStack gunStack);
        String getAmmoId(ItemStack gunStack);
        int getAmmoCountForGun(ItemStack gunStack, ItemStack ammoStack);
        void lowCrouch(LivingEntity entity, boolean isLowCrouch);
        boolean isLowCrouching(LivingEntity entity);
        float[] getGunRecoil(LivingEntity entity);
        /**
         * TaCZ's per-gun {@code crawl_recoil_multiplier} (1.0 = no reduction):
         * the recoil the gun actually kicks with while low-crouching. TaCZ
         * applies it to the real kick via {@link #lowCrouch}; the aim model
         * mirrors it through here so crawling gunners are not charged the
         * standing recoil penalty.
         */
        default float getCrawlRecoilMultiplier(LivingEntity entity) { return 1.0f; }
        int getRPM(LivingEntity entity);
        float getBurstMinInterval(LivingEntity entity);
        float getAimInaccuracy(LivingEntity entity);
        float getAimPitch(LivingEntity entity, Vec3 targetPosition);
        GunshotSignature getGunshotSignature(LivingEntity entity);
        String getGunTabType(LivingEntity entity);
        boolean isMachineGun(LivingEntity entity);
    }

    private static class CompositeGunHandler implements GunHandler {
        private static GunHandler forEntity(LivingEntity entity) {
            if (entity == null) return FALLBACK_HANDLER;
            ItemStack held = entity.getMainHandItem();
            if (sbwLoaded && com.stevesarmy.compat.sbw.SbwCompat.isGun(held)) return sbwHandler;
            if (VpbGunHandler.isVpbGun(held)) return VPB_HANDLER;
            if (isTaczGun(held)) return TACZ_HANDLER;
            return FALLBACK_HANDLER;
        }

        private static GunHandler forStack(ItemStack stack) {
            if (stack == null || stack.isEmpty()) return FALLBACK_HANDLER;
            if (sbwLoaded && com.stevesarmy.compat.sbw.SbwCompat.isGun(stack)) return sbwHandler;
            if (VpbGunHandler.isVpbGun(stack)) return VPB_HANDLER;
            if (isTaczGun(stack)) return TACZ_HANDLER;
            return FALLBACK_HANDLER;
        }

        @Override public boolean hasGun(LivingEntity entity) { return forEntity(entity).hasGun(entity); }
        @Override public MovementProfile getMovementProfile(LivingEntity entity) { return forEntity(entity).getMovementProfile(entity); }
        @Override public float getNativeInaccuracy(LivingEntity entity, boolean aiming) { return forEntity(entity).getNativeInaccuracy(entity, aiming); }
        @Override public ShootResult shoot(LivingEntity shooter, LivingEntity target) { return forEntity(shooter).shoot(shooter, target); }
        @Override public ShootResult shootWithDeviation(LivingEntity shooter, ExposureCalculator.AimPointResult aimPoint, float pitchDeviation, float yawDeviation) { return forEntity(shooter).shootWithDeviation(shooter, aimPoint, pitchDeviation, yawDeviation); }
        @Override public ShootResult shootAtPosition(LivingEntity shooter, Vec3 targetPosition) { return forEntity(shooter).shootAtPosition(shooter, targetPosition); }
        @Override public boolean canReload(LivingEntity entity) { return forEntity(entity).canReload(entity); }
        @Override public void reload(LivingEntity entity) { forEntity(entity).reload(entity); }
        @Override public void refillMagazine(LivingEntity entity) { forEntity(entity).refillMagazine(entity); }
        @Override public void cancelReload(LivingEntity entity) { forEntity(entity).cancelReload(entity); }
        @Override public void bolt(LivingEntity entity) { forEntity(entity).bolt(entity); }
        @Override public void aim(LivingEntity entity, boolean isAiming) { forEntity(entity).aim(entity, isAiming); }
        @Override public boolean isBolting(LivingEntity entity) { return forEntity(entity).isBolting(entity); }
        @Override public boolean isReloading(LivingEntity entity) { return forEntity(entity).isReloading(entity); }
        @Override public float getAimProgress(LivingEntity entity) { return forEntity(entity).getAimProgress(entity); }
        @Override public long getShootCoolDown(LivingEntity entity) { return forEntity(entity).getShootCoolDown(entity); }
        @Override public boolean isDrawing(LivingEntity entity) { return forEntity(entity).isDrawing(entity); }
        @Override public double getEffectiveRange(LivingEntity entity) { return forEntity(entity).getEffectiveRange(entity); }
        @Override public Optional<ItemStack> getGunStack(LivingEntity entity) { return forEntity(entity).getGunStack(entity); }
        @Override public void initialData(LivingEntity entity) { forEntity(entity).initialData(entity); }
        @Override public void draw(LivingEntity entity) { forEntity(entity).draw(entity); }
        @Override public int getMagazineSize(LivingEntity entity) { return forEntity(entity).getMagazineSize(entity); }
        @Override public int getCurrentAmmo(LivingEntity entity) { return forEntity(entity).getCurrentAmmo(entity); }
        @Override public boolean hasAmmoInBarrel(LivingEntity entity) { return forEntity(entity).hasAmmoInBarrel(entity); }
        @Override public boolean isManualBolt(LivingEntity entity) { return forEntity(entity).isManualBolt(entity); }
        @Override public boolean useInventoryAmmo(LivingEntity entity) { return forEntity(entity).useInventoryAmmo(entity); }
        @Override public String getGunId(LivingEntity entity) { return forEntity(entity).getGunId(entity); }
        @Override public String getAmmoId(LivingEntity entity) { return forEntity(entity).getAmmoId(entity); }
        @Override public int getCurrentAmmo(ItemStack gunStack) { return forStack(gunStack).getCurrentAmmo(gunStack); }
        @Override public String getAmmoId(ItemStack gunStack) { return forStack(gunStack).getAmmoId(gunStack); }
        @Override public int getAmmoCountForGun(ItemStack gunStack, ItemStack ammoStack) { return forStack(gunStack).getAmmoCountForGun(gunStack, ammoStack); }
        @Override public void lowCrouch(LivingEntity entity, boolean isLowCrouch) { forEntity(entity).lowCrouch(entity, isLowCrouch); }
        @Override public boolean isLowCrouching(LivingEntity entity) { return forEntity(entity).isLowCrouching(entity); }
        @Override public float[] getGunRecoil(LivingEntity entity) { return forEntity(entity).getGunRecoil(entity); }
        @Override public float getCrawlRecoilMultiplier(LivingEntity entity) { return forEntity(entity).getCrawlRecoilMultiplier(entity); }
        @Override public int getRPM(LivingEntity entity) { return forEntity(entity).getRPM(entity); }
        @Override public float getBurstMinInterval(LivingEntity entity) { return forEntity(entity).getBurstMinInterval(entity); }
        @Override public float getAimInaccuracy(LivingEntity entity) { return forEntity(entity).getAimInaccuracy(entity); }
        @Override public float getAimPitch(LivingEntity entity, Vec3 targetPosition) { return forEntity(entity).getAimPitch(entity, targetPosition); }
        @Override public GunshotSignature getGunshotSignature(LivingEntity entity) { return forEntity(entity).getGunshotSignature(entity); }
        @Override public String getGunTabType(LivingEntity entity) { return forEntity(entity).getGunTabType(entity); }
        @Override public boolean isMachineGun(LivingEntity entity) { return forEntity(entity).isMachineGun(entity); }
    }

    private static class FallbackGunHandler implements GunHandler {
        @Override public boolean hasGun(LivingEntity entity) { return false; }
        @Override public ShootResult shoot(LivingEntity shooter, LivingEntity target) { return ShootResult.NOT_GUN; }
        @Override public ShootResult shootWithDeviation(LivingEntity shooter, ExposureCalculator.AimPointResult aimPoint, float pitchDeviation, float yawDeviation) { return ShootResult.NOT_GUN; }
        @Override public ShootResult shootAtPosition(LivingEntity shooter, Vec3 targetPosition) { return ShootResult.NOT_GUN; }
        @Override public boolean canReload(LivingEntity entity) { return false; }
        @Override public void reload(LivingEntity entity) {}
        @Override public void refillMagazine(LivingEntity entity) {}
        @Override public void cancelReload(LivingEntity entity) {}
        @Override public void bolt(LivingEntity entity) {}
        @Override public void aim(LivingEntity entity, boolean isAiming) {}
        @Override public boolean isBolting(LivingEntity entity) { return false; }
        @Override public boolean isReloading(LivingEntity entity) { return false; }
        @Override public float getAimProgress(LivingEntity entity) { return 0; }
        @Override public long getShootCoolDown(LivingEntity entity) { return 0; }
        @Override public boolean isDrawing(LivingEntity entity) { return false; }
        @Override public double getEffectiveRange(LivingEntity entity) { return 3.0; }
        @Override public Optional<ItemStack> getGunStack(LivingEntity entity) { return Optional.empty(); }
        @Override public void initialData(LivingEntity entity) {}
        @Override public void draw(LivingEntity entity) {}
        @Override public int getMagazineSize(LivingEntity entity) { return 0; }
        @Override public int getCurrentAmmo(LivingEntity entity) { return 0; }
        @Override public boolean hasAmmoInBarrel(LivingEntity entity) { return false; }
        @Override public boolean isManualBolt(LivingEntity entity) { return false; }
        @Override public boolean useInventoryAmmo(LivingEntity entity) { return false; }
        @Override public String getGunId(LivingEntity entity) { return ""; }
        @Override public String getAmmoId(LivingEntity entity) { return ""; }
        @Override public int getCurrentAmmo(ItemStack gunStack) { return 0; }
        @Override public String getAmmoId(ItemStack gunStack) { return ""; }
        @Override public int getAmmoCountForGun(ItemStack gunStack, ItemStack ammoStack) { return 0; }
        @Override public void lowCrouch(LivingEntity entity, boolean isLowCrouch) {}
        @Override public boolean isLowCrouching(LivingEntity entity) { return false; }
        @Override public float[] getGunRecoil(LivingEntity entity) { return new float[]{0.5f, 0.25f}; }
        @Override public int getRPM(LivingEntity entity) { return 600; }
        @Override public float getBurstMinInterval(LivingEntity entity) { return 0.8f; }
        @Override public float getAimInaccuracy(LivingEntity entity) { return 0.15f; }
        @Override public float getAimPitch(LivingEntity entity, Vec3 targetPosition) {
            Vec3 origin = entity.getEyePosition();
            Vec3 toTarget = targetPosition.subtract(origin);
            double horizontalDistance = Math.sqrt(toTarget.x * toTarget.x + toTarget.z * toTarget.z);
            return (float) -Math.toDegrees(Math.atan2(toTarget.y, horizontalDistance));
        }
        @Override public GunshotSignature getGunshotSignature(LivingEntity entity) { return GunshotSignature.UNSUPPRESSED; }
        @Override public String getGunTabType(LivingEntity entity) { return "rifle"; }
        @Override public boolean isMachineGun(LivingEntity entity) { return false; }
    }

    private static class ReflectionGunHandler implements GunHandler {
        private static final UUID EXTRA_MOVEMENT_ID = UUID.fromString("4D5696AE-A7C5-C59C-80E9-2A2DC8373C46");

        private Object cachedProperty(LivingEntity entity, String modifierClass) throws ReflectiveOperationException {
            Class<?> operatorType = Class.forName("com.tacz.guns.api.entity.IGunOperator");
            Object operator = operatorType.getMethod("fromLivingEntity", LivingEntity.class).invoke(null, entity);
            Object cache = operatorType.getMethod("getCacheProperty").invoke(operator);
            if (cache == null) return null;
            String id = (String) Class.forName("com.tacz.guns.resource.modifier.custom." + modifierClass)
                .getField("ID").get(null);
            return cache.getClass().getMethod("getCache", String.class).invoke(cache, id);
        }

        @Override
        public MovementProfile getMovementProfile(LivingEntity entity) {
            double live = Math.max(0, entity.getAttributeValue(Attributes.MOVEMENT_SPEED));
            if (!hasGun(entity)) return new MovementProfile(live, 1, false);
            try {
                Object profile = cachedProperty(entity, "ExtraMovementModifier");
                if (profile == null) return new MovementProfile(live, 1, false);
                double baseFactor = 1 + ((Number) profile.getClass().getMethod("getBaseMultiplier").invoke(profile)).doubleValue();
                double aimFactor = 1 + ((Number) profile.getClass().getMethod("getAimMultiplier").invoke(profile)).doubleValue();
                if (!Double.isFinite(baseFactor) || !Double.isFinite(aimFactor) || baseFactor <= 0 || aimFactor < 0)
                    return new MovementProfile(live, 1, false);
                // TaCZ reload replaces its ADS/base modifier. Do not reinterpret a reload as aiming.
                if (isReloading(entity)) return new MovementProfile(live, 1, true);
                var attribute = entity.getAttribute(Attributes.MOVEMENT_SPEED);
                AttributeModifier installed = attribute == null ? null : attribute.getModifier(EXTRA_MOVEMENT_ID);
                double neutral = live;
                if (installed != null) {
                    double installedFactor = 1 + installed.getAmount();
                    if (installed.getOperation() != AttributeModifier.Operation.MULTIPLY_TOTAL
                        || !Double.isFinite(installedFactor) || installedFactor <= 0
                        || (Math.abs(installedFactor - baseFactor) > 1e-5 && Math.abs(installedFactor - aimFactor) > 1e-5))
                        return new MovementProfile(live, 1, false);
                    neutral = live / installedFactor * baseFactor;
                }
                return new MovementProfile(neutral, aimFactor / baseFactor, true);
            } catch (ReflectiveOperationException | RuntimeException e) {
                return new MovementProfile(live, 1, false);
            }
        }

        @Override
        public float getNativeInaccuracy(LivingEntity entity, boolean aiming) {
            try {
                Object cached = cachedProperty(entity, "InaccuracyModifier");
                if (cached instanceof Map<?, ?> values) {
                    float support = 0;
                    boolean found = false;
                    // A transitioning ADS weapon can still use its movement dispersion.
                    boolean settledAds = aiming && getAimProgress(entity) >= 0.99f;
                    for (var entry : values.entrySet()) {
                        boolean aimEntry = "AIM".equals(String.valueOf(entry.getKey()));
                        if (settledAds != aimEntry && (settledAds || !aiming)) continue;
                        if (entry.getValue() instanceof Number n && Float.isFinite(n.floatValue())) {
                            support = Math.max(support, Math.abs(n.floatValue()));
                            found = true;
                        }
                    }
                    // A generous standard-dispersion envelope; arbitrary Lua calcSpread
                    // scripts are not exposed by this cache and can choose a different model.
                    if (found) return Math.min(89, support * 2);
                }
            } catch (ReflectiveOperationException | RuntimeException ignored) {}
            return GunHandler.super.getNativeInaccuracy(entity, aiming);
        }
        private static final double DEFAULT_GUN_RANGE = 50.0;

        @Override
        public boolean hasGun(LivingEntity entity) {
            try {
                Class<?> gunInterface = Class.forName("com.tacz.guns.api.item.IGun");
                Method mainHandHoldGun = gunInterface.getMethod("mainHandHoldGun", LivingEntity.class);
                return (boolean) mainHandHoldGun.invoke(null, entity);
            } catch (Exception e) {
                return false;
            }
        }

        @Override
        public ShootResult shoot(LivingEntity shooter, LivingEntity target) {
            if (!hasGun(shooter)) return ShootResult.NOT_GUN;
            if (target == null || !target.isAlive()) return ShootResult.NO_TARGET;

            try {
                Class<?> gunOperatorClass = Class.forName("com.tacz.guns.api.entity.IGunOperator");
                Method fromLivingEntity = gunOperatorClass.getMethod("fromLivingEntity", LivingEntity.class);
                Object gunOperator = fromLivingEntity.invoke(null, shooter);

                double dx = target.getX() - shooter.getX();
                double dz = target.getZ() - shooter.getZ();
                float pitch = getAimPitch(shooter, target.getEyePosition());
                float yaw = (float) Math.toDegrees(Math.atan2(dz, dx)) - 90.0F;

                Method shootMethod = gunOperatorClass.getMethod("shoot", java.util.function.Supplier.class, java.util.function.Supplier.class);
                Object result = shootMethod.invoke(gunOperator, 
                    (java.util.function.Supplier<Float>) () -> pitch, 
                    (java.util.function.Supplier<Float>) () -> yaw);
                
                String resultName = result.toString();
                play3pSound(shooter, resultName);
                return mapShootResult(resultName);
            } catch (Exception e) {
                StevesArmyMod.LOGGER.warn("[TaCZ] Shoot failed", e);
                return ShootResult.UNKNOWN;
            }
        }

        @Override
        public ShootResult shootWithDeviation(LivingEntity shooter, ExposureCalculator.AimPointResult aimPoint, float pitchDeviation, float yawDeviation) {
            if (!hasGun(shooter)) return ShootResult.NOT_GUN;
            if (!aimPoint.canShoot()) return ShootResult.PATH_BLOCKED;

            try {
                Class<?> gunOperatorClass = Class.forName("com.tacz.guns.api.entity.IGunOperator");
                Method fromLivingEntity = gunOperatorClass.getMethod("fromLivingEntity", LivingEntity.class);
                Object gunOperator = fromLivingEntity.invoke(null, shooter);

                Vec3 aimPosition = aimPoint.position;
                double dx = aimPosition.x - shooter.getX();
                double dz = aimPosition.z - shooter.getZ();
                float basePitch = getAimPitch(shooter, aimPosition);
                float baseYaw = (float) Math.toDegrees(Math.atan2(dz, dx)) - 90.0F;

                float pitch = basePitch + pitchDeviation;
                float yaw = baseYaw + yawDeviation;

                Method shootMethod = gunOperatorClass.getMethod("shoot", java.util.function.Supplier.class, java.util.function.Supplier.class);
                Object result = shootMethod.invoke(gunOperator, 
                    (java.util.function.Supplier<Float>) () -> pitch, 
                    (java.util.function.Supplier<Float>) () -> yaw);

                String resultName = result.toString();
                play3pSound(shooter, resultName);
                return mapShootResult(resultName);
            } catch (Exception e) {
                StevesArmyMod.LOGGER.warn("[TaCZ] Shoot with deviation failed", e);
                return ShootResult.UNKNOWN;
            }
        }

        @Override
        public ShootResult shootAtPosition(LivingEntity shooter, Vec3 targetPosition) {
            if (!hasGun(shooter)) return ShootResult.NOT_GUN;

            try {
                Class<?> gunOperatorClass = Class.forName("com.tacz.guns.api.entity.IGunOperator");
                Method fromLivingEntity = gunOperatorClass.getMethod("fromLivingEntity", LivingEntity.class);
                Object gunOperator = fromLivingEntity.invoke(null, shooter);

                double dx = targetPosition.x - shooter.getX();
                double dz = targetPosition.z - shooter.getZ();
                float pitch = getAimPitch(shooter, targetPosition);
                float yaw = (float) Math.toDegrees(Math.atan2(dz, dx)) - 90.0F;

                Method shootMethod = gunOperatorClass.getMethod("shoot", java.util.function.Supplier.class, java.util.function.Supplier.class);
                Object result = shootMethod.invoke(gunOperator, 
                    (java.util.function.Supplier<Float>) () -> pitch, 
                    (java.util.function.Supplier<Float>) () -> yaw);

                return mapShootResult(result.toString());
            } catch (Exception e) {
                StevesArmyMod.LOGGER.warn("[TaCZ] shootAtPosition failed: " + e.getMessage());
                return ShootResult.UNKNOWN;
            }
        }

        private ShootResult mapShootResult(String resultName) {
            if (resultName.contains("SUCCESS")) return ShootResult.SUCCESS;
            if (resultName.contains("NO_AMMO")) return ShootResult.NO_AMMO;
            if (resultName.contains("COOL_DOWN")) return ShootResult.COOLDOWN;
            if (resultName.contains("NEED_BOLT")) return ShootResult.NEED_BOLT;
            if (resultName.contains("IS_BOLTING")) return ShootResult.IS_BOLTING;
            if (resultName.contains("IS_RELOADING")) return ShootResult.IS_RELOADING;
            if (resultName.contains("IS_DRAWING")) return ShootResult.IS_DRAWING;
            if (resultName.contains("NOT_DRAW")) return ShootResult.NOT_DRAWN;
            if (resultName.contains("NOT_GUN")) return ShootResult.NOT_GUN;
            return ShootResult.UNKNOWN;
        }

        private static final ResourceLocation DEFAULT_GUN_DISPLAY = ResourceLocation.tryParse("tacz:default");
        private static final int SOUND_DISTANCE = 64;

        private void play3pSound(LivingEntity shooter, String resultName) {
            if (!resultName.contains("SUCCESS")) return;
            if (shooter instanceof net.minecraft.world.entity.player.Player) return;
            try {
                Class<?> soundManagerClass = Class.forName("com.tacz.guns.sound.SoundManager");
                Method sendSound = soundManagerClass.getMethod("sendSoundToNearby", 
                    LivingEntity.class, int.class, ResourceLocation.class, ResourceLocation.class,
                    String.class, float.class, float.class);

                ResourceLocation gunId = ResourceLocation.tryParse(getGunId(shooter));
                ResourceLocation ammoId = ResourceLocation.tryParse(getAmmoId(shooter));

                if (gunId != null && ammoId != null) {
                    sendSound.invoke(null, shooter, SOUND_DISTANCE, gunId, DEFAULT_GUN_DISPLAY,
                        "shoot_3p", 1.0f, 1.0f);
                }
            } catch (Exception e) {
                StevesArmyMod.LOGGER.debug("[TaCZ] Failed to send 3p sound: {}", e.getMessage());
            }
        }

        @Override
        public boolean canReload(LivingEntity entity) {
            if (!hasGun(entity)) return false;
            try {
                ItemStack gunStack = entity.getMainHandItem();
                Class<?> iGunClass = Class.forName("com.tacz.guns.api.item.IGun");
                Method getIGunOrNull = iGunClass.getMethod("getIGunOrNull", ItemStack.class);
                Object iGun = getIGunOrNull.invoke(null, gunStack);
                if (iGun == null) return false;

                Class<?> abstractGunItemClass = Class.forName("com.tacz.guns.api.item.gun.AbstractGunItem");
                if (!abstractGunItemClass.isInstance(iGun)) return false;
                Method canReloadMethod = abstractGunItemClass.getMethod("canReload", LivingEntity.class, ItemStack.class);
                return (boolean) canReloadMethod.invoke(iGun, entity, gunStack);
            } catch (Exception e) {
                return false;
            }
        }

        @Override
        public void reload(LivingEntity entity) {
            if (!hasGun(entity)) return;
            try {
                Class<?> gunOperatorClass = Class.forName("com.tacz.guns.api.entity.IGunOperator");
                Method fromLivingEntity = gunOperatorClass.getMethod("fromLivingEntity", LivingEntity.class);
                Object gunOperator = fromLivingEntity.invoke(null, entity);
                Method reloadMethod = gunOperatorClass.getMethod("reload");
                reloadMethod.invoke(gunOperator);
            } catch (Exception e) {
                StevesArmyMod.LOGGER.warn("[TaCZ] Reload failed", e);
            }
        }

        @Override
        public float getAimPitch(LivingEntity shooter, Vec3 targetPosition) {
            float fallback = straightPitch(shooter, targetPosition);
            BallisticProfile profile = getBallisticProfile(shooter);
            if (profile == null) return fallback;

            Vec3 origin = shooter.getEyePosition();
            double dx = targetPosition.x - origin.x;
            double dz = targetPosition.z - origin.z;
            double horizontalDistance = Math.sqrt(dx * dx + dz * dz);
            if (horizontalDistance < 0.05 || !Double.isFinite(horizontalDistance)) return fallback;

            double verticalDistance = targetPosition.y - origin.y;
            Double elevation = solveBallisticElevation(horizontalDistance, verticalDistance, profile);
            if (elevation == null) return fallback;

            float pitch = (float) -Math.toDegrees(elevation);
            return Float.isFinite(pitch) ? pitch : fallback;
        }

        private BallisticProfile getBallisticProfile(LivingEntity entity) {
            try {
                Class<?> gunOperatorClass = Class.forName("com.tacz.guns.api.entity.IGunOperator");
                Object gunOperator = gunOperatorClass
                    .getMethod("fromLivingEntity", LivingEntity.class)
                    .invoke(null, entity);
                Object cacheProperty = gunOperatorClass.getMethod("getCacheProperty").invoke(gunOperator);
                Method getCache = cacheProperty.getClass().getMethod("getCache", String.class);
                Object cachedSpeed = getCache.invoke(cacheProperty, "ammo_speed");
                if (!(cachedSpeed instanceof Number speedValue)) return null;

                Class<?> gunInterface = Class.forName("com.tacz.guns.api.item.IGun");
                Object gun = gunInterface.getMethod("getIGunOrNull", ItemStack.class)
                    .invoke(null, entity.getMainHandItem());
                if (gun == null) return null;

                ResourceLocation gunId = (ResourceLocation) gunInterface
                    .getMethod("getGunId", ItemStack.class)
                    .invoke(gun, entity.getMainHandItem());
                Class<?> timelessApi = Class.forName("com.tacz.guns.api.TimelessAPI");
                Object indexOptional = timelessApi.getMethod("getCommonGunIndex", ResourceLocation.class)
                    .invoke(null, gunId);
                if (!(indexOptional instanceof Optional<?> optional) || optional.isEmpty()) return null;

                Object gunIndex = optional.get();
                Object gunData = gunIndex.getClass().getMethod("getGunData").invoke(gunIndex);
                Object bulletData = gunData.getClass().getMethod("getBulletData").invoke(gunData);
                double gravity = ((Number) bulletData.getClass().getMethod("getGravity").invoke(bulletData)).doubleValue();
                double friction = ((Number) bulletData.getClass().getMethod("getFriction").invoke(bulletData)).doubleValue();
                double globalSpeedModifier = getGlobalBulletSpeedModifier();
                double speed = speedValue.doubleValue() * globalSpeedModifier / 20.0;

                if (!Double.isFinite(speed) || !Double.isFinite(gravity) || !Double.isFinite(friction)
                    || speed <= 0.0 || gravity < 0.0 || friction < 0.0 || friction >= 1.0) {
                    return null;
                }
                return new BallisticProfile(speed, gravity, friction);
            } catch (Exception e) {
                return null;
            }
        }

        private double getGlobalBulletSpeedModifier() {
            try {
                Class<?> ammoConfig = Class.forName("com.tacz.guns.config.common.AmmoConfig");
                Field field = ammoConfig.getField("GLOBAL_BULLET_SPEED_MODIFIER");
                Object configValue = field.get(null);
                Object value = configValue.getClass().getMethod("get").invoke(configValue);
                if (value instanceof Number number && number.doubleValue() > 0.0) {
                    return number.doubleValue();
                }
            } catch (Exception ignored) {}
            return 2.0;
        }

        private static Double solveBallisticElevation(double horizontalDistance, double verticalDistance, BallisticProfile profile) {
            final double minimumElevation = Math.toRadians(-30.0);
            final double maximumElevation = Math.toRadians(75.0);
            final int samples = 42;
            double previousAngle = minimumElevation;
            double previousError = trajectoryHeightAtDistance(horizontalDistance, previousAngle, profile) - verticalDistance;
            if (!Double.isFinite(previousError)) return null;

            for (int i = 1; i <= samples; i++) {
                double angle = minimumElevation + (maximumElevation - minimumElevation) * i / samples;
                double error = trajectoryHeightAtDistance(horizontalDistance, angle, profile) - verticalDistance;
                if (!Double.isFinite(error)) {
                    previousAngle = angle;
                    previousError = error;
                    continue;
                }
                if (Math.abs(error) < 0.02) return angle;
                if (previousError * error < 0.0) {
                    double low = previousAngle;
                    double high = angle;
                    double lowError = previousError;
                    for (int iteration = 0; iteration < 18; iteration++) {
                        double midpoint = (low + high) * 0.5;
                        double midpointError = trajectoryHeightAtDistance(horizontalDistance, midpoint, profile) - verticalDistance;
                        if (!Double.isFinite(midpointError)) return null;
                        if (Math.abs(midpointError) < 0.005) return midpoint;
                        if (lowError * midpointError <= 0.0) {
                            high = midpoint;
                        } else {
                            low = midpoint;
                            lowError = midpointError;
                        }
                    }
                    return (low + high) * 0.5;
                }
                previousAngle = angle;
                previousError = error;
            }
            return null;
        }

        private static double trajectoryHeightAtDistance(double horizontalDistance, double elevation, BallisticProfile profile) {
            double horizontalVelocity = profile.speed * Math.cos(elevation);
            double verticalVelocity = profile.speed * Math.sin(elevation);
            double horizontalPosition = 0.0;
            double verticalPosition = 0.0;
            double previousHorizontal = 0.0;
            double previousVertical = 0.0;
            double frictionMultiplier = 1.0 - profile.friction;

            for (int tick = 0; tick < 200; tick++) {
                previousHorizontal = horizontalPosition;
                previousVertical = verticalPosition;
                horizontalPosition += horizontalVelocity;
                verticalPosition += verticalVelocity;
                if (horizontalPosition >= horizontalDistance) {
                    double fraction = (horizontalDistance - previousHorizontal)
                        / Math.max(horizontalPosition - previousHorizontal, 1.0E-9);
                    return previousVertical + (verticalPosition - previousVertical) * fraction;
                }
                horizontalVelocity *= frictionMultiplier;
                verticalVelocity = verticalVelocity * frictionMultiplier - profile.gravity;
            }
            return Double.NaN;
        }

        private static float straightPitch(LivingEntity shooter, Vec3 targetPosition) {
            Vec3 origin = shooter.getEyePosition();
            double dx = targetPosition.x - origin.x;
            double dy = targetPosition.y - origin.y;
            double dz = targetPosition.z - origin.z;
            double horizontalDistance = Math.sqrt(dx * dx + dz * dz);
            return (float) -Math.toDegrees(Math.atan2(dy, horizontalDistance));
        }

        private record BallisticProfile(double speed, double gravity, double friction) {}

        @Override
        public void refillMagazine(LivingEntity entity) {
            if (!hasGun(entity)) return;
            try {
                ItemStack gunStack = entity.getMainHandItem();
                Class<?> iGunClass = Class.forName("com.tacz.guns.api.item.IGun");
                Method getIGunOrNull = iGunClass.getMethod("getIGunOrNull", ItemStack.class);
                Object iGun = getIGunOrNull.invoke(null, gunStack);
                if (iGun == null) return;

                int magazineSize = getMagazineSize(entity);
                iGunClass.getMethod("setCurrentAmmoCount", ItemStack.class, int.class)
                    .invoke(iGun, gunStack, magazineSize);
                iGunClass.getMethod("setBulletInBarrel", ItemStack.class, boolean.class)
                    .invoke(iGun, gunStack, true);
            } catch (Exception e) {
                StevesArmyMod.LOGGER.warn("[TaCZ] Failed to refill respawned gun: {}", e.toString());
            }
        }

        @Override
        public void cancelReload(LivingEntity entity) {
            if (!hasGun(entity)) return;
            try {
                Class<?> gunOperatorClass = Class.forName("com.tacz.guns.api.entity.IGunOperator");
                Method fromLivingEntity = gunOperatorClass.getMethod("fromLivingEntity", LivingEntity.class);
                Object gunOperator = fromLivingEntity.invoke(null, entity);
                gunOperatorClass.getMethod("cancelReload").invoke(gunOperator);
            } catch (Exception e) {
                StevesArmyMod.LOGGER.warn("[TaCZ] Failed to cancel reload: {}", e.toString());
            }
        }

        @Override
        public void bolt(LivingEntity entity) {
            if (!hasGun(entity)) return;
            try {
                Class<?> gunOperatorClass = Class.forName("com.tacz.guns.api.entity.IGunOperator");
                Method fromLivingEntity = gunOperatorClass.getMethod("fromLivingEntity", LivingEntity.class);
                Object gunOperator = fromLivingEntity.invoke(null, entity);
                Method boltMethod = gunOperatorClass.getMethod("bolt");
                boltMethod.invoke(gunOperator);
            } catch (Exception e) {
                StevesArmyMod.LOGGER.debug("[TaCZ] Bolt failed: {}", e.getMessage());
            }
        }

        @Override
        public void aim(LivingEntity entity, boolean isAiming) {
            if (!hasGun(entity)) return;
            try {
                Class<?> gunOperatorClass = Class.forName("com.tacz.guns.api.entity.IGunOperator");
                Method fromLivingEntity = gunOperatorClass.getMethod("fromLivingEntity", LivingEntity.class);
                Object gunOperator = fromLivingEntity.invoke(null, entity);
                Method aimMethod = gunOperatorClass.getMethod("aim", boolean.class);
                aimMethod.invoke(gunOperator, isAiming);
            } catch (Exception e) {
                StevesArmyMod.LOGGER.debug("[TaCZ] Aim failed: {}", e.getMessage());
            }
        }

        @Override
        public boolean isBolting(LivingEntity entity) {
            try {
                Class<?> gunOperatorClass = Class.forName("com.tacz.guns.api.entity.IGunOperator");
                Method fromLivingEntity = gunOperatorClass.getMethod("fromLivingEntity", LivingEntity.class);
                Object gunOperator = fromLivingEntity.invoke(null, entity);
                Method isBoltingMethod = gunOperatorClass.getMethod("getSynIsBolting");
                return (boolean) isBoltingMethod.invoke(gunOperator);
            } catch (Exception e) {
                return false;
            }
        }

        @Override
        public boolean isReloading(LivingEntity entity) {
            try {
                Class<?> gunOperatorClass = Class.forName("com.tacz.guns.api.entity.IGunOperator");
                Method fromLivingEntity = gunOperatorClass.getMethod("fromLivingEntity", LivingEntity.class);
                Object gunOperator = fromLivingEntity.invoke(null, entity);
                Method getReloadState = gunOperatorClass.getMethod("getSynReloadState");
                Object reloadState = getReloadState.invoke(gunOperator);
                Class<?> reloadStateClass = Class.forName("com.tacz.guns.api.entity.ReloadState");
                Method getStateType = reloadStateClass.getMethod("getStateType");
                Object stateType = getStateType.invoke(reloadState);
                
                Method isReloadingMethod = stateType.getClass().getMethod("isReloading");
                return (boolean) isReloadingMethod.invoke(stateType);
            } catch (Exception e) {
                return false;
            }
        }

        @Override
        public float getAimProgress(LivingEntity entity) {
            try {
                Class<?> gunOperatorClass = Class.forName("com.tacz.guns.api.entity.IGunOperator");
                Method fromLivingEntity = gunOperatorClass.getMethod("fromLivingEntity", LivingEntity.class);
                Object gunOperator = fromLivingEntity.invoke(null, entity);
                Method getAimProgress = gunOperatorClass.getMethod("getSynAimingProgress");
                return (float) getAimProgress.invoke(gunOperator);
            } catch (Exception e) {
                return 0f;
            }
        }

        @Override
        public long getShootCoolDown(LivingEntity entity) {
            try {
                Class<?> gunOperatorClass = Class.forName("com.tacz.guns.api.entity.IGunOperator");
                Method fromLivingEntity = gunOperatorClass.getMethod("fromLivingEntity", LivingEntity.class);
                Object gunOperator = fromLivingEntity.invoke(null, entity);
                Method getCooldown = gunOperatorClass.getMethod("getSynShootCoolDown");
                return (long) getCooldown.invoke(gunOperator);
            } catch (Exception e) {
                return 0L;
            }
        }

        @Override
        public boolean isDrawing(LivingEntity entity) {
            try {
                Class<?> gunOperatorClass = Class.forName("com.tacz.guns.api.entity.IGunOperator");
                Method fromLivingEntity = gunOperatorClass.getMethod("fromLivingEntity", LivingEntity.class);
                Object gunOperator = fromLivingEntity.invoke(null, entity);
                Method getDrawCoolDown = gunOperatorClass.getMethod("getSynDrawCoolDown");
                long drawCooldown = (long) getDrawCoolDown.invoke(gunOperator);
                return drawCooldown > 0;
            } catch (Exception e) {
                return false;
            }
        }

        @Override
        public double getEffectiveRange(LivingEntity entity) {
            try {
                Class<?> gunOperatorClass = Class.forName("com.tacz.guns.api.entity.IGunOperator");
                Method fromLivingEntity = gunOperatorClass.getMethod("fromLivingEntity", LivingEntity.class);
                Object gunOperator = fromLivingEntity.invoke(null, entity);
                
                Method getCacheProperty = gunOperatorClass.getMethod("getCacheProperty");
                Object cacheProperty = getCacheProperty.invoke(gunOperator);
                
                Method getCache = cacheProperty.getClass().getMethod("getCache", String.class);
                Float effectiveRange = (Float) getCache.invoke(cacheProperty, "effective_range");
                
                if (effectiveRange != null && effectiveRange > 0) {
                    return effectiveRange.doubleValue();
                }
            } catch (Exception e) {
                StevesArmyMod.LOGGER.debug("[TaCZ] Failed to get effective range: {}", e.getMessage());
            }
            return DEFAULT_GUN_RANGE;
        }

        @Override
        public GunshotSignature getGunshotSignature(LivingEntity entity) {
            try {
                Class<?> gunOperatorClass = Class.forName("com.tacz.guns.api.entity.IGunOperator");
                Method fromLivingEntity = gunOperatorClass.getMethod("fromLivingEntity", LivingEntity.class);
                Object gunOperator = fromLivingEntity.invoke(null, entity);
                Method getCacheProperty = gunOperatorClass.getMethod("getCacheProperty");
                Object cacheProperty = getCacheProperty.invoke(gunOperator);
                Method getCache = cacheProperty.getClass().getMethod("getCache", String.class);
                Object silence = getCache.invoke(cacheProperty, "silence");
                if (silence == null) return GunshotSignature.UNSUPPRESSED;

                Object distanceValue = silence.getClass().getMethod("left").invoke(silence);
                Object useSilenceSoundValue = silence.getClass().getMethod("right").invoke(silence);
                int distanceAdjustment = distanceValue instanceof Number number ? number.intValue() : 0;
                boolean useSilenceSound = Boolean.TRUE.equals(useSilenceSoundValue);
                return new GunshotSignature(distanceAdjustment < 0 || useSilenceSound, distanceAdjustment);
            } catch (Exception ignored) {
                return GunshotSignature.UNSUPPRESSED;
            }
        }

        @Override
        public Optional<ItemStack> getGunStack(LivingEntity entity) {
            ItemStack mainHand = entity.getMainHandItem();
            if (hasGun(entity)) return Optional.of(mainHand);
            return Optional.empty();
        }

        @Override
        public void initialData(LivingEntity entity) {
            try {
                Class<?> gunOperatorClass = Class.forName("com.tacz.guns.api.entity.IGunOperator");
                Method fromLivingEntity = gunOperatorClass.getMethod("fromLivingEntity", LivingEntity.class);
                Object gunOperator = fromLivingEntity.invoke(null, entity);
                Method initialDataMethod = gunOperatorClass.getMethod("initialData");
                initialDataMethod.invoke(gunOperator);
            } catch (Exception e) {
                StevesArmyMod.LOGGER.debug("[TaCZ] initialData failed: {}", e.getMessage());
            }
        }

        @Override
        public void draw(LivingEntity entity) {
            if (!hasGun(entity)) return;
            if (isReloading(entity)) return;
            try {
                Class<?> gunOperatorClass = Class.forName("com.tacz.guns.api.entity.IGunOperator");
                Method fromLivingEntity = gunOperatorClass.getMethod("fromLivingEntity", LivingEntity.class);
                Object gunOperator = fromLivingEntity.invoke(null, entity);
                Method drawMethod = gunOperatorClass.getMethod("draw", java.util.function.Supplier.class);
                drawMethod.invoke(gunOperator, (java.util.function.Supplier<ItemStack>) () -> entity.getMainHandItem());
            } catch (Exception e) {
                StevesArmyMod.LOGGER.debug("[TaCZ] Draw failed: {}", e.getMessage());
            }
        }

        @Override
        public int getMagazineSize(LivingEntity entity) {
            try {
                ItemStack gunStack = entity.getMainHandItem();
                Class<?> iGunClass = Class.forName("com.tacz.guns.api.item.IGun");
                Method getIGunOrNull = iGunClass.getMethod("getIGunOrNull", ItemStack.class);
                Object iGun = getIGunOrNull.invoke(null, gunStack);
                if (iGun == null) return 30;

                try {
                    Method getMaxAmmo = iGunClass.getMethod("getMaxAmmoCount", ItemStack.class);
                    Object max = getMaxAmmo.invoke(iGun, gunStack);
                    if (max instanceof Number num && num.intValue() > 0) {
                        return num.intValue();
                    }
                } catch (NoSuchMethodException ignored) {}
                
                Method getGunId = iGunClass.getMethod("getGunId", ItemStack.class);
                Object gunId = getGunId.invoke(iGun, gunStack);
                
                Class<?> timelessApiClass = Class.forName("com.tacz.guns.api.TimelessAPI");
                Method getCommonGunIndex = timelessApiClass.getMethod("getCommonGunIndex", ResourceLocation.class);
                Object indexOpt = getCommonGunIndex.invoke(null, gunId);
                
                if (indexOpt instanceof Optional<?> opt && opt.isPresent()) {
                    Object gunIndex = opt.get();
                    Method getGunData = gunIndex.getClass().getMethod("getGunData");
                    Object gunData = getGunData.invoke(gunIndex);
                    Method getAmmoAmountMethod = gunData.getClass().getMethod("getAmmoAmount");
                    return (int) getAmmoAmountMethod.invoke(gunData);
                }
            } catch (Exception e) {
                StevesArmyMod.LOGGER.debug("[TaCZ] Failed to get magazine size: {}", e.getMessage());
            }
            return 30;
        }

        @Override
        public int getCurrentAmmo(LivingEntity entity) {
            return getCurrentAmmoFromStack(entity.getMainHandItem());
        }

        @Override
        public boolean hasAmmoInBarrel(LivingEntity entity) {
            try {
                ItemStack gunStack = entity.getMainHandItem();
                Class<?> iGunClass = Class.forName("com.tacz.guns.api.item.IGun");
                Method getIGunOrNull = iGunClass.getMethod("getIGunOrNull", ItemStack.class);
                Object iGun = getIGunOrNull.invoke(null, gunStack);
                if (iGun == null) return false;
                Method hasAmmoInBarrelMethod = iGunClass.getMethod("hasAmmoInBarrel", ItemStack.class);
                return (boolean) hasAmmoInBarrelMethod.invoke(iGun, gunStack);
            } catch (Exception e) {
                return false;
            }
        }

        @Override
        public boolean isManualBolt(LivingEntity entity) {
            try {
                ItemStack gunStack = entity.getMainHandItem();
                Class<?> iGunClass = Class.forName("com.tacz.guns.api.item.IGun");
                Method getIGunOrNull = iGunClass.getMethod("getIGunOrNull", ItemStack.class);
                Object iGun = getIGunOrNull.invoke(null, gunStack);
                if (iGun == null) return false;
                
                Method getGunId = iGunClass.getMethod("getGunId", ItemStack.class);
                Object gunId = getGunId.invoke(iGun, gunStack);
                
                Class<?> timelessApiClass = Class.forName("com.tacz.guns.api.TimelessAPI");
                Method getCommonGunIndex = timelessApiClass.getMethod("getCommonGunIndex", ResourceLocation.class);
                Object indexOpt = getCommonGunIndex.invoke(null, gunId);
                
                if (indexOpt instanceof Optional<?> opt && opt.isPresent()) {
                    Object gunIndex = opt.get();
                    Method getGunData = gunIndex.getClass().getMethod("getGunData");
                    Object gunData = getGunData.invoke(gunIndex);
                    Method getBolt = gunData.getClass().getMethod("getBolt");
                    Object bolt = getBolt.invoke(gunData);
                    return bolt.toString().equals("MANUAL_ACTION");
                }
            } catch (Exception ignored) {}
            return false;
        }

        @Override
        public boolean useInventoryAmmo(LivingEntity entity) {
            try {
                ItemStack gunStack = entity.getMainHandItem();
                Class<?> iGunClass = Class.forName("com.tacz.guns.api.item.IGun");
                Method getIGunOrNull = iGunClass.getMethod("getIGunOrNull", ItemStack.class);
                Object iGun = getIGunOrNull.invoke(null, gunStack);
                if (iGun == null) return false;
                
                Method getGunId = iGunClass.getMethod("getGunId", ItemStack.class);
                Object gunId = getGunId.invoke(iGun, gunStack);
                
                Class<?> timelessApiClass = Class.forName("com.tacz.guns.api.TimelessAPI");
                Method getCommonGunIndex = timelessApiClass.getMethod("getCommonGunIndex", ResourceLocation.class);
                Object indexOpt = getCommonGunIndex.invoke(null, gunId);
                
                if (indexOpt instanceof Optional<?> opt && opt.isPresent()) {
                    Object gunIndex = opt.get();
                    Method getGunData = gunIndex.getClass().getMethod("getGunData");
                    Object gunData = getGunData.invoke(gunIndex);
                    Method getUseInventoryAmmoMethod = gunData.getClass().getMethod("getUseInventoryAmmo");
                    return (boolean) getUseInventoryAmmoMethod.invoke(gunData);
                }
            } catch (Exception ignored) {}
            return false;
        }

        @Override
        public String getGunId(LivingEntity entity) {
            try {
                ItemStack gunStack = entity.getMainHandItem();
                Class<?> iGunClass = Class.forName("com.tacz.guns.api.item.IGun");
                Method getIGunOrNull = iGunClass.getMethod("getIGunOrNull", ItemStack.class);
                Object iGun = getIGunOrNull.invoke(null, gunStack);
                if (iGun == null) return "";
                Method getGunIdMethod = iGunClass.getMethod("getGunId", ItemStack.class);
                Object gunId = getGunIdMethod.invoke(iGun, gunStack);
                return gunId != null ? gunId.toString() : "";
            } catch (Exception e) {
                return "";
            }
        }

        @Override
        public String getAmmoId(LivingEntity entity) {
            return getAmmoIdFromStack(entity.getMainHandItem());
        }

        private int getCurrentAmmoFromStack(ItemStack gunStack) {
            try {
                Class<?> iGunClass = Class.forName("com.tacz.guns.api.item.IGun");
                Method getIGunOrNull = iGunClass.getMethod("getIGunOrNull", ItemStack.class);
                Object iGun = getIGunOrNull.invoke(null, gunStack);
                if (iGun == null) return 0;
                Method getCurrentAmmoCount = iGunClass.getMethod("getCurrentAmmoCount", ItemStack.class);
                return (int) getCurrentAmmoCount.invoke(iGun, gunStack);
            } catch (Exception e) {
                return 0;
            }
        }

        private String getAmmoIdFromStack(ItemStack gunStack) {
            try {
                Class<?> iGunClass = Class.forName("com.tacz.guns.api.item.IGun");
                Method getIGunOrNull = iGunClass.getMethod("getIGunOrNull", ItemStack.class);
                Object iGun = getIGunOrNull.invoke(null, gunStack);
                if (iGun == null) return "";

                Method getGunId = iGunClass.getMethod("getGunId", ItemStack.class);
                Object gunId = getGunId.invoke(iGun, gunStack);

                Class<?> timelessApiClass = Class.forName("com.tacz.guns.api.TimelessAPI");
                Method getCommonGunIndex = timelessApiClass.getMethod("getCommonGunIndex", ResourceLocation.class);
                Object indexOpt = getCommonGunIndex.invoke(null, gunId);

                if (indexOpt instanceof Optional<?> opt && opt.isPresent()) {
                    Object gunIndex = opt.get();
                    Method getGunData = gunIndex.getClass().getMethod("getGunData");
                    Object gunData = getGunData.invoke(gunIndex);
                    Method getAmmoIdMethod = gunData.getClass().getMethod("getAmmoId");
                    Object ammoId = getAmmoIdMethod.invoke(gunData);
                    return ammoId != null ? ammoId.toString() : "";
                }
            } catch (Exception ignored) {}
            return "";
        }

        @Override
        public int getCurrentAmmo(ItemStack gunStack) {
            return getCurrentAmmoFromStack(gunStack);
        }

        @Override
        public String getAmmoId(ItemStack gunStack) {
            return getAmmoIdFromStack(gunStack);
        }

        @Override
        public int getAmmoCountForGun(ItemStack gunStack, ItemStack ammoStack) {
            if (gunStack.isEmpty() || ammoStack.isEmpty()) return 0;
            try {
                Class<?> iAmmoClass = Class.forName("com.tacz.guns.api.item.IAmmo");
                Method getIAmmoOrNull = iAmmoClass.getMethod("getIAmmoOrNull", ItemStack.class);
                Object iAmmo = getIAmmoOrNull.invoke(null, ammoStack);
                if (iAmmo != null) {
                    Method isAmmoOfGun = iAmmoClass.getMethod("isAmmoOfGun", ItemStack.class, ItemStack.class);
                    if ((boolean) isAmmoOfGun.invoke(iAmmo, gunStack, ammoStack)) {
                        return ammoStack.getCount();
                    }
                }

                Class<?> iAmmoBoxClass = Class.forName("com.tacz.guns.api.item.IAmmoBox");
                if (!iAmmoBoxClass.isInstance(ammoStack.getItem())) return 0;

                Method isAmmoBoxOfGun = iAmmoBoxClass.getMethod("isAmmoBoxOfGun", ItemStack.class, ItemStack.class);
                if (!(boolean) isAmmoBoxOfGun.invoke(ammoStack.getItem(), gunStack, ammoStack)) return 0;

                Method isCreative = iAmmoBoxClass.getMethod("isCreative", ItemStack.class);
                Method isAllTypeCreative = iAmmoBoxClass.getMethod("isAllTypeCreative", ItemStack.class);
                if ((boolean) isCreative.invoke(ammoStack.getItem(), ammoStack)
                    || (boolean) isAllTypeCreative.invoke(ammoStack.getItem(), ammoStack)) {
                    return 9999;
                }

                Method getAmmoCount = iAmmoBoxClass.getMethod("getAmmoCount", ItemStack.class);
                return (int) getAmmoCount.invoke(ammoStack.getItem(), ammoStack);
            } catch (Exception e) {
                return 0;
            }
        }

        @Override
        public void lowCrouch(LivingEntity entity, boolean isLowCrouch) {
            if (entity instanceof SoldierEntity soldier) {
                soldier.setLowCrouching(isLowCrouch);
            } else {
                if (isLowCrouch) {
                    entity.setPose(net.minecraft.world.entity.Pose.SWIMMING);
                } else if (entity.getPose() == net.minecraft.world.entity.Pose.SWIMMING) {
                    entity.setPose(net.minecraft.world.entity.Pose.STANDING);
                }
            }
        }
        
        @Override
        public boolean isLowCrouching(LivingEntity entity) {
            if (entity instanceof SoldierEntity soldier) {
                return soldier.isLowCrouching();
            }
            return entity.getPose() == net.minecraft.world.entity.Pose.SWIMMING && !entity.isInWater();
        }

        @Override
        public float[] getGunRecoil(LivingEntity entity) {
            try {
                Class<?> gunOperatorClass = Class.forName("com.tacz.guns.api.entity.IGunOperator");
                Method fromLivingEntity = gunOperatorClass.getMethod("fromLivingEntity", LivingEntity.class);
                Object gunOperator = fromLivingEntity.invoke(null, entity);
                Method getCacheProperty = gunOperatorClass.getMethod("getCacheProperty");
                Object cacheProperty = getCacheProperty.invoke(gunOperator);
                Method getCache = cacheProperty.getClass().getMethod("getCache", String.class);
                Object cachedRecoil = getCache.invoke(cacheProperty, "recoil");

                if (cachedRecoil != null) {
                    try {
                        Method getPitch = cachedRecoil.getClass().getMethod("getPitch");
                        Object[] pitchFrames = (Object[]) getPitch.invoke(cachedRecoil);
                        Method getYaw = cachedRecoil.getClass().getMethod("getYaw");
                        Object[] yawFrames = (Object[]) getYaw.invoke(cachedRecoil);
                        Method getValue = pitchFrames[0].getClass().getMethod("getValue");
                        float[] pitchValues = (float[]) getValue.invoke(pitchFrames[0]);
                        float[] yawValues = (float[]) getValue.invoke(yawFrames[0]);
                        float vertical = Math.abs(pitchValues.length > 0 ? pitchValues[0] : 0);
                        float horizontal = Math.abs(yawValues.length > 0 ? yawValues[0] : 0);
                        return new float[]{vertical, horizontal};
                    } catch (Throwable ignored) {}
                }

                ItemStack gunStack = entity.getMainHandItem();
                Class<?> iGunClass = Class.forName("com.tacz.guns.api.item.IGun");
                Method getIGunOrNull = iGunClass.getMethod("getIGunOrNull", ItemStack.class);
                Object iGun = getIGunOrNull.invoke(null, gunStack);
                if (iGun == null) return new float[]{0.5f, 0.25f};

                Method getGunId = iGunClass.getMethod("getGunId", ItemStack.class);
                Object gunId = getGunId.invoke(iGun, gunStack);

                Class<?> timelessApiClass = Class.forName("com.tacz.guns.api.TimelessAPI");
                Method getCommonGunIndex = timelessApiClass.getMethod("getCommonGunIndex", ResourceLocation.class);
                Object indexOpt = getCommonGunIndex.invoke(null, gunId);

                if (indexOpt instanceof Optional<?> opt && opt.isPresent()) {
                    Object gunIndex = opt.get();
                    Method getGunData = gunIndex.getClass().getMethod("getGunData");
                    Object gunData = getGunData.invoke(gunIndex);

                    Method getRecoilMethod = gunData.getClass().getMethod("getRecoil");
                    Object recoil = getRecoilMethod.invoke(gunData);

                    Method getPitch = recoil.getClass().getMethod("getPitch");
                    Object[] pitchFrames = (Object[]) getPitch.invoke(recoil);

                    Method getYaw = recoil.getClass().getMethod("getYaw");
                    Object[] yawFrames = (Object[]) getYaw.invoke(recoil);

                    Method getValue = pitchFrames[0].getClass().getMethod("getValue");
                    float[] pitchValues = (float[]) getValue.invoke(pitchFrames[0]);
                    float[] yawValues = (float[]) getValue.invoke(yawFrames[0]);

                    float vertical = Math.abs(pitchValues.length > 0 ? pitchValues[0] : 0);
                    float horizontal = Math.abs(yawValues.length > 0 ? yawValues[0] : 0);

                    return new float[]{vertical, horizontal};
                }
            } catch (Exception e) {
                StevesArmyMod.LOGGER.debug("[TaCZ] Failed to get gun recoil: {}", e.getMessage());
            }
            return new float[]{0.5f, 0.25f};
        }

        @Override
        public float getCrawlRecoilMultiplier(LivingEntity entity) {
            try {
                ItemStack gunStack = entity.getMainHandItem();
                Class<?> iGunClass = Class.forName("com.tacz.guns.api.item.IGun");
                Method getIGunOrNull = iGunClass.getMethod("getIGunOrNull", ItemStack.class);
                Object iGun = getIGunOrNull.invoke(null, gunStack);
                if (iGun == null) return 1.0f;

                Method getGunId = iGunClass.getMethod("getGunId", ItemStack.class);
                Object gunId = getGunId.invoke(iGun, gunStack);

                Class<?> timelessApiClass = Class.forName("com.tacz.guns.api.TimelessAPI");
                Method getCommonGunIndex = timelessApiClass.getMethod("getCommonGunIndex", ResourceLocation.class);
                Object indexOpt = getCommonGunIndex.invoke(null, gunId);

                if (indexOpt instanceof Optional<?> opt && opt.isPresent()) {
                    Object gunIndex = opt.get();
                    Method getGunData = gunIndex.getClass().getMethod("getGunData");
                    Object gunData = getGunData.invoke(gunIndex);
                    Method getCrawlRecoilMultiplier = gunData.getClass().getMethod("getCrawlRecoilMultiplier");
                    Object multiplier = getCrawlRecoilMultiplier.invoke(gunData);
                    if (multiplier instanceof Float f) return f;
                }
            } catch (Exception e) {
                StevesArmyMod.LOGGER.debug("[TaCZ] Failed to get crawl recoil multiplier: {}", e.getMessage());
            }
            return 1.0f;
        }

        @Override
        public int getRPM(LivingEntity entity) {
            try {
                Class<?> gunOperatorClass = Class.forName("com.tacz.guns.api.entity.IGunOperator");
                Method fromLivingEntity = gunOperatorClass.getMethod("fromLivingEntity", LivingEntity.class);
                Object gunOperator = fromLivingEntity.invoke(null, entity);
                Method getCacheProperty = gunOperatorClass.getMethod("getCacheProperty");
                Object cacheProperty = getCacheProperty.invoke(gunOperator);
                Method getCache = cacheProperty.getClass().getMethod("getCache", String.class);
                Object cachedRpm = getCache.invoke(cacheProperty, "rpm");
                if (cachedRpm instanceof Number num && num.intValue() > 0) {
                    return num.intValue();
                }

                ItemStack gunStack = entity.getMainHandItem();
                Class<?> iGunClass = Class.forName("com.tacz.guns.api.item.IGun");
                Method getIGunOrNull = iGunClass.getMethod("getIGunOrNull", ItemStack.class);
                Object iGun = getIGunOrNull.invoke(null, gunStack);
                if (iGun == null) return 600;

                Method getGunId = iGunClass.getMethod("getGunId", ItemStack.class);
                Object gunId = getGunId.invoke(iGun, gunStack);

                Class<?> timelessApiClass = Class.forName("com.tacz.guns.api.TimelessAPI");
                Method getCommonGunIndex = timelessApiClass.getMethod("getCommonGunIndex", ResourceLocation.class);
                Object indexOpt = getCommonGunIndex.invoke(null, gunId);

                if (indexOpt instanceof Optional<?> opt && opt.isPresent()) {
                    Object gunIndex = opt.get();
                    Method getGunData = gunIndex.getClass().getMethod("getGunData");
                    Object gunData = getGunData.invoke(gunIndex);
                    
                    Method getRpmMethod = gunData.getClass().getMethod("getRpm");
                    return (int) getRpmMethod.invoke(gunData);
                }
            } catch (Exception e) {
                StevesArmyMod.LOGGER.debug("[TaCZ] Failed to get RPM: {}", e.getMessage());
            }
            return 600;
        }

        @Override
        public float getBurstMinInterval(LivingEntity entity) {
            try {
                ItemStack gunStack = entity.getMainHandItem();
                Class<?> iGunClass = Class.forName("com.tacz.guns.api.item.IGun");
                Method getIGunOrNull = iGunClass.getMethod("getIGunOrNull", ItemStack.class);
                Object iGun = getIGunOrNull.invoke(null, gunStack);
                if (iGun == null) return 0.8f;

                Method getGunId = iGunClass.getMethod("getGunId", ItemStack.class);
                Object gunId = getGunId.invoke(iGun, gunStack);

                Class<?> timelessApiClass = Class.forName("com.tacz.guns.api.TimelessAPI");
                Method getCommonGunIndex = timelessApiClass.getMethod("getCommonGunIndex", ResourceLocation.class);
                Object indexOpt = getCommonGunIndex.invoke(null, gunId);

                if (indexOpt instanceof Optional<?> opt && opt.isPresent()) {
                    Object gunIndex = opt.get();
                    Method getGunData = gunIndex.getClass().getMethod("getGunData");
                    Object gunData = getGunData.invoke(gunIndex);
                    
                    Method getBurstDataMethod = gunData.getClass().getMethod("getBurstData");
                    Object burstData = getBurstDataMethod.invoke(gunData);
                    
                    if (burstData != null) {
                        Method getMinIntervalMethod = burstData.getClass().getMethod("getMinInterval");
                        return (float) getMinIntervalMethod.invoke(burstData);
                    }
                }
            } catch (Exception e) {
                StevesArmyMod.LOGGER.debug("[TaCZ] Failed to get burst min interval: {}", e.getMessage());
            }
            return 0.8f;
        }

        @Override
        public float getAimInaccuracy(LivingEntity entity) {
            try {
                Class<?> gunOperatorClass = Class.forName("com.tacz.guns.api.entity.IGunOperator");
                Method fromLivingEntity = gunOperatorClass.getMethod("fromLivingEntity", LivingEntity.class);
                Object gunOperator = fromLivingEntity.invoke(null, entity);
                Method getCacheProperty = gunOperatorClass.getMethod("getCacheProperty");
                Object cacheProperty = getCacheProperty.invoke(gunOperator);
                Method getCache = cacheProperty.getClass().getMethod("getCache", String.class);
                Object cachedInaccuracy = getCache.invoke(cacheProperty, "inaccuracy");
                if (cachedInaccuracy instanceof Number num) {
                    return num.floatValue();
                }

                ItemStack gunStack = entity.getMainHandItem();
                Class<?> iGunClass = Class.forName("com.tacz.guns.api.item.IGun");
                Method getIGunOrNull = iGunClass.getMethod("getIGunOrNull", ItemStack.class);
                Object iGun = getIGunOrNull.invoke(null, gunStack);
                if (iGun == null) return 0.15f;

                Method getGunId = iGunClass.getMethod("getGunId", ItemStack.class);
                Object gunId = getGunId.invoke(iGun, gunStack);

                Class<?> timelessApiClass = Class.forName("com.tacz.guns.api.TimelessAPI");
                Method getCommonGunIndex = timelessApiClass.getMethod("getCommonGunIndex", ResourceLocation.class);
                Object indexOpt = getCommonGunIndex.invoke(null, gunId);

                if (indexOpt instanceof Optional<?> opt && opt.isPresent()) {
                    Object gunIndex = opt.get();
                    Method getGunData = gunIndex.getClass().getMethod("getGunData");
                    Object gunData = getGunData.invoke(gunIndex);
                    
                    Method getInaccuracyMethod = gunData.getClass().getMethod("getInaccuracy");
                    Object inaccuracy = getInaccuracyMethod.invoke(gunData);
                    
                    if (inaccuracy != null) {
                        Method getAimMethod = inaccuracy.getClass().getMethod("getAim");
                        return (float) getAimMethod.invoke(inaccuracy);
                    }
                }
            } catch (Exception e) {
                StevesArmyMod.LOGGER.debug("[TaCZ] Failed to get aim inaccuracy: {}", e.getMessage());
            }
            return 0.15f;
        }
        
        @Override
        public String getGunTabType(LivingEntity entity) {
            try {
                ItemStack gunStack = entity.getMainHandItem();
                Class<?> iGunClass = Class.forName("com.tacz.guns.api.item.IGun");
                Method getIGunOrNull = iGunClass.getMethod("getIGunOrNull", ItemStack.class);
                Object iGun = getIGunOrNull.invoke(null, gunStack);
                if (iGun == null) return "rifle";
                
                Method getGunId = iGunClass.getMethod("getGunId", ItemStack.class);
                Object gunId = getGunId.invoke(iGun, gunStack);
                
                Class<?> timelessApiClass = Class.forName("com.tacz.guns.api.TimelessAPI");
                Method getCommonGunIndex = timelessApiClass.getMethod("getCommonGunIndex", ResourceLocation.class);
                Object indexOpt = getCommonGunIndex.invoke(null, gunId);
                
                if (indexOpt instanceof Optional<?> opt && opt.isPresent()) {
                    Object gunIndex = opt.get();
                    try {
                        Method getTypeMethod = gunIndex.getClass().getMethod("getType");
                        Object type = getTypeMethod.invoke(gunIndex);
                        if (type != null) {
                            return type.toString().toLowerCase(java.util.Locale.ROOT);
                        }
                    } catch (NoSuchMethodException e1) {
                        try {
                            Method getTabTypeMethod = gunIndex.getClass().getMethod("getTabType");
                            Object tabType = getTabTypeMethod.invoke(gunIndex);
                            if (tabType != null) {
                                return tabType.toString().toLowerCase(java.util.Locale.ROOT);
                            }
                        } catch (NoSuchMethodException e2) {
                            return detectMachineGunHeuristic(entity);
                        }
                    }
                }
            } catch (Exception ignored) {}
            return "rifle";
        }
        
        private String detectMachineGunHeuristic(LivingEntity entity) {
            int magSize = getMagazineSize(entity);
            int rpm = getRPM(entity);
            boolean isBolt = isManualBolt(entity);
            if (!isBolt && magSize >= 30 && rpm >= 500) {
                return "machine_gun";
            }
            return "rifle";
        }
        
        @Override
        public boolean isMachineGun(LivingEntity entity) {
            String tabType = getGunTabType(entity);
            return "machine_gun".equals(tabType) || "mg".equals(tabType) || "lmg".equals(tabType) || 
                   "mmg".equals(tabType) || "hmg".equals(tabType) || "smg".equals(tabType);
        }
    }
}
