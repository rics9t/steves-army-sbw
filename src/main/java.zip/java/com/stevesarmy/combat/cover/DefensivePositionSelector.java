package com.stevesarmy.combat.cover;

import com.stevesarmy.combat.ThreatAwareness;
import com.stevesarmy.combat.VisibilityRay;
import com.stevesarmy.StevesArmyMod;
import com.stevesarmy.debug.DiagnosticLogManager;
import com.stevesarmy.entity.SoldierEntity;
import com.stevesarmy.entity.ai.CombatGoalController;
import com.stevesarmy.squad.SquadCoverContext;
import net.minecraft.core.BlockPos;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.Vec3;

import javax.annotation.Nullable;
import java.util.Comparator;
import java.util.List;
import java.util.Optional;

/** Chooses a separated prone lane only when no usable protective cover is available. */
public final class DefensivePositionSelector {
    private DefensivePositionSelector() { }

    public static Optional<DefensivePositionCandidate.ProneFiringCandidate> selectProne(
        SoldierEntity soldier, @Nullable LivingEntity target, ThreatAwareness threats,
        List<CoverFinder.ScoredCover> covers, SquadCoverContext squadCtx,
        ExactPathValidationBudget pathBudget, @Nullable Vec3 threatDirection) {
        CombatGoalController combatGoal = soldier.getCombatGoal();
        if (combatGoal == null) {
            trace(soldier, "no_combat_goal", "none", 0, 0, 0, 0, false, 0, -1.0D, false);
            return Optional.empty();
        }
        AimSource aimSource = resolveAimSource(soldier, target, threats, combatGoal);
        if (aimSource == null) {
            trace(soldier, "no_threat", "none", 0, 0, 0, 0, false, 0, -1.0D, false);
            return Optional.empty();
        }
        String safetyReason = getSafetyGateReason(soldier, target, combatGoal);
        if (safetyReason != null) {
            trace(soldier, safetyReason, aimSource.label(), 0, 0, 0, 0, false, 0, -1.0D, false);
            return Optional.empty();
        }
        CoverFinder coverFinder = new CoverFinder(soldier.level());
        boolean hasProtectionContext = threatDirection != null && threatDirection.lengthSqr() >= 0.001D
            || coverFinder.hasPrimaryThreat(soldier, threatDirection);
        boolean usablePhysicalCover = hasProtectionContext && covers.stream()
            .anyMatch(sc -> !squadCtx.violatesDefensiveSpacing(sc.cover.getPosition())
                && CoverReservationManager.isAvailableFor(sc.cover.getPosition(), soldier)
                && coverFinder.isPrimaryThreatProtected(sc.cover, soldier, threatDirection));
        if (usablePhysicalCover) {
            trace(soldier, "protective_cover", aimSource.label(), 0, 0, 0, 0, true, 0, -1.0D, false);
            return Optional.empty();
        }

        if (DiagnosticLogManager.isCoverLoggingEnabled()) {
            StevesArmyMod.LOGGER.info("[ProneAim] soldier={} pos={} aim={} target={}", soldier.getId(),
                soldier.position(), aimSource.aimPoint(), target != null ? target.getName().getString() : "none");
        }
        ScanResult scan = scanProneLanes(soldier, aimSource.aimPoint(), soldier.level(), pathBudget, squadCtx);
        SpacingResult spacing = selectWithSpacing(scan.candidates(), squadCtx, soldier);
        trace(soldier, spacing.candidate() != null ? "selected" : "no_valid_lane", aimSource.label(), scan.terrainValid(),
            scan.proneLos(), scan.pathValid(), scan.pathRejected(), false, squadCtx.getDefensivePositions().size(),
            spacing.closestPeerDistance(), spacing.usedFallback());
        return Optional.ofNullable(spacing.candidate());
    }

    @Nullable
    private static String getSafetyGateReason(SoldierEntity soldier, @Nullable LivingEntity target,
                                               CombatGoalController combatGoal) {
        if (soldier.hasValidPingMoveTarget()) return "movement_command";
        // Prone is the fallback when no directionally protective cover is
        // usable. Suppression does not veto it: remaining upright in open
        // ground is less safe than taking a validated prone firing lane.
        if (target != null && target.isAlive() && soldier.distanceTo(target) <= 10.0) return "close_target";
        for (LivingEntity other : combatGoal.getPotentialTargets()) {
            if (other != target && other.isAlive() && !soldier.isFriendlyTo(other)
                && soldier.distanceTo(other) <= 10.0) return "nearby_threat";
        }
        return null;
    }

    @Nullable
    private static AimSource resolveAimSource(SoldierEntity soldier, @Nullable LivingEntity target, ThreatAwareness threats,
                                              CombatGoalController combatGoal) {
        if (target != null && target.isAlive()) {
            return new AimSource(combatGoal.getProneFiringAimPoint(target), "target");
        }
        BlockPos threatPos = threats.getPrimaryThreatPosition();
        if (threatPos != null) {
            return new AimSource(new Vec3(threatPos.getX() + .5, threatPos.getY() + 1.35, threatPos.getZ() + .5),
                "threat_memory");
        }
        CoverProtectionContext protection = combatGoal.resolveCoverProtectionContext();
        if (protection.threatPosition() != null) {
            return new AimSource(protection.threatPosition().add(0.0D, 1.0D, 0.0D), "last_seen");
        }
        Vec3 direction = protection.awarenessDirection();
        if (direction != null && direction.horizontalDistanceSqr() > 0.001D) {
            Vec3 horizontal = new Vec3(direction.x, 0.0D, direction.z).normalize();
            return new AimSource(soldier.position().add(horizontal.scale(32.0D)).add(0.0D, 1.35D, 0.0D),
                "awareness_direction");
        }
        return null;
    }

    private static ScanResult scanProneLanes(
        SoldierEntity soldier, Vec3 aimPoint, Level level, ExactPathValidationBudget pathBudget,
        SquadCoverContext squadCtx) {
        java.util.ArrayList<DefensivePositionCandidate.ProneFiringCandidate> eligible = new java.util.ArrayList<>();
        BlockPos origin = soldier.blockPosition();
        int terrainValid = 0;
        int proneLos = 0;
        int pathValid = 0;
        int pathRejected = 0;
        for (int y = -1; y <= 1; y++) for (int x = -5; x <= 5; x++) for (int z = -5; z <= 5; z++) {
            if (x * x + z * z > 25) continue;
            BlockPos pos = origin.offset(x, y, z);
            if (!isProneTerrainValid(level, pos)) continue;
            terrainValid++;
            Vec3 eye = new Vec3(pos.getX() + .5, pos.getY() + .45, pos.getZ() + .5);
            VisibilityRay.Result visibility = VisibilityRay.trace(level, eye, aimPoint, soldier);
            boolean firingLaneAccepted = visibility.hasContact();
            if (!firingLaneAccepted) continue;
            proneLos++;
            boolean currentPosition = pos.equals(origin);
            Vec3 spacingPosition = currentPosition ? soldier.position()
                : new Vec3(pos.getX() + 0.5D, pos.getY(), pos.getZ() + 0.5D);
            if (squadCtx.violatesDefensiveSpacing(spacingPosition)) continue;
            float distance = (float)Math.sqrt(x * x + z * z);
            float protection = adjacentCover(level, pos) ? .15f : 0.0f;
            eligible.add(new DefensivePositionCandidate.ProneFiringCandidate(pos, 1.0f, protection,
                0.0f, distance / 5.0f, currentPosition ? "prone-current-lane" : "prone-lane"));
        }

        // Spend the bounded path budget on the nearest separated lanes first.
        // Stable coordinates break equal-distance ties across repeated searches.
        eligible.sort(Comparator
            .comparingDouble(DefensivePositionCandidate.ProneFiringCandidate::movementCost)
            .thenComparingInt(candidate -> candidate.destination().getX())
            .thenComparingInt(candidate -> candidate.destination().getZ())
            .thenComparingInt(candidate -> candidate.destination().getY()));
        java.util.ArrayList<DefensivePositionCandidate.ProneFiringCandidate> result = new java.util.ArrayList<>();
        for (DefensivePositionCandidate.ProneFiringCandidate candidate : eligible) {
            if (!candidate.destination().equals(origin)) {
                if (!pathBudget.tryAcquire()) break;
                net.minecraft.world.level.pathfinder.Path path =
                    soldier.getNavigation().createPath(candidate.destination(), 0);
                if (path == null || !path.canReach()) {
                    pathRejected++;
                    continue;
                }
            }
            pathValid++;
            result.add(candidate);
        }
        return new ScanResult(result, terrainValid, proneLos, pathValid, pathRejected);
    }

    private static SpacingResult selectWithSpacing(
        List<DefensivePositionCandidate.ProneFiringCandidate> candidates,
        SquadCoverContext squadCtx, SoldierEntity soldier) {
        List<DefensivePositionCandidate.ProneFiringCandidate> spaced = candidates.stream()
            .filter(candidate -> !squadCtx.violatesDefensiveSpacing(position(candidate, soldier)))
            .toList();
        Comparator<DefensivePositionCandidate.ProneFiringCandidate> ranking =
            Comparator.comparingDouble(DefensivePositionCandidate.ProneFiringCandidate::movementCost)
                .thenComparing(Comparator.comparingDouble(
                    (DefensivePositionCandidate.ProneFiringCandidate candidate) ->
                        squadCtx.nearestDefensiveDistance(position(candidate, soldier))).reversed())
                .thenComparingInt(candidate -> candidate.destination().getX())
                .thenComparingInt(candidate -> candidate.destination().getZ())
                .thenComparingInt(candidate -> candidate.destination().getY());
        // Never fall back to an unspaced lane. If every candidate conflicts
        // with a teammate, remain searching until a valid lane is available.
        DefensivePositionCandidate.ProneFiringCandidate selected = spaced.stream().min(ranking).orElse(null);
        return new SpacingResult(selected,
            selected != null ? squadCtx.nearestDefensiveDistance(position(selected, soldier)) : -1.0D, false);
    }

    private static Vec3 position(DefensivePositionCandidate.ProneFiringCandidate candidate, SoldierEntity soldier) {
        BlockPos destination = candidate.destination();
        if (destination.equals(soldier.blockPosition())) {
            return soldier.position();
        }
        return new Vec3(destination.getX() + 0.5D, destination.getY(), destination.getZ() + 0.5D);
    }

    private static void trace(SoldierEntity soldier, String reason, String threatSource, int terrainValid, int proneLos,
                              int pathValid, int pathRejected, boolean physicalCover, int peerCount,
                              double closestPeerDistance, boolean spacingFallback) {
        if (DiagnosticLogManager.isCoverLoggingEnabled()) {
            String closest = closestPeerDistance < 0.0D || !Double.isFinite(closestPeerDistance)
                ? "none" : String.format(java.util.Locale.ROOT, "%.1f", closestPeerDistance);
            StevesArmyMod.LOGGER.info("[DefensivePosition] soldier={} result={} source={} terrain={} proneLos={} paths={} pathRejected={} physicalFiringCover={} peers={} closestPeer={} spacingFallback={}",
                soldier.getId(), reason, threatSource, terrainValid, proneLos, pathValid, pathRejected, physicalCover,
                peerCount, closest, spacingFallback);
        }
    }

    private record AimSource(Vec3 aimPoint, String label) { }

    private record ScanResult(List<DefensivePositionCandidate.ProneFiringCandidate> candidates,
                              int terrainValid, int proneLos, int pathValid, int pathRejected) { }

    private record SpacingResult(@Nullable DefensivePositionCandidate.ProneFiringCandidate candidate,
                                 double closestPeerDistance, boolean usedFallback) { }

    private static boolean isProneTerrainValid(Level level, BlockPos pos) {
        return level.isLoaded(pos) && level.getBlockState(pos.below()).isSolid()
            && level.getBlockState(pos).getCollisionShape(level, pos).isEmpty()
            && level.getBlockState(pos.above()).getCollisionShape(level, pos.above()).isEmpty()
            && level.getBlockState(pos).getFluidState().isEmpty();
    }

    private static boolean adjacentCover(Level level, BlockPos pos) {
        for (net.minecraft.core.Direction d : net.minecraft.core.Direction.Plane.HORIZONTAL) {
            if (!level.getBlockState(pos.relative(d)).getCollisionShape(level, pos.relative(d)).isEmpty()) return true;
        }
        return false;
    }
}
