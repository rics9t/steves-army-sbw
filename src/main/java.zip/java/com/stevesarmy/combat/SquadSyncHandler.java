package com.stevesarmy.combat;

import com.stevesarmy.StevesArmyMod;
import com.stevesarmy.debug.PerformanceMetrics;
import com.stevesarmy.network.NetworkHandler;
import com.stevesarmy.network.AttackDebugPacket;
import com.stevesarmy.network.SquadStatusSyncPacket;
import com.stevesarmy.entity.ai.CoverGoalController;
import com.stevesarmy.entity.ai.CoverTacticalGoal;
import com.stevesarmy.entity.ai.MachineGunnerSupportGoal;
import com.stevesarmy.squad.FireTeam;
import com.stevesarmy.squad.OwnedSoldierRegistry;
import com.stevesarmy.squad.SquadActivityManager;
import com.stevesarmy.entity.SoldierEntity;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.server.level.ServerLevel;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.UUID;

@Mod.EventBusSubscriber(modid = StevesArmyMod.MODID)
public class SquadSyncHandler {
    private static int tickCounter = 0;
    private static final Set<UUID> ATTACK_DEBUG_PLAYERS = new HashSet<>();

    public static boolean toggleAttackDebug(ServerPlayer player) {
        UUID playerId = player.getUUID();
        boolean enabled;
        if (ATTACK_DEBUG_PLAYERS.remove(playerId)) {
            enabled = false;
        } else {
            ATTACK_DEBUG_PLAYERS.add(playerId);
            enabled = true;
        }
        sendAttackDebugPacket(player, enabled);
        return enabled;
    }

    private static void sendAttackDebugPacket(ServerPlayer player, boolean enabled) {
        List<AttackDebugPacket.Entry> entries = enabled
            ? createAttackDebugEntries(player)
            : List.of();
        NetworkHandler.sendTo(player, new AttackDebugPacket(enabled, entries));
    }

    private static List<AttackDebugPacket.Entry> createAttackDebugEntries(ServerPlayer player) {
        List<AttackDebugPacket.Entry> entries = new ArrayList<>();
        for (SoldierEntity soldier : player.serverLevel().getEntitiesOfClass(
                SoldierEntity.class, player.getBoundingBox().inflate(100),
                soldier -> soldier.isOwnedBy(player) && soldier.isAlive() && !soldier.isRemoved())) {
            var cover = soldier.getCoverBehaviorManager();
            var tracker = cover.getSuppressionTracker();
            CoverGoalController controller = soldier.getCoverTacticalGoal();
            CoverTacticalGoal goal;
            if (controller instanceof CoverTacticalGoal t) {
                goal = t;
            } else if (controller instanceof MachineGunnerSupportGoal mg) {
                goal = mg.getCoverController();
            } else {
                goal = null;
            }
            FireTeam fireTeam = soldier.getFireTeam();
            float fireteamLevel = com.stevesarmy.squad.FireTeamSuppressionTracker.getLevel(soldier);
            int fireteamState = com.stevesarmy.squad.FireTeamSuppressionTracker.getState(soldier).ordinal();
            entries.add(new AttackDebugPacket.Entry(
                soldier.getUUID(),
                fireTeam.getShortName(),
                fireteamLevel,
                fireteamState,
                goal == null ? 0 : goal.getAttackPhaseOrdinal(),
                goal == null ? 0.0f : goal.getAttackDwellFraction(),
                tracker.getSuppressionLevel(),
                tracker.isSuppressed(),
                tracker.isRecovered(),
                com.stevesarmy.squad.FireTeamSuppressionTracker.shouldPauseAttack(soldier),
                com.stevesarmy.squad.FireTeamSuppressionTracker.isHeavilySuppressed(soldier),
                goal != null && goal.isRecoverySafetyPeekDone(),
                goal != null && goal.isPeeking(),
                soldier.hasValidAttackTarget(),
                soldier.position(),
                goal != null && goal.isAttackHasPeekedThisCover(),
                goal != null && goal.isAttackDwellMet(),
                goal != null && goal.isPeekCompletedThisCover(),
                goal != null && goal.isAttackDwellMet() && goal.isAttackRecovered()
                    && !goal.isAttackPeeking() && !goal.isAttackFireteamPinned()
                    && !goal.isAttackHeavyHold(),
                goal == null ? 0.0f : goal.getAttackDwellElapsedMs(),
                goal == null ? 0.0f : goal.getAttackRequiredDwellMs(),
                goal == null ? 1.0f : goal.getSuppressionDwellMult(),
                goal == null ? 1.0f : goal.getGroupCohesionDwellMultValue(),
                goal == null ? null : goal.getFireteamCentroid(),
                goal == null ? 0 : goal.getAttackCoverState(),
                goal != null && goal.isCoverSearchPending(),
                goal != null && goal.isFallbackAdvanceActive(),
                goal == null ? 0 : goal.getAttackPhaseAgeMs(),
                goal == null ? Long.MAX_VALUE : goal.getLastAdvanceTriggerAgeMs(),
                com.stevesarmy.squad.FireTeamSuppressionTracker.getMemberPressure(soldier),
                com.stevesarmy.squad.FireTeamSuppressionTracker.getIncomingPressure(soldier),
                com.stevesarmy.squad.FireTeamSuppressionTracker.getFireSuperiority(soldier)));
        }
        return entries;
    }

    @SubscribeEvent
    public static void onServerTick(TickEvent.ServerTickEvent event) {
        if (event.phase == TickEvent.Phase.START) {
            PerformanceMetrics.beginTick();
            PerformanceMetrics.beginCoverPopulationTick();
            return;
        }
        if (event.phase != TickEvent.Phase.END) return;

        SquadActivityManager.tick(event.getServer());
        com.stevesarmy.squad.ClearingCoordinator.tick(event.getServer());
        com.stevesarmy.squad.FireTeamSuppressionTracker.tick(event.getServer());
        com.stevesarmy.squad.SquadMovementCoordinator.tick(event.getServer());

        // Drive each squad's danger map once per level tick. SoldierEntity used
        // to perform a manager lookup from every member tick before the map's
        // own game-time de-duplication could run.
        for (ServerLevel level : event.getServer().getAllLevels()) {
            var manager = com.stevesarmy.squad.SquadManager.get(level);
            for (var squad : manager.getAllSquads()) {
                SoldierEntity anchor = null;
                var leader = level.getEntity(squad.getLeaderId());
                if (leader instanceof SoldierEntity soldier && soldier.isAlive() && !soldier.isRemoved()) {
                    anchor = soldier;
                } else {
                    for (UUID memberId : squad.getMemberIds()) {
                        var entity = level.getEntity(memberId);
                        if (entity instanceof SoldierEntity soldier && soldier.isAlive() && !soldier.isRemoved()) {
                            anchor = soldier;
                            break;
                        }
                    }
                }
                if (anchor != null) {
                    squad.tickDangerMap(level, level.getGameTime(), anchor.position());
                }
            }
        }

        tickCounter++;
        if (tickCounter >= 20) {
            tickCounter = 0;

            OwnedSoldierRegistry registry = OwnedSoldierRegistry.get(event.getServer());
            registry.pruneGoneEntries(event.getServer());

            for (net.minecraft.server.level.ServerLevel level : event.getServer().getAllLevels()) {
                var manager = com.stevesarmy.squad.SquadManager.get(level);
                boolean intelExpired = false;
                for (var squad : manager.getAllSquads()) {
                    int before = squad.getThreatIntel().getThreatCount();
                    squad.tickIntelCleanup(level.getGameTime());
                    intelExpired |= squad.getThreatIntel().getThreatCount() != before;
                }
                if (intelExpired) manager.setDirty();
                for (var entity : level.getEntities().getAll()) {
                    if (entity instanceof SoldierEntity soldier && !soldier.level().isClientSide) {
                        if (soldier.isAlive() && !soldier.isRemoved()) {
                            registry.refresh(soldier, level);
                        } else {
                            registry.remove(soldier.getUUID());
                        }
                    }
                }
            }

            for (ServerPlayer player : event.getServer().getPlayerList().getPlayers()) {
                SquadStatusSyncPacket packet = SquadStatusSyncPacket.createForPlayer(player);
                NetworkHandler.sendTo(player, packet);
                SquadActivityManager.sync(player);
                com.stevesarmy.squad.FireTeamSuppressionTracker.syncToPlayer(player);
                if (ATTACK_DEBUG_PLAYERS.contains(player.getUUID())) {
                    sendAttackDebugPacket(player, true);
                }
            }
        }

        PerformanceMetrics.endCoverPopulationTick();
        PerformanceMetrics.endTick();
    }
}
