package com.stevesarmy.combat;

import com.stevesarmy.StevesArmyConfig;
import com.stevesarmy.StevesArmyMod;
import com.stevesarmy.compat.SbwCompat;
import com.stevesarmy.compat.TallyhoCompat;
import com.stevesarmy.compat.VS2Compat;
import com.stevesarmy.debug.DiagnosticLogManager;
import com.stevesarmy.entity.SoldierEntity;
import com.stevesarmy.entity.SoldierRole;
import com.stevesarmy.squad.SquadData;
import com.stevesarmy.squad.SquadManager;
import com.stevesarmy.squad.SquadThreatIntel;
import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;

import javax.annotation.Nullable;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Set;
import java.util.UUID;

/**
 * Periodic scan for enemy-crewed vehicles. Two detection paths feed the same
 * shared-threat-intel "hard target" record: crewed tallyho turret cameras
 * (hull MG / periscope, requires tallyho), and crewed occupancy — a ship
 * carrying enemy vehicle crew (a VEHICLE_CREW-role soldier or anyone riding a
 * seat on the hull) reads as an enemy vehicle such as an APC. Infantry merely
 * standing on a ship or dock never qualifies: the occupancy gate is crew
 * identity, never position alone. Hostility is decided with the soldier's
 * ordinary {@link SoldierEntity#isFriendlyTo} identity (owner, scoreboard
 * teams, allies), and a ship is never reported while the observer or any of
 * the observer's side's people are aboard it — our own transports and
 * boarded-friendly hulls are not rocket targets. A hostile sighting is
 * published into the
 * squad's shared threat intel as a "hard target" — small arms cannot destroy
 * it, so soldiers react by role: squads without an anti-armor gun keep their
 * distance, and squads with one designate its carrier as the armor hunter
 * while everyone else keeps the vehicle suppressed.
 *
 * Cameras may sit in shipyard space on VS2 ships, so world positions go
 * through {@link VS2Compat#stationCameraWorldPos} and are plausibility-gated
 * (same contract as the vehicle crew role). Velocity is derived from
 * consecutive world sightings; a station with no possessing player and no
 * crew soldier is a parked vehicle and not an active threat.
 */
public final class ArmorThreatScanner {
    public record ArmorContact(UUID threatId, Vec3 aimPoint, Vec3 hullCenter,
                               @Nullable Vec3 velocity, @Nullable Vec3[] hullCorners,
                               long seenTick) {}

    private static final int SCAN_INTERVAL_TICKS = 10;
    /** Sighting trail length for velocity estimation (ticks). */
    private static final long VELOCITY_TRAIL_MAX_TICKS = 100;
    private static final int PRUNE_INTERVAL_TICKS = 200;
    private static final double LOS_TOLERANCE = 2.0;
    private static final Map<UUID, Long> lastScanTickBySoldier = new HashMap<>();
    private static final Map<UUID, PrevSighting> lastSightingByThreat = new HashMap<>();
    /** Last resolved firing-solution point per soldier, for debug rendering. */
    private static final Map<UUID, FiringSolutionDebug> firingSolutionBySoldier = new HashMap<>();
    private static final long FIRING_SOLUTION_FRESH_TICKS = 40;
    private static long lastPruneGameTime = Long.MIN_VALUE;

    private record PrevSighting(Vec3 hullCenter, long gameTime) {}

    private ArmorThreatScanner() {}

    /**
     * Runs the armor scan for the soldier at a staggered interval. Safe to
     * call every tick; a no-op for vehicle crew soldiers (they man a station)
     * and wherever the feature is disabled. The turret-camera path needs
     * tallyho; crewed-occupancy detection does not.
     */
    public static void maybeScan(SoldierEntity soldier) {
        if (!StevesArmyConfig.isArmorAwarenessEnabled()) {
            return;
        }
        if (!(soldier.level() instanceof ServerLevel serverLevel)) {
            return;
        }
        if (soldier.isVehicleCrewActive() || soldier.isCrewSeated()) {
            return;
        }
        long gameTime = serverLevel.getGameTime();
        UUID soldierId = soldier.getUUID();
        Long last = lastScanTickBySoldier.get(soldierId);
        // Per-soldier offset de-synchronizes scans across a squad.
        int stagger = SCAN_INTERVAL_TICKS + Math.floorMod(soldierId.hashCode(), SCAN_INTERVAL_TICKS);
        if (last != null && gameTime - last < stagger) {
            return;
        }
        lastScanTickBySoldier.put(soldierId, gameTime);

        SquadThreatIntel intel = intelFor(soldier, serverLevel);
        if (intel == null) {
            return;
        }

        // Own-ship guard: a soldier never reports the hull he is himself
        // riding or standing on. Without this, a transported soldier scans his
        // own transport while its real crew reads as friendly and the ship
        // ends up in shared intel as an enemy vehicle.
        Long ownShipId = VS2Compat.getShipIdOf(VS2Compat.resolveShipUnderEntity(soldier));

        double range = StevesArmyConfig.getArmorDetectionDistance();
        AABB searchBox = soldier.getBoundingBox().inflate(range);
        List<Entity> cannons = serverLevel.getEntitiesOfClass(Entity.class, searchBox,
            ArmorThreatScanner::isCannonContraption);

        ArmorContact nearest = null;
        Set<Long> scannedShipIds = new HashSet<>();
        if (TallyhoCompat.isAvailable()) {
            List<Entity> cameras = serverLevel.getEntitiesOfClass(Entity.class, searchBox,
                cam -> TallyhoCompat.isCameraEntity(cam) && isHostileCamera(serverLevel, cam, soldier));
            for (Entity camera : cameras) {
                Object ship = VS2Compat.getShipUnder(camera);
                Vec3 aimPoint = VS2Compat.stationCameraWorldPos(ship, camera);
                if (!VS2Compat.isWorldPlausible(aimPoint)) {
                    continue;
                }
                Vec3 hullCenter = ship != null ? shipCenterWorld(ship) : aimPoint;
                if (hullCenter == null || !VS2Compat.isWorldPlausible(hullCenter)) {
                    continue;
                }
                Long shipId = VS2Compat.getShipIdOf(ship);
                if (shipId != null && shipId.equals(ownShipId)) {
                    continue;
                }
                Vec3[] hullCorners = ship != null ? shipHullCorners(ship) : null;
                UUID contactId = contactIdFor(ship, camera.getUUID());
                if (shipId != null) {
                    scannedShipIds.add(shipId);
                }
                int vehicleClass = TallyhoCompat.isHullMG(camera)
                    ? SquadThreatIntel.VC_HULL_MG : SquadThreatIntel.VC_VEHICLE;
                vehicleClass = upgradeForCannons(cannons, hullCenter, vehicleClass);

                Vec3 velocity = estimateVelocity(contactId, hullCenter, gameTime);
                intel.reportHardTarget(soldier.getUUID(), contactId,
                    BlockPos.containing(hullCenter), aimPoint, velocity, hullCorners, 1.0f,
                    serverLevel, vehicleClass);

                double distSqr = soldier.distanceToSqr(aimPoint);
                if (nearest == null || distSqr < soldier.distanceToSqr(nearest.aimPoint())) {
                    nearest = new ArmorContact(contactId, aimPoint, hullCenter, velocity,
                        hullCorners, gameTime);
                }
            }
        }

        // Crewed-occupancy vehicles (APC): a ship counts as an enemy vehicle when
        // enemy CREW are aboard — a vehicle-crew-role soldier or anyone riding a
        // seat on the hull. Infantry merely standing on a ship or dock never
        // qualifies, so ship-heavy areas cannot flood the doctrine with fake
        // contacts the way the old position-only scan did.
        if (StevesArmyConfig.isOccupancyVehicleDetectionEnabled()) {
            // The self gotcha: isFriendlyTo(self) is false by definition, so the
            // observer must be excluded explicitly or a soldier riding in a
            // transport seat reads as a hostile crewman on his own vehicle.
            List<LivingEntity> occupants = serverLevel.getEntitiesOfClass(LivingEntity.class, searchBox,
                occ -> occ.isAlive() && occ != soldier
                    && !soldier.isFriendlyTo(occ) && isVehicleOccupant(occ));
            // Friendly-aboard veto, through the same isFriendlyTo identity used
            // for every living-target decision (owner, teams, allies): a ship
            // carrying any of our side's people is never a rocket target, even
            // when an enemy crewman or boarder stands on it too.
            Set<Long> friendlyShipIds = occupants.isEmpty()
                ? Set.of() : friendlyShipIdsNear(soldier, serverLevel, searchBox);
            for (LivingEntity occupant : occupants) {
                Object ship = VS2Compat.resolveShipUnderEntity(occupant);
                Long shipId = VS2Compat.getShipIdOf(ship);
                if (shipId == null || scannedShipIds.contains(shipId)) {
                    continue;
                }
                scannedShipIds.add(shipId);
                if (shipId.equals(ownShipId)) {
                    if (DiagnosticLogManager.isCoverLoggingEnabled()) {
                        StevesArmyMod.LOGGER.info(
                            "[ArmorDoctrine] Soldier {} occupancy veto: ship {} is the observer's own mount (crewman {})",
                            soldier.getId(), shipId, occupant.getName().getString());
                    }
                    continue;
                }
                if (friendlyShipIds.contains(shipId)) {
                    if (DiagnosticLogManager.isCoverLoggingEnabled()) {
                        StevesArmyMod.LOGGER.info(
                            "[ArmorDoctrine] Soldier {} occupancy veto: ship {} carries friendly personnel (enemy crewman {})",
                            soldier.getId(), shipId, occupant.getName().getString());
                    }
                    continue;
                }
                Vec3 hullCenter = shipCenterWorld(ship);
                if (hullCenter == null || !VS2Compat.isWorldPlausible(hullCenter)) {
                    continue;
                }
                // Seated riders live at shipyard coordinates server-side; resolve a
                // world-space aim point, degrading to the hull center.
                Vec3 aimPoint = VS2Compat.stationCameraWorldPos(ship, occupant);
                if (aimPoint == null) {
                    aimPoint = hullCenter;
                }
                Vec3[] hullCorners = shipHullCorners(ship);
                UUID contactId = shipThreatId(shipId);
                boolean firstSighting = intel.getThreat(contactId).isEmpty();
                int vehicleClass = upgradeForCannons(cannons, hullCenter, SquadThreatIntel.VC_VEHICLE);
                Vec3 velocity = estimateVelocity(contactId, hullCenter, gameTime);
                intel.reportHardTarget(soldier.getUUID(), contactId,
                    BlockPos.containing(hullCenter), aimPoint, velocity, hullCorners, 0.8f,
                    serverLevel, vehicleClass);
                if (firstSighting && DiagnosticLogManager.isCoverLoggingEnabled()) {
                    StevesArmyMod.LOGGER.info("[ArmorDoctrine] Soldier {} spotted enemy vehicle (ship {}, class {}) crewed by {} at {}",
                        soldier.getId(), shipId, vehicleClass,
                        occupant.getName().getString(), hullCenter);
                }

                double distSqr = soldier.distanceToSqr(aimPoint);
                if (nearest == null || distSqr < soldier.distanceToSqr(nearest.aimPoint())) {
                    nearest = new ArmorContact(contactId, aimPoint, hullCenter, velocity,
                        hullCorners, gameTime);
                }
            }
        }

        // Superb Warfare vehicles: plain world-space entities — not ships, not
        // living targets, invisible to both ship paths above. Same hostile-
        // occupant doctrine: a vehicle whose riders are unfriendly reads as an
        // enemy vehicle; a vehicle carrying any of our side's people is vetoed.
        // The contact id is the entity's own UUID (the synthetic ship-id
        // namespace cannot collide with it).
        if (StevesArmyConfig.isOccupancyVehicleDetectionEnabled() && SbwCompat.isEnabled()) {
            List<Entity> vehicles = serverLevel.getEntitiesOfClass(Entity.class, searchBox,
                SbwCompat::isOperational);
            for (Entity vehicle : vehicles) {
                if (vehicle == soldier.getVehicle()) {
                    continue;
                }
                if (!SbwCompat.hasHostileOccupant(soldier, vehicle)) {
                    continue;
                }
                if (SbwCompat.hasFriendlyOccupant(soldier, vehicle)) {
                    if (DiagnosticLogManager.isCoverLoggingEnabled()) {
                        StevesArmyMod.LOGGER.info(
                            "[ArmorDoctrine] Soldier {} SBW veto: vehicle {} carries friendly personnel",
                            soldier.getId(), vehicle.getId());
                    }
                    continue;
                }
                AABB box = vehicle.getBoundingBox();
                Vec3 hullCenter = box.getCenter();
                Vec3[] corners = aabbCorners(box);
                UUID contactId = vehicle.getUUID();
                int vehicleClass = SquadThreatIntel.VC_VEHICLE;
                if ("TANK".equals(SbwCompat.getVehicleTypeName(vehicle))) {
                    vehicleClass = SquadThreatIntel.VC_TANK;
                } else {
                    vehicleClass = upgradeForCannons(cannons, hullCenter, vehicleClass);
                }
                Vec3 velocity = estimateVelocity(contactId, hullCenter, gameTime);
                intel.reportHardTarget(soldier.getUUID(), contactId,
                    BlockPos.containing(hullCenter), hullCenter, velocity, corners,
                    0.8f, serverLevel, vehicleClass);

                double distSqr = soldier.distanceToSqr(hullCenter);
                if (nearest == null || distSqr < soldier.distanceToSqr(nearest.aimPoint())) {
                    nearest = new ArmorContact(contactId, hullCenter, hullCenter, velocity,
                        corners, gameTime);
                }
            }
        }

        pruneIfNeeded(gameTime);
    }

    /** The vehicle's own bounding-box corners, for hull-silhouette sight tests. */
    @Nullable
    private static Vec3[] aabbCorners(AABB box) {
        return new Vec3[] {
            new Vec3(box.minX, box.minY, box.minZ),
            new Vec3(box.maxX, box.minY, box.minZ),
            new Vec3(box.minX, box.maxY, box.minZ),
            new Vec3(box.minX, box.minY, box.maxZ),
            new Vec3(box.maxX, box.maxY, box.minZ),
            new Vec3(box.maxX, box.minY, box.maxZ),
            new Vec3(box.minX, box.maxY, box.maxZ),
            new Vec3(box.maxX, box.maxY, box.maxZ),
        };
    }

    /**
     * Crew-identity gate for occupancy vehicles: the occupant must be manning
     * the vehicle — a soldier with the vehicle-crew role, or a rider whose
     * mount is an entity seat/mount rather than a living creature (a horse
     * rider is cavalry, not crew).
     */
    private static boolean isVehicleOccupant(Entity occupant) {
        if (occupant instanceof SoldierEntity soldierOcc
            && soldierOcc.getRole() == SoldierRole.VEHICLE_CREW) {
            return true;
        }
        Entity vehicle = occupant.getVehicle();
        return vehicle != null && !(vehicle instanceof LivingEntity);
    }

    /**
     * Ship ids under any of the observer's side's people in range: the standard
     * {@link SoldierEntity#isFriendlyTo} test (owner, scoreboard teams, allies)
     * applied to nearby entities, each resolved onto its ship. Covers the
     * driver's seat, transported soldiers, and anyone standing on a deck.
     */
    private static Set<Long> friendlyShipIdsNear(SoldierEntity soldier, ServerLevel level, AABB searchBox) {
        Set<Long> ids = new HashSet<>();
        List<LivingEntity> friendlies = level.getEntitiesOfClass(LivingEntity.class, searchBox,
            f -> f.isAlive() && f != soldier && soldier.isFriendlyTo(f));
        for (LivingEntity friendly : friendlies) {
            Long shipId = VS2Compat.getShipIdOf(VS2Compat.resolveShipUnderEntity(friendly));
            if (shipId != null) {
                ids.add(shipId);
            }
        }
        return ids;
    }

    private record OwnShipSnapshot(long gameTime, @Nullable Long shipId) {}

    /** Per-soldier cache so the per-tick consumption guard can afford the ship resolution. */
    private static final Map<UUID, OwnShipSnapshot> ownShipSnapshotBySoldier = new HashMap<>();
    private static final long OWN_SHIP_CACHE_TICKS = 10;

    /**
     * True when the contact is the very ship the soldier is currently aboard.
     * Consumption-side safety net: squad intel may still hold a stale record
     * (it survives save/load for up to 600 ticks), and a hunter must refuse to
     * engage its own mount regardless of what the intel says.
     */
    public static boolean isOwnMountContact(SoldierEntity soldier, ArmorContact contact) {
        // Plain-entity mount (Superb Warfare): the contact id is the mount's own
        // UUID, so the check is direct — no ship resolution involved.
        if (soldier.isPassenger() && soldier.getVehicle() != null
            && contact.threatId().equals(soldier.getVehicle().getUUID())) {
            return true;
        }
        if (!(soldier.level() instanceof ServerLevel serverLevel)) {
            return false;
        }
        long gameTime = serverLevel.getGameTime();
        UUID soldierId = soldier.getUUID();
        OwnShipSnapshot snapshot = ownShipSnapshotBySoldier.get(soldierId);
        Long ownShipId;
        if (snapshot != null && gameTime - snapshot.gameTime() < OWN_SHIP_CACHE_TICKS) {
            ownShipId = snapshot.shipId();
        } else {
            ownShipId = VS2Compat.getShipIdOf(VS2Compat.resolveShipUnderEntity(soldier));
            ownShipSnapshotBySoldier.put(soldierId, new OwnShipSnapshot(gameTime, ownShipId));
        }
        return ownShipId != null && shipThreatId(ownShipId).equals(contact.threatId());
    }

    private record FiringSolutionDebug(Vec3 point, long gameTime) {}

    private static void rememberFiringSolution(SoldierEntity soldier, Vec3 point) {
        firingSolutionBySoldier.put(soldier.getUUID(),
            new FiringSolutionDebug(point, soldier.level().getGameTime()));
    }

    private static void forgetFiringSolution(SoldierEntity soldier) {
        firingSolutionBySoldier.remove(soldier.getUUID());
    }

    /** Last resolved hull surface, or null when no current solution exists. */
    @Nullable
    public static Vec3 getLastFiringSolution(SoldierEntity soldier) {
        FiringSolutionDebug debug = firingSolutionBySoldier.get(soldier.getUUID());
        if (debug == null
            || soldier.level().getGameTime() - debug.gameTime() > FIRING_SOLUTION_FRESH_TICKS) {
            return null;
        }
        return debug.point();
    }

    /** Nearest fresh hard target known to the soldier's squad, or null. */
    @Nullable
    public static ArmorContact getPrimaryArmorThreat(SoldierEntity soldier) {
        SquadThreatIntel intel = intelFor(soldier, soldier.level());
        if (intel == null) {
            return null;
        }
        List<SquadThreatIntel.ThreatKnowledge> hardTargets =
            intel.getHardTargetThreats(soldier.level().getGameTime());
        for (SquadThreatIntel.ThreatKnowledge knowledge : hardTargets) {
            if (knowledge.lastKnownPosition == null) {
                continue;
            }
            Vec3 hull = Vec3.atCenterOf(knowledge.lastKnownPosition);
            Vec3 aim = knowledge.lastVisibleAimPoint != null ? knowledge.lastVisibleAimPoint : hull;
            return new ArmorContact(knowledge.threatEntityId, aim, hull,
                knowledge.lastKnownVelocity, knowledge.lastKnownHullCorners, knowledge.lastSeenTime);
        }
        return null;
    }

    /** A station is hostile when an enemy player possesses it or an enemy soldier crews it. */
    private static boolean isHostileCamera(ServerLevel level, Entity camera, SoldierEntity observer) {
        for (Entity passenger : camera.getPassengers()) {
            if (passenger instanceof Player player && !observer.isFriendlyTo(player)) {
                return true;
            }
        }
        UUID claimant = VehicleCrewManager.claimantOf(camera.getUUID());
        if (claimant == null) {
            return false;
        }
        Entity crew = level.getEntity(claimant);
        return crew instanceof SoldierEntity crewSoldier && !observer.isFriendlyTo(crewSoldier);
    }

    /**
     * World-space proximity to a CBC cannon contraption upgrades a contact to a
     * tank. Association deliberately ignores ship identity: the cannon entity
     * may live on a different (attached) ship than the hull-MG camera, so only
     * the world-space distance to the hull decides.
     */
    private static final double CANNON_ASSOCIATION_RANGE = 32.0;
    private static final String CBC_PITCH_CONTRAPTION_CLASS =
        "rbasamoyai.createbigcannons.cannon_control.contraption.PitchOrientedContraptionEntity";
    private static volatile boolean cannonClassChecked;
    private static Class<?> cannonContraptionClass;

    private static boolean isCannonContraption(Entity entity) {
        if (!cannonClassChecked) {
            cannonClassChecked = true;
            try {
                cannonContraptionClass = Class.forName(CBC_PITCH_CONTRAPTION_CLASS);
            } catch (ClassNotFoundException | LinkageError ignored) {
                cannonContraptionClass = null;
            }
        }
        return cannonContraptionClass != null && cannonContraptionClass == entity.getClass();
    }

    private static int upgradeForCannons(List<Entity> cannons, Vec3 hullCenter, int vehicleClass) {
        if (vehicleClass >= SquadThreatIntel.VC_TANK || cannons.isEmpty()) {
            return vehicleClass;
        }
        for (Entity cannon : cannons) {
            Vec3 pos = VS2Compat.stationCameraWorldPos(VS2Compat.getShipUnder(cannon), cannon);
            if (pos == null || !VS2Compat.isWorldPlausible(pos)) {
                continue;
            }
            if (pos.distanceTo(hullCenter) <= CANNON_ASSOCIATION_RANGE) {
                return SquadThreatIntel.VC_TANK;
            }
        }
        return vehicleClass;
    }

    /** Contact identity: the ship when known, otherwise the station entity itself. */
    private static UUID contactIdFor(Object ship, UUID fallback) {
        Long shipId = VS2Compat.getShipIdOf(ship);
        return shipId != null ? shipThreatId(shipId) : fallback;
    }

    /** Stable synthetic threat id for a ship, shared by every observer. */
    private static UUID shipThreatId(long shipId) {
        return UUID.nameUUIDFromBytes(
            ("stevesarmy:ship:" + shipId).getBytes(java.nio.charset.StandardCharsets.UTF_8));
    }

    @Nullable
    private static Vec3 shipCenterWorld(Object ship) {
        BlockPos min = VS2Compat.getShipyardMin(ship);
        BlockPos max = VS2Compat.getShipyardMax(ship);
        if (min == null || max == null) {
            return null;
        }
        Vec3 local = new Vec3(
            (min.getX() + max.getX()) / 2.0,
            (min.getY() + max.getY()) / 2.0,
            (min.getZ() + max.getZ()) / 2.0);
        return VS2Compat.shipToWorldPosition(ship, local);
    }

    /**
     * The ship-space bounding-box corners transformed to world space, so line
     * of sight can be tested against the whole hull silhouette instead of only
     * the gun position. Null when the ship gives no bounds or a corner fails
     * the world-plausibility gate (degrades callers to gun-point checks).
     */
    @Nullable
    private static Vec3[] shipHullCorners(Object ship) {
        BlockPos min = VS2Compat.getShipyardMin(ship);
        BlockPos max = VS2Compat.getShipyardMax(ship);
        if (min == null || max == null) {
            return null;
        }
        Vec3[] corners = new Vec3[8];
        int index = 0;
        for (int cx = 0; cx < 2; cx++) {
            for (int cy = 0; cy < 2; cy++) {
                for (int cz = 0; cz < 2; cz++) {
                    Vec3 local = new Vec3(
                        cx == 0 ? min.getX() : max.getX(),
                        cy == 0 ? min.getY() : max.getY(),
                        cz == 0 ? min.getZ() : max.getZ());
                    Vec3 world = VS2Compat.shipToWorldPosition(ship, local);
                    if (world == null || !VS2Compat.isWorldPlausible(world)) {
                        return null;
                    }
                    corners[index++] = world;
                }
            }
        }
        return corners;
    }

    /**
     * Resolves the point the soldier can actually shoot at on a hard target.
     * Doctrine: line of sight to any block of the vehicle counts, not just the
     * gun optic. The gun position is used when its ray is near-clear; hull
     * samples are bounding-box envelope coordinates that usually float in air,
     * so a sample only counts where the ray actually meets ship geometry — the
     * soldier aims at that surface point, pulled slightly toward the eye so
     * the shot connects. Null when nothing on the vehicle is shootable.
     */
    @Nullable
    public static Vec3 findFiringSolution(SoldierEntity soldier, ArmorContact armor) {
        if (TargetAcquisition.hasNearLineOfSightToPosition(soldier, armor.aimPoint(), LOS_TOLERANCE)) {
            rememberFiringSolution(soldier, armor.aimPoint());
            return armor.aimPoint();
        }
        // Plain-entity vehicle (Superb Warfare): hull samples are points inside
        // the entity's own hitbox, so sight is plain block/smoke — the ship clip
        // below never sees the vehicle and there is no surface to pull back from.
        if (soldier.level() instanceof ServerLevel serverLevel) {
            Entity vehicle = serverLevel.getEntity(armor.threatId());
            if (SbwCompat.isOperational(vehicle)) {
                for (Vec3 candidate : hullSamples(armor)) {
                    if (TargetAcquisition.hasLineOfSightToPosition(soldier, candidate)) {
                        rememberFiringSolution(soldier, candidate);
                        return candidate;
                    }
                }
                forgetFiringSolution(soldier);
                return null;
            }
        }
        Vec3 eye = soldier.getEyePosition();
        AABB region = hullRegion(armor);
        List<Vec3> candidates = hullSamples(armor);
        for (Vec3 candidate : candidates) {
            Vec3 direction = candidate.subtract(eye);
            double distance = direction.length();
            if (distance < 1.0e-4) {
                continue;
            }
            double hit = VS2Compat.getShipAwareBlockHitDistance(
                soldier.level(), eye, candidate, soldier);
            if (!Double.isFinite(hit) || hit < MIN_SURFACE_DISTANCE
                || hit > distance + HULL_HIT_TOLERANCE) {
                // The ray reaches the sample without meeting hull geometry in
                // front of it: the sample is envelope air, not a target.
                continue;
            }
            Vec3 unit = direction.scale(1.0 / distance);
            Vec3 surface = eye.add(unit.scale(hit));
            if (!region.contains(surface.x, surface.y, surface.z)) {
                // Solid, but not this vehicle: terrain or an unrelated ship.
                continue;
            }
            Vec3 solution = eye.add(unit.scale(Math.max(hit - SURFACE_PULLBACK, MIN_SURFACE_DISTANCE)));
            rememberFiringSolution(soldier, solution);
            return solution;
        }
        forgetFiringSolution(soldier);
        return null;
    }

    /** Hull center plus bounding-box corners, the shared sampling set for both solution paths. */
    private static List<Vec3> hullSamples(ArmorContact armor) {
        List<Vec3> samples = new ArrayList<>(9);
        samples.add(armor.hullCenter());
        if (armor.hullCorners() != null) {
            samples.addAll(java.util.Arrays.asList(armor.hullCorners()));
        }
        return samples;
    }

    /** World-space test region around the hull for accepting ray-hit surfaces. */
    private static AABB hullRegion(ArmorContact armor) {
        Vec3[] corners = armor.hullCorners();
        if (corners == null || corners.length == 0) {
            return new AABB(armor.hullCenter(), armor.hullCenter()).inflate(2.0);
        }
        double minX = Double.MAX_VALUE, minY = Double.MAX_VALUE, minZ = Double.MAX_VALUE;
        double maxX = -Double.MAX_VALUE, maxY = -Double.MAX_VALUE, maxZ = -Double.MAX_VALUE;
        for (Vec3 corner : corners) {
            minX = Math.min(minX, corner.x); minY = Math.min(minY, corner.y); minZ = Math.min(minZ, corner.z);
            maxX = Math.max(maxX, corner.x); maxY = Math.max(maxY, corner.y); maxZ = Math.max(maxZ, corner.z);
        }
        return new AABB(minX, minY, minZ, maxX, maxY, maxZ).inflate(2.0);
    }

    private static final double MIN_SURFACE_DISTANCE = 1.5;
    /** How far past a hull sample a ray hit may land and still be this vehicle's surface. */
    private static final double HULL_HIT_TOLERANCE = 2.0;
    /** Pull the aim point this far off the surface toward the shooter. */
    private static final double SURFACE_PULLBACK = 0.4;

    /**
     * {@link #findFiringSolution} for a squad-intel knowledge entry — used by
     * the suppression path, which reads the shared threat store rather than a
     * fresh scan contact.
     */
    @Nullable
    public static Vec3 findFiringSolution(SoldierEntity soldier, SquadThreatIntel.ThreatKnowledge knowledge) {
        if (knowledge.lastKnownPosition == null) {
            return null;
        }
        Vec3 hull = Vec3.atCenterOf(knowledge.lastKnownPosition);
        Vec3 aim = knowledge.lastVisibleAimPoint != null ? knowledge.lastVisibleAimPoint : hull;
        return findFiringSolution(soldier, new ArmorContact(knowledge.threatEntityId, aim, hull,
            knowledge.lastKnownVelocity, knowledge.lastKnownHullCorners, knowledge.lastSeenTime));
    }

    /** Blocks per tick between this and the previous world sighting of the vehicle. */
    @Nullable
    private static Vec3 estimateVelocity(UUID threatId, Vec3 hullCenter, long gameTime) {
        PrevSighting prev = lastSightingByThreat.get(threatId);
        lastSightingByThreat.put(threatId, new PrevSighting(hullCenter, gameTime));
        if (prev == null) {
            return null;
        }
        long dt = gameTime - prev.gameTime();
        if (dt <= 0 || dt > VELOCITY_TRAIL_MAX_TICKS) {
            return null;
        }
        return hullCenter.subtract(prev.hullCenter()).scale(1.0 / dt);
    }

    private static void pruneIfNeeded(long gameTime) {
        if (lastPruneGameTime != Long.MIN_VALUE && gameTime - lastPruneGameTime < PRUNE_INTERVAL_TICKS) {
            return;
        }
        lastPruneGameTime = gameTime;
        lastSightingByThreat.entrySet().removeIf(
            entry -> gameTime - entry.getValue().gameTime() > VELOCITY_TRAIL_MAX_TICKS * 4);
        lastScanTickBySoldier.clear();
        firingSolutionBySoldier.entrySet().removeIf(
            entry -> gameTime - entry.getValue().gameTime() > FIRING_SOLUTION_FRESH_TICKS * 10);
    }

    @Nullable
    private static SquadThreatIntel intelFor(SoldierEntity soldier, net.minecraft.world.level.Level level) {
        if (!(level instanceof ServerLevel serverLevel)) {
            return null;
        }
        UUID squadId = soldier.getSquadId();
        if (squadId == null) {
            return null;
        }
        return SquadManager.get(serverLevel).getSquadById(squadId)
            .map(SquadData::getThreatIntel)
            .orElse(null);
    }
}
