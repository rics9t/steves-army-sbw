package com.stevesarmy.combat;

import com.stevesarmy.StevesArmyConfig;
import com.stevesarmy.compat.sbw.SbwCompat;
import com.stevesarmy.compat.sbw.SbwVehicles;
import com.stevesarmy.entity.SoldierEntity;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.util.Mth;
import net.minecraft.world.phys.Vec3;

import java.util.Comparator;
import java.util.List;

/** Handheld weapon support for SBW passengers in seats that allow hand use. */
public final class MountedSoldierGunnery {
    private static final int RETARGET_INTERVAL_TICKS = 10;

    private MountedSoldierGunnery() {}

    public static void tickMounted(SoldierEntity soldier) {
        Entity vehicle = soldier.getVehicle();
        if (!SbwCompat.isVehicle(vehicle) || SbwVehicles.isDrone(vehicle)) return;

        int seat = SbwVehicles.seatIndexOf(vehicle, soldier);
        if (seat < 0 || SbwVehicles.isDriver(vehicle, soldier)
            || !SbwVehicles.seatAllowsHandheld(vehicle, seat)
            || !GunIntegration.isAnyGunLoaded() || !GunIntegration.hasGun(soldier)
            || ArmorRoleManager.isAtGunStack(soldier.getMainHandItem())) {
            soldier.setTarget(null);
            GunIntegration.aim(soldier, false);
            return;
        }

        double range = Math.min(StevesArmyConfig.getBasicDetectionDistance(),
            Math.max(8.0, GunIntegration.getEffectiveRange(soldier)));
        LivingEntity target = soldier.getTarget();
        if (!isValidTarget(soldier, vehicle, target, range)) {
            if (target != null) soldier.setTarget(null);
            target = null;
            int scanOffset = Math.floorMod(soldier.getUUID().hashCode(), RETARGET_INTERVAL_TICKS);
            if (Math.floorMod(soldier.tickCount, RETARGET_INTERVAL_TICKS) == scanOffset) {
                List<LivingEntity> candidates = soldier.level().getEntitiesOfClass(
                    LivingEntity.class, soldier.getBoundingBox().inflate(range),
                    candidate -> isValidTarget(soldier, vehicle, candidate, range));
                target = candidates.stream()
                    .min(Comparator.comparingDouble(soldier::distanceToSqr))
                    .orElse(null);
                soldier.setTarget(target);
            }
        }

        if (target == null) {
            GunIntegration.aim(soldier, false);
            return;
        }

        Vec3 aimPoint = target.getEyePosition();
        faceTarget(soldier, aimPoint);
        GunIntegration.aim(soldier, true);
        if (GunIntegration.getAimProgress(soldier) < 0.5f
            || GunIntegration.isDrawing(soldier)
            || GunIntegration.isReloading(soldier)
            || GunIntegration.isBolting(soldier)) {
            return;
        }

        if (GunIntegration.getCurrentAmmo(soldier) <= 0) {
            if (GunIntegration.canReload(soldier)) GunIntegration.reload(soldier);
            return;
        }
        if (!FriendlyFireChecker.isSafeToShoot(soldier, aimPoint, 0.65f)) return;

        switch (GunIntegration.shoot(soldier, target)) {
            case NO_AMMO -> {
                if (GunIntegration.canReload(soldier)) GunIntegration.reload(soldier);
            }
            case NEED_BOLT -> GunIntegration.bolt(soldier);
            case NOT_DRAWN -> GunIntegration.draw(soldier);
            default -> {}
        }
    }

    private static boolean isValidTarget(SoldierEntity soldier, Entity vehicle,
                                         LivingEntity target, double range) {
        return target != null && target != soldier && target.isAlive()
            && target.level() == soldier.level() && target.getVehicle() != vehicle
            && !target.isSpectator() && soldier.isProactiveTarget(target)
            && !soldier.isFriendlyTo(target)
            && soldier.distanceToSqr(target) <= range * range
            && TargetAcquisition.hasLineOfSight(soldier, target);
    }

    private static void faceTarget(SoldierEntity soldier, Vec3 target) {
        Vec3 delta = target.subtract(soldier.getEyePosition());
        double horizontal = Math.sqrt(delta.x * delta.x + delta.z * delta.z);
        float targetYaw = (float) (Math.toDegrees(Math.atan2(delta.z, delta.x)) - 90.0);
        float targetPitch = (float) -Math.toDegrees(Math.atan2(delta.y, horizontal));

        // SBW controls the seated body's rotation from its seat transform.
        // Changing YRot/YBodyRot here fights that update and makes the head
        // oscillate. Track with the head and pitch; the handheld firing API
        // aims at the target position independently of body yaw.
        float headYaw = Mth.approachDegrees(soldier.getYHeadRot(), targetYaw, 8.0f);
        soldier.setYHeadRot(headYaw);
        soldier.setXRot(Mth.approach(soldier.getXRot(), Mth.clamp(targetPitch, -90.0f, 90.0f), 5.0f));
    }
}
