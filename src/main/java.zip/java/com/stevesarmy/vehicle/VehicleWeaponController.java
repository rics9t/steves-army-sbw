package com.stevesarmy.vehicle;

import com.stevesarmy.compat.sbw.SbwCompat;
import com.stevesarmy.compat.sbw.SbwTurret;
import com.stevesarmy.compat.sbw.SbwVehicles;
import com.stevesarmy.entity.SoldierEntity;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.phys.Vec3;

import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

public final class VehicleWeaponController {

    private static final Map<String, Long> NEXT_FIRE = new ConcurrentHashMap<>();
    private static final Map<UUID, IdleScan> IDLE = new ConcurrentHashMap<>();
    private static final int HEAT_CUTOFF = 90;

    /** Idle traverse rate, degrees per tick. Deliberately slow. */
    private static final float IDLE_TRAVERSE = 0.45f;
    private static final float IDLE_ELEVATION_RATE = 0.12f;
    private static final float IDLE_ARC = 38.0f;

    private VehicleWeaponController() {
    }

    private static final class IdleScan {
        float yawOffset;
        float targetYawOffset;
        float pitch;
        float targetPitch;
        int dwell;
    }

    public static void tick(VehicleDriver driver, Entity vehicle) {
        if (vehicle == null || vehicle.level().isClientSide) return;

        Vec3 orderedTargetPos = driver.resolveAttackPosition(vehicle);
        UUID targetId = driver.attackTargetId();

        boolean engaging = orderedTargetPos != null
            && (driver.mode() == VehicleDriveMode.ATTACK || driver.mode() == VehicleDriveMode.HOLD);

        if (!engaging) {
            SbwVehicles.fire(vehicle, false);
            aimIdleTurret(vehicle);
            return;
        }

        // A location order may outlive the target that originally attracted
        // the crew. Fire only while the spotter has a live hostile target, so
        // the cannon or MG never keeps shooting at the old aim point.
        SoldierEntity spotter = driver.driverSoldier();
        Entity tracked = targetId != null && vehicle.level() instanceof ServerLevel level
            ? level.getEntity(targetId)
            : spotter != null ? spotter.getTarget() : null;
        if (!(tracked instanceof LivingEntity target) || !target.isAlive()
            || spotter == null || spotter.isFriendlyTo(target)
            || !spotter.isProactiveTarget(target)) {
            SbwVehicles.fire(vehicle, false);
            aimIdleTurret(vehicle);
            return;
        }
        targetId = target.getUUID();
        Entity targetVehicle = target.getVehicle();
        Vec3 targetPos = SbwCompat.isVehicle(targetVehicle)
            ? targetVehicle.getBoundingBox().getCenter()
            : target.getBoundingBox().getCenter();

        // Engaging again, so the idle scan restarts from where the turret is.
        IDLE.remove(vehicle.getUUID());

        // The driver seat owns the main turret's selectable weapons. Prefer
        // the cannon against hostile crew inside a vehicle and the coaxial MG
        // against exposed infantry; passenger stations keep their own loadout.
        selectMainWeapon(vehicle, target);

        long now = vehicle.level().getGameTime();
        int seats = SbwVehicles.maxPassengers(vehicle);

        for (int seatIndex = 0; seatIndex < seats; seatIndex++) {
            Entity occupant = SbwVehicles.passengerAt(vehicle, seatIndex);
            if (!(occupant instanceof SoldierEntity gunner)) continue;
            if (!SbwVehicles.seatHasWeapon(vehicle, seatIndex)) continue;

            String weaponName = SbwVehicles.getGunName(vehicle, seatIndex);
            if (weaponName == null) continue;

            if (SbwVehicles.ammoCount(vehicle, seatIndex) <= 0) continue;
            if (SbwVehicles.weaponHeat(vehicle, seatIndex) >= HEAT_CUTOFF) continue;

            String key = vehicle.getUUID() + ":" + seatIndex + ":" + weaponName;
            long next = NEXT_FIRE.getOrDefault(key, 0L);
            if (now < next) continue;

            Vec3 shootPos = SbwVehicles.shootPos(vehicle, seatIndex);
            Vec3 aimVec = targetPos.subtract(shootPos).normalize();
            SbwTurret.aim(vehicle, seatIndex, aimVec);

            boolean fired = SbwVehicles.shoot(vehicle, gunner, targetId, targetPos);
            if (fired) {
                NEXT_FIRE.put(key, now + cooldownFor(vehicle, seatIndex, weaponName));
            }
        }
    }

    private static void selectMainWeapon(Entity vehicle, LivingEntity target) {
        int seat = SbwVehicles.turretControllerIndex(vehicle);
        if (seat < 0) return;
        boolean armoredTarget = SbwCompat.isVehicle(target.getVehicle());
        java.util.List<String> weapons = SbwVehicles.seatWeapons(vehicle, seat);
        for (int i = 0; i < weapons.size(); i++) {
            String name = weapons.get(i).toLowerCase(java.util.Locale.ROOT);
            boolean match = armoredTarget
                ? name.contains("cannon") || name.contains("main_gun") || name.equals("main")
                : name.contains("machinegun") || name.contains("machine_gun")
                    || name.contains("coax") || name.equals("mg");
            if (match && SbwVehicles.weaponIndex(vehicle, seat) != i) {
                SbwVehicles.setWeaponIndex(vehicle, seat, i);
            }
            if (match) return;
        }
    }

    private static int cooldownFor(Entity vehicle, int seatIndex, String weaponName) {
        String normalized = weaponName.toLowerCase(java.util.Locale.ROOT);
        if (normalized.contains("machinegun") || normalized.contains("machine_gun")
            || normalized.contains("coax") || normalized.equals("mg")) {
            return 2;
        }
        if (normalized.contains("missile") || normalized.contains("rocket")) return 40;
        SbwVehicles.Kind kind = SbwVehicles.kind(vehicle);
        if (seatIndex == 0 && kind == SbwVehicles.Kind.TRACKED) {
            return 80;
        }
        return kind == SbwVehicles.Kind.HELICOPTER || kind == SbwVehicles.Kind.AIRCRAFT ? 10 : 15;
    }

    /**
     * Idle turret behaviour. The old version pushed a raw sine straight into
     * the aim call every tick, which either snapped the turret or, when the
     * vector aim helper was not found, did nothing at all and left the gun
     * frozen. This keeps a per vehicle scan state, picks a new bearing inside
     * a narrow arc every few seconds and creeps toward it, the same way the
     * crew's heads drift while idle.
     */
    private static void aimIdleTurret(Entity vehicle) {
        int seat = SbwVehicles.turretControllerIndex(vehicle);
        if (seat < 0 || !SbwVehicles.seatHasWeapon(vehicle, seat)) return;
        // Nobody in the turret, nothing to scan with.
        if (!(SbwVehicles.passengerAt(vehicle, seat) instanceof SoldierEntity)) return;

        IdleScan scan = IDLE.computeIfAbsent(vehicle.getUUID(), id -> new IdleScan());
        if (--scan.dwell <= 0) {
            net.minecraft.util.RandomSource random = vehicle.level().getRandom();
            scan.targetYawOffset = (random.nextFloat() * 2.0f - 1.0f) * IDLE_ARC;
            scan.targetPitch = -1.0f + random.nextFloat() * 4.0f;
            scan.dwell = 70 + random.nextInt(130);
        }
        scan.yawOffset = approach(scan.yawOffset, scan.targetYawOffset, IDLE_TRAVERSE);
        scan.pitch = approach(scan.pitch, scan.targetPitch, IDLE_ELEVATION_RATE);

        float yaw = Mth.wrapDegrees(vehicle.getYRot() + scan.yawOffset);
        float pitch = -scan.pitch;
        SbwTurret.aimAngles(vehicle, seat, yaw, pitch);
    }

    private static float approach(float current, float desired, float maxStep) {
        float delta = desired - current;
        if (Math.abs(delta) <= maxStep) return desired;
        return current + Math.signum(delta) * maxStep;
    }

    public static void forget(Entity vehicle) {
        if (vehicle == null) return;
        String prefix = vehicle.getUUID().toString() + ":";
        NEXT_FIRE.keySet().removeIf(k -> k.startsWith(prefix));
        IDLE.remove(vehicle.getUUID());
    }
}
