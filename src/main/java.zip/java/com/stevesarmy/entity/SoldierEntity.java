package com.stevesarmy.entity;

import com.stevesarmy.GameClock;
import com.stevesarmy.StevesArmyMod;
import com.stevesarmy.StevesArmyConfig;
import com.stevesarmy.compat.VS2Compat;
import com.stevesarmy.skin.SoldierSkinManager;
import com.stevesarmy.squad.OwnedSoldierRegistry;
import com.stevesarmy.combat.CombatDebugData;
import com.stevesarmy.combat.CoverStateDebugManager;
import com.stevesarmy.combat.DetectionSystem;
import com.stevesarmy.combat.GrenadeIntegration;
import com.stevesarmy.combat.GunIntegration;
import com.stevesarmy.combat.MountedSoldierGunnery;
import com.stevesarmy.combat.SbwVehicleGunnery;
import com.stevesarmy.combat.ThreatAwareness;
import com.stevesarmy.combat.cover.CoverBehaviorManager;
import com.stevesarmy.combat.cover.CoverPoint;
import com.stevesarmy.combat.cover.CoverType;
import com.stevesarmy.combat.cover.IncomingFireHandler;
import com.stevesarmy.combat.cover.SuppressionTracker;
import com.stevesarmy.debug.DiagnosticLogManager;

import com.stevesarmy.entity.ai.SoldierCombatGoal;
import com.stevesarmy.entity.ai.SoldierFollowOwnerGoal;
import com.stevesarmy.entity.ai.SoldierHoleRescueGoal;
import com.stevesarmy.entity.ai.SoldierHoldPositionGoal;
import com.stevesarmy.entity.ai.SoldierHealController;
import com.stevesarmy.entity.ai.SoldierMoveToPingGoal;
import com.stevesarmy.entity.ai.SoldierStrollGoal;
import com.stevesarmy.entity.ai.SuppressionOrderController;
import com.stevesarmy.entity.ai.CoverTacticalGoal;
import com.stevesarmy.entity.ai.CombatGoalController;
import com.stevesarmy.entity.ai.CoverGoalController;
import com.stevesarmy.entity.ai.PeekController;
import com.stevesarmy.entity.ai.GrenadeTacticalController;
import com.stevesarmy.inventory.SoldierInventory;
import com.stevesarmy.inventory.SoldierInventoryHandler;
import com.stevesarmy.network.NetworkHandler;
import com.stevesarmy.network.CoverStateDebugPacket;
import com.stevesarmy.network.OpenSoldierInventoryMessage;
import com.stevesarmy.squad.FireDiscipline;
import com.stevesarmy.squad.FireTeam;
import com.stevesarmy.squad.FireTeamAssignment;
import com.stevesarmy.squad.FofCategory;
import com.stevesarmy.squad.FofSettings;
import com.stevesarmy.squad.FofStance;
import com.stevesarmy.squad.SquadManager;
import com.stevesarmy.squad.SquadThreatIntel;
import com.stevesarmy.squad.SquadMode;
import com.stevesarmy.squad.SquadFormation;
import com.stevesarmy.squad.TeamManager;
import com.stevesarmy.registry.ModItems;
import com.stevesarmy.util.SpacingHelper;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.network.chat.Component;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.util.Mth;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.Container;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.*;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.goal.*;
import net.minecraft.world.entity.ai.goal.target.HurtByTargetGoal;
import net.minecraft.world.entity.ai.goal.target.NearestAttackableTargetGoal;
import net.minecraft.world.entity.monster.Monster;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.level.pathfinder.Path;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;
import net.minecraft.world.scores.Team;
import net.minecraftforge.common.capabilities.Capability;
import net.minecraftforge.common.capabilities.ForgeCapabilities;
import net.minecraftforge.common.util.LazyOptional;
import net.minecraftforge.items.IItemHandler;
import net.minecraftforge.network.PacketDistributor;

import javax.annotation.Nonnull;
import javax.annotation.Nullable;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.UUID;

public class SoldierEntity extends PathfinderMob implements Container {
    private static final EntityDataAccessor<Optional<UUID>> OWNER_UUID = 
        SynchedEntityData.defineId(SoldierEntity.class, EntityDataSerializers.OPTIONAL_UUID);
    private static final EntityDataAccessor<Integer> FOLLOW_STATE = 
        SynchedEntityData.defineId(SoldierEntity.class, EntityDataSerializers.INT);
    private static final EntityDataAccessor<Integer> SQUAD_MODE = 
        SynchedEntityData.defineId(SoldierEntity.class, EntityDataSerializers.INT);
    private static final EntityDataAccessor<BlockPos> HOLD_POSITION = 
        SynchedEntityData.defineId(SoldierEntity.class, EntityDataSerializers.BLOCK_POS);
    
    private static final EntityDataAccessor<Float> DEBUG_DETECTION_POINTS =
        SynchedEntityData.defineId(SoldierEntity.class, EntityDataSerializers.FLOAT);
    private static final EntityDataAccessor<Boolean> DEBUG_IS_DETECTED =
        SynchedEntityData.defineId(SoldierEntity.class, EntityDataSerializers.BOOLEAN);
    private static final EntityDataAccessor<Float> DEBUG_DISTANCE =
        SynchedEntityData.defineId(SoldierEntity.class, EntityDataSerializers.FLOAT);
    private static final EntityDataAccessor<Boolean> DEBUG_HAS_LOS =
        SynchedEntityData.defineId(SoldierEntity.class, EntityDataSerializers.BOOLEAN);
    private static final EntityDataAccessor<Boolean> DEBUG_IN_FOCUSED =
        SynchedEntityData.defineId(SoldierEntity.class, EntityDataSerializers.BOOLEAN);
    private static final EntityDataAccessor<Optional<UUID>> DEBUG_TARGET_UUID =
        SynchedEntityData.defineId(SoldierEntity.class, EntityDataSerializers.OPTIONAL_UUID);
    
    private static final EntityDataAccessor<Integer> COVER_STATE =
        SynchedEntityData.defineId(SoldierEntity.class, EntityDataSerializers.INT);
    private static final EntityDataAccessor<BlockPos> COVER_CURRENT_POS =
        SynchedEntityData.defineId(SoldierEntity.class, EntityDataSerializers.BLOCK_POS);
    private static final EntityDataAccessor<Integer> COVER_CURRENT_TYPE =
        SynchedEntityData.defineId(SoldierEntity.class, EntityDataSerializers.INT);
    private static final EntityDataAccessor<Float> COVER_CURRENT_QUALITY =
        SynchedEntityData.defineId(SoldierEntity.class, EntityDataSerializers.FLOAT);
    private static final EntityDataAccessor<Float> COVER_CURRENT_HEIGHT =
        SynchedEntityData.defineId(SoldierEntity.class, EntityDataSerializers.FLOAT);
    private static final EntityDataAccessor<BlockPos> COVER_TARGET_POS =
        SynchedEntityData.defineId(SoldierEntity.class, EntityDataSerializers.BLOCK_POS);
    private static final EntityDataAccessor<Integer> COVER_TARGET_TYPE =
        SynchedEntityData.defineId(SoldierEntity.class, EntityDataSerializers.INT);
    private static final EntityDataAccessor<Float> COVER_TARGET_QUALITY =
        SynchedEntityData.defineId(SoldierEntity.class, EntityDataSerializers.FLOAT);
    private static final EntityDataAccessor<BlockPos> COVER_LAST_POS =
        SynchedEntityData.defineId(SoldierEntity.class, EntityDataSerializers.BLOCK_POS);
    private static final EntityDataAccessor<Float> SUPPRESSION_LEVEL =
        SynchedEntityData.defineId(SoldierEntity.class, EntityDataSerializers.FLOAT);
    private static final EntityDataAccessor<Integer> SUPPRESSION_EVENT_SEQUENCE =
        SynchedEntityData.defineId(SoldierEntity.class, EntityDataSerializers.INT);
    private static final EntityDataAccessor<Integer> PEEK_STATE =
        SynchedEntityData.defineId(SoldierEntity.class, EntityDataSerializers.INT);
    private static final EntityDataAccessor<BlockPos> PEEK_POSITION =
        SynchedEntityData.defineId(SoldierEntity.class, EntityDataSerializers.BLOCK_POS);
    private static final EntityDataAccessor<Boolean> CORNER_PEEK_CROUCH =
        SynchedEntityData.defineId(SoldierEntity.class, EntityDataSerializers.BOOLEAN);
    private static final EntityDataAccessor<Boolean> LOW_CROUCHING =
        SynchedEntityData.defineId(SoldierEntity.class, EntityDataSerializers.BOOLEAN);
    private static final EntityDataAccessor<Float> HALF_COVER_RISE_PROGRESS =
        SynchedEntityData.defineId(SoldierEntity.class, EntityDataSerializers.FLOAT);
    private static final EntityDataAccessor<Boolean> HALF_COVER_RISING =
        SynchedEntityData.defineId(SoldierEntity.class, EntityDataSerializers.BOOLEAN);
    private static final EntityDataAccessor<Boolean> RELOAD_PENDING =
        SynchedEntityData.defineId(SoldierEntity.class, EntityDataSerializers.BOOLEAN);
    private static final EntityDataAccessor<Boolean> TACTICAL_RELOADING =
        SynchedEntityData.defineId(SoldierEntity.class, EntityDataSerializers.BOOLEAN);
    private static final EntityDataAccessor<Boolean> ANIMATION_WEAPON_READY =
        SynchedEntityData.defineId(SoldierEntity.class, EntityDataSerializers.BOOLEAN);
    
    private static final EntityDataAccessor<Float> THREAT_DIR_X =
        SynchedEntityData.defineId(SoldierEntity.class, EntityDataSerializers.FLOAT);
    private static final EntityDataAccessor<Float> THREAT_DIR_Y =
        SynchedEntityData.defineId(SoldierEntity.class, EntityDataSerializers.FLOAT);
    private static final EntityDataAccessor<Float> THREAT_DIR_Z =
        SynchedEntityData.defineId(SoldierEntity.class, EntityDataSerializers.FLOAT);
    private static final EntityDataAccessor<String> DEBUG_CQB_PATH =
        SynchedEntityData.defineId(SoldierEntity.class, EntityDataSerializers.STRING);

    private static final EntityDataAccessor<Integer> FIRE_DISCIPLINE =
        SynchedEntityData.defineId(SoldierEntity.class, EntityDataSerializers.INT);

    private static final EntityDataAccessor<Integer> FIRE_TEAM =
        SynchedEntityData.defineId(SoldierEntity.class, EntityDataSerializers.INT);

    private static final EntityDataAccessor<String> YSM_MODEL_ID =
        SynchedEntityData.defineId(SoldierEntity.class, EntityDataSerializers.STRING);
    private static final EntityDataAccessor<String> YSM_TEXTURE_ID =
        SynchedEntityData.defineId(SoldierEntity.class, EntityDataSerializers.STRING);

    private static final EntityDataAccessor<String> SKIN =
        SynchedEntityData.defineId(SoldierEntity.class, EntityDataSerializers.STRING);

    private static final EntityDataAccessor<Integer> RECALL_TICKS =
        SynchedEntityData.defineId(SoldierEntity.class, EntityDataSerializers.INT);
    private static final EntityDataAccessor<BlockPos> MG_DEBUG_POSITION =
        SynchedEntityData.defineId(SoldierEntity.class, EntityDataSerializers.BLOCK_POS);
    private static final EntityDataAccessor<BlockPos> MG_DEBUG_CENTER =
        SynchedEntityData.defineId(SoldierEntity.class, EntityDataSerializers.BLOCK_POS);
    private static final EntityDataAccessor<Float> MG_DEBUG_ACCESS =
        SynchedEntityData.defineId(SoldierEntity.class, EntityDataSerializers.FLOAT);
    private static final EntityDataAccessor<Integer> MG_DEBUG_POSTURE =
        SynchedEntityData.defineId(SoldierEntity.class, EntityDataSerializers.INT);
    private static final EntityDataAccessor<Boolean> MG_DEBUG_ACTIVE =
        SynchedEntityData.defineId(SoldierEntity.class, EntityDataSerializers.BOOLEAN);
    private static final EntityDataAccessor<Boolean> MG_DEBUG_SUPPRESSED =
        SynchedEntityData.defineId(SoldierEntity.class, EntityDataSerializers.BOOLEAN);
    private static final EntityDataAccessor<BlockPos> MG_DEBUG_MOVEMENT_POSITION =
        SynchedEntityData.defineId(SoldierEntity.class, EntityDataSerializers.BLOCK_POS);
    private static final EntityDataAccessor<Boolean> MG_DEBUG_FALLBACK =
        SynchedEntityData.defineId(SoldierEntity.class, EntityDataSerializers.BOOLEAN);

    /** Mirror of the sidearm slot for clients; the back-weapon layer draws this while it is not held. */
    private static final EntityDataAccessor<ItemStack> DATA_STOWED_WEAPON =
        SynchedEntityData.defineId(SoldierEntity.class, EntityDataSerializers.ITEM_STACK);

    private static final int HALF_COVER_RISE_TICKS = 8;
    private static final int NAVIGATION_LANDING_LOCK_TICKS = 4;
    private static final int NAVIGATION_COLLISION_LOCK_TICKS = 2;

    /** How long a NEUTRAL-marked attacker stays a valid retaliation target. */
    private static final int NEUTRAL_RETALIATION_TICKS = 200;

    @Nullable
    private UUID squadId;
    @Nullable
    protected BlockPos defendPosition;
    private long grenadeCooldownUntilTick;
    private SquadFormation squadFormation = SquadFormation.NONE;
    @Nullable
    private BlockPos formationOffset;
    @Nullable
    private LivingEntity cachedOwner;
    private final SoldierInventory inventory;
    private final SoldierInventoryHandler inventoryHandler;
    private final LazyOptional<IItemHandler> itemHandlerCap;
    
    protected CombatGoalController combatGoal;
    protected Goal combatGoalTask;
    private CoverBehaviorManager coverBehaviorManager;
    private PeekController peekController;
    protected CoverGoalController coverTacticalGoal;
    protected Goal coverTacticalGoalTask;
    /** Set by the vehicle crew goal while it holds a hull MG or periscope station. */
    private boolean vehicleCrewActive;
    private final ThreatAwareness threatAwareness;
    private final com.stevesarmy.entity.ai.TravelCrawlController travelCrawl;
    private final com.stevesarmy.entity.ai.SoldierMovementController movementController;
    private final GrenadeTacticalController grenadeTacticalController;
    private final SoldierHealController healController;
    
    private boolean healing = false;
    private int navigationTraversalLockUntilTick = -1;
    private int navigationTraversalHeightDelta;
    private String navigationTraversalLockReason = "none";

    /** FoF: last NEUTRAL-marked entity that damaged us, for the retaliation window. */
    @Nullable
    private LivingEntity neutralAttacker;
    private int neutralAttackerTick = Integer.MIN_VALUE;
    /** True when combat, rather than cover movement, owns the low-prone posture. */
    private boolean firingProne = false;
    /** Armed only by a low-crouch exit; prevents unrelated peek transitions from rising. */
    private boolean halfCoverRisePending;
    private int lastRotationTraceWriterTick = -1;
    private boolean hasRotationTraceSnapshot;
    private float lastRotationTraceYaw;
    private float lastRotationTraceBodyYaw;
    private float lastRotationTraceHeadYaw;
    private int lastPeekTraceSnapshotTick = -20;
    private SuppressionTracker.SuppressionState lastPeekTraceSuppressionState;
    private boolean lastPeekTraceEmergencyPosture;

    private BlockPos pingMoveTarget = null;
    private long pingMoveTimestamp = 0;
    private static final long PING_MOVE_MEMORY_MS = 15000;
    private boolean persistentGoTo = false;
    private boolean goToHolding = false;

    private int pingMoveGeneration = 0;

    private BlockPos attackTargetPos = null;
    private long attackTargetTimestamp = 0;
    private static final long ATTACK_MEMORY_MS = 60000;
    private int attackGeneration = 0;

    /** Cached advance-spine route for the current attack command; not persisted —
     * the owning goal rebuilds it per command and nulls it on reset. Exposed here
     * so the cover scorer (a different package) can read path-based progression. */
    private transient com.stevesarmy.entity.ai.pathfinding.AdvanceSpine attackSpine = null;

    public com.stevesarmy.entity.ai.pathfinding.AdvanceSpine getAttackSpine() {
        return attackSpine;
    }

    public void setAttackSpine(com.stevesarmy.entity.ai.pathfinding.AdvanceSpine spine) {
        this.attackSpine = spine;
    }

    private BlockPos pingThreatPos = null;
    private long pingThreatTimestamp = 0;
    private static final long PING_THREAT_MEMORY_MS = 20000;
    
    private BlockPos forcedTargetPos = null;
    private long forcedTargetTimestamp = 0;
    private static final long FORCED_TARGET_MEMORY_MS = 10000;
    
    private final SuppressionOrderController suppressionOrder = new SuppressionOrderController();
    private java.util.List<Vec3> suppressionAimPoints = new java.util.ArrayList<>();
    private Vec3 lastSuppressionAimPoint = null;
    public static final double SUPPRESSION_ZONE_RADIUS = 15.0;
    
    private boolean dispatchedBySend = false;
    private boolean inventorySyncingFromEntity = false;
    private boolean cqbMode = false;
    private boolean cqbEngagementHold = false;
    private long cqbHoldLatchedAtTick;
    private long cqbHoldLastShotTick;
    private long cqbHoldReleaseCooldownUntilTick;
    private boolean closeCombatContext = false;
    private long closeCombatContextRefreshedAtTick;
    private String lastSyncedCqbPath = null;
    /** Fire-pipeline gate/shot state; lazily created (see getter) because
     * registerGoals runs inside the superclass constructor. */
    private com.stevesarmy.combat.EngagementTelemetry engagementTelemetry;

    public static final double CQB_RANGE = 5.0;
    /** Radius around the remaining path within which a known enemy triggers caution steering. */
    public static final double CQB_CAUTION_RADIUS = 10.0;
    /** How long a close-combat context flag stays valid without a refresh from a threat-aware ticker. */
    private static final long CLOSE_COMBAT_CONTEXT_STALE_TICKS = 40;

    public boolean isDispatchedBySend() {
        return dispatchedBySend;
    }

    public boolean isCQB() {
        return cqbMode;
    }

    public void setCQB(boolean cqbMode) {
        this.cqbMode = cqbMode;
    }

    public boolean hasCloseRangeTarget() {
        if (this.getTarget() == null || !this.getTarget().isAlive()) return false;
        return this.distanceToSqr(this.getTarget()) < CQB_RANGE * CQB_RANGE;
    }

    public boolean isCqbEngagementHold() {
        return cqbEngagementHold;
    }

    private boolean vehicleEngagement;

    /**
     * True while the combat goal holds a live vehicle contact as its
     * engagement. Cover reads this to pause opportunistic re-selection; the
     * combat goal owns setting and clearing it.
     */
    public boolean isInVehicleEngagement() {
        return vehicleEngagement;
    }

    public void setVehicleEngagement(boolean vehicleEngagement) {
        this.vehicleEngagement = vehicleEngagement;
    }

    public void beginCqbEngagement() {
        if (cqbEngagementHold) return;
        cqbEngagementHold = true;
        cqbHoldLatchedAtTick = tickCount;
        cqbHoldLastShotTick = tickCount;
        // A full-cover peek return is the safety-critical movement here. Do not
        // clear it when close-range LOS is acquired during the duck-back.
        boolean returningToFullCover = getPeekController().isReturning()
            && getCoverBehaviorManager().getCurrentCover() != null
            && getCoverBehaviorManager().getCurrentCover().getType() == CoverType.FULL;
        if (returningToFullCover) return;

        // An approach that is about to reach protection finishes first: the
        // last step into cover beats engaging from the open. The hold flag is
        // already set, so the controller freezes the soldier the moment the
        // dock completes (or the threat closes inside the overrun range).
        if (moveControl instanceof com.stevesarmy.entity.ai.CoverPositionController ctrl
            && ctrl.shouldDeferCqbHold()) {
            return;
        }

        if (movementController != null && movementController.canBypassCqbHold()) {
            return;
        }

        getNavigation().stop();
        cancelCoverMovement();
        setZza(0.0F);
        setXxa(0.0F);
        setDeltaMovement(0.0D, getDeltaMovement().y, 0.0D);
    }

    public void endCqbEngagement() {
        cqbEngagementHold = false;
    }

    /** A burst started while the engagement hold is active — the hold is doing its job. */
    public void markCqbHoldShot() {
        cqbHoldLastShotTick = tickCount;
    }

    /** Ticks since the hold latched (or its last productive burst, whichever is newer). */
    public long cqbHoldTicksWithoutShot() {
        return tickCount - cqbHoldLastShotTick;
    }

    public void armCqbHoldReleaseCooldown() {
        cqbHoldReleaseCooldownUntilTick = tickCount + StevesArmyConfig.getCqbHoldReleaseCooldownTicks();
    }

    public boolean isCqbHoldReleaseCooldown() {
        return tickCount < cqbHoldReleaseCooldownUntilTick;
    }

    /**
     * True when the engagement hold should actually pin the legs: a live
     * point-blank threat (survival stop), or shot activity within the grace
     * window (stand to shoot / through burst gaps). A hold that cannot
     * produce fire past the grace never blocks movement - cover seeking
     * outranks a frozen stance with no burst.
     */
    public boolean cqbHoldFreezeEffective() {
        if (!cqbEngagementHold) return false;
        LivingEntity threat = getTarget();
        if (threat != null && threat.isAlive()
            && distanceToSqr(threat) <= StevesArmyConfig.getCqbOverrunRange() * StevesArmyConfig.getCqbOverrunRange()) {
            return true;
        }
        return tickCount - cqbHoldLastShotTick <= StevesArmyConfig.getCqbHoldFreezeGraceTicks();
    }

    /**
     * Threat-aware tickers refresh the close-combat context each tick; the flag
     * decays to false when no ticker runs (no combat goal, no threats).
     */
    public void refreshCloseCombatContext(boolean active) {
        this.closeCombatContext = active;
        this.closeCombatContextRefreshedAtTick = tickCount;
    }

    public boolean isInCloseCombatContext() {
        return closeCombatContext && (tickCount - closeCombatContextRefreshedAtTick) <= CLOSE_COMBAT_CONTEXT_STALE_TICKS;
    }

    public com.stevesarmy.combat.EngagementTelemetry getEngagementTelemetry() {
        if (engagementTelemetry == null) {
            engagementTelemetry = new com.stevesarmy.combat.EngagementTelemetry();
        }
        return engagementTelemetry;
    }

    public String getSyncedCqbPath() {
        return entityData.get(DEBUG_CQB_PATH);
    }

    private void syncCqbDebugPath() {
        Path path = getNavigation().getPath();
        if (path == null || path.isDone() || path.getNodeCount() == 0) {
            if (!"".equals(lastSyncedCqbPath)) {
                entityData.set(DEBUG_CQB_PATH, "");
                lastSyncedCqbPath = "";
            }
            return;
        }
        StringBuilder encoded = new StringBuilder();
        int start = Math.max(0, path.getNextNodeIndex());
        int end = Math.min(path.getNodeCount(), start + 12);
        for (int i = start; i < end; i++) {
            if (encoded.length() > 0) encoded.append('|');
            BlockPos p = path.getNode(i).asBlockPos();
            encoded.append(p.getX()).append(':').append(p.getY()).append(':').append(p.getZ());
        }
        String value = encoded.toString();
        if (!value.equals(lastSyncedCqbPath)) {
            entityData.set(DEBUG_CQB_PATH, value);
            lastSyncedCqbPath = value;
        }
    }

    public boolean isHealing() {
        return healing;
    }

    public SoldierHealController getHealController() {
        return healController;
    }

    public void setHealing(boolean healing) {
        this.healing = healing;
    }

    public SoldierEntity(EntityType<? extends SoldierEntity> type, Level level) {
        super(type, level);
        this.moveControl = new com.stevesarmy.entity.ai.CoverPositionController(this);
        this.setCanPickUpLoot(true);
        this.inventory = new SoldierInventory();
        this.inventoryHandler = new SoldierInventoryHandler(inventory);
        this.itemHandlerCap = LazyOptional.of(() -> inventoryHandler);
        this.coverBehaviorManager = new CoverBehaviorManager(this);
        this.peekController = new PeekController();
        this.threatAwareness = new ThreatAwareness();
        this.travelCrawl = new com.stevesarmy.entity.ai.TravelCrawlController(this);
        this.movementController = new com.stevesarmy.entity.ai.SoldierMovementController(this);
        this.grenadeTacticalController = new GrenadeTacticalController(this);
        this.healController = new SoldierHealController(this);
        this.inventory.setMainHandChangedCallback(stack -> {
            if (!this.level().isClientSide) {
                if (inventorySyncingFromEntity) return;
                boolean reloading = GunIntegration.isAnyGunLoaded() && GunIntegration.isReloading(this);
                if (reloading && !ItemStack.isSameItem(stack, getMainHandItem())) {
                    StevesArmyMod.LOGGER.info("[Soldier] Blocked gun swap during reload (callback)");
                    return;
                }
                // Share the inventory's stack instance with the hand slot so
                // TaCZ's per-shot/reload NBT writes land on the stack the
                // inventory shows; copying would strand them on an orphan.
                setItemSlot(EquipmentSlot.MAINHAND, stack);
                if (GunIntegration.isAnyGunLoaded() && !stack.isEmpty() && !reloading) {
                    GunIntegration.initialData(this);
                    GunIntegration.draw(this);
                }
            }
        });
        this.inventory.setSidearmChangedCallback(stack -> syncStowedWeaponData());
    }

    /**
     * Publishes the sidearm slot to clients as the stowed weapon. After a
     * weapon swap the not-held gun always ends up in the sidearm slot, so this
     * is all the back-weapon layer needs; server-side only, vanilla entity
     * data sync carries it the rest of the way.
     */
    private void syncStowedWeaponData() {
        if (this.level().isClientSide) return;
        entityData.set(DATA_STOWED_WEAPON, inventory.getItem(SoldierInventory.SLOT_SIDEARM).copy());
    }

    /** The gun currently stowed on the soldier's back (the sidearm slot mirror). */
    public ItemStack getStowedWeapon() {
        return entityData.get(DATA_STOWED_WEAPON);
    }

    @Override
    protected net.minecraft.world.entity.ai.navigation.PathNavigation createNavigation(Level level) {
        return new com.stevesarmy.entity.ai.SoldierGroundNavigation(this, level);
    }

    @Override
    protected void defineSynchedData() {
        super.defineSynchedData();
        this.entityData.define(OWNER_UUID, Optional.empty());
        this.entityData.define(FOLLOW_STATE, 1);
        this.entityData.define(SQUAD_MODE, SquadMode.FOLLOW.ordinal());
        this.entityData.define(HOLD_POSITION, BlockPos.ZERO);
        this.entityData.define(DEBUG_DETECTION_POINTS, 0f);
        this.entityData.define(DEBUG_IS_DETECTED, false);
        this.entityData.define(DEBUG_DISTANCE, 0f);
        this.entityData.define(DEBUG_HAS_LOS, false);
        this.entityData.define(DEBUG_IN_FOCUSED, false);
        this.entityData.define(DEBUG_TARGET_UUID, Optional.empty());
        
        this.entityData.define(COVER_STATE, 0);
        this.entityData.define(COVER_CURRENT_POS, BlockPos.ZERO);
        this.entityData.define(COVER_CURRENT_TYPE, 0);
        this.entityData.define(COVER_CURRENT_QUALITY, 0f);
        this.entityData.define(COVER_CURRENT_HEIGHT, 0f);
        this.entityData.define(COVER_TARGET_POS, BlockPos.ZERO);
        this.entityData.define(COVER_TARGET_TYPE, 0);
        this.entityData.define(COVER_TARGET_QUALITY, 0f);
        this.entityData.define(COVER_LAST_POS, BlockPos.ZERO);
        this.entityData.define(SUPPRESSION_LEVEL, 0f);
        this.entityData.define(SUPPRESSION_EVENT_SEQUENCE, 0);
        this.entityData.define(PEEK_STATE, 0);
        this.entityData.define(PEEK_POSITION, BlockPos.ZERO);
        this.entityData.define(LOW_CROUCHING, false);
        this.entityData.define(CORNER_PEEK_CROUCH, false);
        this.entityData.define(HALF_COVER_RISE_PROGRESS, 1.0f);
        this.entityData.define(HALF_COVER_RISING, false);
        this.entityData.define(RELOAD_PENDING, false);
        this.entityData.define(TACTICAL_RELOADING, false);
        this.entityData.define(ANIMATION_WEAPON_READY, false);
        this.entityData.define(THREAT_DIR_X, 0f);
        this.entityData.define(THREAT_DIR_Y, 0f);
        this.entityData.define(THREAT_DIR_Z, 0f);
        this.entityData.define(DEBUG_CQB_PATH, "");

        this.entityData.define(FIRE_DISCIPLINE, FireDiscipline.STANDARD.ordinal());

        this.entityData.define(FIRE_TEAM, FireTeam.ALPHA.ordinal());

        this.entityData.define(YSM_MODEL_ID, "");
        this.entityData.define(YSM_TEXTURE_ID, "");

        this.entityData.define(SKIN, "");

        this.entityData.define(RECALL_TICKS, 0);
        this.entityData.define(MG_DEBUG_POSITION, BlockPos.ZERO);
        this.entityData.define(MG_DEBUG_CENTER, BlockPos.ZERO);
        this.entityData.define(MG_DEBUG_ACCESS, 0.0f);
        this.entityData.define(MG_DEBUG_POSTURE, 0);
        this.entityData.define(MG_DEBUG_ACTIVE, false);
        this.entityData.define(MG_DEBUG_SUPPRESSED, false);
        this.entityData.define(MG_DEBUG_MOVEMENT_POSITION, BlockPos.ZERO);
        this.entityData.define(MG_DEBUG_FALLBACK, false);
        this.entityData.define(DATA_STOWED_WEAPON, ItemStack.EMPTY);
    }

    @Override
    protected void registerGoals() {
        initializeCombatGoal();
        
        this.goalSelector.addGoal(0, new SoldierHoleRescueGoal(this));
        this.goalSelector.addGoal(0, new FloatGoal(this));
        this.goalSelector.addGoal(1, new com.stevesarmy.entity.ai.VehicleBoardingGoal(this));
        this.goalSelector.addGoal(1, new OpenDoorGoal(this, true));
        this.goalSelector.addGoal(1, new SoldierMoveToPingGoal(this));
        initializeCoverTacticalGoal();
        this.goalSelector.addGoal(2, coverTacticalGoalTask);
        this.goalSelector.addGoal(3, new SoldierFollowOwnerGoal(this));
        this.goalSelector.addGoal(3, new SoldierHoldPositionGoal(this));
        this.goalSelector.addGoal(4, combatGoalTask);
        this.goalSelector.addGoal(5, new SoldierStrollGoal(this, 0.8D));
        this.goalSelector.addGoal(6, new LookAtPlayerGoal(this, Player.class, 8.0F));
        this.goalSelector.addGoal(7, new RandomLookAroundGoal(this));
    }

    /**
     * Stores the combat goal so cover and combat coordination use the same instance.
     * Subclasses with custom goal layouts must use this instead of constructing one directly.
     */
    protected Goal initializeCombatGoal() {
        SoldierCombatGoal goal = new SoldierCombatGoal(this);
        this.combatGoal = goal;
        this.combatGoalTask = goal;
        return goal;
    }

    /** Creates the shared cover goal instance used by squad cover coordination. */
    protected Goal initializeCoverTacticalGoal() {
        CoverTacticalGoal goal = new CoverTacticalGoal(this);
        this.coverTacticalGoal = goal;
        this.coverTacticalGoalTask = goal;
        return goal;
    }

    /** The default entity role is the rifleman pipeline. */
    public SoldierRole getRole() {
        return SoldierRole.RIFLEMAN;
    }

    /** True when this role should never peek from cover. Override for roles like support. */
    public boolean isPeekDisabled() {
        return false;
    }

    /** True while the vehicle crew goal holds a station (hull MG / periscope). */
    public boolean isVehicleCrewActive() {
        return vehicleCrewActive;
    }

    public void setVehicleCrewActive(boolean active) {
        this.vehicleCrewActive = active;
    }

    /** True while seated on a crew transport seat (VS2 keeps the seat, AI keeps ticking). */
    public boolean isCrewSeated() {
        return VS2Compat.isCrewSeated(this);
    }

    /**
     * Optional direction that a role prefers for cover evaluation. Riflemen keep
     * the default threat-based evaluation direction.
     */
    @Nullable
    public Vec3 getPreferredCoverEvaluationDirection() {
        return null;
    }

    /**
     * Sinks seated soldiers onto the cushion. The vanilla humanoid riding pose
     * draws the body ~0.75 above the rider origin, while Create's SeatEntity puts
     * the origin at seat-block-bottom + 0.2625 - so without this offset the body
     * hovers ~0.5 blocks above the seat. Used by both Create's server-side rider
     * placement and VS2's client render rebuild, so model and hitbox sink together.
     * Tunable: raise (toward 0) if soldiers sit too low, lower if they still hover.
     */
    private static final double SIT_SINK = -0.5;

    @Override
    public double getMyRidingOffset() {
        return SIT_SINK;
    }

    @Override
    public void addAdditionalSaveData(CompoundTag tag) {
        super.addAdditionalSaveData(tag);
        
        getOwnerUUID().ifPresent(uuid -> tag.putUUID("Owner", uuid));
        tag.putInt("FollowState", getFollowState());
        tag.putInt("SquadMode", getSquadMode().ordinal());
        tag.putBoolean("HasSquad", squadId != null);
        if (squadId != null) {
            tag.putUUID("SquadId", squadId);
        }
        tag.putLong("HoldPos", getHoldPosition().asLong());
        tag.put("Inventory", inventory.save());
        tag.putInt("FireDiscipline", getFireDiscipline().ordinal());
        tag.putInt("FireTeam", getFireTeam().ordinal());
        tag.putLong("GrenadeCooldownUntil", grenadeCooldownUntilTick);
        tag.putString("YsmModelId", getYsmModelId());
        tag.putString("YsmTextureId", getYsmTextureId());
        tag.putString("Skin", getSkin());
        VS2Compat.saveTransportState(this, tag);
    }

    @Override
    public void readAdditionalSaveData(CompoundTag tag) {
        super.readAdditionalSaveData(tag);
        if (tag.hasUUID("Owner")) {
            setOwnerUUID(tag.getUUID("Owner"));
        }
        setFollowState(tag.getInt("FollowState"));
        setSquadMode(SquadMode.values()[tag.getInt("SquadMode") % SquadMode.values().length]);
        if (tag.getBoolean("HasSquad")) {
            squadId = tag.getUUID("SquadId");
        }
        setHoldPosition(BlockPos.of(tag.getLong("HoldPos")));
        if (tag.contains("Inventory")) {
            inventory.load(tag.getCompound("Inventory"));
        }
        inventory.syncArmorToEntity(this);
        if (tag.contains("FireDiscipline")) {
            setFireDiscipline(FireDiscipline.values()[tag.getInt("FireDiscipline") % FireDiscipline.values().length]);
        }
        if (tag.contains("FireTeam")) {
            setFireTeam(FireTeam.values()[tag.getInt("FireTeam") % FireTeam.values().length]);
        }
        grenadeCooldownUntilTick = tag.getLong("GrenadeCooldownUntil");
        if (tag.contains("YsmModelId")) {
            setYsmModelId(tag.getString("YsmModelId"));
        }
        if (tag.contains("YsmTextureId")) {
            setYsmTextureId(tag.getString("YsmTextureId"));
        }
        if (tag.contains("Skin")) {
            setSkinRaw(tag.getString("Skin"));
        }
        VS2Compat.restoreTransportState(this, tag);
    }

    @Override
    public ItemStack getPickedResult(HitResult target) {
        inventory.syncFromEntity(this);

        for (int i = 0; i < inventory.getContainerSize(); i++) {
            InfiniteReserveAmmo.stripInfiniteReserveNbt(inventory.getItem(i));
        }

        ItemStack stack = new ItemStack(getPickBlockEggItem());
        CompoundTag tag = new CompoundTag();
        tag.put("Inventory", inventory.save());
        tag.putInt("Role", getRole().ordinal());
        tag.putInt("FollowState", getFollowState());
        tag.putInt("SquadMode", getSquadMode().ordinal());
        UUID squadId = getSquadId();
        if (squadId != null) {
            tag.putBoolean("HasSquad", true);
            tag.putUUID("SquadId", squadId);
        }
        BlockPos holdPos = getHoldPosition();
        if (holdPos != null) {
            tag.putLong("HoldPos", holdPos.asLong());
        }
        if (defendPosition != null) {
            tag.putLong("DefendPosition", defendPosition.asLong());
        }
        tag.putInt("FireTeam", getFireTeam().ordinal());
        tag.putInt("FireDiscipline", getFireDiscipline().ordinal());
        tag.putString("YsmModelId", getYsmModelId());
        tag.putString("YsmTextureId", getYsmTextureId());

        stack.getOrCreateTag().put("EntityTag", tag);
        return stack;
    }

    /**
     * The spawn egg that pick-blocking this soldier yields. Subclasses may
     * override to surface a different egg (e.g. the team garrison egg).
     */
    protected Item getPickBlockEggItem() {
        return switch (getRole()) {
            case RIFLEMAN -> ModItems.SOLDIER_SPAWN_EGG.get();
            case MACHINE_GUNNER -> ModItems.MACHINE_GUNNER_SPAWN_EGG.get();
            case GARRISON -> ModItems.GARRISON_SPAWN_EGG.get();
            case SUPPORT -> ModItems.SUPPORT_SPAWN_EGG.get();
            case VEHICLE_CREW -> ModItems.VEHICLE_CREW_SPAWN_EGG.get();
            case ANTI_TANK -> ModItems.ANTI_TANK_SPAWN_EGG.get();
        };
    }

    /**
     * Restores the persistent soldier state carried by a pick-blocked spawn egg.
     * Position is not touched; the caller places the entity. Ownership and squad
     * membership are deliberately not restored — the player spawning the egg
     * becomes the owner via {@link SoldierSpawner#finishSpawn}, so a traded or
     * cloned egg never stays loyal to the player it was picked from.
     */
    public void fillFromPickBlockData(CompoundTag entityTag) {
        if (entityTag.contains("FollowState")) {
            setFollowState(entityTag.getInt("FollowState"));
        }
        if (entityTag.contains("SquadMode")) {
            int modeOrdinal = entityTag.getInt("SquadMode");
            SquadMode[] modes = SquadMode.values();
            if (modeOrdinal >= 0 && modeOrdinal < modes.length) {
                setSquadMode(modes[modeOrdinal]);
            }
        }
        if (entityTag.contains("HoldPos")) {
            setHoldPosition(BlockPos.of(entityTag.getLong("HoldPos")));
        }
        if (entityTag.contains("DefendPosition")) {
            setDefendPosition(BlockPos.of(entityTag.getLong("DefendPosition")));
        }
        if (entityTag.contains("FireTeam")) {
            int ordinal = entityTag.getInt("FireTeam");
            FireTeam[] teams = FireTeam.values();
            if (ordinal >= 0 && ordinal < teams.length) {
                setFireTeam(teams[ordinal]);
            }
        }
        if (entityTag.contains("FireDiscipline")) {
            int ordinal = entityTag.getInt("FireDiscipline");
            FireDiscipline[] disciplines = FireDiscipline.values();
            if (ordinal >= 0 && ordinal < disciplines.length) {
                setFireDiscipline(disciplines[ordinal]);
            }
        }
        if (entityTag.contains("YsmModelId")) {
            setYsmModelId(entityTag.getString("YsmModelId"));
        }
        if (entityTag.contains("YsmTextureId")) {
            setYsmTextureId(entityTag.getString("YsmTextureId"));
        }
        if (entityTag.contains("Inventory")) {
            inventory.load(entityTag.getCompound("Inventory"));
            inventory.syncArmorToEntity(this);
        }
    }

    @Override
    public InteractionResult mobInteract(Player player, InteractionHand hand) {
        // Knives handle their own interaction on the item (YSM editor, skin menu);
        // pass so the held item always receives the click.
        if (player.getItemInHand(hand).is(ModItems.SURGICAL_KNIFE.get())
            || player.getItemInHand(hand).is(ModItems.SKIN_KNIFE.get())) {
            return InteractionResult.PASS;
        }
        // Creative players may inspect the inventory of any soldier, regardless of ownership.
        boolean canOpenInventory = isOwnedBy(player) || player.getAbilities().instabuild;
        if (canOpenInventory && player.isShiftKeyDown()) {
            if (!this.level().isClientSide && player instanceof ServerPlayer serverPlayer) {
                com.stevesarmy.inventory.SoldierInventoryMenuProvider provider =
                    new com.stevesarmy.inventory.SoldierInventoryMenuProvider(this);
                net.minecraftforge.network.NetworkHooks.openScreen(serverPlayer,
                    provider,
                    provider::writeExtraData);
            }
            return InteractionResult.sidedSuccess(this.level().isClientSide);
        }
        return super.mobInteract(player, hand);
    }

    @Nullable
    public LivingEntity getOwner() {
        Optional<UUID> ownerUUID = getOwnerUUID();
        if (ownerUUID.isEmpty()) {
            return null;
        }
        
        UUID uuid = ownerUUID.get();
        if (cachedOwner != null
            && cachedOwner.getUUID().equals(uuid)
            && cachedOwner.isAlive()
            && !cachedOwner.isRemoved()
            && cachedOwner.level() == this.level()) {
            return cachedOwner;
        }

        cachedOwner = null;
        
        if (this.level() instanceof ServerLevel serverLevel) {
            Entity entity = serverLevel.getEntity(uuid);
            if (entity instanceof LivingEntity livingEntity
                && livingEntity.isAlive()
                && !livingEntity.isRemoved()) {
                cachedOwner = livingEntity;
                return cachedOwner;
            }
        }
        return null;
    }

    public Optional<UUID> getOwnerUUID() {
        return this.entityData.get(OWNER_UUID);
    }

    public void setOwnerUUID(UUID uuid) {
        this.entityData.set(OWNER_UUID, Optional.of(uuid));
        this.cachedOwner = null;
    }

    public boolean isOwnedBy(Player player) {
        return getOwnerUUID().map(uuid -> uuid.equals(player.getUUID())).orElse(false);
    }

    public int getFollowState() {
        return this.entityData.get(FOLLOW_STATE);
    }

    public void setFollowState(int state) {
        this.entityData.set(FOLLOW_STATE, state);
    }

    public SquadMode getSquadMode() {
        return SquadMode.values()[this.entityData.get(SQUAD_MODE) % SquadMode.values().length];
    }

    public void setSquadMode(SquadMode mode) {
        this.entityData.set(SQUAD_MODE, mode.ordinal());
        
        if (mode == SquadMode.HOLD && getOwner() != null) {
            setHoldPosition(blockPosition());
        }
    }

    public FireDiscipline getFireDiscipline() {
        return FireDiscipline.values()[this.entityData.get(FIRE_DISCIPLINE) % FireDiscipline.values().length];
    }

    public void setFireDiscipline(FireDiscipline discipline) {
        this.entityData.set(FIRE_DISCIPLINE, discipline.ordinal());
    }

    public FireTeam getFireTeam() {
        return FireTeam.values()[this.entityData.get(FIRE_TEAM) % FireTeam.values().length];
    }

    public void setFireTeam(FireTeam team) {
        this.entityData.set(FIRE_TEAM, team.ordinal());
    }

    public String getYsmModelId() {
        return this.entityData.get(YSM_MODEL_ID);
    }

    public void setYsmModelId(String modelId) {
        this.entityData.set(YSM_MODEL_ID, modelId);
    }

    public String getYsmTextureId() {
        return this.entityData.get(YSM_TEXTURE_ID);
    }

    public void setYsmTextureId(String textureId) {
        this.entityData.set(YSM_TEXTURE_ID, textureId);
    }

    public boolean hasYsmModel() {
        return !getYsmModelId().isEmpty();
    }

    public String getSkin() {
        return this.entityData.get(SKIN);
    }

    /** Sets a custom skin by name; unknown names are ignored and keep the default. */
    public void setSkin(String name) {
        if (name == null || name.isEmpty()) {
            this.entityData.set(SKIN, "");
        } else if (SoldierSkinManager.isKnown(name)) {
            this.entityData.set(SKIN, name);
        } else {
            StevesArmyMod.LOGGER.warn("[Skins] Ignoring unknown skin '{}' for {}", name, getUUID());
        }
    }

    /** Sets the skin without validation (NBT load of a skin whose file is temporarily missing). */
    public void setSkinRaw(String name) {
        this.entityData.set(SKIN, name == null ? "" : name);
    }

    /** Picks a random folder skin for newly spawned soldiers when skins.randomizeOnSpawn is enabled. */
    public void maybeRandomizeSkin() {
        if (!StevesArmyConfig.isSkinRandomizeOnSpawn()) {
            return;
        }
        String skin = SoldierSkinManager.randomSkinName();
        if (skin != null) {
            setSkinRaw(skin);
        }
    }

    public int getRecallTicks() {
        return this.entityData.get(RECALL_TICKS);
    }

    public boolean isRecalling() {
        return getRecallTicks() > 0;
    }

    public void setRecallTicks(int ticks) {
        this.entityData.set(RECALL_TICKS, ticks);
    }

    public void startRecall() {
        setRecallTicks(80);
        this.getNavigation().stop();
    }

    public void cancelRecall() {
        setRecallTicks(0);
    }

    @Override
    public Component getDisplayName() {
        FireTeam team = getFireTeam();
        if (team == FireTeam.ALL) {
            return super.getDisplayName();
        }
        return Component.literal("[" + team.getShortName() + "] ").append(super.getDisplayName());
    }

    public BlockPos getHoldPosition() {
        return this.entityData.get(HOLD_POSITION);
    }

    public void setHoldPosition(BlockPos pos) {
        this.entityData.set(HOLD_POSITION, pos);
    }

    @Nullable
    public BlockPos getDefendPosition() {
        return defendPosition;
    }

    public void setDefendPosition(@Nullable BlockPos pos) {
        this.defendPosition = pos;
    }

    public double getDefendRadius() {
        return 20.0;
    }

    @Nullable
    public UUID getSquadId() {
        return squadId;
    }

    public void setSquadId(UUID squadId) {
        this.squadId = squadId;
    }

    public SquadFormation getSquadFormation() {
        return squadFormation;
    }

    public void setSquadFormation(SquadFormation formation) {
        this.squadFormation = formation;
    }

    @Nullable
    public BlockPos getFormationOffset() {
        return formationOffset;
    }

    public void setFormationOffset(@Nullable BlockPos offset) {
        this.formationOffset = offset;
    }

    public void clearFormationOffset() {
        this.formationOffset = null;
    }

    @Override
    public boolean canBeLeashed(Player player) {
        return false;
    }

    @Override
    protected boolean canRide(Entity vehicle) {
        return VS2Compat.isAuthorizedMount(this, vehicle) || com.stevesarmy.compat.sbw.SbwCompat.isVehicle(vehicle);
    }

    @Override
    public boolean requiresCustomPersistence() {
        return true;
    }

    @Override
    public boolean removeWhenFarAway(double distanceToClosestPlayer) {
        return false;
    }

    @Override
    public boolean isAlliedTo(Entity other) {
        if (other instanceof LivingEntity living && isAlliedByTeam(living)) return true;
        LivingEntity owner = getOwner();
        if (owner != null && owner.isAlliedTo(other)) return true;
        return super.isAlliedTo(other);
    }

    @Override
    public boolean canAttack(LivingEntity target) {
        // An explicit HOSTILE mark beats team/owner alliance (traitor-teammate case).
        if (target != this && getFofOverride(target) == FofStance.HOSTILE) {
            return super.canAttack(target);
        }
        if (target instanceof SoldierEntity soldier && soldier.getOwnerUUID().equals(this.getOwnerUUID())) {
            return false;
        }
        if (isAlliedByTeam(target)) {
            return false;
        }
        LivingEntity owner = getOwner();
        if (owner != null && target == owner) {
            return false;
        }
        if (owner != null && target instanceof Player targetPlayer && owner.isAlliedTo(targetPlayer)) {
            return false;
        }
        if (target instanceof SoldierEntity targetSoldier) {
            LivingEntity targetOwner = targetSoldier.getOwner();
            if (owner != null && targetOwner != null && owner.isAlliedTo(targetOwner)) {
                return false;
            }
        }
        return super.canAttack(target);
    }

    /** True when the other entity shares the soldier's (or owner's) scoreboard team. */
    private boolean isAlliedByTeam(LivingEntity other) {
        Team otherTeam = other instanceof SoldierEntity soldier
            ? TeamManager.getEffectiveTeam(soldier) : other.getTeam();
        if (otherTeam == null) return false;
        Team soldierTeam = TeamManager.getEffectiveTeam(this);
        if (soldierTeam != null && soldierTeam.isAlliedTo(otherTeam)) return true;
        LivingEntity owner = getOwner();
        Team ownerTeam = owner != null ? owner.getTeam() : null;
        return ownerTeam != null && ownerTeam.isAlliedTo(otherTeam);
    }
    
    /**
     * Explicit FoF stance this soldier's owner marked on other, or null when
     * the built-in default rules apply. Server side only; client-side calls
     * (rendering, prediction) fall back to the defaults.
     */
    @Nullable
    public FofStance getFofOverride(LivingEntity other) {
        if (this.level().isClientSide) return null;
        MinecraftServer server = this.level().getServer();
        if (server == null) return null;
        Optional<UUID> ownerUUID = getOwnerUUID();
        if (ownerUUID.isEmpty()) return null;
        return FofSettings.resolveStance(server, ownerUUID.get(), other);
    }

    /**
     * Whether this soldier may proactively hunt the candidate. NEUTRAL-marked
     * entities are left alone until they attack us; every other entity
     * follows the default rules.
     */
    public boolean isProactiveTarget(LivingEntity candidate) {
        if (getFofOverride(candidate) != FofStance.NEUTRAL) return true;
        return candidate == neutralAttacker
            && this.tickCount - neutralAttackerTick <= NEUTRAL_RETALIATION_TICKS;
    }

    /** Category targeting gate: an explicit FoF stance replaces the config default. */
    public boolean fofCategoryAllows(FofCategory category, boolean configDefault) {
        if (this.level().isClientSide) return configDefault;
        MinecraftServer server = this.level().getServer();
        if (server == null) return configDefault;
        Optional<UUID> ownerUUID = getOwnerUUID();
        if (ownerUUID.isEmpty()) return configDefault;
        FofSettings.OwnerFof fof = FofSettings.get(server).peek(ownerUUID.get());
        FofStance override = fof != null ? fof.resolveCategory(category) : null;
        if (override == null) return configDefault;
        return override != FofStance.FRIENDLY;
    }

    public boolean isFriendlyTo(LivingEntity other) {
        if (other == this) return false;

        // Explicit per-owner FoF overrides sit above the default rules below.
        // FRIENDLY protects even team enemies; HOSTILE engages even team allies;
        // NEUTRAL falls through as non-friendly (retaliation still works) and
        // is kept out of proactive targeting by isProactiveTarget.
        FofStance override = getFofOverride(other);
        if (override == FofStance.FRIENDLY) return true;
        if (override == FofStance.HOSTILE) return false;

        if (isAlliedByTeam(other)) return true;
        
        LivingEntity owner = getOwner();
        if (other == owner) return true;
        
        Optional<UUID> myOwner = getOwnerUUID();
        if (myOwner.isPresent()) {
            if (other instanceof Player otherPlayer) {
                if (otherPlayer.getUUID().equals(myOwner.get())) return true;
                if (owner != null && owner.isAlliedTo(otherPlayer)) return true;
            }
        }
        
        if (other instanceof SoldierEntity otherSoldier) {
            Optional<UUID> theirOwner = otherSoldier.getOwnerUUID();
            if (myOwner.isPresent() && theirOwner.isPresent() 
                && myOwner.get().equals(theirOwner.get())) return true;
            if (owner != null) {
                LivingEntity theirOwnerEntity = otherSoldier.getOwner();
                if (theirOwnerEntity != null) {
                    if (owner.isAlliedTo(theirOwnerEntity)) return true;
                    Team ownerTeam = owner.getTeam();
                    Team theirTeam = theirOwnerEntity.getTeam();
                    if (ownerTeam != null && theirTeam != null
                        && ownerTeam.getName().startsWith("steves_army_friendly_")
                        && theirTeam.getName().startsWith("steves_army_friendly_")) {
                        return true;
                    }
                }
            }
        }
        
        return false;
    }

    @Override
    protected void dropEquipment() {
    }

    @Override
    public boolean canPickUpLoot() {
        return true;
    }

    @Override
    public boolean canHoldItem(ItemStack stack) {
        // Soldiers never swallow supply pouches; the pouch must stay intact for
        // players. AI resupply happens via thrown pouches instead.
        if (stack.getItem() instanceof com.stevesarmy.item.SupplyPouchItem) {
            return false;
        }
        return true;
    }

    @Override
    protected void pickUpItem(ItemEntity itemEntity) {
        ItemStack stack = itemEntity.getItem();
        int count = stack.getCount();
        boolean pickedGun = GunIntegration.isGun(stack);
        boolean pickedLauncher = pickedGun && com.stevesarmy.combat.ArmorRoleManager.isAtGunStack(stack);

        // Try to put in an existing partial stack in bag slots first
        for (int i = SoldierInventory.SLOT_GENERAL_START; i < inventory.getContainerSize(); i++) {
            ItemStack existing = inventory.getItem(i);
            if (!existing.isEmpty() && ItemStack.isSameItemSameTags(existing, stack)) {
                int space = Math.min(existing.getMaxStackSize(), 64) - existing.getCount();
                if (space > 0) {
                    int toAdd = Math.min(count, space);
                    existing.grow(toAdd);
                    inventory.setChanged();
                    count -= toAdd;
                    if (count <= 0) {
                        itemEntity.discard();
                        return;
                    }
                }
            }
        }
        
        // Try bag slots for empty slots
        for (int i = SoldierInventory.SLOT_GENERAL_START; i < inventory.getContainerSize(); i++) {
            if (inventory.getItem(i).isEmpty()) {
                ItemStack toInsert = stack.split(count);
                inventory.setItem(i, toInsert);
                inventory.setChanged();
                itemEntity.discard();
                if (pickedGun) {
                    onGunPickedUp(pickedLauncher);
                }
                return;
            }
        }
        
        // The main hand is reserved for firearms. Do not let vanilla pickup
        // behavior replace a soldier's gun with a knife or other item.
        ItemStack mainHand = inventory.getItem(SoldierInventory.SLOT_MAIN_HAND);
        if (mainHand.isEmpty() && pickedGun) {
            ItemStack toInsert = stack.split(count);
            inventory.setItem(SoldierInventory.SLOT_MAIN_HAND, toInsert);
            inventory.setChanged();
            itemEntity.discard();
            onGunPickedUp(pickedLauncher);
            return;
        }
    }

    /**
     * After a gun lands in the inventory, re-slot guns into the standard
     * layout; picking up a launcher turns an owned non-AT soldier into an
     * AT soldier with the launcher stowed in the sidearm slot.
     */
    private void onGunPickedUp(boolean launcherPicked) {
        if (level().isClientSide) {
            return;
        }
        if (launcherPicked && getRole() != SoldierRole.ANTI_TANK && getRole() != SoldierRole.GARRISON
            && !(this instanceof TeamGarrisonEntity) && getOwnerUUID().isPresent()) {
            SoldierEntity replacement = SoldierRoleHandler.convertSoldier(this, SoldierRole.ANTI_TANK);
            if (replacement != null) {
                com.stevesarmy.combat.SoldierWeaponSelector.normalizeGunSlots(replacement);
                return;
            }
        }
        com.stevesarmy.combat.SoldierWeaponSelector.normalizeGunSlots(this);
    }

    /**
     * Drop guns and one carried ammo stack per caliber loose, with the rest in
     * a pouch. Only the persistent inventory is used, never mirrored equipment.
     */
    @Override
    protected void dropCustomDeathLoot(net.minecraft.world.damagesource.DamageSource source,
                                       int lootingLevel, boolean recentlyHit) {
        if (!StevesArmyConfig.isSoldierDeathDropsEnabled()) {
            return;
        }
        List<ItemStack> guns = new ArrayList<>();
        boolean[] loose = new boolean[inventory.getContainerSize()];
        for (int i = 0; i < inventory.getContainerSize(); i++) {
            ItemStack stack = inventory.getItem(i);
            InfiniteReserveAmmo.stripInfiniteReserveNbt(stack);
            if (GunIntegration.isGun(stack)) {
                guns.add(stack);
                loose[i] = true;
            }
        }

        // Prefer ordinary ammo over boxes, without making TaCZ a required dependency.
        Class<?> ammoBoxClass = null;
        try {
            ammoBoxClass = Class.forName("com.tacz.guns.api.item.IAmmoBox");
        } catch (ClassNotFoundException ignored) {
        }
        java.util.Set<String> ammoTypes = new java.util.HashSet<>();
        for (ItemStack gun : guns) {
            String ammoId = GunIntegration.getAmmoId(gun);
            if (ammoId.isEmpty() || !ammoTypes.add(ammoId)) continue;
            int boxSlot = -1;
            int ammoSlot = -1;
            for (int i = 0; i < inventory.getContainerSize(); i++) {
                ItemStack stack = inventory.getItem(i);
                if (loose[i] || GunIntegration.getAmmoCountForGun(gun, stack) <= 0) continue;
                if (ammoBoxClass != null && ammoBoxClass.isInstance(stack.getItem())) {
                    if (boxSlot < 0) boxSlot = i;
                } else {
                    ammoSlot = i;
                    break;
                }
            }
            int selected = ammoSlot >= 0 ? ammoSlot : boxSlot;
            if (selected >= 0) loose[selected] = true;
        }

        SoldierInventory pouchInventory = new SoldierInventory();
        for (int i = 0; i < inventory.getContainerSize(); i++) {
            ItemStack stack = inventory.getItem(i);
            if (stack.isEmpty()) continue;
            if (loose[i]) {
                spawnAtLocation(stack.copy());
            } else {
                pouchInventory.setItem(i, stack.copy());
            }
        }
        if (!pouchInventory.isEmpty()) {
            com.stevesarmy.inventory.PouchContainer.dropInventoryAsPouch(this, pouchInventory);
        }
        for (int i = 0; i < inventory.getContainerSize(); i++) {
            inventory.setItem(i, ItemStack.EMPTY);
        }
    }

    public SoldierInventory getSoldierInventory() {
        return inventory;
    }

    public GrenadeTacticalController getGrenadeTacticalController() {
        return grenadeTacticalController;
    }

    @Nullable
    public SquadThreatIntel getGrenadeSquadIntel() {
        if (squadId == null || !(level() instanceof ServerLevel serverLevel)) return null;
        return SquadManager.get(serverLevel).getSquadById(squadId)
            .map(com.stevesarmy.squad.SquadData::getThreatIntel).orElse(null);
    }

    private boolean shouldTickGrenadeController(long gameTime) {
        if (grenadeTacticalController.isActive()
            || DiagnosticLogManager.isAttackLoggingEnabled()
            || DiagnosticLogManager.isGrenadeLoggingEnabled()) {
            return true;
        }
        // The shared arc scheduler limits expensive world simulations to one
        // complete request per server tick. Let controllers submit requests on
        // every tick so the queue is responsive instead of adding another
        // ten-tick delay before a soldier can enter it.
        return GrenadeIntegration.findSupportedSlot(inventory) >= 0;
    }

    public boolean canUseGrenade(long gameTime) {
        return gameTime >= grenadeCooldownUntilTick;
    }

    public long getGrenadeCooldownUntilTick() {
        return grenadeCooldownUntilTick;
    }

    public void markGrenadeUsed(long gameTime) {
        grenadeCooldownUntilTick = gameTime + com.stevesarmy.StevesArmyConfig.getGrenadePersonalCooldownTicks();
    }

    @Override
    public int getContainerSize() {
        return inventory.getContainerSize();
    }

    @Override
    public boolean isEmpty() {
        return inventory.isEmpty();
    }

    @Override
    public ItemStack getItem(int slot) {
        return inventory.getItem(slot);
    }

    @Override
    public ItemStack removeItem(int slot, int amount) {
        return inventory.removeItem(slot, amount);
    }

    @Override
    public ItemStack removeItemNoUpdate(int slot) {
        return inventory.removeItemNoUpdate(slot);
    }

    @Override
    public void setItem(int slot, ItemStack stack) {
        boolean reloading = GunIntegration.isAnyGunLoaded() && GunIntegration.isReloading(this);
        if (slot == SoldierInventory.SLOT_MAIN_HAND && reloading && !ItemStack.isSameItem(stack, getMainHandItem())) {
            StevesArmyMod.LOGGER.info("[Soldier] Blocked gun swap during reload (setItem)");
            return;
        }
        inventory.setItem(slot, stack);
        if (slot == SoldierInventory.SLOT_MAIN_HAND) {
            setItemSlot(EquipmentSlot.MAINHAND, stack);
            if (GunIntegration.isAnyGunLoaded() && !stack.isEmpty() && !reloading) {
                GunIntegration.initialData(this);
                GunIntegration.draw(this);
            }
        }
    }

    @Override
    public void setChanged() {
        inventory.setChanged();
    }

    @Override
    public void clearContent() {
        inventory.clearContent();
        setItemSlot(EquipmentSlot.MAINHAND, ItemStack.EMPTY);
    }

    @Override
    public void setItemSlot(EquipmentSlot slot, ItemStack stack) {
        super.setItemSlot(slot, stack);
        inventorySyncingFromEntity = true;
        try {
            if (slot == EquipmentSlot.MAINHAND) {
                // Share the instance (not a copy) so the persistent slot and
                // the hand are always the same stack; see the main-hand callback.
                inventory.setItem(SoldierInventory.SLOT_MAIN_HAND, stack);
            } else if (slot.getType() == EquipmentSlot.Type.ARMOR) {
                int invSlot;
                switch (slot) {
                    case HEAD -> invSlot = SoldierInventory.ARMOR_HEAD;
                    case CHEST -> invSlot = SoldierInventory.ARMOR_CHEST;
                    case LEGS -> invSlot = SoldierInventory.ARMOR_LEGS;
                    default -> invSlot = SoldierInventory.ARMOR_FEET;
                }
                inventory.setItem(invSlot, stack.copy());
            }
        } finally {
            inventorySyncingFromEntity = false;
        }
    }

    @Override
    public boolean stillValid(Player player) {
        return this.isAlive() && this.distanceTo(player) <= 64.0F;
    }

    public void tick() {
        if (!this.level().isClientSide) {
            movementController.beginTick();
            travelCrawl.tick();
        }
        super.tick();
        if (this.level().isClientSide) {
            com.stevesarmy.network.SyncSoldierInventoryPacket.applyPendingInventory(this);
            tickCrawlRenderAmount();
        }
        
        if (!this.level().isClientSide) {
            GunIntegration.tick(this);
            syncCqbDebugPath();
            threatAwareness.tick();
            holdMovementForReload();
            updateCrawlFacing();
            movementController.finishTick();
            // Reload and cover helpers may hold navigation and update their own
            // crouch state. A live firing-prone plan remains the authoritative
            // posture until that plan explicitly cancels it.
            if (firingProne && !entityData.get(LOW_CROUCHING)) {
                setLowCrouching(true);
            }
            tickHalfCoverRiseProgress();
            tickAnimationWeaponReady();
            traceRotationSnapshot();
            tracePeekSnapshot();
        }

        // Swimming is also our prone pose. Keep the synchronized posture clear
        // while riding an SBW vehicle so old combat/cover plans cannot make a
        // seated soldier lie across the vehicle model.
        if (isMountedInSbwVehicle()) {
            firingProne = false;
            if (entityData.get(LOW_CROUCHING)) {
                entityData.set(LOW_CROUCHING, false);
            }
            if (getPose() == Pose.SWIMMING) {
                setPose(Pose.STANDING);
                refreshDimensions();
            }
        }

        // Enforce the server-synced posture every tick to fight vanilla pose overrides.
        // Suppression recovery is owned by CoverTacticalGoal, not this entity tick.
        if (entityData.get(LOW_CROUCHING)) {
            if (this.getPose() != Pose.SWIMMING) {
                this.setPose(Pose.SWIMMING);
                this.refreshDimensions();
            }
        } else {
            // Read synced data so the client knows what the server is doing
            int coverState = getSyncedCoverState();
            boolean inCover = coverState == CoverBehaviorManager.CoverState.IN_COVER.ordinal() 
                           || coverState == CoverBehaviorManager.CoverState.SUPPRESSED_IN_COVER.ordinal();
            boolean isHalfCover = getSyncedCoverCurrentType() == CoverType.HALF.ordinal();

            if (entityData.get(CORNER_PEEK_CROUCH)) {
                if (this.getPose() != Pose.CROUCHING) {
                    this.setPose(Pose.CROUCHING);
                    this.refreshDimensions();
                }
            } else if (inCover && isHalfCover) {
                Pose coverPose = isHalfCoverRising() ? Pose.CROUCHING
                    : getSyncedCoverCurrentHeight() >= 1.3f
                    ? Pose.STANDING : Pose.CROUCHING;
                if (this.getPose() != coverPose) {
                    this.setPose(coverPose);
                    this.refreshDimensions();
                }
            } else {
                // Ensure they stand back up when leaving cover
                if (this.getPose() == Pose.CROUCHING || this.getPose() == Pose.SWIMMING) {
                    this.setPose(Pose.STANDING);
                    this.refreshDimensions();
                }
            }
        }

    }

    private Vec3 velocityBeforeTravel = Vec3.ZERO;

    private void tickAnimationWeaponReady() {
        if (isDeadOrDying()) {
            animationWeaponReadyHoldTicks = 0;
            entityData.set(ANIMATION_WEAPON_READY, false);
            return;
        }

        LivingEntity target = getTarget();
        boolean hasLiveTarget = target != null && target.isAlive();
        boolean isAiming = GunIntegration.isAnyGunLoaded()
            && GunIntegration.getAimProgress(this) > 0.0f;
        boolean combatReady = hasLiveTarget
            || (combatGoal != null && combatGoal.isSuppressing())
            || isAiming
            || isCornerPeekCrouching();

        if (combatReady) {
            animationWeaponReadyHoldTicks = ANIMATION_WEAPON_READY_HOLD_TICKS;
            entityData.set(ANIMATION_WEAPON_READY, true);
        } else if (animationWeaponReadyHoldTicks > 0) {
            animationWeaponReadyHoldTicks--;
            if (animationWeaponReadyHoldTicks == 0) {
                entityData.set(ANIMATION_WEAPON_READY, false);
            }
        }
    }

    public boolean isAnimationWeaponReady() {
        return entityData.get(ANIMATION_WEAPON_READY);
    }

    @Override
    public void travel(Vec3 input) {
        // LivingEntity.travel adds walking acceleration before calling move.
        // Only the velocity entering travel can identify an external impulse;
        // the accelerated velocity would exempt ordinary fast walking.
        velocityBeforeTravel = getDeltaMovement();
        try {
            super.travel(input);
            if (moveControl instanceof com.stevesarmy.entity.ai.CoverPositionController ctrl) {
                setDeltaMovement(ctrl.getSpeedController().finishTravel(getDeltaMovement()));
            }
        } finally {
            velocityBeforeTravel = Vec3.ZERO;
        }
    }

    @Override
    public void setPose(Pose pose) {
        if (pose == Pose.SWIMMING && isMountedInSbwVehicle()) {
            super.setPose(Pose.STANDING);
            refreshDimensions();
            return;
        }
        super.setPose(pose);
    }

    private boolean isMountedInSbwVehicle() {
        return isPassenger()
            && com.stevesarmy.compat.sbw.SbwCompat.isVehicle(getVehicle());
    }

    @Override
    public void knockback(double strength, double x, double z) {
        Vec3 before = getDeltaMovement();
        super.knockback(strength, x, z);
        if (moveControl instanceof com.stevesarmy.entity.ai.CoverPositionController ctrl
            && getDeltaMovement().subtract(before).horizontalDistanceSqr() > 1.0e-10) {
            ctrl.getSpeedController().markExternalImpulse();
        }
    }

    @Override
    public void move(net.minecraft.world.entity.MoverType type, Vec3 movement) {
        if (type == net.minecraft.world.entity.MoverType.SELF
            && moveControl instanceof com.stevesarmy.entity.ai.CoverPositionController ctrl) {
            Vec3 velocity = getDeltaMovement();
            boolean velocityMove = movement.distanceToSqr(velocity) < 1.0e-12;
            movement = ctrl.getSpeedController().limitSelfMovement(movement, velocityBeforeTravel);
            if (velocityMove) {
                // Vanilla travel applies drag to getDeltaMovement after move returns.
                // Feed it the bounded velocity, rather than retaining acceleration
                // that was never physically applied (including during knockback).
                setDeltaMovement(movement.x, velocity.y, movement.z);
            }
        }
        super.move(type, movement);
    }

    @Override
    protected void customServerAiStep() {
        // Suppression decay runs from the entity tick, not the cover goal, so it
        // continues while CoverTacticalGoal is preempted or on its restart
        // cooldown — a suppressed soldier must always converge back to reacting.
        if (coverBehaviorManager != null) {
            coverBehaviorManager.tickSuppression(coverBehaviorManager.isInCover());
        }
        suppressionOrder.tick(this);
        refreshAttackTargetUnderFire();
        tickCoverStuckWatchdog();
        if (tickCount % 10 == 0) {
            sendCoverStateDebugPacket();
        }

        long gameTime = level().getGameTime();
        if (com.stevesarmy.compat.sbw.SbwCompat.hasVehicles()) {
            com.stevesarmy.compat.sbw.SbwCompat.tickVehicle(this);
        }
        Entity sbwVehicle = getVehicle();
        if (com.stevesarmy.compat.sbw.SbwCompat.hasVehicles()
            && com.stevesarmy.compat.sbw.SbwCompat.isVehicle(sbwVehicle)
            && !com.stevesarmy.compat.sbw.SbwVehicles.isDrone(sbwVehicle)) {
            // SBW passengers are real taxi riders: keep them seated and freeze
            // movement AI. Dedicated crew spots for the vehicle weapons; other
            // passengers can fire their handheld gun from seats that allow it.
            if (getRole() == SoldierRole.VEHICLE_CREW) {
                SbwVehicleGunnery.tickMounted(this);
            } else {
                MountedSoldierGunnery.tickMounted(this);
            }
            return;
        }
        if (VS2Compat.prepareSoldierAi(this)) {
            if (shouldTickGrenadeController(gameTime)) {
                grenadeTacticalController.tick(getTarget(), getGrenadeSquadIntel());
            }
            return;
        }
        updateNavigationTraversalLock();
        if (shouldTickGrenadeController(gameTime)
            && grenadeTacticalController.tick(getTarget(), getGrenadeSquadIntel())) {
            return;
        }
        super.customServerAiStep();
    }

    /**
     * Cover state-machine debug feed ({@code /stevesarmy_debug coverstate}).
     * Runs from the entity tick rather than the cover goal so the card stays
     * live during goal cooldowns and restarts — exactly the blind spots where
     * strands hide. Read-only diagnostics.
     */
    private void sendCoverStateDebugPacket() {
        if (!(getOwner() instanceof ServerPlayer serverPlayer)) return;
        if (!CoverStateDebugManager.isEnabled(serverPlayer.getUUID())) return;
        if (!(coverTacticalGoal instanceof CoverTacticalGoal tacticalGoal)) return;
        CoverStateDebugPacket packet = tacticalGoal.buildCoverStateDebugPacket();
        NetworkHandler.INSTANCE.send(PacketDistributor.PLAYER.with(() -> serverPlayer), packet);
    }

    // --- Cover anti-stuck watchdog -----------------------------------------

    private static final int COVER_WATCHDOG_STILL_TICKS = 100;
    private static final double COVER_WATCHDOG_MOVE_EPSILON = 0.5D;
    private Vec3 coverWatchdogLastPos = null;
    private int coverWatchdogStillTicks = 0;

    /**
     * Safety net for untraced stuck states: a soldier sitting in SEEKING_COVER
     * or REPOSITIONING with no active path and no position change for several
     * seconds has nothing driving its legs. Reset the cover machine so it
     * re-decides, instead of standing exposed forever. Intended stillness
     * (occupied cover, CQB hold, reload, healing) is exempt.
     */
    private void tickCoverStuckWatchdog() {
        if (coverBehaviorManager == null || !this.isAlive()) {
            return;
        }
        CoverBehaviorManager.CoverState state = coverBehaviorManager.getState();
        boolean movingState = state == CoverBehaviorManager.CoverState.SEEKING_COVER
            || state == CoverBehaviorManager.CoverState.REPOSITIONING;
        if (!movingState || isCqbEngagementHold() || isPreparingOrReloading() || isHealing()) {
            coverWatchdogStillTicks = 0;
            coverWatchdogLastPos = position();
            return;
        }

        Vec3 pos = position();
        if (coverWatchdogLastPos == null
            || pos.distanceTo(coverWatchdogLastPos) > COVER_WATCHDOG_MOVE_EPSILON) {
            coverWatchdogStillTicks = 0;
            coverWatchdogLastPos = pos;
            return;
        }

        // A path is being followed; the goal's own progress watchdogs own
        // path-level failures. Only a pathless standstill is ours to reset.
        if (!getNavigation().isDone()) {
            return;
        }

        coverWatchdogStillTicks++;
        if (coverWatchdogStillTicks >= COVER_WATCHDOG_STILL_TICKS) {
            coverWatchdogStillTicks = 0;
            coverWatchdogLastPos = pos;
            // Pinned-dock protection (suppressedRelocationSafeRoute): while the
            // soldier is under fire and not yet recovered, the watchdog must
            // NOT strip the cover claim via the legacy full reset — cancel the
            // stalled move and re-hold instead. GO_TO relocations and fully
            // recovered soldiers keep the legacy reset (handled inside the goal).
            if (StevesArmyConfig.isSuppressedRelocationSafeRoute()
                && !coverBehaviorManager.getSuppressionTracker().isRecovered()
                && coverTacticalGoal instanceof CoverTacticalGoal tacticalGoal) {
                tacticalGoal.holdFromStuckWatchdog();
                return;
            }
            coverTacticalGoal.resetFromStuckWatchdog();
        }
    }
    
    @Override
    public void remove(RemovalReason reason) {
        if (DiagnosticLogManager.isRotationTraceEnabledFor(getUUID())) {
            DiagnosticLogManager.clearRotationTrace();
            StevesArmyMod.LOGGER.info("[RotationTrace] soldier={} removed, trace stopped", getId());
        }
        if (!this.level().isClientSide) {
            VS2Compat.onSoldierRemoved(this);
            com.stevesarmy.combat.VehicleCrewManager.releaseAllFor(this.getUUID());
            if (reason.shouldDestroy()) TeamManager.removeFromTeam(this);
            com.stevesarmy.combat.cover.CoverReservationManager.releaseAll(this);
            com.stevesarmy.combat.VpbEntityState.remove(this.getUUID());
            com.stevesarmy.compat.sbw.SbwEntityState.remove(this.getUUID());
            if (this.level() instanceof ServerLevel serverLevel) {
                com.stevesarmy.squad.SquadManager.get(serverLevel).removeMemberFromSquad(this.getUUID());
                OwnedSoldierRegistry.get(serverLevel.getServer()).remove(this.getUUID());
                com.stevesarmy.squad.SquadActivityManager.removeSoldier(this.getUUID(), serverLevel.getServer());
            }
        }
        super.remove(reason);
    }
    
    @Override
    public EntityDimensions getDimensions(Pose pose) {
        if (entityData.get(LOW_CROUCHING)) {
            return EntityDimensions.scalable(0.6F, 0.6F);
        }
        if (isHalfCoverRising()) {
            EntityDimensions standing = super.getDimensions(Pose.STANDING);
            float height = Mth.lerp(getHalfCoverRiseProgress(), 1.5f, standing.height);
            return EntityDimensions.scalable(0.6F, height);
        }
        if (pose == Pose.CROUCHING) {
            return EntityDimensions.scalable(0.6F, 1.5F);
        }
        return super.getDimensions(pose);
    }

    @Override
    protected float getStandingEyeHeight(Pose pose, EntityDimensions dimensions) {
        if (entityData.get(LOW_CROUCHING)) {
            return 0.4F;
        }
        if (isHalfCoverRising()) {
            EntityDimensions standing = super.getDimensions(Pose.STANDING);
            float standingEyeHeight = super.getStandingEyeHeight(Pose.STANDING, standing);
            return Mth.lerp(getHalfCoverRiseProgress(), 1.27F, standingEyeHeight);
        }
        if (pose == Pose.CROUCHING) {
            return 1.27F;
        }
        return super.getStandingEyeHeight(pose, dimensions);
    }

    @Override
    public void die(DamageSource source) {
        if (!this.level().isClientSide && !this.isRemoved() && this.level() instanceof ServerLevel serverLevel) {
            getOwnerUUID().ifPresent(ownerUUID -> {
                ServerPlayer owner = serverLevel.getServer().getPlayerList().getPlayer(ownerUUID);
                if (owner != null) {
                    owner.sendSystemMessage(Component.literal("[Squad] ").append(this.getCombatTracker().getDeathMessage().copy()));
                }
            });
        }
        super.die(source);
    }
    
    @Override
    public boolean hurt(DamageSource source, float amount) {
        if (DiagnosticLogManager.isDamageLoggingEnabled()) {
            StevesArmyMod.LOGGER.info("[DAMAGE_DEBUG] SoldierEntity.hurt() called: entity={} id={} source={} amount={} sourceEntity={}",
                this.getName().getString(), this.getId(), source.getMsgId(), amount,
                source.getEntity() != null ? source.getEntity().getName().getString() + "(" + source.getEntity().getClass().getSimpleName() + ")" : "null");
        }
        boolean result = super.hurt(source, amount);
        if (DiagnosticLogManager.isDamageLoggingEnabled()) {
            StevesArmyMod.LOGGER.info("[DAMAGE_DEBUG] SoldierEntity.hurt() result: {} (super.hurt returned {})", result ? "damage applied" : "damage blocked", result);
        }

        if (result && !this.level().isClientSide) {
            if (isHealing()) {
                stopUsingItem();
            }
            if (isRecalling()) {
                cancelRecall();
            }
            // A NEUTRAL-marked attacker forfeits neutrality: remember them so
            // isProactiveTarget lets the squad fight back for a while.
            if (source.getEntity() instanceof LivingEntity neutralCandidate && neutralCandidate != this
                && getFofOverride(neutralCandidate) == FofStance.NEUTRAL) {
                this.neutralAttacker = neutralCandidate;
                this.neutralAttackerTick = this.tickCount;
            }
            if (coverBehaviorManager != null) {
                CoverBehaviorManager.CoverState preState = coverBehaviorManager.getState();
                PeekController.State prePeekState = peekController.getState();
                
                LivingEntity attacker = source.getEntity() instanceof LivingEntity a ? a : null;
                coverBehaviorManager.onTakeDamage(attacker);
                
                if (attacker != null && attacker != this && !isFriendlyTo(attacker)) {
                    coverBehaviorManager.onIncomingFire(attacker);

                    if (preState == CoverBehaviorManager.CoverState.IN_COVER ||
                        preState == CoverBehaviorManager.CoverState.SUPPRESSED_IN_COVER) {
                        // A hostile hit while fully hidden proves this position no longer protects us.
                        if (prePeekState == PeekController.State.HIDING) {
                            coverBehaviorManager.requestShotInCoverReposition();
                        } else {
                            // Hits while peeking are expected exposure, not proof of
                            // compromise — but repeated ones still rotate the cover.
                            coverTacticalGoal.noteHitWhilePeekingAtCover();
                        }
                    }
                }
                
                if (attacker != null && attacker != this) {
                    Vec3 toAttacker = attacker.position().subtract(this.position()).normalize();
                    threatAwareness.setSmoothDirection(toAttacker);
                }
            }
        }
        
        return result;
    }

    @Nonnull
    @Override
    public <T> LazyOptional<T> getCapability(@Nonnull Capability<T> cap, @Nullable Direction side) {
        if (cap == ForgeCapabilities.ITEM_HANDLER) {
            return itemHandlerCap.cast();
        }
        return super.getCapability(cap, side);
    }

    @Override
    public void invalidateCaps() {
        super.invalidateCaps();
        itemHandlerCap.invalidate();
    }
    
    public void receivePing(com.stevesarmy.ping.PingType type, net.minecraft.world.phys.Vec3 position) {
        com.stevesarmy.StevesArmyMod.LOGGER.info("Soldier received ping: type={} pos={}", type, position);
        
        if (type == com.stevesarmy.ping.PingType.SEND
            || type == com.stevesarmy.ping.PingType.GO_TO
            || type == com.stevesarmy.ping.PingType.ATTACK
            || type == com.stevesarmy.ping.PingType.FOLLOW
            || type == com.stevesarmy.ping.PingType.HOLD) {
            clearPingSuppressPos();
        }

        switch (type) {
            case SEND -> {
                BlockPos pos = BlockPos.containing(position);
                clearGoToState();
                pingMoveTarget = pos;
                pingMoveTimestamp = GameClock.nowMs();
                setSquadMode(com.stevesarmy.squad.SquadMode.HOLD);
                setHoldPosition(pos);
                coverBehaviorManager.clearCover();
                dispatchedBySend = true;
                StevesArmyMod.LOGGER.info("SEND: set hold position at {} (dispatched)", pos);
            }
            case GO_TO -> {
                pingMoveGeneration++;
                pingMoveTarget = BlockPos.containing(position);
                pingMoveTimestamp = GameClock.nowMs();
                persistentGoTo = true;
                goToHolding = false;
                setSquadMode(com.stevesarmy.squad.SquadMode.HOLD);
                setHoldPosition(BlockPos.containing(position));
                coverBehaviorManager.clearCover();
                cancelCoverMovement();
                StevesArmyMod.LOGGER.info("Set move target: {}", pingMoveTarget);
            }
            case THREAT_DIRECTION -> {
                BlockPos pos = BlockPos.containing(position);
                threatAwareness.onPingDirection(pos);
                pingThreatPos = pos;
                pingThreatTimestamp = GameClock.nowMs();
                forcedTargetPos = pos;
                forcedTargetTimestamp = GameClock.nowMs();
                com.stevesarmy.StevesArmyMod.LOGGER.info("Set threat direction position: {} (forced target inherited from ENEMY)", pingThreatPos);
            }
            case LOCATION -> {
            }
            case FOLLOW -> {
                setSquadMode(com.stevesarmy.squad.SquadMode.FOLLOW);
                dispatchedBySend = false;
                clearPingMoveTarget();
                clearPingThreatPos();
                clearForcedTarget();
                clearPingSuppressPos();
                threatAwareness.clear();
                if (squadId != null) com.stevesarmy.util.SpacingHelper.clearAssignment(squadId);
                com.stevesarmy.StevesArmyMod.LOGGER.info("Switched to FOLLOW mode, cleared all threat data");
            }
            case HOLD -> {
                setSquadMode(com.stevesarmy.squad.SquadMode.HOLD);
                setHoldPosition(blockPosition());
                coverBehaviorManager.clearCover();
                dispatchedBySend = false;
                clearPingMoveTarget();
                clearPingThreatPos();
                clearForcedTarget();
                clearPingSuppressPos();
                threatAwareness.clear();
                if (squadId != null) com.stevesarmy.util.SpacingHelper.clearAssignment(squadId);
                StevesArmyMod.LOGGER.info("Switched to HOLD mode, cleared all threat data");
            }
            case SUPPRESS_AREA -> {
                if (getRole() == SoldierRole.SUPPORT || getRole() == SoldierRole.VEHICLE_CREW || isVehicleCrewActive()) {
                    LivingEntity owner = getOwner();
                    if (owner instanceof ServerPlayer player) {
                        player.sendSystemMessage(Component.literal("[Squad] " + getName().getString()
                            + " cannot execute suppress-area orders."));
                    }
                    return;
                }
                setPingSuppressPos(BlockPos.containing(position));
                suppressionAimPoints.clear();
                lastSuppressionAimPoint = null;
                
                if (this.combatGoal != null) {
                    this.combatGoal.forceRestartPingSuppression();
                }
                
                StevesArmyMod.LOGGER.info("Set suppress area: {}", getPingSuppressPos());
            }
            case ATTACK -> {
                setAttackTarget(BlockPos.containing(position));
                coverBehaviorManager.clearCover();
                cancelCoverMovement();
                setSquadMode(com.stevesarmy.squad.SquadMode.HOLD);
                setHoldPosition(attackTargetPos);
                StevesArmyMod.LOGGER.info("ATTACK: set attack position at {} (gen {})", attackTargetPos, attackGeneration);
            }
        }
    }
    
public BlockPos getPingMoveTarget() {
        return pingMoveTarget;
    }

    public int getPingMoveGeneration() {
        return pingMoveGeneration;
    }

    public boolean hasValidPingMoveTarget() {
        return pingMoveTarget != null &&
               (persistentGoTo || GameClock.nowMs() - pingMoveTimestamp < PING_MOVE_MEMORY_MS);
    }

    public boolean hasPersistentGoTo() {
        return persistentGoTo && pingMoveTarget != null;
    }

    public boolean isGoToHolding() {
        return persistentGoTo && goToHolding;
    }

    /** True while an active or completed GO_TO command owns CQB movement decisions. */
    public boolean hasGoToNavigationOwnership() {
        return persistentGoTo;
    }

    public void completeGoToIfGeneration(int expectedGeneration) {
        if (pingMoveGeneration != expectedGeneration || !persistentGoTo) return;

        pingMoveTarget = null;
        pingMoveTimestamp = 0;
        goToHolding = true;
        if (squadId != null) {
            com.stevesarmy.util.SpacingHelper.clearAssignment(squadId);
        }
    }

    public void clearPingMoveTarget() {
        pingMoveTarget = null;
        pingMoveTimestamp = 0;
        clearGoToState();
        if (squadId != null) {
            com.stevesarmy.util.SpacingHelper.clearAssignment(squadId);
        }
    }

    public void clearPingMoveTargetIfGeneration(int expectedGeneration) {
        if (pingMoveGeneration == expectedGeneration) {
            pingMoveTarget = null;
            pingMoveTimestamp = 0;
            clearGoToState();
            if (squadId != null) {
                com.stevesarmy.util.SpacingHelper.clearAssignment(squadId);
            }
        }
    }

    private void clearGoToState() {
        persistentGoTo = false;
        goToHolding = false;
    }

    public BlockPos getAttackTargetPos() {
        return attackTargetPos;
    }

    public boolean hasValidAttackTarget() {
        return attackTargetPos != null &&
               GameClock.nowMs() - attackTargetTimestamp < ATTACK_MEMORY_MS;
    }

    /**
     * Clearing-doctrine persistence: {@link com.stevesarmy.squad.ClearingCoordinator}
     * refreshes this while the ATTACK order of record is alive, so the 60s
     * memory window never silently ends an active order. The timeout still
     * applies once the order is gone (owner left, order completed/replaced).
     */
    public void refreshAttackOrderClock() {
        if (attackTargetPos != null) {
            attackTargetTimestamp = GameClock.nowMs();
        }
    }

    /**
     * Keeps the attack objective alive while the soldier is under fire. The
     * 60s memory exists to drop stale objectives, but a fireteam pinned by
     * sustained suppression for longer than that must not silently stop
     * attacking — being suppressed is evidence the attack is still on, so
     * extend the window; it expires 60s after the pressure ends.
     */
    private void refreshAttackTargetUnderFire() {
        if (attackTargetPos == null || coverBehaviorManager == null) return;
        if (coverBehaviorManager.getSuppressionTracker().getSuppressionLevel() >= 0.2f) {
            attackTargetTimestamp = GameClock.nowMs();
        }
    }

    public int getAttackGeneration() {
        return attackGeneration;
    }

    public void setAttackTarget(BlockPos pos) {
        attackGeneration++;
        this.attackTargetPos = pos;
        this.attackTargetTimestamp = GameClock.nowMs();
        // Clear incompatible ping move target
        clearPingMoveTarget();
        // ATTACK is objective-only: it defines where the soldier should
        // reposition (lateral/forward) but does NOT change the active threat
        // direction or combat target. Use THREAT_DIRECTION pings for that.
        // The existing threat (from entity detection, damage, or enemy pings)
        // continues to drive cover-facing and peek decisions.
    }

    public void clearAttackTarget() {
        this.attackTargetPos = null;
        this.attackTargetTimestamp = 0;
        if (squadId != null) {
            com.stevesarmy.util.SpacingHelper.clearAssignment(squadId);
        }
    }

    public void clearAttackTargetIfGeneration(int expectedGeneration) {
        if (attackGeneration == expectedGeneration) {
            this.attackTargetPos = null;
            this.attackTargetTimestamp = 0;
            if (squadId != null) {
                com.stevesarmy.util.SpacingHelper.clearAssignment(squadId);
            }
        }
    }

    public BlockPos getPingThreatPos() {
        return pingThreatPos;
    }
    
    public boolean hasValidPingThreatPos() {
        return pingThreatPos != null && 
               GameClock.nowMs() - pingThreatTimestamp < PING_THREAT_MEMORY_MS;
    }
    
    public void clearPingThreatPos() {
        pingThreatPos = null;
        pingThreatTimestamp = 0;
    }
    
    public BlockPos getForcedTargetPos() {
        return forcedTargetPos;
    }
    
    public boolean hasValidForcedTarget() {
        return forcedTargetPos != null && 
               GameClock.nowMs() - forcedTargetTimestamp < FORCED_TARGET_MEMORY_MS;
    }
    
    public void setForcedTargetPos(BlockPos pos) {
        this.forcedTargetPos = pos;
        this.forcedTargetTimestamp = GameClock.nowMs();
    }
    
    public void clearForcedTarget() {
        this.forcedTargetPos = null;
        this.forcedTargetTimestamp = 0;
    }
    
    public BlockPos getPingSuppressPos() {
        return suppressionOrder.getArea();
    }
    
    public boolean hasValidPingSuppressPos() {
        return suppressionOrder.isActive();
    }

    public void setPingSuppressPos(BlockPos pos) {
        if (suppressionOrder.isActive() && coverTacticalGoal != null) {
            coverTacticalGoal.cancelSuppressionPosition(suppressionOrder.getGeneration());
        }
        if (suppressionOrder.getArea() == null || !suppressionOrder.getArea().equals(pos)) {
            suppressionAimPoints.clear();
            lastSuppressionAimPoint = null;
        }
        suppressionOrder.start(pos, tickCount);
        suppressionOrder.setOrigin(blockPosition());
    }
    
    public void clearPingSuppressPos() {
        suppressionOrder.cancel();
        suppressionAimPoints.clear();
        lastSuppressionAimPoint = null;
    }

    public SuppressionOrderController getSuppressionOrder() {
        return suppressionOrder;
    }
    
    public java.util.List<Vec3> getSuppressionAimPoints() {
        return suppressionAimPoints;
    }
    
    public void setSuppressionAimPoints(java.util.List<Vec3> points) {
        // Callers pass immutable lists (List.of(...)); the clear helpers below
        // mutate this field in place, so store a mutable copy.
        this.suppressionAimPoints = new java.util.ArrayList<>(points);
        this.lastSuppressionAimPoint = null;
    }
    
    public Vec3 getNextSuppressionAimPoint() {
        if (suppressionAimPoints.isEmpty()) return null;
        if (suppressionAimPoints.size() == 1) return suppressionAimPoints.get(0);
        
        java.util.Random random = new java.util.Random();
        Vec3 selected;
        int attempts = 0;
        
        do {
            int index = random.nextInt(suppressionAimPoints.size());
            selected = suppressionAimPoints.get(index);
            attempts++;
        } while (selected.equals(lastSuppressionAimPoint) && attempts < 10);
        
        lastSuppressionAimPoint = selected;
        return selected;
    }
    
    public Vec3 getHorizontalSpreadFallbackTarget(BlockPos pingCenter) {
        java.util.Random random = new java.util.Random();
        double angle = random.nextDouble() * 2 * Math.PI;
        double radius = random.nextDouble() * SUPPRESSION_ZONE_RADIUS;
        
        Vec3 center = pingCenter.getCenter();
        return new Vec3(
            center.x + Math.cos(angle) * radius,
            center.y + 1.0,
            center.z + Math.sin(angle) * radius
        );
    }
    
    public CombatGoalController getCombatGoal() {
        return combatGoal;
    }

    public void syncMachineGunnerDebug(BlockPos position, BlockPos movementPosition, BlockPos center,
                                       float access, int posture, boolean active, boolean fallback,
                                       boolean suppressed) {
        if (level().isClientSide) return;
        entityData.set(MG_DEBUG_POSITION, position != null ? position : BlockPos.ZERO);
        entityData.set(MG_DEBUG_MOVEMENT_POSITION,
            movementPosition != null ? movementPosition : BlockPos.ZERO);
        entityData.set(MG_DEBUG_CENTER, center != null ? center : BlockPos.ZERO);
        entityData.set(MG_DEBUG_ACCESS, access);
        entityData.set(MG_DEBUG_POSTURE, posture);
        entityData.set(MG_DEBUG_ACTIVE, active);
        entityData.set(MG_DEBUG_FALLBACK, fallback);
        entityData.set(MG_DEBUG_SUPPRESSED, suppressed);
    }

    public BlockPos getMachineGunnerDebugPosition() { return entityData.get(MG_DEBUG_POSITION); }
    public BlockPos getMachineGunnerDebugMovementPosition() { return entityData.get(MG_DEBUG_MOVEMENT_POSITION); }
    public BlockPos getMachineGunnerDebugCenter() { return entityData.get(MG_DEBUG_CENTER); }
    public float getMachineGunnerDebugAccess() { return entityData.get(MG_DEBUG_ACCESS); }
    public int getMachineGunnerDebugPosture() { return entityData.get(MG_DEBUG_POSTURE); }
    public boolean isMachineGunnerDebugActive() { return entityData.get(MG_DEBUG_ACTIVE); }
    public boolean isMachineGunnerDebugFallback() { return entityData.get(MG_DEBUG_FALLBACK); }
    public boolean isMachineGunnerDebugSuppressed() { return entityData.get(MG_DEBUG_SUPPRESSED); }

    @Override
    public void onSyncedDataUpdated(EntityDataAccessor<?> accessor) {
        super.onSyncedDataUpdated(accessor);
        if (LOW_CROUCHING.equals(accessor) || HALF_COVER_RISE_PROGRESS.equals(accessor)
            || HALF_COVER_RISING.equals(accessor)) {
            // DATA_POSE and LOW_CROUCHING can arrive in either order. Refresh
            // here so the client bounding box always uses the current posture.
            this.refreshDimensions();
        }
    }

    public boolean isPreparingOrReloading() {
        return entityData.get(RELOAD_PENDING)
            || (GunIntegration.isAnyGunLoaded() && GunIntegration.isReloading(this));
    }

    public boolean isTacticalReloading() {
        return entityData.get(TACTICAL_RELOADING);
    }

    public void setReloadStatus(boolean reloadPending, boolean tacticalReloading) {
        entityData.set(RELOAD_PENDING, reloadPending);
        entityData.set(TACTICAL_RELOADING, tacticalReloading);
    }

    /** True when the soldier's gun never runs out of reserve ammo. */
    public boolean hasInfiniteReserveAmmo() {
        return false;
    }

    /** Restores the virtual reserve before a reload when infinite reserve is enabled. */
    public boolean ensureInfiniteReserveAmmo() {
        return false;
    }

    public void configureInfiniteReserveAmmo() {
    }

    /** Read-only labels for the explicitly enabled flight recorder. */
    public java.util.List<String> getTraceRunningGoals() {
        return goalSelector.getRunningGoals().map(g -> g.getPriority() + ":" + g.getGoal().getClass().getSimpleName()).toList();
    }

    public CoverGoalController getCoverTacticalGoal() {
        return coverTacticalGoal;
    }
    
    public CoverBehaviorManager getCoverBehaviorManager() {
        return coverBehaviorManager;
    }
    
    public PeekController getPeekController() {
        return peekController;
    }
    
    public void updateDebugData(float detectionPoints, boolean isDetected, float distance, boolean hasLOS, boolean inFocused) {
        this.entityData.set(DEBUG_DETECTION_POINTS, detectionPoints);
        this.entityData.set(DEBUG_IS_DETECTED, isDetected);
        this.entityData.set(DEBUG_DISTANCE, distance);
        this.entityData.set(DEBUG_HAS_LOS, hasLOS);
        this.entityData.set(DEBUG_IN_FOCUSED, inFocused);
    }
    
    public float getDebugDetectionPoints() {
        return this.entityData.get(DEBUG_DETECTION_POINTS);
    }
    
    public boolean getDebugIsDetected() {
        return this.entityData.get(DEBUG_IS_DETECTED);
    }
    
    public float getDebugDistance() {
        return this.entityData.get(DEBUG_DISTANCE);
    }
    
    public boolean getDebugHasLOS() {
        return this.entityData.get(DEBUG_HAS_LOS);
    }
    
    public boolean getDebugInFocused() {
        return this.entityData.get(DEBUG_IN_FOCUSED);
    }
    
    public void setDebugTargetUUID(UUID targetUUID) {
        this.entityData.set(DEBUG_TARGET_UUID, Optional.ofNullable(targetUUID));
    }
    
    public Optional<UUID> getDebugTargetUUID() {
        return this.entityData.get(DEBUG_TARGET_UUID);
    }
    
    public void syncCoverState(int stateOrdinal) {
        this.entityData.set(COVER_STATE, stateOrdinal);
    }
    
    public int getSyncedCoverState() {
        return this.entityData.get(COVER_STATE);
    }
    
    public void syncCoverCurrent(BlockPos pos, int typeOrdinal, float quality, float height) {
        boolean changedCover = !pos.equals(this.entityData.get(COVER_CURRENT_POS))
            || typeOrdinal != this.entityData.get(COVER_CURRENT_TYPE);
        this.entityData.set(COVER_CURRENT_POS, pos);
        this.entityData.set(COVER_CURRENT_TYPE, typeOrdinal);
        this.entityData.set(COVER_CURRENT_QUALITY, quality);
        this.entityData.set(COVER_CURRENT_HEIGHT, height);
        if (changedCover) {
            cancelHalfCoverRise("cover-changed");
        }
    }

    public void beginHalfCoverRise() {
        beginHalfCoverRise("unspecified");
    }

    public void beginHalfCoverRise(String source) {
        if (this.level().isClientSide || entityData.get(LOW_CROUCHING) || !halfCoverRisePending) {
            return;
        }
        halfCoverRisePending = false;
        this.entityData.set(HALF_COVER_RISE_PROGRESS, 0.0f);
        this.entityData.set(HALF_COVER_RISING, true);
        this.refreshDimensions();
        tracePeek("half-cover-rise", "action=started, source=" + source);
    }

    public void cancelHalfCoverRise() {
        cancelHalfCoverRise("unspecified");
    }

    public void cancelHalfCoverRise(String source) {
        if (this.level().isClientSide) {
            return;
        }
        halfCoverRisePending = false;
        this.entityData.set(HALF_COVER_RISE_PROGRESS, 1.0f);
        this.entityData.set(HALF_COVER_RISING, false);
        this.refreshDimensions();
        tracePeek("half-cover-rise", "action=cancelled, source=" + source);
    }

    public float getHalfCoverRiseProgress() {
        return this.entityData.get(HALF_COVER_RISE_PROGRESS);
    }

    public boolean isHalfCoverRising() {
        if (!entityData.get(HALF_COVER_RISING) || entityData.get(LOW_CROUCHING)
            || getHalfCoverRiseProgress() >= 1.0f) {
            return false;
        }
        int state = getSyncedCoverState();
        boolean inCover = state == CoverBehaviorManager.CoverState.IN_COVER.ordinal()
            || state == CoverBehaviorManager.CoverState.SUPPRESSED_IN_COVER.ordinal();
        return inCover && getSyncedCoverCurrentType() == CoverType.HALF.ordinal();
    }

    private void tickHalfCoverRiseProgress() {
        if (!isHalfCoverRising()) return;
        float next = Math.min(1.0f, getHalfCoverRiseProgress() + 1.0f / HALF_COVER_RISE_TICKS);
        this.entityData.set(HALF_COVER_RISE_PROGRESS, next);
        if (next >= 1.0f) {
            this.entityData.set(HALF_COVER_RISING, false);
        }
        this.refreshDimensions();
    }
    
    public BlockPos getSyncedCoverCurrentPos() {
        return this.entityData.get(COVER_CURRENT_POS);
    }
    
    public int getSyncedCoverCurrentType() {
        return this.entityData.get(COVER_CURRENT_TYPE);
    }
    
    public float getSyncedCoverCurrentQuality() {
        return this.entityData.get(COVER_CURRENT_QUALITY);
    }

    public float getSyncedCoverCurrentHeight() {
        return this.entityData.get(COVER_CURRENT_HEIGHT);
    }
    
    public void syncCoverTarget(BlockPos pos, int typeOrdinal, float quality) {
        this.entityData.set(COVER_TARGET_POS, pos);
        this.entityData.set(COVER_TARGET_TYPE, typeOrdinal);
        this.entityData.set(COVER_TARGET_QUALITY, quality);
    }
    
    public BlockPos getSyncedCoverTargetPos() {
        return this.entityData.get(COVER_TARGET_POS);
    }
    
    public int getSyncedCoverTargetType() {
        return this.entityData.get(COVER_TARGET_TYPE);
    }
    
    public float getSyncedCoverTargetQuality() {
        return this.entityData.get(COVER_TARGET_QUALITY);
    }
    
    public void syncCoverLast(BlockPos pos) {
        this.entityData.set(COVER_LAST_POS, pos);
    }
    
    public BlockPos getSyncedCoverLastPos() {
        return this.entityData.get(COVER_LAST_POS);
    }
    
    public void syncSuppressionLevel(float level) {
        this.entityData.set(SUPPRESSION_LEVEL, level);
    }
    
    public float getSyncedSuppressionLevel() {
        return this.entityData.get(SUPPRESSION_LEVEL);
    }

    public void syncSuppressionEventSequence(int sequence) {
        this.entityData.set(SUPPRESSION_EVENT_SEQUENCE, sequence);
    }

    public int getSyncedSuppressionEventSequence() {
        return this.entityData.get(SUPPRESSION_EVENT_SEQUENCE);
    }
    
    public void syncPeekState(int peekStateOrdinal) {
        this.entityData.set(PEEK_STATE, peekStateOrdinal);
    }
    
    public int getSyncedPeekState() {
        return this.entityData.get(PEEK_STATE);
    }

    /** Client render hint for the exposed half-cover idle; never changes gameplay posture. */
    public boolean isHalfCoverPeekIdle() {
        int state = getSyncedCoverState();
        boolean inCover = state == CoverBehaviorManager.CoverState.IN_COVER.ordinal()
            || state == CoverBehaviorManager.CoverState.SUPPRESSED_IN_COVER.ordinal();
        return !this.level().isClientSide || (inCover
            && getSyncedCoverCurrentType() == CoverType.HALF.ordinal()
            && getSyncedPeekState() == PeekController.State.EXPOSED.ordinal());
    }
    
    public void syncPeekPosition(BlockPos pos) {
        this.entityData.set(PEEK_POSITION, pos);
    }
    
    public BlockPos getSyncedPeekPosition() {
        return this.entityData.get(PEEK_POSITION);
    }
    
    private int emergencyEngagementPostureUntilTick = -1;
    private static final double CRAWL_MOVEMENT_SPEED_SQR = 0.0004D;
    private static final float CRAWL_TURN_RATE_DEGREES = 25.0F;
    private static final int ANIMATION_WEAPON_READY_HOLD_TICKS = 20;
    private int animationWeaponReadyHoldTicks;

    /** Normal crouch owned by the bounded corner excursion; crawl/prone keep priority. */
    public void setCornerPeekCrouching(boolean active) {
        if (level().isClientSide) return;
        entityData.set(CORNER_PEEK_CROUCH, active);
        if (!isLowCrouching()) {
            setPose(active ? Pose.CROUCHING : Pose.STANDING);
            refreshDimensions();
        }
    }

    public boolean isCornerPeekCrouching() { return entityData.get(CORNER_PEEK_CROUCH); }

    public void setLowCrouching(boolean lowCrouch) {
        if (this.level().isClientSide) {
            return;
        }

        // A route approved only at crawl height cannot be invalidated by a
        // competing combat/cover stand request. Route owners release this first.
        if (!lowCrouch && movementController != null && movementController.isMandatoryCrawl()) {
            lowCrouch = true;
        }

        // Soldiers aboard ships never crawl: the crawl pose re-dimensions a
        // VS2-mounted passenger, breaking seat rendering and ship collision.
        if (lowCrouch && VS2Compat.isOnShip(this)) {
            lowCrouch = false;
        }

        // A seated SBW passenger cannot enter the swimming/prone pose. Keep
        // the combat ownership bit in sync so it does not reassert the pose.
        if (lowCrouch && isMountedInSbwVehicle()) {
            lowCrouch = false;
            firingProne = false;
        }

        if (!lowCrouch) {
            // Any explicit stand request (cover exit, movement, or combat) ends
            // the firing-prone ownership before the shared pose is cleared.
            this.firingProne = false;
        }

        boolean wasLowCrouching = entityData.get(LOW_CROUCHING);
        if (wasLowCrouching == lowCrouch) {
            return;
        }
        
        this.entityData.set(LOW_CROUCHING, lowCrouch);
        if (lowCrouch) {
            cancelHalfCoverRise("low-crouch");
        } else {
            halfCoverRisePending = true;
        }
        this.setPose(lowCrouch ? Pose.SWIMMING : Pose.STANDING);
        this.refreshDimensions();
        tracePeek("low-crouch", "changed=" + wasLowCrouching + "->" + lowCrouch);
    }

    /** Requests the shared low-prone pose for a direct-fire stabilization stance. */
    public void setFiringProne(boolean active) {
        if (this.level().isClientSide) {
            return;
        }

        this.firingProne = active;
        setLowCrouching(active);
    }

    public boolean isFiringProne() {
        return firingProne;
    }
    
    public boolean isLowCrouching() {
        return entityData.get(LOW_CROUCHING);
    }

    /**
     * Render-side crawl amount (0..1, client tick maintained) so the prone
     * pose/rotation path lights up on LAND: vanilla only feeds swimAmount in
     * water, which left every land crawler rendering as a standing walk no
     * matter what SoldierModel's prone pose wanted to draw.
     */
    private float crawlRenderAmount = 0.0F;
    private float oldCrawlRenderAmount = 0.0F;

    @Override
    public float getSwimAmount(float partialTick) {
        float vanilla = super.getSwimAmount(partialTick);
        float crawl = net.minecraft.util.Mth.lerp(partialTick, oldCrawlRenderAmount, crawlRenderAmount);
        return Math.max(vanilla, crawl);
    }

    private void tickCrawlRenderAmount() {
        oldCrawlRenderAmount = crawlRenderAmount;
        float target = isLowCrouching() ? 1.0F : 0.0F;
        if (crawlRenderAmount < target) {
            crawlRenderAmount = Math.min(target, crawlRenderAmount + 0.25F);
        } else if (crawlRenderAmount > target) {
            crawlRenderAmount = Math.max(target, crawlRenderAmount - 0.25F);
        }
    }

    /** True while low-crouching movement has a stable horizontal travel direction. */
    public boolean isCrawlMoving() {
        return isLowCrouching()
            && getDeltaMovement().horizontalDistanceSqr() > CRAWL_MOVEMENT_SPEED_SQR;
    }

    /** Returns the yaw that points along the current crawl movement vector. */
    public float getCrawlMovementYaw() {
        Vec3 movement = getDeltaMovement();
        return (float) Math.toDegrees(Math.atan2(-movement.x, movement.z));
    }

    /** Returns the stable body direction used while crawling. */
    public float getCrawlFacingYaw() {
        return this.yBodyRot;
    }

    private void updateCrawlFacing() {
        if (!isCrawlMoving()) {
            return;
        }

        float previousYaw = getYRot();
        float previousBodyYaw = yBodyRot;
        float previousHeadYaw = getYHeadRot();
        float movementYaw = getCrawlMovementYaw();
        float bodyYaw = approachAngle(this.yBodyRot, movementYaw, CRAWL_TURN_RATE_DEGREES);
        this.setYRot(bodyYaw);
        this.setYBodyRot(bodyYaw);
        this.setYHeadRot(bodyYaw);
        traceRotationWrite("crawl-facing", previousYaw, previousBodyYaw, previousHeadYaw,
            "movement=" + formatVec(getDeltaMovement()) + ", targetYaw=" + formatAngle(movementYaw));
    }

    /** Records a mod-owned yaw write when this soldier is the active rotation trace target. */
    public void traceRotationWrite(String source, float previousYaw, float previousBodyYaw,
                                   float previousHeadYaw, String detail) {
        if (!isRotationTraceActive()) return;
        lastRotationTraceWriterTick = tickCount;
        StevesArmyMod.LOGGER.info("[RotationTrace] tick={} soldier={} source={} {} -> {} detail={} context={}",
            tickCount, getId(), source, formatYawTriplet(previousYaw, previousBodyYaw, previousHeadYaw),
            formatYawTriplet(getYRot(), yBodyRot, getYHeadRot()), detail, rotationTraceContext());
    }

    private void traceRotationSnapshot() {
        if (!isRotationTraceActive()) {
            hasRotationTraceSnapshot = false;
            return;
        }
        float yaw = getYRot();
        float bodyYaw = yBodyRot;
        float headYaw = getYHeadRot();
        boolean changed = hasRotationTraceSnapshot
            && (Math.abs(Mth.wrapDegrees(yaw - lastRotationTraceYaw)) > 0.01F
                || Math.abs(Mth.wrapDegrees(bodyYaw - lastRotationTraceBodyYaw)) > 0.01F
                || Math.abs(Mth.wrapDegrees(headYaw - lastRotationTraceHeadYaw)) > 0.01F);
        String source = changed && lastRotationTraceWriterTick != tickCount ? "external-or-vanilla" : "final";
        StevesArmyMod.LOGGER.info("[RotationTrace] tick={} soldier={} source={} yaw={} changed={} context={}",
            tickCount, getId(), source, formatYawTriplet(yaw, bodyYaw, headYaw), changed, rotationTraceContext());
        hasRotationTraceSnapshot = true;
        lastRotationTraceYaw = yaw;
        lastRotationTraceBodyYaw = bodyYaw;
        lastRotationTraceHeadYaw = headYaw;
    }

    private boolean isRotationTraceActive() {
        return !level().isClientSide && DiagnosticLogManager.isRotationTraceEnabledFor(getUUID());
    }

    /** Records a selected soldier's posture/peek decision with one common state context. */
    public void tracePeek(String event, String detail) {
        if (!isPeekTraceActive()) return;
        StevesArmyMod.LOGGER.info("[PeekTrace] tick={} soldier={} event={} detail={} context={}",
            tickCount, getId(), event, detail, peekTraceContext());
    }

    private void tracePeekSnapshot() {
        if (!isPeekTraceActive()) {
            lastPeekTraceSuppressionState = null;
            return;
        }

        SuppressionTracker.SuppressionState suppressionState = getCoverBehaviorManager()
            .getSuppressionTracker().getState();
        boolean emergency = hasEmergencyEngagementPosture();
        if (suppressionState != lastPeekTraceSuppressionState) {
            tracePeek("suppression-state", "previous=" + lastPeekTraceSuppressionState + ", current=" + suppressionState);
            lastPeekTraceSuppressionState = suppressionState;
        }
        if (emergency != lastPeekTraceEmergencyPosture) {
            tracePeek("emergency-posture", "active=" + emergency + ", remainingTicks=" + getEmergencyEngagementPostureRemainingTicks());
            lastPeekTraceEmergencyPosture = emergency;
        }
        if (tickCount - lastPeekTraceSnapshotTick < 20) return;

        lastPeekTraceSnapshotTick = tickCount;
        PeekController peekController = getPeekController();
        boolean pinnedAndExposed = suppressionState == SuppressionTracker.SuppressionState.PINNED
            && (peekController.isExposed() || peekController.isMovingToPeek());
        tracePeek(pinnedAndExposed ? "ANOMALY-pinned-exposed" : "snapshot",
            "peekElapsedMs=" + peekController.getTimeInCurrentState()
                + ", emergencyOverride=" + emergency
                + ", riseActive=" + isHalfCoverRising()
                + ", riseProgress=" + String.format("%.3f", getHalfCoverRiseProgress())
                + ", pinnedAndExposed=" + pinnedAndExposed);
    }

    private boolean isPeekTraceActive() {
        return !level().isClientSide && DiagnosticLogManager.isPeekTraceEnabledFor(getUUID());
    }

    private String peekTraceContext() {
        CoverBehaviorManager manager = getCoverBehaviorManager();
        SuppressionTracker tracker = manager.getSuppressionTracker();
        CoverPoint cover = manager.getCurrentCover();
        LivingEntity target = getTarget();
        String targetDescription = target == null ? "none"
            : target.getId() + "@" + String.format("%.2f", distanceTo(target));
        return "suppression=" + String.format("%.5f", tracker.getSuppressionLevel())
            + ", suppressionState=" + tracker.getState()
            + ", coverState=" + manager.getState()
            + ", coverType=" + (cover == null ? "NONE" : cover.getType())
            + ", peek=" + getPeekController().getState()
            + ", lowCrouch=" + isLowCrouching()
            + ", riseActive=" + isHalfCoverRising()
            + ", riseProgress=" + String.format("%.3f", getHalfCoverRiseProgress())
            + ", emergency=" + hasEmergencyEngagementPosture()
            + ", emergencyRemaining=" + getEmergencyEngagementPostureRemainingTicks()
            + ", target=" + targetDescription;
    }

    private String rotationTraceContext() {
        Vec3 threat = threatAwareness.getPrimaryDirection(position());
        LivingEntity target = getTarget();
        String coverState = enumName(CoverBehaviorManager.CoverState.values(), getSyncedCoverState());
        String coverType = enumName(CoverType.values(), getSyncedCoverCurrentType());
        String peekState = enumName(PeekController.State.values(), getSyncedPeekState());
        return "coverState=" + coverState + ", coverType=" + coverType + ", peek=" + peekState
            + ", suppression=" + String.format("%.2f", getSyncedSuppressionLevel())
            + ", lowCrouch=" + isLowCrouching() + ", target=" + (target == null ? "none" : target.getId())
            + ", threat=" + formatVec(threat) + ", navDone=" + getNavigation().isDone()
            + ", velocity=" + formatVec(getDeltaMovement());
    }

    private static String enumName(Enum<?>[] values, int ordinal) {
        return ordinal >= 0 && ordinal < values.length ? values[ordinal].name() : "INVALID(" + ordinal + ")";
    }

    private static String formatYawTriplet(float yaw, float bodyYaw, float headYaw) {
        return "entity=" + formatAngle(yaw) + ",body=" + formatAngle(bodyYaw) + ",head=" + formatAngle(headYaw);
    }

    private static String formatAngle(float angle) { return String.format("%.1f", Mth.wrapDegrees(angle)); }

    private static String formatVec(Vec3 value) {
        return value == null ? "none" : String.format("(%.2f,%.2f,%.2f)", value.x, value.y, value.z);
    }

    private static float approachAngle(float current, float target, float maxChange) {
        return current + Mth.clamp(Mth.wrapDegrees(target - current), -maxChange, maxChange);
    }

    /** Lets a close flanker briefly interrupt defensive low-crouch posture. */
    public void requestEmergencyEngagementPosture() {
        emergencyEngagementPostureUntilTick = tickCount + 20;
        tracePeek("emergency-posture", "requested remainingTicks=20");
    }

    public boolean hasEmergencyEngagementPosture() {
        return tickCount <= emergencyEngagementPostureUntilTick;
    }

    public void clearEmergencyEngagementPosture() {
        emergencyEngagementPostureUntilTick = -1;
        tracePeek("emergency-posture", "cleared");
    }

    public int getEmergencyEngagementPostureRemainingTicks() {
        return Math.max(0, emergencyEngagementPostureUntilTick - tickCount + 1);
    }

    /**
     * Returns the forward direction for formation positioning.
     * Uses the goal/movement direction first (squad-consistent via owner's position),
     * then owner's look direction, then threat direction, then fallback.
     */
    public ThreatAwareness getThreatAwareness() {
        return threatAwareness;
    }

    /** Universal suppressed-movement posture controller (dangerTravelResponse). */
    public com.stevesarmy.entity.ai.TravelCrawlController getTravelCrawlController() {
        return travelCrawl;
    }

    public com.stevesarmy.entity.ai.SoldierMovementController getMovementController() {
        return movementController;
    }
    
    public void syncThreatDirection(Vec3 direction) {
        if (direction == null || direction.lengthSqr() < 0.001) {
            this.entityData.set(THREAT_DIR_X, 0f);
            this.entityData.set(THREAT_DIR_Y, 0f);
            this.entityData.set(THREAT_DIR_Z, 0f);
        } else {
            Vec3 normalized = direction.normalize();
            this.entityData.set(THREAT_DIR_X, (float) normalized.x);
            this.entityData.set(THREAT_DIR_Y, (float) normalized.y);
            this.entityData.set(THREAT_DIR_Z, (float) normalized.z);
        }
    }
    
    public Vec3 getSyncedThreatDirection() {
        float x = this.entityData.get(THREAT_DIR_X);
        float y = this.entityData.get(THREAT_DIR_Y);
        float z = this.entityData.get(THREAT_DIR_Z);
        if (x == 0f && y == 0f && z == 0f) {
            return null;
        }
        return new Vec3(x, y, z);
    }

    public void cancelCoverMovement() {
        if (moveControl instanceof com.stevesarmy.entity.ai.CoverPositionController ctrl) {
            ctrl.clear();
        }
    }

    /**
     * Temporarily gives vanilla navigation exclusive control of facing while
     * traversing a vertical route segment. Combat uses this to avoid pulling a
     * soldier back toward a threat in the middle of a jump or landing.
     */
    private void updateNavigationTraversalLock() {
        Path path = getNavigation().getPath();
        if (path == null || path.isDone()) {
            return;
        }

        int nextIndex = path.getNextNodeIndex();
        BlockPos nextNode = path.getNode(Math.min(nextIndex, path.getNodeCount() - 1)).asBlockPos();
        int currentY = blockPosition().getY();
        int heightDelta = nextNode.getY() - currentY;
        boolean verticalNextNode = heightDelta != 0;
        boolean upcomingClimb = heightDelta > 0;

        if (!verticalNextNode && nextIndex + 1 < path.getNodeCount()) {
            BlockPos followingNode = path.getNode(nextIndex + 1).asBlockPos();
            upcomingClimb = followingNode.getY() > nextNode.getY();
        }

        if (verticalNextNode) {
            setNavigationTraversalLock("vertical_node", heightDelta, NAVIGATION_LANDING_LOCK_TICKS);
        } else if (!onGround()) {
            setNavigationTraversalLock("airborne", 0, NAVIGATION_LANDING_LOCK_TICKS);
        } else if ((horizontalCollision || minorHorizontalCollision) && upcomingClimb) {
            setNavigationTraversalLock("climb_collision", 1, NAVIGATION_COLLISION_LOCK_TICKS);
        }
    }

    private void setNavigationTraversalLock(String reason, int heightDelta, int durationTicks) {
        navigationTraversalLockUntilTick = Math.max(navigationTraversalLockUntilTick, tickCount + durationTicks);
        navigationTraversalHeightDelta = heightDelta;
        navigationTraversalLockReason = reason;
    }

    public boolean isNavigationTraversalLocked() {
        return tickCount <= navigationTraversalLockUntilTick;
    }

    public String getNavigationTraversalLockReason() {
        return isNavigationTraversalLocked() ? navigationTraversalLockReason : "none";
    }

    public int getNavigationTraversalHeightDelta() {
        return isNavigationTraversalLocked() ? navigationTraversalHeightDelta : 0;
    }

    /** Directs LookControl along the active path without directly changing body yaw. */
    public void faceNavigationTraversal() {
        if (!isNavigationTraversalLocked()) {
            return;
        }

        Path path = getNavigation().getPath();
        if (path != null && !path.isDone() && path.getNodeCount() > 0) {
            int nextIndex = Math.min(path.getNextNodeIndex(), path.getNodeCount() - 1);
            BlockPos nextNode = path.getNode(nextIndex).asBlockPos();
            getLookControl().setLookAt(nextNode.getX() + 0.5D, getEyeY(), nextNode.getZ() + 0.5D, 30.0F, 30.0F);
            return;
        }

        Vec3 movement = getDeltaMovement();
        if (movement.horizontalDistanceSqr() > 0.0001D) {
            getLookControl().setLookAt(getX() + movement.x, getEyeY(), getZ() + movement.z, 30.0F, 30.0F);
        }
    }

    /** Stops ordinary movement while a reload is pending or active. */
    public void holdMovementForReload() {
        if (!isPreparingOrReloading()) {
            return;
        }

        // A soldier without occupied cover must be allowed to finish an
        // already-selected cover approach. The cover goal and position
        // controller apply the bounded movement exception for this case.
        if (isMovingToUnoccupiedCoverDuringReload()) {
            return;
        }

        // The claim→dock alignment onto an already-claimed cover also finishes
        // through the reload — see CoverPositionController's dock exception.
        if (moveControl instanceof com.stevesarmy.entity.ai.CoverPositionController ctrl
            && ctrl.isFinishingCoverDockDuringReload()) {
            return;
        }

        this.getNavigation().stop();
        if (moveControl instanceof com.stevesarmy.entity.ai.CoverPositionController ctrl) {
            // A tactical goal may deliberately preserve a full-cover duck-back.
            ctrl.stopForReload();
        }
    }

    public boolean isMovingToUnoccupiedCoverDuringReload() {
        CoverBehaviorManager.CoverState state = coverBehaviorManager.getState();
        // NO_COVER with a selected target is how findAndMoveToCover hands a fresh
        // cover to navigation; the approach exception must cover it or a reload
        // started mid-search rejects every candidate as a fake PATH_FAILED.
        return coverBehaviorManager.getCurrentCover() == null
            && coverBehaviorManager.getTargetCover() != null
            && (state == CoverBehaviorManager.CoverState.SEEKING_COVER
                || state == CoverBehaviorManager.CoverState.REPOSITIONING
                || state == CoverBehaviorManager.CoverState.NO_COVER);
    }
}
