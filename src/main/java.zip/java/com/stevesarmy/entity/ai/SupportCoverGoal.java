package com.stevesarmy.entity.ai;

import com.stevesarmy.combat.cover.CoverBehaviorManager;
import com.stevesarmy.entity.SupportEntity;
import com.stevesarmy.entity.SoldierEntity;
import net.minecraft.core.BlockPos;
import net.minecraft.world.entity.ai.goal.Goal;

import javax.annotation.Nullable;
import java.util.EnumSet;

/**
 * Support cover goal. Delegates all state machine, movement, ping, and
 * suppression behavior to CoverTacticalGoal. The support role uses rear
 * positioning (like the MG) but never peeks. This shell keeps the support's
 * cover pipeline a distinct goal instance and disables peeking.
 */
public final class SupportCoverGoal extends Goal implements CoverGoalController {
    private final SupportEntity soldier;
    private final CoverTacticalGoal coverController;
    private final SupportDutyController supportDuty;
    private SupportPhase phase = SupportPhase.COVER;

    private enum SupportPhase {
        COVER,
        DUTY
    }

    public SupportCoverGoal(SoldierEntity soldier) {
        if (!(soldier instanceof SupportEntity support)) {
            throw new IllegalArgumentException("SupportCoverGoal requires a support entity");
        }
        this.soldier = support;
        this.coverController = new CoverTacticalGoal(soldier, true);
        this.supportDuty = new SupportDutyController(support);
        this.setFlags(EnumSet.of(Flag.MOVE, Flag.LOOK));
    }

    /** The wrapped cover state machine (debug/sim surface, mirrors MachineGunnerSupportGoal). */
    public CoverTacticalGoal getCoverController() {
        return coverController;
    }

    @Override
    public boolean canUse() {
        if (phase == SupportPhase.DUTY) return soldier.isAlive();
        return coverController.canUse();
    }

    @Override
    public boolean canContinueToUse() {
        if (phase == SupportPhase.DUTY) return soldier.isAlive() && supportDuty.isActive();
        return coverController.canContinueToUse();
    }

    @Override
    public void start() {
        if (phase == SupportPhase.DUTY) {
            supportDuty.start();
            return;
        }
        coverController.start();
    }

    @Override
    public void stop() {
        if (phase == SupportPhase.DUTY) {
            supportDuty.stop();
            phase = SupportPhase.COVER;
            coverController.stop();
            return;
        }
        coverController.stop();
    }

    @Override
    public void resetFromStuckWatchdog() {
        coverController.resetFromStuckWatchdog();
    }

    @Override
    public void noteHitWhilePeekingAtCover() {
        coverController.noteHitWhilePeekingAtCover();
    }

    @Override
    public void tick() {
        if (phase == SupportPhase.DUTY) {
            // Suppression mid-duty is handled by the duty controller (duck and
            // hold); only non-combat interruptions abort immediately.
            if (soldier.isRecalling() || soldier.isHealing() || soldier.isUsingItem()) {
                supportDuty.stop();
                phase = SupportPhase.COVER;
                resumeCover();
                return;
            }

            SupportDutyController.DutyResult result = supportDuty.tick();
            if (result != SupportDutyController.DutyResult.RUNNING) {
                phase = SupportPhase.COVER;
                resumeCover();
            }
            return;
        }

        coverController.tick();

        CoverBehaviorManager manager = soldier.getCoverBehaviorManager();
        if (manager.isInCover()
            && supportDuty.tryStartDuty()) {
            phase = SupportPhase.DUTY;
            coverController.stop();
            manager.clearCover();
            supportDuty.start();
        }
    }

    private void resumeCover() {
        CoverBehaviorManager manager = soldier.getCoverBehaviorManager();
        manager.clearCover();
        manager.setState(CoverBehaviorManager.CoverState.SEEKING_COVER);
        coverController.start();
    }

    @Override
    public boolean requestGoToRelocation(BlockPos destination, int commandGeneration) {
        return coverController.requestGoToRelocation(destination, commandGeneration);
    }

    @Override
    public boolean isHandlingGoToRelocation(int commandGeneration) {
        return coverController.isHandlingGoToRelocation(commandGeneration);
    }

    @Override
    public SuppressionPositionStatus requestSuppressionPosition(BlockPos area, int generation) {
        return coverController.requestSuppressionPosition(area, generation);
    }

    @Override
    public SuppressionPositionStatus getSuppressionPositionStatus(int generation) {
        return coverController.getSuppressionPositionStatus(generation);
    }

    @Override
    public void cancelSuppressionPosition(int generation) {
        coverController.cancelSuppressionPosition(generation);
    }

    @Override
    @Nullable
    public BlockPos getProneDefensivePosition() {
        return coverController.getProneDefensivePosition();
    }
}
