package com.stevesarmy.entity.ai;

import com.stevesarmy.GameClock;
import com.stevesarmy.StevesArmyMod;
import com.stevesarmy.StevesArmyConfig;
import com.stevesarmy.combat.CombatStateSnapshot;
import com.stevesarmy.combat.GunIntegration;
import com.stevesarmy.combat.TargetAcquisition;
import com.stevesarmy.combat.ThreatAwareness;
import com.stevesarmy.combat.VisibilityRay;
import com.stevesarmy.combat.cover.*;
import com.stevesarmy.squad.ClearingCoordinator;
import com.stevesarmy.squad.ContactPlan;
import com.stevesarmy.squad.FireTeamSuppressionTracker;
import com.stevesarmy.squad.SmokeDeploymentCoordinator;
import com.stevesarmy.combat.cover.pure.CoverSearchResult;
import com.stevesarmy.combat.cover.pure.AsyncCoverShadowService;
import com.stevesarmy.combat.cover.pure.CoverSnapshotCapture;
import com.stevesarmy.combat.cover.pure.PureCoverEvaluator;
import com.stevesarmy.debug.DiagnosticLogManager;
import com.stevesarmy.debug.PerformanceMetrics;
import com.stevesarmy.entity.SoldierEntity;
import com.stevesarmy.entity.SoldierRole;
import com.stevesarmy.entity.MachineGunnerEntity;
import com.stevesarmy.entity.SupportEntity;
import com.stevesarmy.network.CoverStateDebugPacket;
import com.stevesarmy.squad.SquadCoverContext;
import com.stevesarmy.squad.SquadManager;
import com.stevesarmy.squad.SquadMode;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.ai.goal.Goal;
import net.minecraft.world.entity.ai.navigation.PathNavigation;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.pathfinder.Path;
import net.minecraft.world.phys.Vec3;

import java.util.*;

public class CoverTacticalGoal extends Goal implements CoverGoalController {
    // Attack phase enum - what the soldier is trying to do
    public enum AttackPhase {
        NONE,
        SELECTING_COVER,
        MOVING_TO_COVER,
        OCCUPYING_COVER,
        COMPLETE
    }

    // Result of a cover search operation
    private enum CoverMoveResult {
        COVER_STARTED,
        NO_COVER_FOUND,
        NO_ELIGIBLE_COVER,
        ASYNC_PENDING
    }

    private enum QueuedSearchMode {
        NORMAL,
        REPOSITION,
        ATTACK_SELECTING,
        SHOT_IN_COVER,
        CONTINUOUS_SUPPRESSION,
        SUPPRESSION_REPOSITION,
        // Player-issued suppress-area movement. This deliberately does not share
        // the incoming-fire escape request or its threat-derived search centre.
        SUPPRESSION_POSITION
    }

    private final SoldierEntity soldier;
    private final PathNavigation navigation;
    private final boolean machineGunnerPipeline;
    private CoverSelectionStrategy coverSelectionStrategy;
    
    private int cooldown = 0;
    private int stuckTicks = 0;
    private int reevaluateCounter = 0;
    private int noProgressTicks = 0;
    private int seekingTicks = 0;
    private int repositioningTicks = 0;
    private int consecutiveFailedSearches = 0;
    private int searchExhaustionCooldown = 0;
    private int goToRelocationTicks = 0;
    // Distance-scaled ceiling for goToRelocationTicks: the flat 200-tick cap
    // bounds only search latency, but the clock counts staged walking too, so
    // any cover farther than ~30 walked blocks force-failed mid-route. Scales
    // with the request distance beyond the exact-path radius, mirroring the
    // distance-scaled repositioning budget below it.
    private int goToRelocationMaxTicks = MAX_GO_TO_RELOCATION_TICKS;
    private Vec3 lastSeekingPosition = null;
    // A prone lane reserves squad spacing without a physical-cover claim, peek state, or cover bonus.
    private BlockPos proneFiringDestination;
    private int lastProneFallbackSearchTick = -100;
    private final ProneFiringController proneFiringController;
    
    private static final int COOLDOWN_TICKS = 40;
    private static final int MAX_STUCK_TICKS = 60;
    /** Covers one search may start walking toward when the best is taken (bounds path cost). */
    private static final int MAX_RESERVE_CANDIDATE_ATTEMPTS = 4;
    /** Movement attempts started so far by the current cover search's reserve pools. */
    private int searchReserveAttempts = 0;
    /**
     * Without a cover claim for this long (wall clock, immune to prone walks
     * and state flips that freeze seekingTicks), the next search widens toward
     * the squad. Roughly the seek timeout: enough failed searches that radius,
     * not luck, is the problem.
     */
    private static final int SEEK_ESCALATION_TICKS = 120;
    /** Set once the escalation threshold passed without a cover claim; cleared on claim. */
    private boolean seekEscalated = false;
    /** Game tick of the last tick spent in an occupied-cover state. */
    private int lastInCoverTick = 0;
    private static final int REEVALUATE_INTERVAL_TICKS = 60;
    
    private static final double COVER_REACHED_DISTANCE = 1.5D;
    private static final double COVER_VALID_DISTANCE = 1.6D;
    private static final double COMBAT_COVER_VALID_DISTANCE = 6.0D;
    private static final double COVER_ABANDON_DISTANCE = 8.0D;
    
    private static final int SEARCH_RADIUS = 12;
    private static final long MIN_COVER_DWELL_TIME_MS = 4000;
    private static final int SHOT_IN_COVER_RETRY_TICKS = 20;
    private static final long MIN_SUPPRESSED_DWELL_TIME_MS = 6000;
    private static final float HYSTERESIS_THRESHOLD = 0.20f;
    private static final float BACKWARD_HYSTERESIS_THRESHOLD = 0.35f;
    private static final long MIN_PEEK_INTERVAL_MS = 2000;
    private static final int MAX_SEEKING_TICKS = 200;
    private static final int MAX_CONSECUTIVE_FAILED_SEARCHES = 4;
    private static final int SEARCH_EXHAUSTION_COOLDOWN_TICKS = 60;
    // An under-fire soldier cannot afford the full exhaustion wait in the open.
    private static final int SEARCH_EXHAUSTION_COOLDOWN_SUPPRESSED_TICKS = 15;
    // Emergency reposition searches that keep failing stop after this many
    // attempts instead of looping forever every SHOT_IN_COVER_RETRY_TICKS.
    private static final int EMERGENCY_SEARCH_MAX_CONSECUTIVE_FAILURES = 3;
    private static final int EMERGENCY_SEARCH_FAILURE_COOLDOWN_TICKS = 100;
    // A pressured peek may continue only this long before it is folded back
    // into the defensive crouch.
    private static final int PRESSURED_PEEK_STALL_GRACE_TICKS = 60;
    // GO_TO must fall back to direct navigation promptly if cover search is
    // queued behind a large squad or repeatedly fails to produce a route.
    private static final int MAX_GO_TO_RELOCATION_TICKS = MAX_SEEKING_TICKS;
    private static final float LOW_HEALTH_THRESHOLD = 0.3f;
    private static final float FOLLOW_COVER_DISTANCE = 15.0f;
    private static final int REPEATED_SUPPRESSION_EPISODE_THRESHOLD = 3;
    private static final int PRESSURED_PEEK_DECISION_INTERVAL_TICKS = 10;
    private static final double PRESSURED_PEEK_RADIUS = 8.0D;
    private static final float PRESSURED_PEEK_MIN_CHANCE = 0.10f;
    private static final float PRESSURED_PEEK_RECOVERY_WEIGHT = 0.40f;
    private static final float PRESSURED_PEEK_ALLY_WEIGHT = 0.20f;
    private static final float PRESSURED_PEEK_MAX_CHANCE = 0.90f;
    
    private static final double FOLLOW_COVER_SEARCH_RADIUS = 15.0D;
    private static final double FOLLOW_REGROUP_DISTANCE = 10.0D;
    private static final int RELOCATION_SEARCH_RADIUS = 16;
    /** Near-LOS tolerance for suppression siting: a lane blocked within this distance of a zone sample is a valid lane. */
    private static final double SUPPRESSION_SIGHTING_TOLERANCE = 2.0D;
    private static final int FOLLOW_COVER_RETRY_TICKS = 40;
    private static final long CONTINUOUS_SUPPRESSION_REPOSITION_DELAY_MS = 8000L;
    private static final int SUPPRESSION_ROUTE_CANDIDATE_LIMIT = 8;
    private static final double CRAWL_ROUTE_SPEED = 0.65D;
    // Vanilla pathfinding is bounded by FOLLOW_RANGE. Far relocation targets need
    // progressive paths until they enter this exact-path validation radius.
    private static final double RELOCATION_EXACT_PATH_DISTANCE = 32.0D;
    private static final double MIN_STAGED_PATH_PROGRESS = 1.0D;
    // FOLLOW cover target is replaced when the owner has moved far enough
    // from the selected cover's position (18 blocks ~= FOLLOW_COVER_SEARCH_RADIUS + margin).
    private static final double FOLLOW_TARGET_STALE_DISTANCE = 18.0D;
    private static final int FOLLOW_REPLAN_COOLDOWN_TICKS = 40;
    // Rear roles (support) get a looser FOLLOW leash: a pacing owner must not
    // drag the medic into a new cover search every few seconds.
    private static final float SUPPORT_FOLLOW_COVER_DISTANCE = 22.0f;
    private static final double SUPPORT_FOLLOW_TARGET_STALE_DISTANCE = 30.0D;
    private static final double SUPPORT_FOLLOW_OWNER_MAX_DISTANCE_SQR = 32.0D * 32.0D;
    // The support/MG search anchor is latched so repeated searches within this
    // window score identically instead of tracking every teammate step.
    private static final int MG_ANCHOR_LATCH_TICKS = 200;
    
    private static final double POSITIONING_TOLERANCE = 0.05;
    private static final double POSITIONING_SPEED = 1.0;
    private static final long BLACKLIST_CLEAR_INTERVAL_MS = 15000;
    
    private static final double THREAT_ANGLE_REPOSITION_THRESHOLD = 2.09;
    private static final int NON_PEEKABLE_REPOSITION_TICKS = 40;

    private static final float FLANKING_PROTECTION_THRESHOLD = 0.7f;
    private static final float MIN_FLANKING_IMPROVEMENT = 0.1f;
    private static final long FLANK_REPOSITION_COOLDOWN_MS = 5000;
    private static final int FLANK_SEARCH_RETRY_TICKS = 40;
    private static final double MID_MOVE_ANGLE_THRESHOLD = 1.05;

    // Attack-mode constants
    private static final int ATTACK_FORWARD_BIAS_BLOCKS = 6;
    private static final double ATTACK_MIN_FORWARD_PROGRESS = 2.0;
    private static final long ATTACK_MIN_DWELL_MS = 4000;
    private static final long ATTACK_MAX_DWELL_MS = 8000;
    private static final long ATTACK_HARD_OCCUPANCY_TIMEOUT_MS = 15000;
    private static final double ATTACK_OBJECTIVE_RADIUS = 4.0;
    /** Matches ContactPlan.MG_BACK_ROW_LAG_BLOCKS: absorb threshold jitter. */
    private static final double MG_BACK_ROW_LAG_BLOCKS = 1.0;
    /**
     * How far past the MG's dock the frontmost rifleman must be before the
     * gunner abandons it and leapfrogs to a cover behind the new line. One
     * spine hop — a shorter lead makes the dock cycle at dwell cadence.
     */
    private static final double MG_LEAPFROG_MARGIN_BLOCKS = 5.0;

    // Attack corridor constants (search rectangle along objective direction)
    private static final int ATTACK_CORRIDOR_FORWARD_LENGTH = 24;
    private static final int ATTACK_CORRIDOR_HALF_WIDTH = 6;
    private static final int ATTACK_WIDE_SECTOR_HALF_WIDTH = 16;
    private static final int ATTACK_CORRIDOR_SEARCH_RADIUS = 24;
    private static final double ATTACK_FRONTIER_TOLERANCE = 2.0;
    private static final int ATTACK_CORRIDOR_REFRESH_TICKS = 15;
    // Fallback advance when no cover found in corridor
    private static final double ATTACK_FALLBACK_ADVANCE_LENGTH = 4.0;
    private static final int ATTACK_FALLBACK_STUCK_TICKS = 60;
    // Spine hop: minimum route progress a dock must buy. SIZED BETWEEN the
    // structures it separates: house-wall docks sit ~5 blocks apart along
    // the exit route (a smaller minimum turns the exit into a wall relay),
    // while street cover rows sit ~12 apart (a larger minimum skips them).
    private static final double ATTACK_SPINE_HOP_LENGTH = 10.0;
    // Spine LEG: how far a dockless-failure advance walks along the route
    // before re-searching. Matched to the street cover-row spacing so a leg
    // lands beside the next row instead of jumping past it.
    private static final double ATTACK_SPINE_LEG_LENGTH = 12.0;
    // Catch-up steps tried when the row gate denies a full leg: from a bunched
    // squad start every full leg lands past the back-row line, which froze the
    // gunner at spawn until the riflemen were a whole leg ahead. Shortened
    // fractions keep him trailing the group (each candidate is re-validated by
    // the same gate, so the row line itself is never weakened).
    private static final double[] CATCHUP_LEG_FRACTIONS = {0.5D, 0.25D};
    // Spine corridor half-width. Wider than the legacy straight-line
    // corridor (6): the route dodges cover rows, so docks BESIDE a row can
    // sit several blocks off the polyline while still being the natural
    // cover on the street the route is walking.
    private static final double ATTACK_SPINE_CORRIDOR_WIDTH = 10.0;

    // Attack phase state
    private AttackPhase attackPhase = AttackPhase.NONE;
    private int attackCommandGeneration = -1;
    private long attackPhaseStartTime = 0;
    private long attackCoverArrivalTime = 0;
    private BlockPos attackExpectedCover = null;
    private boolean attackDwellEligible = false;
    private long attackDwellDelay = 0;
    private int attackAdvanceStaggerTicks = 0;
    private boolean attackHasPeekedThisCover = false;
    private boolean peekCompletedThisCover = false;
    private long lastAdvanceTriggerTime = 0;

    // Attack progress tracking: best (closest) distance to objective this command
    private double attackBestObjectiveDist = Double.MAX_VALUE;
    // Forward frontier: any cover closer to objective than this is acceptable
    private double attackFrontierDistance = Double.MAX_VALUE;
    /** Clearing-doctrine view for this tick (null = no order of record). */
    private ClearingCoordinator.ClearingView clearingView = null;
    /** CLEAR-stage job target the search should dock near (null = plain advance). */
    private BlockPos clearingPoiTarget = null;
    /** Consecutive goal ticks the assigned blind spot stayed open while held. */
    private int clearingStaleTargetTicks = 0;
    /** Dock position the clearing windows were last reset at (null = no dock). */
    private BlockPos clearingLastDockPos = null;
    /** How long an assigned check target may stay unobserved before walking to it. */
    private static final int CLEARING_INVESTIGATE_TICKS = 160;
    /** Jobs beyond this range of the soldier are walked, not dock-hopped (12 blocks). */
    private static final double CLEARING_INVESTIGATE_BAND_SQ = 144.0D;
    /** Before walking to an assigned check target, how long its "no route" verdict holds. */
    private static final int CLEARING_POI_UNREACHABLE_BACKOFF_TICKS = 600;
    /** Per-guide "no route" verdicts: guide position -> expiry tick. Keyed by
     * guide because the search-fail and investigate paths probe different
     * guides for the same order; a single-slot cache would thrash between them. */
    private final Map<BlockPos, Long> clearingUnreachableUntil = new HashMap<>();
    /** The assigned job an in-flight investigate reposition was delivered for,
     * and the position it started from — the re-dock measures the approach. */
    private BlockPos investigateJob = null;
    private Vec3 investigateStartPos = null;
    /** Consecutive goal ticks the squad-completion assemble pull has applied to this soldier. */
    private int clearingAssembleTicks = 0;
    /** How long a soldier outside the healthy area waits before the assemble walk starts. */
    private static final int CLEARING_ASSEMBLE_TICKS = 30;
    /** The current fallback advance is the SECURE assemble walk (explicit executor action). */
    private boolean fallbackAdvanceAssemble = false;
    /** After repeated assemble stuck escalations, back off before retrying. */
    private long assembleRetryAfterTick = 0;
    private static final int CLEARING_ASSEMBLE_RETRY_BACKOFF_TICKS = 200;
    /**
     * Graded assemble windows that bought no approach. Two consecutive
     * failures mean the cover-system re-dock cannot see an inside slot from
     * where the soldier is parked — the churn then repeats forever (a
     * mid-clear death can leave a survivor parked just outside the area,
     * starving the all-inside settle until the order STALLEDs). At 2 the
     * assemble escalates to releasing the dock and walking in directly.
     */
    private int assembleDockFailures = 0;
    /**
     * Direct egress (attackClearDirectEgress): consecutive parked ticks while
     * the soldier's job lies beyond investigate range — or there is no in-band
     * job at all. Dock-hopping cannot deliver a far job (the re-dock search
     * only finds cover near the soldier, every window misses, and the delivery
     * grade poisons the route cache), so past the window the soldier walks one
     * full route instead. Mirrors the assemble window/backoff shape.
     */
    private int clearingEgressTicks = 0;
    private long egressRetryAfterTick = 0;
    /**
     * Churn grading for the dwell clocks: a re-dock restarts a clock only if
     * it closed at least this much on the best approach the dwell has seen.
     * The cover system re-docks a soldier every window or two while he orbits
     * a pocket; resetting clocks on every arrival lets the churn itself starve
     * the walk that would end it.
     */
    private static final double CLEARING_DOCK_PROGRESS_DELTA_SQ = 4.0;
    /** Best distance-sq to the egress guide since the egress dwell last reset; -1 unanchored. */
    private double clearingEgressBestDistSq = -1.0;
    /** Claim the stale-dwell best-distance is measured against; null unanchored. */
    private BlockPos clearingStaleBestJob = null;
    /** Best distance-sq to {@link #clearingStaleBestJob} since the stale dwell last reset. */
    private double clearingStaleBestDistSq = -1.0;

    private long lastFlankRepositionTime = 0;
    private long failedFlankSearchFingerprint = Long.MIN_VALUE;
    private int nextFlankSearchTick = 0;

    // Routine-reposition safety gates (peek-first, soft covering-fire, HEAVY hold).
    // These only throttle P1 routine advances; P0 emergency moves bypass them.
    private long recoverySafetyPeekStartMs = 0L;
    private long recoverySafetyPeekSeqSnapshot = -1L;
    private boolean recoverySafetyPeekDone = false;
    private boolean recoverySafetyPeekInProgress = false;

    // Fallback advance state (no cover found — walk forward and re-search)
    private BlockPos fallbackAdvanceTarget = null;
    private int fallbackStuckTicks = 0;
    /** Arrival threshold (squared) for the in-flight advance; investigate walks stop tight. */
    private double fallbackAdvanceArriveDistSq = 4.0;
    private Vec3 fallbackLastPosition = null;
    private int fallbackNoProgressResets = 0;

    // Advance spine (path-based progression): the wide-lens route to the
    // objective, computed once per command. ATTACK cover progression is
    // measured as walked distance along this polyline instead of straight-
    // line distance — the two disagree wherever a building forces the route
    // away from the objective before rounding it.
    private com.stevesarmy.entity.ai.pathfinding.AdvanceSpine attackSpine = null;
    private int spineRetryAfterTick = 0;
    /** Command-start tick + bound: SELECTING holds the first search until the
     * spine probe lands (or this expires) so the first dock is spine-scored. */
    private int spineWaitUntilTick = 0;
    /** Best spine progress this command — the spine-frame frontier. */
    private double attackSpineProgressFrontier = -Double.MAX_VALUE;
    /** Best spine progress any dock in this command bought (egress clock). */
    private double clearingEgressBestProgress = -Double.MAX_VALUE;
    /** LoS to the objective along the straight line (spine exposure gate). */
    private boolean attackSpineExposed = false;
    private int spineExposureRefreshTick = 0;

    private final Set<BlockPos> failedCoverPositions = new HashSet<>();
    private final java.util.Map<BlockPos, BlacklistEntry> blacklistReasons = new java.util.HashMap<>();
    private long lastBlacklistClearTime = 0;
    private BlockPos lastFailedCover = null;
    private int nonPeekableTicks = 0;
    private int nextShotInCoverSearchTick = 0;
    private BlockPos compromisedCoverPosition = null;
    private boolean emergencyCoverSearchActive = false;
    private BlockPos suppressionEpisodeCover = null;
    private BlockPos latchedMachineGunnerSearchCenter = null;
    private int latchedMachineGunnerSearchCenterTick = 0;
    private int suppressionEpisodeCount = 0;
    private boolean suppressionEpisodeActive = false;
    private long continuousSuppressionStartTime = 0L;
    private boolean continuousSuppressionRepositionStarted = false;
    private BlockPos absolutePinDockPos = null;
    private int nextPressuredPeekDecisionTick = 0;
    private boolean suppressionRouteSearchActive = false;
    private List<Vec3> suppressionRouteFiringOrigins = List.of();
    private SuppressionRoutePlan selectedSuppressionRoute = null;
    private RouteMovement activeSuppressionRouteMovement = RouteMovement.NORMAL;
    private boolean activeRouteCrawlMandatory;
    private int nextSuppressionRouteSearchTick = 0;
    // Suppression rarely comes from one rifle: the goal remembers the last few
    // DISTINCT firing origins that pressured this soldier (CoverBehaviorManager
    // keeps only the most recent one) so a relocation route must be shielded
    // from every lane we know about, not just the latest shooter's.
    private static final int SUPPRESSION_ORIGIN_MEMORY_LIMIT = 4;
    private static final double SUPPRESSION_ORIGIN_DISTINCT_DIST_SQ = 4.0D; // 2 blocks
    // Mirrors CoverBehaviorManager.SUPPRESSION_FIRING_ORIGIN_MEMORY_MS.
    private static final long SUPPRESSION_ORIGIN_FRESH_MS = 15000L;
    // Sustained-quiet window before an autonomous ATTACK advance may leave a
    // held dock (suppressedRelocationSafeRoute): momentary recovery inside a
    // live fire cycle (sup decays to 0 between enemy bursts) must not re-seed
    // a corridor walk that the next burst catches mid-crossing.
    private static final long ATTACK_ADVANCE_QUIET_MS = 8000L;
    private final List<SuppressionFiringOrigin> recentSuppressionFiringOrigins = new ArrayList<>();
    // --- Suppressed open-ground escape (suppressedRelocationSafeRoute) ------
    // Composed doctrine (user): a suppressed soldier IN THE OPEN whose
    // classified relocation is withheld must still MOVE — dash to close cover,
    // crawl low toward the best cover when the nearest shooter is far, dash
    // anyway as the last resort. Thresholds verbatim from the doctrine.
    private static final double ESCAPE_DASH_RANGE = 5.0D;
    private static final double ESCAPE_CRAWL_SHOOTER_MIN_DIST = 32.0D;
    // Escape-mode flag for the suppression search pass: the classifier's veto
    // becomes a preference (PROTECTED > CRAWL_SAFE > best-scored EXPOSED).
    private boolean suppressionEscapeSearchActive = false;
    // Oscillation guard: the committed escape dock. Once chosen, the escape is
    // not re-decided until arrival, invalidation, or suppression-state change.
    private BlockPos escapeCommitCoverPos = null;
    // True while the committed escape move is a doctrine crawl still outside
    // dash range of its dock (the final stretch upgrades to a dash).
    private boolean escapeCrawlToDashPending = false;
    private BlockPos suppressionPositionArea = null;
    private BlockPos suppressionPositionOrigin = null;
    private int suppressionPositionGeneration = -1;
    private SuppressionPositionStatus suppressionPositionStatus = SuppressionPositionStatus.IDLE;
    private int suppressionPositionFailures;
    private int nextSuppressionPositionSearchTick;
    private String suppressionPositionLastFailure = "none";
    private int emergencySearchFailureCount = 0;
    private int pressuredPeekStallStartTick = -1;
    private int hitWhilePeekingCount = 0;
    private int peekCycleLogTick = 0;
    
    private CoverPoint pendingRetryCover = null;
    private boolean isRetryAttempt = false;
    private boolean reloadHoldActive;
    private int reloadMovementLogCooldown;
    private boolean healingPosturePending;

    private enum RelocationType { NONE, GO_TO, FOLLOW }

    private enum RouteNodeExposure { PROTECTED, CRAWL_SAFE, EXPOSED }

    private enum RouteMovement { NORMAL, CRAWL }

    private record SuppressionRoutePlan(CoverPoint cover, Path path, RouteMovement movement,
                                        boolean classifierRequiresCrawl, List<Vec3> firingOrigins) {}

    private record SuppressionFiringOrigin(Vec3 pos, long recordedMs) {}

    private RelocationType relocationType = RelocationType.NONE;
    private BlockPos relocationCenter = null;
    private int relocationCommandGeneration = -1;
    private int failedGoToRelocationGeneration = -1;
    private int nextFollowRelocationSearchTick = 0;
    private int followReplanCooldownTicks = 0;

    private boolean coverSearchPending;
    private boolean asyncPilotPending;
    private long asyncPilotSubmittedTick = Long.MIN_VALUE;
    private boolean asyncPilotFallback;
    private QueuedSearchMode queuedSearchMode;
    private int queuedAttackGeneration = -1;
    private RelocationType queuedRelocationType = RelocationType.NONE;
    private BlockPos queuedRelocationCenter;
    /** Whether the soldier was already docked when this search was queued.
     * A search queued from cover (job-done advance, investigate reposition)
     * must run even though the soldier is still docked at execution; one
     * queued while traveling that lands after he docked is stale — running
     * it yanks him off the fresh dock (dock-to-dock orbit churn). */
    private boolean queuedSearchFromDock = false;
    private QueuedSearchMode executingSearchMode;
    private long failedSearchFingerprint = Long.MIN_VALUE;
    private QueuedSearchMode failedSearchMode;
    private int nextFailedSearchTick;
    private long blacklistRevision;

    private BlockPos movementAttemptTarget = null;
    private int movementAttemptCount = 0;
    /** Consecutive stalled-navigation re-issues against the current cover target. */
    private int noProgressReissues = 0;
    /** Distance to the current repositioning target when the attempt began (timeout budget input). */
    private double repositioningStartDist = 2.0;
    private final Map<BlockPos, Path> validatedCoverPaths = new HashMap<>();
    private final Set<BlockPos> unreachableCoverPaths = new HashSet<>();
    private BlockPos validatedCoverPathSource = null;
    private long validatedCoverPathTick = Long.MIN_VALUE;
    private ExactPathValidationBudget exactPathValidationBudget = new ExactPathValidationBudget();

    private CoverFinder.ScoredCover[] cachedTopCovers = new CoverFinder.ScoredCover[0];
    private BlockPos debugSearchCenter = null;
    /** Why shouldSeekCover last returned true; empty when it returned false. Debug only. */
    private String lastWantCoverReason = "";

    // Last-search telemetry: what the most recent cover search looked at and
    // what came back. Fills the snapshot's LastSearch so a seek stall is
    // visible as "searches keep returning nothing from HERE" instead of a
    // silent frozen state.
    private int debugSearchRadius = -1;
    private int noCoverSearchStreak = 0;

    // Dock-stall escalation: a FORWARD dock whose next-cover search keeps
    // coming back empty is a starved hold, not a valid hold — the search
    // center/radius/filters are fixed, so retrying identically can never
    // make progress. After ATTACK_DOCK_STALL_SEARCHES consecutive failures
    // from the same dock, release the dock and let the fallback advance
    // re-center the search. The keep-dock doctrine (f25f358) fixed blocked-
    // door churn but removed the only escape; this restores a bounded form.
    private static final int ATTACK_DOCK_STALL_SEARCHES = 3;
    private BlockPos attackStallDock = null;
    private int attackStallFails = 0;

    // Guide-stall concession: a DOCKLESS soldier whose clearing guide is
    // unreachable has neither a dock to hold nor an advance to take — the
    // search-fail branch used to re-request the same doomed search forever
    // (the frozen SELECTING_COVER/NO_COVER wall). After
    // ATTACK_DOCK_STALL_SEARCHES consecutive failures against the same
    // unreachable guide, concede the obligation to the coordinator so the
    // order can settle or report STALLED instead of hanging on this soldier.
    private BlockPos attackGuideStallGuide = null;
    private int attackGuideStallFails = 0;

    // GO_TO seek-starvation tracker. Keyed on the DESTINATION, not the ping
    // generation: every re-ping bumps the generation and resets
    // goToRelocationTicks, so a player mashing the ping could restart the
    // 200t relocation window forever and the direct-walk fallback would
    // never fire. This counter only resets when the destination changes or
    // a cover route actually commits.
    private BlockPos goToStallDestination = null;
    private int goToSeekStallTicks = 0;

    /** Consume the direct-walk arrival once; failed searches must retain their retry pacing. */
    private int handledGoToArrivalGeneration = -1;
    private BlockPos lastGoToArrivalObjective;
    private BlockPos lastGoToArrivalPosition;
    private String debugLastSearchMode = "";
    private String debugLastSearchResult = "";
    private String debugLastSearchPhase = "";
    private int debugLastSearchTick = -1;

    // Per-soldier rate limiters (ticks between repeated log lines)
    private static final int SNAPSHOT_INTERVAL = 20; // 1 second at 20 TPS
    private int snapshotCounter = 0;
    private int tickLogCounter = 0;
    private int peekLogCounter = 0;
    private int suppressionLogCounter = 0;
    private int threatReportLogCounter = 0;
    private int findNewTargetLogCounter = 0;
    private int moveCtlLogCounter = 0;

    // Debug logging gates — delegates to server-wide DiagnosticLogManager.
    public static void setAttackDebugLogging(boolean enabled) {
        DiagnosticLogManager.setAttackLoggingEnabled(enabled);
    }

    public static boolean isAttackDebugLoggingEnabled() {
        return DiagnosticLogManager.isAttackLoggingEnabled();
    }

    private boolean attackDebugLog() {
        return DiagnosticLogManager.isAttackLoggingEnabled() && soldier.hasValidAttackTarget();
    }

    public static void setDebugLogging(boolean enabled) {
        DiagnosticLogManager.setCoverLoggingEnabled(enabled);
    }

    public static boolean isDebugLoggingEnabled() {
        return DiagnosticLogManager.isCoverLoggingEnabled();
    }

    public static float calculatePressuredPeekChance(float suppression, int nearbyPeekers) {
        float recovery = Math.max(0.0f, Math.min(1.0f, (0.90f - suppression) / 0.40f));
        return Math.min(PRESSURED_PEEK_MAX_CHANCE,
            PRESSURED_PEEK_MIN_CHANCE
                + PRESSURED_PEEK_RECOVERY_WEIGHT * recovery
                + PRESSURED_PEEK_ALLY_WEIGHT * Math.max(0, nearbyPeekers));
    }

    public enum BlacklistReason {
        PATH_FAILED("PATH FAILED"),
        STUCK_SEEKING("STUCK SEEKING"),
        STUCK_REPOSITIONING("STUCK REPOS"),
        SHOT_IN_COVER("SHOT IN COVER"),
        POSITIONING_BLOCKED("POSITION BLOCKED");
        
        public final String label;
        BlacklistReason(String label) { this.label = label; }
    }
    
    public static class BlacklistEntry {
        public final BlacklistReason reason;
        public final long timestamp;
        
        public BlacklistEntry(BlacklistReason reason, long timestamp) {
            this.reason = reason;
            this.timestamp = timestamp;
        }
        
        public long getAgeMs(long now) {
            return now - timestamp;
        }
    }
    
    public java.util.Map<BlockPos, BlacklistEntry> getBlacklistReasons() {
        return blacklistReasons;
    }
    
    public CoverTacticalGoal(SoldierEntity soldier) {
        this(soldier, false);
    }

    public CoverTacticalGoal(SoldierEntity soldier, boolean machineGunnerPipeline) {
        this.soldier = soldier;
        this.navigation = soldier.getNavigation();
        this.machineGunnerPipeline = machineGunnerPipeline;
        this.proneFiringController = new ProneFiringController(soldier);
        // This goal remains active while occupying cover, so it must retain the
        // scheduler's movement lock across every cover-state transition.
        this.setFlags(EnumSet.of(Flag.MOVE, Flag.LOOK));
    }

    /**
     * Installs a role-specific cover-selection override (e.g. the MG's fire
     * lane first selection). Riflemen never set this, so their base selection
     * is unchanged. Null clears the override.
     */
    public void setCoverSelectionStrategy(@javax.annotation.Nullable CoverSelectionStrategy strategy) {
        this.coverSelectionStrategy = strategy;
    }

    /**
     * Queues routine cover work without allowing a command burst to execute
     * every search in the same server tick. Emergency suppression searches use
     * their existing synchronous path until they can be integrated separately.
     */
    private void requestCoverSearch(QueuedSearchMode mode) {
        if (!soldier.isAlive() || soldier.level().isClientSide) {
            return;
        }

        if (shouldSkipFailedSearch(mode)) {
            if (com.stevesarmy.debug.trace.SoldierFlightRecorder.isRecording())
                com.stevesarmy.debug.trace.SoldierFlightRecorder.event(soldier, "cover-search", "retry policy skipped failed search", mode.name());
            return;
        }

        if (com.stevesarmy.debug.trace.SoldierFlightRecorder.isRecording())
            com.stevesarmy.debug.trace.SoldierFlightRecorder.event(soldier, "cover-search", "requested", mode.name());

        if (coverSearchPending) {
            if (searchPriority(mode) < searchPriority(queuedSearchMode)) {
                queuedSearchMode = mode;
                queuedAttackGeneration = soldier.getAttackGeneration();
                queuedRelocationType = relocationType;
                queuedRelocationCenter = relocationCenter;
                queuedSearchFromDock = dockedForSearch();
            }
            CoverSearchScheduler.request(this, searchPriority(queuedSearchMode),
                CoverSearchScheduler.currentServerTick(this), isEmergencySearchMode(queuedSearchMode));
            return;
        }

        int priority = searchPriority(mode);
        int stagger = priority == 2
            ? Math.floorMod(soldier.getUUID().hashCode(), CoverSearchScheduler.ROUTINE_STAGGER_TICKS)
            : 0;
        coverSearchPending = true;
        queuedSearchMode = mode;
        queuedAttackGeneration = soldier.getAttackGeneration();
        queuedRelocationType = relocationType;
        queuedRelocationCenter = relocationCenter;
        queuedSearchFromDock = dockedForSearch();
        CoverSearchScheduler.request(this, priority,
            CoverSearchScheduler.currentServerTick(this) + stagger, isEmergencySearchMode(mode));
    }

    private int searchPriority(QueuedSearchMode mode) {
        return isEmergencySearchMode(mode) ? 0
            : mode == QueuedSearchMode.ATTACK_SELECTING ? 1
            : mode == QueuedSearchMode.REPOSITION || relocationType != RelocationType.NONE ? 0
            : getCoverManager().isSuppressed() ? 1 : 2;
    }

    private boolean dockedForSearch() {
        CoverBehaviorManager.CoverState state = getCoverManager().getState();
        return getCoverManager().getCurrentCover() != null
            && (state == CoverBehaviorManager.CoverState.IN_COVER
                || state == CoverBehaviorManager.CoverState.SUPPRESSED_IN_COVER);
    }

    private boolean isEmergencySearchMode(QueuedSearchMode mode) {
        return mode == QueuedSearchMode.SHOT_IN_COVER
            || mode == QueuedSearchMode.CONTINUOUS_SUPPRESSION
            || mode == QueuedSearchMode.SUPPRESSION_REPOSITION
            || mode == QueuedSearchMode.SUPPRESSION_POSITION;
    }

    private void requestEmergencySearch(QueuedSearchMode mode) {
        if (!StevesArmyConfig.isRetryPolicyEnabled()) {
            executeQueuedEmergencySearch(mode);
            return;
        }
        if (!coverSearchPending || queuedSearchMode != mode) {
            requestCoverSearch(mode);
        }
    }

    private boolean shouldSkipFailedSearch(QueuedSearchMode mode) {
        if (!StevesArmyConfig.isRetryPolicyEnabled() || isEmergencySearchMode(mode)
            || relocationType != RelocationType.NONE || coverSearchPending
            || failedSearchMode != mode || soldier.tickCount >= nextFailedSearchTick) {
            return false;
        }

        long fingerprint = getCoverSearchFingerprint(mode);
        if (fingerprint == failedSearchFingerprint) {
            PerformanceMetrics.recordCoverSearchCooldownSkip();
            return true;
        }

        failedSearchFingerprint = Long.MIN_VALUE;
        failedSearchMode = null;
        nextFailedSearchTick = 0;
        PerformanceMetrics.recordCoverSearchFingerprintChange();
        return false;
    }

    private long getCoverSearchFingerprint(QueuedSearchMode mode) {
        long fingerprint = 0xcbf29ce484222325L;
        fingerprint = mixFingerprint(fingerprint, mode.ordinal());
        fingerprint = mixFingerprint(fingerprint, soldier.blockPosition().asLong());
        fingerprint = mixFingerprint(fingerprint, soldier.getSquadMode().ordinal());
        fingerprint = mixFingerprint(fingerprint, blacklistRevision);

        BlockPos currentCover = getCoverManager().getCurrentCover() != null
            ? getCoverManager().getCurrentCover().getPosition() : null;
        if (currentCover != null) fingerprint = mixFingerprint(fingerprint, currentCover.asLong());
        if (relocationCenter != null) fingerprint = mixFingerprint(fingerprint, relocationCenter.asLong());
        if (soldier.hasValidAttackTarget()) {
            fingerprint = mixFingerprint(fingerprint, soldier.getAttackGeneration());
            fingerprint = mixFingerprint(fingerprint, soldier.getAttackTargetPos().asLong());
        }
        if (soldier.getSquadMode() == SquadMode.FOLLOW) {
            LivingEntity owner = soldier.getOwner();
            if (owner != null) fingerprint = mixFingerprint(fingerprint, owner.blockPosition().asLong());
        }
        BlockPos threatPosition = getThreats().getPrimaryThreatPosition();
        if (threatPosition != null) {
            // Crew on a moving or bobbing ship shifts block-by-block; grid
            // quantization stops the failed-search retry gate from re-arming
            // on every armor scan.
            fingerprint = mixFingerprint(fingerprint, new BlockPos(
                threatPosition.getX() & ~3,
                threatPosition.getY() & ~3,
                threatPosition.getZ() & ~3).asLong());
        }
        Vec3 threatDirection = getThreats().getPrimaryDirection(soldier.position());
        if (threatDirection != null && threatDirection.lengthSqr() > 0.001D) {
            fingerprint = mixFingerprint(fingerprint,
                CoverFinder.getDirectionFromVector(threatDirection).ordinal());
        }
        return fingerprint;
    }

    private void recordFailedSearch(QueuedSearchMode mode, CoverMoveResult result, String phase) {
        if (!StevesArmyConfig.isRetryPolicyEnabled() || mode == null || isEmergencySearchMode(mode)
            || relocationType != RelocationType.NONE || pendingRetryCover != null
            || result == CoverMoveResult.COVER_STARTED || result == CoverMoveResult.ASYNC_PENDING
            || "reservation".equals(phase)) {
            return;
        }
        failedSearchMode = mode;
        failedSearchFingerprint = getCoverSearchFingerprint(mode);
        nextFailedSearchTick = soldier.tickCount + StevesArmyConfig.getCoverSearchFailureRetryTicks();
    }

    private void clearFailedSearch() {
        failedSearchFingerprint = Long.MIN_VALUE;
        failedSearchMode = null;
        nextFailedSearchTick = 0;
    }

    int getSoldierTickCount() {
        return soldier.tickCount;
    }

    ServerLevel getServerLevel() {
        return soldier.level() instanceof ServerLevel serverLevel ? serverLevel : null;
    }

    /** Called only by CoverSearchScheduler on the server thread. */
    void executeQueuedCoverSearch() {
        if (!coverSearchPending) {
            return;
        }

        QueuedSearchMode mode = queuedSearchMode;
        coverSearchPending = false;
        queuedSearchMode = null;
        int expectedAttackGeneration = queuedAttackGeneration;
        RelocationType expectedRelocationType = queuedRelocationType;
        BlockPos expectedRelocationCenter = queuedRelocationCenter;
        boolean fromDock = queuedSearchFromDock;
        queuedAttackGeneration = -1;
        queuedRelocationType = RelocationType.NONE;
        queuedRelocationCenter = null;
        queuedSearchFromDock = false;

        if (!soldier.isAlive() || soldier.level().isClientSide) {
            return;
        }
        if (isEmergencySearchMode(mode)) {
            executeQueuedEmergencySearch(mode);
            return;
        }
        if (mode == QueuedSearchMode.ATTACK_SELECTING
            && (!soldier.hasValidAttackTarget() || expectedAttackGeneration != soldier.getAttackGeneration())) {
            PerformanceMetrics.recordCoverSearchRequestStale();
            return;
        }
        if (expectedRelocationType != RelocationType.NONE
            && (relocationType != expectedRelocationType
                || !Objects.equals(relocationCenter, expectedRelocationCenter)
                || !isRelocationStillValid())) {
            if (expectedRelocationType == RelocationType.GO_TO) {
                PerformanceMetrics.recordGoToCoverSearchRequestStale();
            } else {
                PerformanceMetrics.recordCoverSearchRequestStale();
            }
            return;
        }
        // The dock landed while this search sat queued: the soldier wanted
        // cover and now has it. Executing the stale search would yank him off
        // the fresh dock toward a POI-centered candidate — the dock-to-dock
        // orbit around an unreachable clearing job. A docked soldier's next
        // move belongs to the phase logic, which queues its own searches
        // (flagged from-dock) when it decides to advance.
        if (mode == QueuedSearchMode.ATTACK_SELECTING && !fromDock && dockedForSearch()) {
            PerformanceMetrics.recordCoverSearchRequestStale();
            return;
        }

        // A queued plain ATTACK_SELECTING search that comes due while the
        // soldier is pinned and dockless must not walk an unclassified corridor
        // dock under fire: reroute it through the classified suppression search
        // with its retry pacing. Withheld verdicts hold position ducked instead
        // of falling into the fallback advance.
        if (mode == QueuedSearchMode.ATTACK_SELECTING && docklessSuppressedSearchActive()) {
            runDocklessSuppressedSearch();
            return;
        }

        // Advance-launch hold: the same search requested from a dock before
        // the pressure arrived must not execute inside the quiet window or the
        // absolute-pin freeze — the launch would leave the dock the
        // momentary-recovery way. Treated as stale; the phase re-requests
        // once the hold clears.
        if (mode == QueuedSearchMode.ATTACK_SELECTING && dockAdvanceLaunchHeld()) {
            PerformanceMetrics.recordCoverSearchRequestStale();
            return;
        }

        executingSearchMode = mode;
        CoverMoveResult result;
        try {
            result = findAndMoveToCover();
        } finally {
            executingSearchMode = null;
        }
        if ((result == CoverMoveResult.NO_COVER_FOUND || result == CoverMoveResult.NO_ELIGIBLE_COVER)
            && tryStartSpacedProneFallback()) {
            result = CoverMoveResult.COVER_STARTED;
        }
        if (mode == QueuedSearchMode.ATTACK_SELECTING && attackPhase == AttackPhase.SELECTING_COVER) {
            handleQueuedAttackSearchResult(result);
        } else if ((mode == QueuedSearchMode.REPOSITION || relocationType != RelocationType.NONE)
            && getCoverManager().getTargetCover() != null) {
            getCoverManager().setState(CoverBehaviorManager.CoverState.REPOSITIONING);
        }
    }

    @Override
    public void applyAsyncCoverPilotResult(CoverSearchResult result, BlockPos sourcePosition, long sourceTick) {
        if (!asyncPilotPending) {
            PerformanceMetrics.recordPhase6StaleResult();
            return;
        }
        asyncPilotPending = false;
        asyncPilotSubmittedTick = Long.MIN_VALUE;
        PerformanceMetrics.recordPhase6ResultApplied();

        if (!StevesArmyConfig.isAsyncCoverPilotEnabled()) {
            PerformanceMetrics.recordPhase6ApplyFallback(PerformanceMetrics.Phase6ApplyFallbackReason.DISABLED);
            runAsyncPilotFallback();
            return;
        }
        if (asyncPilotFallback) {
            PerformanceMetrics.recordPhase6ApplyFallback(PerformanceMetrics.Phase6ApplyFallbackReason.FALLBACK_IN_PROGRESS);
            runAsyncPilotFallback();
            return;
        }
        if (!isAsyncCoverPilotEligible()) {
            PerformanceMetrics.recordPhase6ApplyFallback(asyncPilotIneligibilityReason());
            runAsyncPilotFallback();
            return;
        }
        if (!soldier.blockPosition().equals(sourcePosition)) {
            PerformanceMetrics.recordPhase6ApplyFallback(PerformanceMetrics.Phase6ApplyFallbackReason.MOVED);
            runAsyncPilotFallback();
            return;
        }
        if (result == null) {
            PerformanceMetrics.recordPhase6ApplyFallback(PerformanceMetrics.Phase6ApplyFallbackReason.NULL_RESULT);
            runAsyncPilotFallback();
            return;
        }

        CoverFinder finder = new CoverFinder(soldier.level());
        CoverPoint currentCover = getCoverManager().getCurrentCover();
        List<CoverSearchResult.RankedCandidate> rankedCandidates = result.rankedCandidates();
        PerformanceMetrics.recordPhase6RankedCandidates(rankedCandidates.size());
        if (rankedCandidates.isEmpty()) {
            PerformanceMetrics.recordPhase6RankedEmpty();
        }

        for (CoverSearchResult.RankedCandidate ranked : rankedCandidates) {
            BlockPos position = ranked.candidate().position();
            if (failedCoverPositions.contains(position)) {
                PerformanceMetrics.recordPhase6SkippedFailedCover();
                continue;
            }
            if (currentCover != null && currentCover.getPosition().equals(position)) {
                PerformanceMetrics.recordPhase6SkippedCurrentCover();
                continue;
            }
            if (!CoverReservationManager.isAvailableFor(position, soldier)) {
                PerformanceMetrics.recordPhase6SkippedReservationUnavailable();
                continue;
            }
            CoverPoint cover = finder.evaluatePosition(position, null);
            if (cover == null || cover.getType() == CoverType.NONE
                || !cover.getProtectedDirections().equals(ranked.candidate().protectedDirections())) {
                PerformanceMetrics.recordPhase6ValidationReject();
                continue;
            }
            cover.setQuality(ranked.score());
            cover.setCombatScore(ranked.score());
            if (currentCover != null
                && soldier.position().distanceTo(cover.getPosition().getCenter()) < COVER_REACHED_DISTANCE) {
                blacklistCover(cover.getPosition(), BlacklistReason.STUCK_REPOSITIONING);
                continue;
            }
            getCoverManager().clearCoverQualityPenalty();
            cancelProneFiringPlan();
            if (!CoverReservationManager.reserve(position, soldier)) {
                PerformanceMetrics.recordPhase6ReservationReject();
                continue;
            }
            getCoverManager().setTargetCover(cover);
            if (!moveToCover(cover)) {
                CoverReservationManager.release(position, soldier);
                getCoverManager().clearTargetCover();
                PerformanceMetrics.recordPhase6PathReject();
                continue;
            }
            PerformanceMetrics.recordPhase6Selection();
            return;
        }
        runAsyncPilotFallback();
    }

    @Override
    public void rejectAsyncCoverPilot() {
        if (!asyncPilotPending) {
            return;
        }
        asyncPilotPending = false;
        asyncPilotSubmittedTick = Long.MIN_VALUE;
        PerformanceMetrics.recordPhase6FallbackRejected();
        runAsyncPilotFallback();
    }

    private boolean isAsyncCoverPilotEligible() {
        return !machineGunnerPipeline && !soldier.hasValidAttackTarget()
            && relocationType == RelocationType.NONE && !suppressionRouteSearchActive
            && getCoverManager().getState() == CoverBehaviorManager.CoverState.SEEKING_COVER;
    }

    private PerformanceMetrics.Phase6ApplyFallbackReason asyncPilotIneligibilityReason() {
        if (machineGunnerPipeline) {
            return PerformanceMetrics.Phase6ApplyFallbackReason.MACHINE_GUNNER;
        }
        if (soldier.hasValidAttackTarget()) {
            return PerformanceMetrics.Phase6ApplyFallbackReason.ATTACK_TARGET;
        }
        if (relocationType != RelocationType.NONE) {
            return PerformanceMetrics.Phase6ApplyFallbackReason.RELOCATION;
        }
        if (suppressionRouteSearchActive) {
            return PerformanceMetrics.Phase6ApplyFallbackReason.SUPPRESSION_SEARCH;
        }
        if (getCoverManager().getState() != CoverBehaviorManager.CoverState.SEEKING_COVER) {
            return PerformanceMetrics.Phase6ApplyFallbackReason.STATE;
        }
        return PerformanceMetrics.Phase6ApplyFallbackReason.UNKNOWN;
    }

    private void runAsyncPilotFallback() {
        PerformanceMetrics.recordPhase6Fallback();
        asyncPilotFallback = true;
        try {
            if (soldier.isAlive() && isAsyncCoverPilotEligible()) {
                findAndMoveToCover();
            }
        } finally {
            asyncPilotFallback = false;
        }
    }

    private void executeQueuedEmergencySearch(QueuedSearchMode mode) {
        CoverBehaviorManager coverManager = getCoverManager();
        if (mode == QueuedSearchMode.SUPPRESSION_POSITION) {
            if (!isSuppressionPositionRequestCurrent()) {
                PerformanceMetrics.recordEmergencyCoverRequestStale();
                return;
            }

            CoverMoveResult result = findAndMoveToSuppressionPosition();
            if (result == CoverMoveResult.COVER_STARTED && coverManager.getTargetCover() != null) {
                suppressionPositionStatus = SuppressionPositionStatus.MOVING;
                suppressionPositionFailures = 0;
                suppressionPositionLastFailure = "none";
                // The ping order now owns movement. Clear the superseded scoot
                // flags at move start rather than only on arrival — if the
                // approach aborts, their leftover state would immediately fire
                // a competing (non-ping-directed) cover search.
                coverManager.clearRepositionRequest();
                coverManager.clearShotInCoverRepositionRequest();
                coverManager.clearContinuousSuppressionRepositionRequest();
                coverManager.setState(CoverBehaviorManager.CoverState.REPOSITIONING);
                return;
            }

            suppressionPositionFailures++;
            boolean exhausted = suppressionPositionFailures >= EMERGENCY_SEARCH_MAX_CONSECUTIVE_FAILURES;
            nextSuppressionPositionSearchTick = soldier.tickCount
                + (exhausted ? EMERGENCY_SEARCH_FAILURE_COOLDOWN_TICKS : SHOT_IN_COVER_RETRY_TICKS);
            suppressionPositionLastFailure = result == CoverMoveResult.NO_ELIGIBLE_COVER
                ? "no reachable firing lane" : "no reachable firing position";
            suppressionPositionStatus = exhausted
                ? SuppressionPositionStatus.FAILED : SuppressionPositionStatus.BLOCKED;
            coverManager.setState(coverManager.getCurrentCover() != null
                ? CoverBehaviorManager.CoverState.IN_COVER : CoverBehaviorManager.CoverState.NO_COVER);
            if (DiagnosticLogManager.isCoverLoggingEnabled()) {
                StevesArmyMod.LOGGER.info(
                    "[SuppressPosition] soldier={} generation={} origin={} area={} status={} attempts={} reason={}",
                    soldier.getId(), suppressionPositionGeneration, suppressionPositionOrigin,
                    suppressionPositionArea, suppressionPositionStatus, suppressionPositionFailures,
                    suppressionPositionLastFailure);
            }
            return;
        }
        if (mode == QueuedSearchMode.SHOT_IN_COVER) {
            CoverPoint currentCover = coverManager.getCurrentCover();
            if (!coverManager.isShotInCoverRepositionRequested() || currentCover == null) {
                PerformanceMetrics.recordEmergencyCoverRequestStale();
                return;
            }
            // Pinned-dock protection (suppressedRelocationSafeRoute): an
            // absolutely pinned soldier stays at his cover — even a
            // compromised-cover relocation must not launch while suppression
            // holds (a crawl out of a hit-through cover still crosses the
            // fire that is hitting it). The request stays pending and executes
            // once recovery completes, or re-arms from the next hit.
            if (StevesArmyConfig.isSuppressedRelocationSafeRoute()
                && relocationType == RelocationType.NONE
                && !canLeaveCoverNow()) {
                if (DiagnosticLogManager.isCoverLoggingEnabled()) {
                    StevesArmyMod.LOGGER.info("[CoverSuppression] Soldier {} shot-in-cover reposition held: pinned at cover",
                        soldier.getId());
                }
                return;
            }
            if (currentCover != null) {
                blacklistCover(currentCover.getPosition(), BlacklistReason.SHOT_IN_COVER);
                compromisedCoverPosition = currentCover.getPosition();
            }
            coverManager.resetPeekState();
            coverManager.setPeekPosition(null);
            getPositionController().clear();
            emergencyCoverSearchActive = true;
            CoverMoveResult result;
            try {
                result = findSuppressionMoveToCover();
            } finally {
                emergencyCoverSearchActive = false;
            }
            if (result == CoverMoveResult.COVER_STARTED && coverManager.getTargetCover() != null) {
                coverManager.clearShotInCoverRepositionRequest();
                nextShotInCoverSearchTick = 0;
                compromisedCoverPosition = null;
                emergencySearchFailureCount = 0;
                coverManager.setState(CoverBehaviorManager.CoverState.REPOSITIONING);
            } else {
                emergencySearchFailureCount++;
                if (emergencySearchFailureCount >= EMERGENCY_SEARCH_MAX_CONSECUTIVE_FAILURES) {
                    // No pathable replacement cover exists. Stop the every-20-tick
                    // loop: keep the current cover at a low profile and re-arm the
                    // search later (or on the next hit, via the hurt hook).
                    emergencySearchFailureCount = 0;
                    coverManager.clearShotInCoverRepositionRequest();
                    nextShotInCoverSearchTick = soldier.tickCount + EMERGENCY_SEARCH_FAILURE_COOLDOWN_TICKS;
                    enterOpenGroundFallbackPosture();
                    if (DiagnosticLogManager.isCoverLoggingEnabled()) {
                        StevesArmyMod.LOGGER.info("[CoverSuppression] Soldier {} shot-in-cover reposition failed {} times, holding at current cover",
                            soldier.getId(), EMERGENCY_SEARCH_MAX_CONSECUTIVE_FAILURES);
                    }
                } else {
                    nextShotInCoverSearchTick = soldier.tickCount + SHOT_IN_COVER_RETRY_TICKS;
                }
                coverManager.setState(coverManager.isSuppressed()
                    ? CoverBehaviorManager.CoverState.SUPPRESSED_IN_COVER
                    : CoverBehaviorManager.CoverState.IN_COVER);
            }
            return;
        }

        if (mode == QueuedSearchMode.CONTINUOUS_SUPPRESSION
            && !coverManager.isContinuousSuppressionRepositionRequested()) {
            PerformanceMetrics.recordEmergencyCoverRequestStale();
            return;
        }
        if (mode == QueuedSearchMode.SUPPRESSION_REPOSITION
            && !coverManager.isRepositionRequested()) {
            PerformanceMetrics.recordEmergencyCoverRequestStale();
            return;
        }
        if (mode == QueuedSearchMode.SUPPRESSION_REPOSITION && !canLeaveCoverNow()) {
            PerformanceMetrics.recordEmergencyCoverRequestStale();
            return;
        }

        // Pinned-dock protection (suppressedRelocationSafeRoute): the
        // continuous-pin emergency channel was designed to relocate WHILE
        // pinned — under the pinned-stays doctrine it must not launch until
        // recovery, exactly like the routine channel above. The request stays
        // pending (the 8s continuous interval re-arms it if cleared) and the
        // soldier holds his cover; a classifier-approved CRAWL route is still
        // a multi-block walk away from the dock under fire.
        if (mode == QueuedSearchMode.CONTINUOUS_SUPPRESSION
            && StevesArmyConfig.isSuppressedRelocationSafeRoute()
            && relocationType == RelocationType.NONE
            && !canLeaveCoverNow()) {
            if (DiagnosticLogManager.isCoverLoggingEnabled()) {
                StevesArmyMod.LOGGER.info("[CoverSuppression] Soldier {} continuous-suppression reposition held: pinned at cover",
                    soldier.getId());
            }
            return;
        }

        boolean started = startSuppressionRepositioning();
        if (started) {
            emergencySearchFailureCount = 0;
            if (mode == QueuedSearchMode.CONTINUOUS_SUPPRESSION) {
                coverManager.clearContinuousSuppressionRepositionRequest();
            } else {
                coverManager.clearRepositionRequest();
            }
            resetSuppressionEpisodes();
        } else {
            emergencySearchFailureCount++;
            if (emergencySearchFailureCount >= EMERGENCY_SEARCH_MAX_CONSECUTIVE_FAILURES) {
                // No protected or crawl-safe route exists. Drop the request instead
                // of retrying forever; the soldier holds at a low profile and a new
                // episode or continuous-pin event re-arms the search.
                emergencySearchFailureCount = 0;
                if (mode == QueuedSearchMode.CONTINUOUS_SUPPRESSION) {
                    coverManager.clearContinuousSuppressionRepositionRequest();
                } else {
                    coverManager.clearRepositionRequest();
                }
                nextSuppressionRouteSearchTick = soldier.tickCount + EMERGENCY_SEARCH_FAILURE_COOLDOWN_TICKS;
                enterOpenGroundFallbackPosture();
                if (DiagnosticLogManager.isCoverLoggingEnabled()) {
                    StevesArmyMod.LOGGER.info("[CoverSuppression] Soldier {} suppression reposition failed {} times, holding at current cover",
                        soldier.getId(), EMERGENCY_SEARCH_MAX_CONSECUTIVE_FAILURES);
                }
            } else {
                nextSuppressionRouteSearchTick = soldier.tickCount + SHOT_IN_COVER_RETRY_TICKS;
            }
        }
    }

    private boolean isSuppressionPositionRequestCurrent() {
        return suppressionPositionGeneration >= 0
            && suppressionPositionArea != null
            && suppressionPositionOrigin != null
            && soldier.hasValidPingSuppressPos()
            && soldier.getSuppressionOrder().getGeneration() == suppressionPositionGeneration
            && suppressionPositionStatus == SuppressionPositionStatus.SEARCHING;
    }

    /** Re-arm a command-local search after its bounded retry delay. */
    private void tickSuppressionPositionRetry() {
        if ((suppressionPositionStatus != SuppressionPositionStatus.BLOCKED
            && suppressionPositionStatus != SuppressionPositionStatus.FAILED)
            || soldier.tickCount < nextSuppressionPositionSearchTick
            || !soldier.hasValidPingSuppressPos()
            || soldier.getSuppressionOrder().getGeneration() != suppressionPositionGeneration) {
            return;
        }
        // A re-armed exhausted search gets a fresh failure budget: without this
        // one FAILED verdict would silence the soldier for the rest of the ping.
        if (suppressionPositionStatus == SuppressionPositionStatus.FAILED) {
            suppressionPositionFailures = 0;
        }
        suppressionPositionStatus = SuppressionPositionStatus.SEARCHING;
        requestEmergencySearch(QueuedSearchMode.SUPPRESSION_POSITION);
    }

    /**
     * A repositioning move that aborted without reaching the cover must not
     * leave the ping channel reporting MOVING forever — the retry loop only
     * re-arms from BLOCKED/FAILED, so a stale MOVING verdict would silence the
     * order's relocation for the rest of the generation.
     */
    private void noteSuppressionMoveAborted() {
        if (suppressionPositionStatus == SuppressionPositionStatus.MOVING
            && soldier.getSuppressionOrder().getGeneration() == suppressionPositionGeneration) {
            suppressionPositionStatus = SuppressionPositionStatus.BLOCKED;
            nextSuppressionPositionSearchTick = soldier.tickCount + SHOT_IN_COVER_RETRY_TICKS;
        }
    }

    private void handleQueuedAttackSearchResult(CoverMoveResult result) {
        if (result == CoverMoveResult.NO_COVER_FOUND || result == CoverMoveResult.NO_ELIGIBLE_COVER) {
            // A failed search while docked means no better cover exists —
            // hold the dock. Returning to SELECTING from here re-requested
            // searches every tick and re-docked the squad around an
            // unobservable job: the blocked-door dock churn.
            CoverBehaviorManager.CoverState coverState = getCoverManager().getState();
            if (getCoverManager().getCurrentCover() != null
                && (coverState == CoverBehaviorManager.CoverState.IN_COVER
                    || coverState == CoverBehaviorManager.CoverState.SUPPRESSED_IN_COVER)) {
                BlockPos dock = getCoverManager().getCurrentCover().getPosition();
                if (dock.equals(attackStallDock)) {
                    attackStallFails++;
                } else {
                    attackStallDock = dock;
                    attackStallFails = 1;
                }
                boolean stalled = attackStallFails >= ATTACK_DOCK_STALL_SEARCHES;
                // A dock BEHIND the advance is not a hold position: holding it
                // froze followers inside the start building while the front
                // soldier carried the route alone. Release it and take the
                // dockless recovery below — but protection still yields to
                // fire and contact, same as the spine revalidation. A FORWARD
                // dock releases only once its searches have starved (stalled).
                if (getCoverManager().isSuppressed()
                    || ContactPlan.hasLiveContact(soldier)
                    || (!isBackwardAttackDock(dock)
                        && soldier.level().canSeeSky(BlockPos.containing(soldier.getEyePosition())))
                    || (!isBackwardAttackDock(dock) && !stalled)) {
                    attackPhase = AttackPhase.OCCUPYING_COVER;
                    return;
                }
                attackStallDock = null;
                attackStallFails = 0;
                getCoverManager().clearCover();
            }
            // No dock anywhere: a fallback advance step is the recovery (it
            // re-centers the next search), but under a clearing order it must
            // respect the reachability verdict. Stepping toward an
            // unreachable job forever IS the dockless mill: a perpetual walk
            // that never arrives, claim flips on every failed re-dock, and a
            // squad that can never stand still long enough to settle.
            // Pinned-and-dockless guard (suppressedRelocationSafeRoute): an
            // open-ground advance leg under fire is the walk-out this machine
            // must not produce — hold ducked; the classified dockless search
            // re-arms on its own pacing instead.
            if (docklessSuppressedSearchActive()) {
                enterOpenGroundFallbackPosture();
                attackPhase = AttackPhase.SELECTING_COVER;
                return;
            }
            BlockPos guide = clearingPoiTarget != null
                ? clearingPoiTarget : soldier.getAttackTargetPos();
            if (clearingGuideReachable(guide)) {
                attackGuideStallGuide = null;
                attackGuideStallFails = 0;
                startFallbackAdvance();
            } else {
                // Dockless with an unreachable guide has NO recovery at all:
                // no dock to hold, no advance to take, and re-requesting the
                // same doomed search 1/s was the frozen SELECTING_COVER wall.
                // After bounded consecutive failures, concede the obligation
                // — the coordinator marks it checked (re-armed on sighting),
                // the claim strips, and the next pass assigns reachable work
                // so the order can settle or report STALLED.
                if (guide != null && guide.equals(attackGuideStallGuide)) {
                    attackGuideStallFails++;
                } else {
                    attackGuideStallGuide = guide;
                    attackGuideStallFails = 1;
                }
                if (attackGuideStallFails >= ATTACK_DOCK_STALL_SEARCHES
                    && ClearingCoordinator.concedePoi(soldier, guide)) {
                    if (attackDebugLog()) {
                        StevesArmyMod.LOGGER.info(
                            "[AttackAdvance] Soldier {} conceded unreachable job {} after {} starved searches",
                            soldier.getId(), guide.toShortString(), attackGuideStallFails);
                    }
                    attackGuideStallGuide = null;
                    attackGuideStallFails = 0;
                }
            }
            attackPhase = AttackPhase.SELECTING_COVER;
            return;
        }

        attackStallDock = null;
        attackStallFails = 0;
        attackPhase = AttackPhase.MOVING_TO_COVER;
        if (getCoverManager().getCurrentCover() == null && getCoverManager().getTargetCover() != null) {
            getCoverManager().setState(CoverBehaviorManager.CoverState.SEEKING_COVER);
        } else if (getCoverManager().getTargetCover() != null) {
            getCoverManager().setState(CoverBehaviorManager.CoverState.REPOSITIONING);
        }
    }

    /**
     * Consults the installed cover-selection strategy over the path's
     * already-scored candidates. Returns empty when no strategy is installed or
     * when the strategy defers, so callers always fall back to the base
     * selection.
     */
    private Optional<CoverPoint> selectPreferredCover(List<CoverFinder.ScoredCover> candidates) {
        if (coverSelectionStrategy == null) {
            return Optional.empty();
        }
        return coverSelectionStrategy.select(soldier, candidates);
    }
    
    private CoverBehaviorManager getCoverManager() {
        return soldier.getCoverBehaviorManager();
    }

    /**
     * Gives a GO_TO command first claim on reachable cover near its assigned
     * formation slot. False leaves the command's normal location movement intact.
     */
    public boolean requestGoToRelocation(BlockPos destination, int commandGeneration) {
        if (destination == null || !soldier.hasValidPingMoveTarget()
            || soldier.getPingMoveGeneration() != commandGeneration
            || failedGoToRelocationGeneration == commandGeneration) {
            return false;
        }
        if (relocationType == RelocationType.GO_TO
            && relocationCommandGeneration == commandGeneration) {
            return true;
        }
        clearRelocationTarget();
        relocationType = RelocationType.GO_TO;
        relocationCenter = destination.immutable();
        relocationCommandGeneration = commandGeneration;
        goToRelocationTicks = 0;
        double requestDistance = Math.hypot(soldier.getX() - (destination.getX() + 0.5),
            soldier.getZ() - (destination.getZ() + 0.5));
        double excessBlocks = Math.max(0.0D, requestDistance - RELOCATION_EXACT_PATH_DISTANCE);
        goToRelocationMaxTicks = MAX_GO_TO_RELOCATION_TICKS + (int) (excessBlocks * 8.0D);
        getCoverManager().setGoToRelocationActive(true);
        return true;
    }

    public boolean isHandlingGoToRelocation(int commandGeneration) {
        return relocationType == RelocationType.GO_TO
            && relocationCommandGeneration == commandGeneration;
    }

    /**
     * True while this soldier is executing a coordinator-driven advance (an
     * investigate walk to an assigned check target or the SECURE assemble).
     * The churn detector treats a claim change during such a walk as the
     * ordered move it is, not as cover oscillation.
     */
    public boolean isClearingAdvancing() {
        return fallbackAdvanceTarget != null;
    }

    @Override
    public SuppressionPositionStatus requestSuppressionPosition(BlockPos area, int generation) {
        if (area == null || !soldier.hasValidPingSuppressPos()
            || soldier.getSuppressionOrder().getGeneration() != generation) {
            return SuppressionPositionStatus.FAILED;
        }
        if (suppressionPositionGeneration == generation
            && (suppressionPositionStatus == SuppressionPositionStatus.SEARCHING
                || suppressionPositionStatus == SuppressionPositionStatus.MOVING)) {
            return suppressionPositionStatus;
        }

        if (suppressionPositionGeneration != generation) {
            suppressionPositionArea = area.immutable();
            BlockPos orderOrigin = soldier.getSuppressionOrder().getOrigin();
            suppressionPositionOrigin = (orderOrigin != null ? orderOrigin : soldier.blockPosition()).immutable();
            suppressionPositionGeneration = generation;
            suppressionPositionFailures = 0;
            nextSuppressionPositionSearchTick = 0;
            suppressionPositionLastFailure = "none";
        }
        if (suppressionPositionStatus == SuppressionPositionStatus.FAILED) {
            return suppressionPositionStatus;
        }
        if (soldier.tickCount < nextSuppressionPositionSearchTick) {
            suppressionPositionStatus = SuppressionPositionStatus.BLOCKED;
            return suppressionPositionStatus;
        }

        suppressionPositionStatus = SuppressionPositionStatus.SEARCHING;
        requestEmergencySearch(QueuedSearchMode.SUPPRESSION_POSITION);
        return suppressionPositionStatus;
    }

    @Override
    public SuppressionPositionStatus getSuppressionPositionStatus(int generation) {
        return generation == suppressionPositionGeneration
            ? suppressionPositionStatus : SuppressionPositionStatus.IDLE;
    }

    @Override
    public boolean currentCoverHasSuppressionLane(int generation) {
        if (generation != suppressionPositionGeneration || suppressionPositionArea == null) {
            return false;
        }
        CoverPoint currentCover = getCoverManager().getCurrentCover();
        if (currentCover == null) {
            return false;
        }
        // From the live eye while exposed (that is where shots actually leave),
        // otherwise from the cover's standing position — a ducked soldier must
        // still be credited with the lane he exposes into.
        Vec3 from = soldier.getPeekController().getState() == PeekController.State.EXPOSED
            ? soldier.getEyePosition()
            : getCoverStandingPosition(currentCover.getPosition());
        return hasSuppressionFiringLaneFrom(from);
    }

    /** Debug channel: consecutive search failures for the active order. */
    public int getSuppressionPositionFailures(int generation) {
        return generation == suppressionPositionGeneration ? suppressionPositionFailures : 0;
    }

    /** Debug channel: why the last search failed, or null when no order is active. */
    public String getSuppressionPositionLastFailure(int generation) {
        if (generation != suppressionPositionGeneration) return null;
        return "none".equals(suppressionPositionLastFailure) ? "" : suppressionPositionLastFailure;
    }

    /** Debug channel: anchor position the relocation search fans out from. */
    public Vec3 getSuppressionPositionSearchOrigin(int generation) {
        return generation == suppressionPositionGeneration && suppressionPositionOrigin != null
            ? Vec3.atCenterOf(suppressionPositionOrigin) : null;
    }

    /** Debug channel: radius of the relocation search fan. */
    public int getSuppressionPositionSearchRadius() {
        return RELOCATION_SEARCH_RADIUS;
    }

    @Override
    public void cancelSuppressionPosition(int generation) {
        if (generation != suppressionPositionGeneration) return;
        if (suppressionPositionStatus == SuppressionPositionStatus.MOVING) {
            navigation.stop();
            getPositionController().clear();
            CoverPoint targetCover = getCoverManager().getTargetCover();
            if (targetCover != null) {
                CoverReservationManager.release(targetCover.getPosition(), soldier);
                getCoverManager().clearTargetCover();
            }
            getCoverManager().setState(getCoverManager().getCurrentCover() != null
                ? CoverBehaviorManager.CoverState.IN_COVER
                : CoverBehaviorManager.CoverState.NO_COVER);
        }
        suppressionPositionArea = null;
        suppressionPositionOrigin = null;
        suppressionPositionGeneration = -1;
        suppressionPositionStatus = SuppressionPositionStatus.IDLE;
        suppressionPositionFailures = 0;
        nextSuppressionPositionSearchTick = 0;
        suppressionPositionLastFailure = "none";
    }

    /** True while a queued cover search belongs to a GO_TO command. */
    public boolean isGoToRelocation() {
        return relocationType == RelocationType.GO_TO;
    }

    private boolean beginFollowRelocationIfNeeded() {
        if (relocationType != RelocationType.NONE || soldier.getSquadMode() != SquadMode.FOLLOW
            || getCoverManager().isSuppressed() || soldier.tickCount < nextFollowRelocationSearchTick) {
            return relocationType == RelocationType.FOLLOW;
        }

        LivingEntity owner = soldier.getOwner();
        if (owner == null || !owner.isAlive() || owner.isSpectator()
            || soldier.distanceToSqr(owner) < followCoverDistance() * followCoverDistance()) {
            return false;
        }

        relocationType = RelocationType.FOLLOW;
        relocationCenter = owner.blockPosition().immutable();
        relocationCommandGeneration = -1;
        return true;
    }

    /** Rear roles tolerate a farther owner before interrupting for a follow cover move. */
    private float followCoverDistance() {
        return soldier.isPeekDisabled() ? SUPPORT_FOLLOW_COVER_DISTANCE : FOLLOW_COVER_DISTANCE;
    }

    private double followTargetStaleDistance() {
        return soldier.isPeekDisabled() ? SUPPORT_FOLLOW_TARGET_STALE_DISTANCE : FOLLOW_TARGET_STALE_DISTANCE;
    }

    private double followOwnerMaxDistanceSqr() {
        return soldier.isPeekDisabled() ? SUPPORT_FOLLOW_OWNER_MAX_DISTANCE_SQR : 20.0D * 20.0D;
    }

    private boolean isRelocationStillValid() {
        if (relocationType == RelocationType.GO_TO) {
            return soldier.hasValidPingMoveTarget()
                && soldier.getPingMoveGeneration() == relocationCommandGeneration;
        }
        if (relocationType == RelocationType.FOLLOW) {
            LivingEntity owner = soldier.getOwner();
            return soldier.getSquadMode() == SquadMode.FOLLOW && owner != null
                && owner.isAlive() && !owner.isSpectator();
        }
        return false;
    }

    private void clearRelocationTarget() {
        if (activeRouteCrawlMandatory) {
            activeRouteCrawlMandatory = false;
            soldier.getMovementController().setMandatoryCrawl(false, "relocation-released");
        }
        CoverPoint targetCover = getCoverManager().getTargetCover();
        if (targetCover != null && relocationType != RelocationType.NONE) {
            CoverReservationManager.release(targetCover.getPosition(), soldier);
            getCoverManager().clearTargetCover();
        }
        relocationType = RelocationType.NONE;
        relocationCenter = null;
        relocationCommandGeneration = -1;
        goToRelocationTicks = 0;
        goToRelocationMaxTicks = MAX_GO_TO_RELOCATION_TICKS;
        getCoverManager().setGoToRelocationActive(false);
    }

    private void failGoToRelocation() {
        if (relocationType != RelocationType.GO_TO) {
            return;
        }

        failedGoToRelocationGeneration = relocationCommandGeneration;
        CoverSearchScheduler.cancel(this);
        coverSearchPending = false;
        queuedSearchMode = null;
        queuedAttackGeneration = -1;
        queuedRelocationType = RelocationType.NONE;
        queuedRelocationCenter = null;
        pendingRetryCover = null;
        isRetryAttempt = false;
        navigation.stop();
        getPositionController().clear();
        clearRelocationTarget();
        getCoverManager().setState(CoverBehaviorManager.CoverState.NO_COVER);
    }
    
    private PeekController getPeekController() {
        return soldier.getPeekController();
    }
    
    private ThreatAwareness getThreats() {
        return soldier.getThreatAwareness();
    }

    /**
     * Refreshes the close-combat context from live threat intel plus the
     * current combat target. Drives faster target re-evaluation and the
     * bounded close-range cover seek. The entity's copy decays when this
     * goal stops ticking, so a stale context never outlives the fight.
     */
    private void refreshCloseCombatContext() {
        double nearestSq = Double.MAX_VALUE;
        for (ThreatAwareness.ThreatInfo info : getThreats().getThreatInfos()) {
            double d = soldier.distanceToSqr(Vec3.atCenterOf(info.position));
            if (d < nearestSq) nearestSq = d;
        }
        LivingEntity target = soldier.getTarget();
        if (target != null && target.isAlive()) {
            double d = soldier.distanceToSqr(target);
            if (d < nearestSq) nearestSq = d;
        }
        double exitRange = Math.max(StevesArmyConfig.getCloseCombatRange(),
            StevesArmyConfig.getCloseCombatExitRange());
        soldier.refreshCloseCombatContext(nearestSq <= exitRange * exitRange);
    }

    /**
     * Direction used to score cover candidates. Roles may aim cover selection
     * via SoldierEntity.getPreferredCoverEvaluationDirection(); the default is
     * the primary threat direction (rifleman behavior).
     */
    private Vec3 getCoverSearchDirection() {
        Vec3 preferred = soldier.getPreferredCoverEvaluationDirection();
        if (preferred != null) {
            return preferred;
        }
        return getThreats().getPrimaryDirection(soldier.position());
    }

    /**
     * Uses a small rearward squad anchor for MG and Support cover searches in
     * FOLLOW and ATTACK. Other roles and HOLD mode retain the existing search
     * centers.
     */
    private BlockPos getMachineGunnerSearchCenter() {
        if (!(soldier instanceof MachineGunnerEntity) && !(soldier instanceof SupportEntity)) {
            return null;
        }
        if (!soldier.hasValidAttackTarget() && soldier.getSquadMode() != SquadMode.FOLLOW) {
            return null;
        }
        // The live anchor (riflemen centroid + engagement direction) moves with
        // every teammate step, which re-ranks all cover on each search. Latch it
        // briefly so repeated searches — duty recovery, reposition requests —
        // land on the same spot instead of walking the soldier in circles.
        if (latchedMachineGunnerSearchCenter != null
            && soldier.tickCount - latchedMachineGunnerSearchCenterTick < MG_ANCHOR_LATCH_TICKS) {
            return latchedMachineGunnerSearchCenter;
        }
        BlockPos target = soldier.hasValidAttackTarget()
            ? soldier.getAttackTargetPos()
            : soldier instanceof MachineGunnerEntity mg ? mg.getSuppressionCenter() : null;
        BlockPos anchor = SupportPositionFinder.findRearAnchor(soldier, target);
        if (anchor != null) {
            latchedMachineGunnerSearchCenter = anchor;
            latchedMachineGunnerSearchCenterTick = soldier.tickCount;
        }
        return anchor;
    }

    // --- Cover state-machine debug render ------------------------------------

    BlockPos debugLatchedMachineGunnerAnchor() {
        return latchedMachineGunnerSearchCenter;
    }

    /** Ticks since the MG/Support rear-anchor latch was taken; -1 when unset. */
    int debugLatchedMachineGunnerAnchorAge() {
        return latchedMachineGunnerSearchCenter != null
            ? soldier.tickCount - latchedMachineGunnerSearchCenterTick : -1;
    }

    /**
     * Builds the per-soldier snapshot for the cover state-machine debug render
     * (network/CoverStateDebugPacket). Read-only: mirrors the canUse /
     * canContinueToUse / SoldierFollowOwnerGoal decision inputs so a strand is
     * visible as it forms instead of only as a stuck pose.
     */
    public CoverStateDebugPacket buildCoverStateDebugPacket() {
        return CoverStateDebugPacket.fromSnapshot(captureStateSnapshot());
    }

    /**
     * Assembles the shared {@link CombatStateSnapshot} behind the coverstate
     * debug render. The simulation harness samples the same snapshot so its
     * detectors see exactly what the in-game card shows.
     */
    /** Continuous-standing-still sampling state (advanced only when the
     * snapshot is captured on a new tick, so debug-sync and sim sampling can
     * both call captureStateSnapshot without double-counting). */
    private Vec3 stationaryLastPos;
    private int stationaryTicksCounter;
    private long stationarySampleTick = -1;

    public CombatStateSnapshot captureStateSnapshot() {
        CoverBehaviorManager mgr = getCoverManager();
        CoverBehaviorManager.CoverState state = mgr.getState();

        LivingEntity owner = soldier.getOwner();
        float ownerDist = owner != null ? soldier.distanceTo(owner) : -1.0f;
        String followBlockedBy = describeFollowBlocker(state);

        Vec3 relocCenterVec = relocationCenter != null
            ? Vec3.atBottomCenterOf(relocationCenter) : null;

        BlockPos latchedAnchor = latchedMachineGunnerSearchCenter;
        Vec3 mgAnchorVec = latchedAnchor != null
            ? Vec3.atBottomCenterOf(latchedAnchor) : null;
        int mgAnchorAge = debugLatchedMachineGunnerAnchorAge();

        Vec3 suppressionCenterVec = null;
        int supCenterFresh = -1;
        Vec3 laneVec = null;
        if (soldier instanceof MachineGunnerEntity mg) {
            BlockPos supPos = mg.getSuppressionCenter();
            if (supPos != null) {
                suppressionCenterVec = Vec3.atBottomCenterOf(supPos);
                supCenterFresh = mg.getSuppressionCenterFreshTicks();
            }
            BlockPos lanePos = soldier.hasValidAttackTarget()
                ? soldier.getAttackTargetPos() : supPos;
            if (lanePos != null) {
                laneVec = Vec3.atBottomCenterOf(lanePos);
            }
        }

        int blacklistClearInSec = 0;
        if (lastBlacklistClearTime > 0) {
            long elapsedMs = GameClock.nowMs() - lastBlacklistClearTime;
            blacklistClearInSec = (int) Math.max(0L, (BLACKLIST_CLEAR_INTERVAL_MS - elapsedMs) / 1000L);
        }

        CoverPoint currentCover = mgr.getCurrentCover();
        CoverPoint targetCover = mgr.getTargetCover();

        com.stevesarmy.combat.EngagementTelemetry eng = soldier.getEngagementTelemetry();
        LivingEntity knownThreat = soldier.getTarget() != null && soldier.getTarget().isAlive()
            ? soldier.getTarget() : null;
        if (knownThreat == null) {
            LivingEntity hurtBy = soldier.getLastHurtByMob();
            knownThreat = hurtBy != null && hurtBy.isAlive() ? hurtBy : null;
        }
        float facingErrorDeg = -1.0f;
        boolean threatInRange = false;
        if (knownThreat != null) {
            Vec3 toThreat = knownThreat.getEyePosition().subtract(soldier.getEyePosition());
            if (toThreat.horizontalDistanceSqr() > 1.0e-4) {
                float threatBearing = (float) (Math.atan2(-toThreat.x, toThreat.z) * (180.0 / Math.PI));
                facingErrorDeg = Math.abs(net.minecraft.util.Mth.wrapDegrees(soldier.yBodyRot - threatBearing));
            }
            threatInRange = soldier.distanceToSqr(knownThreat) <= 24.0 * 24.0;
        }

        if (soldier.tickCount != stationarySampleTick) {
            int elapsed = stationarySampleTick < 0 ? 0
                : (int) (soldier.tickCount - stationarySampleTick);
            if (stationaryLastPos != null
                && soldier.position().distanceToSqr(stationaryLastPos) < 0.002) {
                stationaryTicksCounter += elapsed;
            } else {
                stationaryTicksCounter = 0;
                stationaryLastPos = soldier.position();
            }
            stationarySampleTick = soldier.tickCount;
        }

        boolean objectiveFar = soldier.hasValidAttackTarget()
            && soldier.blockPosition().distSqr(soldier.getAttackTargetPos()) > 144.0;

        String blockedExcuse = "";
        if (!followBlockedBy.isEmpty()) {
            blockedExcuse = "follow:" + followBlockedBy;
        } else if (mgr.isPinned()) {
            blockedExcuse = "pinned";
        } else if (FireTeamSuppressionTracker.isHeavilySuppressed(soldier)) {
            blockedExcuse = "suppressed";
        } else if (!eng.isMovingSupported()) {
            blockedExcuse = "contact-plan:" + eng.getMovementBlockReason();
        } else if (state == CoverBehaviorManager.CoverState.SEEKING_COVER
            || state == CoverBehaviorManager.CoverState.REPOSITIONING) {
            blockedExcuse = state.name().toLowerCase(java.util.Locale.ROOT);
        } else if (coverSearchPending) {
            blockedExcuse = "search-pending";
        }

        return new CombatStateSnapshot(
            soldier.getUUID(),
            soldier.getRole().name(),
            soldier.position(),
            state.name(),
            soldier.getPeekController().getState().name(),
            soldier.getSquadMode().name(),
            mgr.getSuppressionTracker().getSuppressionLevel(),
            mgr.isPinned(),
            !lastWantCoverReason.isEmpty(),
            lastWantCoverReason,
            cooldown,
            seekingTicks,
            relocationType != RelocationType.NONE ? MAX_SEEKING_TICKS * 3 : MAX_SEEKING_TICKS,
            stuckTicks,
            MAX_STUCK_TICKS,
            noProgressTicks,
            searchExhaustionCooldown,
            consecutiveFailedSearches,
            failedCoverPositions.size(),
            blacklistClearInSec,
            coverSearchPending,
            queuedSearchMode != null ? queuedSearchMode.name() : "",
            CoverSearchScheduler.pendingCount(),
            relocationType.name(),
            relocCenterVec,
            Math.max(0, nextFollowRelocationSearchTick - soldier.tickCount),
            followBlockedBy,
            ownerDist,
            machineGunnerPipeline,
            mgAnchorVec,
            mgAnchorAge,
            suppressionCenterVec,
            supCenterFresh,
            laneVec,
            currentCover != null ? currentCover.getPosition() : null,
            targetCover != null ? targetCover.getPosition() : null,
            currentCover != null ? currentCover.getType().name() : null,
            targetCover != null ? targetCover.getType().name() : null,
            debugLastSearchTick >= 0 ? new CombatStateSnapshot.LastSearch(
                debugLastSearchMode, debugLastSearchResult, debugLastSearchPhase,
                debugSearchCenter != null ? Vec3.atBottomCenterOf(debugSearchCenter) : null,
                debugSearchRadius, debugLastSearchTick, noCoverSearchStreak) : null,
            soldier.getPose().name(),
            soldier.isLowCrouching(),
            soldier.hasEmergencyEngagementPosture(),
            currentCover != null ? soldier.getSyncedCoverCurrentHeight() : -1f,
            mgr.isGoToRelocationActive()
                || com.stevesarmy.entity.ai.SoldierHoldPositionGoal.isTravelingToObjective(soldier),
            soldier.hasValidAttackTarget() || clearingView != null,
            soldier.getTravelCrawlController().isCrawlActive(),
            soldier.getTravelCrawlController().isCrawlHidingHere(),
            mgr.getTravelReroutesServed(),
            soldier.getYHeadRot(),
            eng.getGateReason().wire(),
            eng.getTicksInGate(soldier.tickCount),
            eng.getTicksSinceLastShot(soldier.tickCount),
            knownThreat != null,
            eng.isWeaponReady(),
            facingErrorDeg,
            soldier.yBodyRot,
            eng.isMovingSupported(),
            eng.getMovementBlockReason(),
            eng.getMovementOwner(),
            threatInRange,
            stationaryTicksCounter,
            objectiveFar,
            blockedExcuse);
    }

    /**
     * Names the gate currently refusing SoldierFollowOwnerGoal.canUse, in that
     * goal's check order; empty when nothing blocks the follow march.
     */
    private String describeFollowBlocker(CoverBehaviorManager.CoverState state) {
        if (soldier.hasValidPingSuppressPos()) return "ping-suppress";
        if (soldier.getRole() == SoldierRole.VEHICLE_CREW) return "crew";
        if (soldier.getSquadMode() != SquadMode.FOLLOW) return "";
        if (state == CoverBehaviorManager.CoverState.SEEKING_COVER
            || state == CoverBehaviorManager.CoverState.REPOSITIONING) {
            return state.name();
        }
        if (getCoverManager().isSuppressed()) return "suppressed";
        LivingEntity owner = soldier.getOwner();
        if (owner == null || owner.isSpectator()) return "no-owner";
        return "";
    }

    /**
     * Counts entries into suppression while occupying the same cover. Individual
     * rounds and ticks inside one suppressed state do not create extra episodes.
     */
    private void trackSuppressionEpisode() {
        CoverBehaviorManager coverManager = getCoverManager();
        CoverPoint currentCover = coverManager.getCurrentCover();
        if (currentCover == null || !coverManager.isInCover()) {
            resetSuppressionEpisodes();
            return;
        }

        BlockPos coverPosition = currentCover.getPosition();
        if (suppressionEpisodeCover == null || !suppressionEpisodeCover.equals(coverPosition)) {
            suppressionEpisodeCover = coverPosition;
            suppressionEpisodeCount = 0;
            suppressionEpisodeActive = false;
        }

        boolean pressured = coverManager.isSuppressed();
        boolean pinned = coverManager.isPinned();
        if (!pressured) {
            suppressionEpisodeActive = false;
            continuousSuppressionStartTime = 0L;
            continuousSuppressionRepositionStarted = false;
            return;
        }

        if (!pinned) {
            continuousSuppressionStartTime = 0L;
            continuousSuppressionRepositionStarted = false;
        } else {
            // Absolute-pin latch (suppressedRelocationSafeRoute): remember the
            // dock where the soldier was absolutely pinned (>= PINNED_THRESHOLD).
            // While the fight that pinned him is still live, the autonomous
            // ATTACK advance from this dock stays held at the dock — the fire
            // going quiet is an artifact of him hiding (enemies stop firing at
            // what they cannot see), not the fight being over, so a "recovered"
            // window must not re-seed a corridor walk the enemy line catches
            // the moment he steps out. The latch goes inert when the dock
            // changes or the threat context is gone (see dockAdvanceLaunchHeld).
            absolutePinDockPos = coverPosition;
            if (continuousSuppressionStartTime == 0L) {
                continuousSuppressionStartTime = GameClock.nowMs();
            } else if (!continuousSuppressionRepositionStarted
                && GameClock.nowMs() - continuousSuppressionStartTime >= CONTINUOUS_SUPPRESSION_REPOSITION_DELAY_MS
                && !coverManager.isContinuousSuppressionRepositionRequested()) {
                continuousSuppressionRepositionStarted = true;
                coverManager.requestContinuousSuppressionReposition();
                if (DiagnosticLogManager.isCoverLoggingEnabled()) {
                    StevesArmyMod.LOGGER.info("[CoverSuppression] Soldier {} continuously pinned at {} for {}ms, queued immediate reposition",
                        soldier.getId(), coverPosition, CONTINUOUS_SUPPRESSION_REPOSITION_DELAY_MS);
                }
            }
        }

        if (suppressionEpisodeActive) {
            return;
        }

        suppressionEpisodeActive = true;
        suppressionEpisodeCount++;
        // A new suppression requires a fresh post-recovery safety peek before the
        // next routine reposition, so the latch is reset on every suppression entry.
        resetRecoverySafetyPeek();
        if (DiagnosticLogManager.isCoverLoggingEnabled()) {
            StevesArmyMod.LOGGER.info("[CoverSuppression] Soldier {} suppression episode {}/{} at cover {}",
                soldier.getId(), suppressionEpisodeCount, REPEATED_SUPPRESSION_EPISODE_THRESHOLD, coverPosition);
        }

        if (suppressionEpisodeCount >= REPEATED_SUPPRESSION_EPISODE_THRESHOLD
            && !coverManager.isRepositionRequested()) {
            coverManager.requestReposition();
            if (DiagnosticLogManager.isCoverLoggingEnabled()) {
                StevesArmyMod.LOGGER.info("[CoverSuppression] Soldier {} repeatedly suppressed at {}, queued reposition after recovery",
                    soldier.getId(), coverPosition);
            }
        }
    }

    private void resetSuppressionEpisodes() {
        suppressionEpisodeCover = null;
        suppressionEpisodeCount = 0;
        suppressionEpisodeActive = false;
        continuousSuppressionStartTime = 0L;
        continuousSuppressionRepositionStarted = false;
        nextPressuredPeekDecisionTick = 0;
        hitWhilePeekingCount = 0;
    }

    /**
     * Remembers the last few DISTINCT firing origins that pressured this
     * soldier (CoverBehaviorManager keeps only the most recent one). Suppression
     * fire routinely comes from several shooters parked along a line — a
     * relocation route is only safe when it is shielded from every lane we
     * know about, not just the latest shooter's. Sampling is config-gated so
     * {@code suppressedRelocationSafeRoute=false} is an exact legacy no-op.
     */
    private void sampleSuppressionFiringOrigin() {
        if (!StevesArmyConfig.isSuppressedRelocationSafeRoute()) {
            recentSuppressionFiringOrigins.clear();
            return;
        }
        Vec3 origin = getCoverManager().getRecentSuppressionFiringOrigin();
        if (origin == null) {
            return;
        }
        long now = GameClock.nowMs();
        recentSuppressionFiringOrigins.removeIf(o -> now - o.recordedMs() > SUPPRESSION_ORIGIN_FRESH_MS);
        // One entry per distinct shooter position: re-sampling the same origin
        // refreshes its timestamp (and its last seen position) in place.
        recentSuppressionFiringOrigins.removeIf(o -> o.pos().distanceToSqr(origin) < SUPPRESSION_ORIGIN_DISTINCT_DIST_SQ);
        recentSuppressionFiringOrigins.add(0, new SuppressionFiringOrigin(origin, now));
        while (recentSuppressionFiringOrigins.size() > SUPPRESSION_ORIGIN_MEMORY_LIMIT) {
            recentSuppressionFiringOrigins.remove(recentSuppressionFiringOrigins.size() - 1);
        }
    }

    /**
     * The firing origins a relocation route must be shielded from: the most
     * recent suppression origin plus the other distinct recent ones (newest
     * first, capped). Legacy mode ({@code suppressedRelocationSafeRoute=false})
     * classifies against the single recorded origin only.
     */
    private List<Vec3> suppressionFiringOriginsForRoute() {
        Vec3 latest = getCoverManager().getRecentSuppressionFiringOrigin();
        if (latest == null) {
            return List.of();
        }
        if (!StevesArmyConfig.isSuppressedRelocationSafeRoute()) {
            return List.of(latest);
        }
        long now = GameClock.nowMs();
        List<Vec3> origins = new ArrayList<>();
        origins.add(latest);
        for (SuppressionFiringOrigin known : recentSuppressionFiringOrigins) {
            if (origins.size() >= SUPPRESSION_ORIGIN_MEMORY_LIMIT) {
                break;
            }
            if (now - known.recordedMs() > SUPPRESSION_ORIGIN_FRESH_MS
                || known.pos().distanceToSqr(latest) < SUPPRESSION_ORIGIN_DISTINCT_DIST_SQ) {
                continue;
            }
            origins.add(known.pos());
        }
        return origins;
    }

    /**
     * Centralized policy: may the soldier leave its occupied cover?
     * A suppressed soldier must remain in cover until fully recovered
     * (suppression below threshold + 2.5s since last event).
     * Exceptions: emergency flank movement while pinned may be added
     * as an explicit named policy later.
     */
    private boolean canLeaveCoverNow() {
        return getCoverManager().getSuppressionTracker().isRecovered();
    }

    /**
     * Pinned-dock protection ({@code suppressedRelocationSafeRoute}): while the
     * soldier is under fire and not yet recovered, an absolutely pinned soldier
     * stays at his cover — the dock claim is not stripped and the machine holds
     * instead of launching exposed walks. Gated on {@link #canLeaveCoverNow()}
     * (not the instantaneous isSuppressed flag) so a suppression flicker between
     * bursts cannot slip a strip through, and on the absence of a player-ordered
     * relocation so GO_TO/FOLLOW behavior is untouched. Once suppression decays
     * (isRecovered) every path works exactly as before the gate existed.
     */
    private boolean suppressedDockHoldActive() {
        return StevesArmyConfig.isSuppressedRelocationSafeRoute()
            && relocationType == RelocationType.NONE
            && !canLeaveCoverNow();
    }

    /** Dockless variant: pinned with no cover claim — the classified search reroute owns re-deciding. */
    private boolean docklessSuppressedSearchActive() {
        return suppressedDockHoldActive() && getCoverManager().getCurrentCover() == null;
    }

    /**
     * Sustained-quiet gate ({@code suppressedRelocationSafeRoute}): a docked
     * autonomous soldier may only launch an ATTACK advance (leave the dock)
     * once enemy fire has been quiet for {@link #ATTACK_ADVANCE_QUIET_MS}.
     * {@code isRecovered()} alone (2.5s) leaves a relaunch window inside a
     * live fire cycle — the decay-to-zero gap between enemy bursts — whose
     * corridor walk the next burst catches mid-crossing. Once fire has
     * genuinely stopped (enemies dead, reloading away, disengaged) the window
     * elapses and every path works exactly as before the gate existed.
     */
    private boolean dockAdvanceQuietHoldActive() {
        if (!StevesArmyConfig.isSuppressedRelocationSafeRoute()
            || relocationType != RelocationType.NONE
            || getCoverManager().getCurrentCover() == null) {
            return false;
        }
        // The event sequence guards the never-fired case: lastSuppressionTime
        // starts at 0 and the game clock starts near 0 in a fresh sim world,
        // so a soldier who has never taken fire must not read as "recently
        // suppressed" and lose his initial advance.
        if (getCoverManager().getSuppressionTracker().getSuppressionEventSequence() == 0) {
            return false;
        }
        return getCoverManager().getSuppressionTracker().getTimeSinceLastSuppression() < ATTACK_ADVANCE_QUIET_MS;
    }

    /**
     * Pinned-advance hold at the dock ({@code suppressedRelocationSafeRoute},
     * repurposed from the round-1 "absolute-pin freeze"): the soldier was
     * absolutely pinned at THIS dock and the fight that pinned him is still
     * live (active threat intel or a live attack target), so the autonomous
     * ATTACK advance must not LAUNCH from it — stepping out is what re-drew
     * the fire that pinned him. This is docked-soldier launch protection
     * only; it never freezes a soldier in the open (that role belongs to the
     * suppressed open-ground escape policy, which always moves him to the
     * best available cover). Releases when the threat context is gone
     * (enemies dead or disengaged) or the dock changes.
     */
    private boolean dockAdvancePinnedHoldActive() {
        if (!StevesArmyConfig.isSuppressedRelocationSafeRoute()
            || relocationType != RelocationType.NONE) {
            return false;
        }
        CoverPoint currentCover = getCoverManager().getCurrentCover();
        if (currentCover == null) {
            return false;
        }
        if (absolutePinDockPos == null || !absolutePinDockPos.equals(currentCover.getPosition())) {
            return false;
        }
        if (!getThreats().hasActiveThreat() && !soldier.hasValidAttackTarget()) {
            // The fight that pinned him is over: the latch goes inert and the
            // advance works exactly as before the gate existed.
            absolutePinDockPos = null;
            return false;
        }
        return true;
    }

    /** Combined docked advance-launch hold: sustained-quiet OR pinned-advance hold. */
    private boolean dockAdvanceLaunchHeld() {
        return dockAdvanceQuietHoldActive() || dockAdvancePinnedHoldActive();
    }

    private boolean isExposedToFlank() {
        // Close range no longer suppresses flank reasoning: a flank at 5 blocks
        // is more dangerous than one at 50, so the ordinary evaluation runs.
        if (GameClock.nowMs() - lastFlankRepositionTime < FLANK_REPOSITION_COOLDOWN_MS) {
            PerformanceMetrics.recordCoverSearchCooldownSkip();
            return false;
        }

        CoverPoint cover = getCoverManager().getCurrentCover();
        if (cover == null) return false;

        Set<Direction> protectedDirs = cover.getProtectedDirections();
        if (protectedDirs == null || protectedDirs.isEmpty()) return true;

        List<ThreatAwareness.ThreatInfo> threats = getThreats().getThreatInfos();
        if (threats.isEmpty()) return false;

        for (ThreatAwareness.ThreatInfo info : threats) {
            Vec3 toThreat = Vec3.atCenterOf(info.position).subtract(soldier.position());
            Direction threatDir = CoverFinder.getDirectionFromVector(toThreat);
            if (!protectedDirs.contains(threatDir)) {
                return true;
            }
        }
        return false;
    }

    private float getWeightedFlankingProtection(CoverPoint cover) {
        Set<Direction> protectedDirs = cover.getProtectedDirections();
        if (protectedDirs == null || protectedDirs.isEmpty()) return 0.0f;

        List<ThreatAwareness.ThreatInfo> threats = getThreats().getThreatInfos();
        if (threats.isEmpty()) return 1.0f;

        float protectedWeight = 0.0f;
        float totalWeight = 0.0f;

        for (ThreatAwareness.ThreatInfo info : threats) {
            Vec3 toThreat = Vec3.atCenterOf(info.position).subtract(cover.getPosition().getCenter());
            Direction threatDir = CoverFinder.getDirectionFromVector(toThreat);

            if (protectedDirs.contains(threatDir)) {
                protectedWeight += info.weight;
            }
            totalWeight += info.weight;
        }

        return totalWeight > 0 ? protectedWeight / totalWeight : 1.0f;
    }

    /**
     * Find a flank-reposition cover using the correct search center and squad context.
     * Returns the best candidate that improves weighted flank protection by at least MIN_FLANKING_IMPROVEMENT.
     */
    private Optional<CoverPoint> findBetterCoverForFlank() {
        Level level = soldier.level();
        CoverFinder finder = new CoverFinder(level);

        Vec3 threatDirection = getThreats().getPrimaryDirection(soldier.position());
        List<LivingEntity> threats = getThreatList();
        SquadCoverContext squadCtx = buildSquadCoverContext();

        int searchRadius = SEARCH_RADIUS;
        BlockPos searchCenter = soldier.blockPosition();

        if (soldier.hasValidAttackTarget()) {
            BlockPos attackPos = soldier.getAttackTargetPos();
            Vec3 toTarget = new Vec3(
                attackPos.getX() - soldier.getX(),
                0,
                attackPos.getZ() - soldier.getZ()
            );
            double distToTarget = toTarget.length();
            if (distToTarget > 1.0) {
                toTarget = toTarget.normalize();
                double ahead = Math.min(distToTarget * 0.5, 10.0);
                searchCenter = soldier.blockPosition().offset(
                    (int)(toTarget.x * ahead),
                    0,
                    (int)(toTarget.z * ahead)
                );
            }
        } else if (soldier.getSquadMode() == SquadMode.HOLD) {
            BlockPos holdPos = soldier.getHoldPosition();
            if (holdPos != null && !holdPos.equals(BlockPos.ZERO)) {
                searchCenter = holdPos;
            }
        } else if (soldier.getSquadMode() == SquadMode.FOLLOW) {
            LivingEntity owner = soldier.getOwner();
            if (owner instanceof Player) {
                searchCenter = owner.blockPosition();
                searchRadius = (int) FOLLOW_COVER_SEARCH_RADIUS;
            }
        }

        BlockPos machineGunnerAnchor = getMachineGunnerSearchCenter();
        if (machineGunnerAnchor != null && clearingPoiTarget == null) {
            searchCenter = machineGunnerAnchor;
            if (soldier.hasValidAttackTarget()) {
                searchRadius = ATTACK_CORRIDOR_SEARCH_RADIUS;
            }
        }

        // Close-combat doctrine: protection near a close threat must be a
        // short, useful movement, not a long relocation under fire. Bound the
        // radius only when the search is centered near the soldier - an
        // owner-anchored FOLLOW search 15 blocks out must keep its full span
        // or nearby protection becomes undiscoverable.
        if (soldier.isInCloseCombatContext() || soldier.hasCloseRangeTarget()) {
            double bound = StevesArmyConfig.getCloseCombatSeekRadius();
            if (searchCenter.distSqr(soldier.blockPosition()) <= Math.max(4.0, bound * bound)) {
                searchRadius = Math.min(searchRadius, (int) bound);
            }
        }

        // Use squad-aware evaluation from the correct center, excluding other soldiers' reservations
        List<CoverFinder.ScoredCover> scored;
        if (!searchCenter.equals(soldier.blockPosition())) {
            // The bounded searchRadius applies to center-based searches too -
            // a hard-coded corridor span here ignored the close-combat bound
            // and sent soldiers hunting "cover" beside the threat itself.
            scored = finder.evaluateAndScoreAllFromCenter(
                searchCenter, soldier, threatDirection, threats, searchRadius, squadCtx);
        } else {
            scored = finder.evaluateAndScoreAll(
                soldier, threatDirection, threats, searchRadius, false, squadCtx);
        }

        CoverPoint currentCover = getCoverManager().getCurrentCover();
        float currentProtection = currentCover != null ? getWeightedFlankingProtection(currentCover) : 0.0f;

        for (CoverFinder.ScoredCover sc : scored) {
            if (currentCover != null && sc.cover.getPosition().equals(currentCover.getPosition())) {
                continue;
            }
            float newProtection = getWeightedFlankingProtection(sc.cover);
            if (newProtection - currentProtection >= MIN_FLANKING_IMPROVEMENT) {
                return Optional.of(sc.cover);
            }
        }

        return Optional.empty();
    }

    /**
     * Check if the soldier should reposition for flank reasons.
     * Returns an Optional containing the target cover if repositioning is warranted.
     */
    private Optional<CoverPoint> shouldRepositionForFlank() {
        if (!isExposedToFlank()) return Optional.empty();

        // Suppressed soldiers stay in cover — don't allow flank repositioning
        if (!canLeaveCoverNow()) return Optional.empty();

        float currentProtection = getWeightedFlankingProtection(getCoverManager().getCurrentCover());
        if (currentProtection >= FLANKING_PROTECTION_THRESHOLD) {
            return Optional.empty();
        }

        long fingerprint = getFlankSearchFingerprint();
        if (StevesArmyConfig.isRetryPolicyEnabled()
            && failedFlankSearchFingerprint == fingerprint
            && soldier.tickCount < nextFlankSearchTick) {
            PerformanceMetrics.recordFlankSearchRetrySkip();
            return Optional.empty();
        }
        if (StevesArmyConfig.isRetryPolicyEnabled()
            && failedFlankSearchFingerprint != Long.MIN_VALUE
            && failedFlankSearchFingerprint != fingerprint) {
            PerformanceMetrics.recordFlankSearchFingerprintChange();
            failedFlankSearchFingerprint = Long.MIN_VALUE;
            nextFlankSearchTick = 0;
        }

        PerformanceMetrics.recordFlankSearchAttempt();
        Optional<CoverPoint> betterCover = findBetterCoverForFlank();
        if (betterCover.isEmpty()) {
            PerformanceMetrics.recordFlankSearchFailure();
            if (StevesArmyConfig.isRetryPolicyEnabled()) {
                failedFlankSearchFingerprint = fingerprint;
                nextFlankSearchTick = soldier.tickCount + FLANK_SEARCH_RETRY_TICKS;
            }
            return Optional.empty();
        }

        failedFlankSearchFingerprint = Long.MIN_VALUE;
        nextFlankSearchTick = 0;

        float newProtection = getWeightedFlankingProtection(betterCover.get());
        if (newProtection - currentProtection < MIN_FLANKING_IMPROVEMENT) {
            return Optional.empty();
        }

        return betterCover;
    }

    /**
     * Identifies the live inputs that can change a failed flank-search result.
     * Threat weights are intentionally omitted because they decay every tick;
     * block positions and the quantized primary direction capture meaningful
     * geometry changes without defeating the retry policy on every tick.
     */
    private long getFlankSearchFingerprint() {
        long fingerprint = 0xcbf29ce484222325L;
        fingerprint = mixFingerprint(fingerprint, getCoverManager().getCurrentCover().getPosition().asLong());
        fingerprint = mixFingerprint(fingerprint, soldier.blockPosition().asLong());
        fingerprint = mixFingerprint(fingerprint, soldier.getSquadMode().ordinal());

        LivingEntity owner = soldier.getOwner();
        if (owner != null) {
            fingerprint = mixFingerprint(fingerprint, owner.blockPosition().asLong());
        }

        BlockPos holdPosition = soldier.getHoldPosition();
        if (holdPosition != null) {
            fingerprint = mixFingerprint(fingerprint, holdPosition.asLong());
        }

        Vec3 primaryDirection = getThreats().getPrimaryDirection(soldier.position());
        if (primaryDirection != null && primaryDirection.lengthSqr() > 0.001) {
            fingerprint = mixFingerprint(fingerprint,
                CoverFinder.getDirectionFromVector(primaryDirection).ordinal());
        }

        for (ThreatAwareness.ThreatInfo threat : getThreats().getThreatInfos()) {
            fingerprint = mixFingerprint(fingerprint, threat.position.asLong());
        }
        return fingerprint;
    }

    private static long mixFingerprint(long fingerprint, long value) {
        fingerprint ^= value;
        return fingerprint * 0x100000001b3L;
    }
    
    @Override
    public boolean canUse() {
        // Seated crew soldiers never seek cover; they hold their station.
        if (soldier.isVehicleCrewActive() || soldier.isCrewSeated()
            || soldier.getRole() == SoldierRole.VEHICLE_CREW) return false;
        if (soldier.isHealing()) {
            return canContinueHealingInCover();
        }
        if (!soldier.isAlive()) return false;
        
        // ATTACK mode: always try to use cover (cover-to-cover advance)
        if (soldier.hasValidAttackTarget()) {
            return true;
        }

        if (relocationType != RelocationType.NONE && !isRelocationStillValid()) {
            clearRelocationTarget();
        }
        beginFollowRelocationIfNeeded();
        if (relocationType != RelocationType.NONE) {
            return true;
        }

        if (suppressionPositionStatus == SuppressionPositionStatus.SEARCHING
            || suppressionPositionStatus == SuppressionPositionStatus.MOVING
            || suppressionPositionStatus == SuppressionPositionStatus.BLOCKED) {
            return true;
        }

        if (soldier.isGoToHolding()
            && handledGoToArrivalGeneration != soldier.getPingMoveGeneration()) {
            handledGoToArrivalGeneration = soldier.getPingMoveGeneration();
            // A failed relocation searched from the old travel context. Reaching
            // the objective deserves a fresh local search, not the remainder of
            // that goal's restart delay (decremented only on canUse scans).
            // Re-pinging the same location while already there is not another
            // arrival: preserve failed-search pacing on a coverless objective.
            if (!Objects.equals(lastGoToArrivalObjective, soldier.getHoldPosition())
                || lastGoToArrivalPosition == null
                || lastGoToArrivalPosition.distSqr(soldier.blockPosition()) > 4 * 4) {
                lastGoToArrivalObjective = soldier.getHoldPosition();
                lastGoToArrivalPosition = soldier.blockPosition();
                cooldown = 0;
                searchExhaustionCooldown = 0;
                consecutiveFailedSearches = 0;
                clearFailedSearch();
            }
        }

        // Explicit movement replaces both an occupied lane and a pending one.
        // Test this before allowing a persistent prone plan to restart the goal.
        if (soldier.hasValidPingMoveTarget() && !soldier.hasValidAttackTarget()) {
            if (proneFiringController.isPlanActive()) {
                cancelProneFiringPlan();
                getPositionController().clear();
            }
            return false;
        }
        if (proneFiringController.isPlanActive()) return true;
        // Fresh fire at an unprotected endpoint must be serviced even if a
        // previous goal stop left a routine restart cooldown behind.
        if (docklessSuppressedSearchActive()) return true;
        if (cooldown > 0) {
            cooldown--;
            return false;
        }
        
        // Suppression decay is driven by SoldierEntity's server tick so it keeps
        // running while this goal is preempted or on its restart cooldown.

        CoverBehaviorManager.CoverState state = getCoverManager().getState();
        
        boolean result;
        switch (state) {
            case NO_COVER: {
                result = shouldSeekCover();
                break;
            }
            case SEEKING_COVER:
                result = true;
                break;
            case IN_COVER:
            case SUPPRESSED_IN_COVER: {
                CoverPoint cover = getCoverManager().getCurrentCover();
                if (cover != null) {
                    double distance = soldier.position().distanceTo(cover.getPosition().getCenter());
                    if (distance > COVER_ABANDON_DISTANCE) {
                        if (suppressedDockHoldActive()) {
                            // canUse() runs before tickInCover(), so the normal
                            // drift guard below cannot repair this case. Keep
                            // the occupied dock while suppression is live and
                            // let recovery re-evaluate the physical distance.
                            if (DiagnosticLogManager.isCoverLoggingEnabled()) {
                                StevesArmyMod.LOGGER.info(
                                    "[CoverSuppression] Soldier {} cover abandon held at {}: distance={} suppression={} reason=ABANDON_DISTANCE",
                                    soldier.getId(), cover.getPosition(), String.format("%.2f", distance),
                                    String.format("%.2f", getCoverManager().getSuppressionLevel()));
                            }
                            holdSuppressedAtDock(cover);
                            result = true;
                            break;
                        }
                        if (DiagnosticLogManager.isCoverLoggingEnabled()) {
                            StevesArmyMod.LOGGER.info("[CoverGoal] canUse=false: cover abandoned (dist={})", distance);
                        }
                        getCoverManager().resetPeekState();
                        getPositionController().clear();
                        getCoverManager().clearCover();
                        cooldown = COOLDOWN_TICKS;
                        result = false;
                        break;
                    }
                }
                result = true;
                break;
            }
            case REPOSITIONING:
                result = true;
                break;
            default:
                result = false;
                break;
        }
        if (DiagnosticLogManager.isCoverLoggingEnabled()) {
            StevesArmyMod.LOGGER.info("[CoverGoal] canUse={}, state={}, hasThreat={}, suppressed={}, health={}",
                result, state, getThreats().hasActiveThreat(),
                getCoverManager().isSuppressed(),
                String.format("%.2f", soldier.getHealth() / soldier.getMaxHealth()));
        }
        return result;
    }
    
    @Override
    public boolean canContinueToUse() {
        if (!soldier.isAlive()) return false;
        if (soldier.isVehicleCrewActive() || soldier.isCrewSeated()
            || soldier.getRole() == SoldierRole.VEHICLE_CREW) return false;
        if (soldier.isHealing()) {
            return canContinueHealingInCover();
        }

        if (relocationType != RelocationType.NONE && !isRelocationStillValid()) {
            logDockTransition("RELOCATION_INVALID");
            navigation.stop();
            getPositionController().clear();
            clearRelocationTarget();
            getCoverManager().setState(CoverBehaviorManager.CoverState.NO_COVER);
            return false;
        }
        
        CoverBehaviorManager.CoverState state = getCoverManager().getState();
        if (com.stevesarmy.debug.DiagnosticLogManager.isCoverScoreLoggingEnabled()
            && soldier.tickCount % 100 == 0) {
            CoverPoint dcc = getCoverManager().getCurrentCover();
            StevesArmyMod.LOGGER.info("[MarchDwell] S{} ccu t{}: state={} sup={} mode={} cover={} hold={} ctx={} bounder={} over={}",
                soldier.getId(), soldier.tickCount, state, getCoverManager().isSuppressed(), soldier.getSquadMode(),
                dcc != null ? dcc.getPosition() : "null",
                soldier.getHoldPosition(), soldier.isInCloseCombatContext(),
                com.stevesarmy.squad.SquadMovementCoordinator.isBounder(soldier),
                com.stevesarmy.squad.SquadMovementCoordinator.isOverwatching(soldier));
        }
        if (state == CoverBehaviorManager.CoverState.IN_COVER && !getCoverManager().isSuppressed()) {
            // Street-crossing doctrine: a dock is a pause under fire, not a
            // terminus. A docked soldier whose hold objective is still beyond
            // the hold radius yields the legs after the quiet dwell - stop()
            // releases the cover and SoldierHoldPositionGoal resumes the march.
            if (soldier.getSquadMode() == SquadMode.HOLD
                && SoldierHoldPositionGoal.shouldResumeMarch(soldier, getCoverManager())) {
                if (DiagnosticLogManager.isCoverLoggingEnabled()) {
                    StevesArmyMod.LOGGER.info("[CoverGoal] canContinueToUse=false: quiet dwell expired, resuming hold march");
                }
                return false;
            }
            if (soldier.getSquadMode() == SquadMode.FOLLOW) {
                LivingEntity owner = soldier.getOwner();
                if (owner != null && soldier.distanceToSqr(owner) > 15 * 15) {
                    getCoverManager().clearCover();
                    getCoverManager().resetPeekState();
                    getPositionController().clear();
                    cooldown = COOLDOWN_TICKS;
                    if (DiagnosticLogManager.isCoverLoggingEnabled()) {
                        StevesArmyMod.LOGGER.info("[CoverGoal] canContinueToUse=false: FOLLOW mode, not suppressed, far from owner");
                    }
                    return false;
                }
            }
        }
        
        boolean result = proneFiringController.isPlanActive()
            || docklessSuppressedSearchActive()
            || state != CoverBehaviorManager.CoverState.NO_COVER || soldier.hasValidAttackTarget();
        if (DiagnosticLogManager.isCoverLoggingEnabled()) {
            StevesArmyMod.LOGGER.info("[CoverGoal] canContinueToUse={}, state={}", result, state);
        }
        return result;
    }
    
    @Override
    public void start() {
        if (com.stevesarmy.debug.trace.SoldierFlightRecorder.isRecording())
            com.stevesarmy.debug.trace.SoldierFlightRecorder.event(soldier, "cover-goal", "start", getCoverManager().getState().name());
        stuckTicks = 0;
        reevaluateCounter = 0;
        
        CoverBehaviorManager.CoverState state = getCoverManager().getState();
        
        // Initialize attack phase if we have a valid attack target
        if (soldier.hasValidAttackTarget()) {
            initAttackPhase();
        }
        
        if (state == CoverBehaviorManager.CoverState.NO_COVER) {
            if (docklessSuppressedSearchActive()) {
                // Pinned with no dock: the classified suppression search with
                // its retry pacing replaces the plain corridor request, which
                // used to walk an unclassified ATTACK_SELECTING dock under fire.
                runDocklessSuppressedSearch();
            } else {
                getCoverManager().setState(CoverBehaviorManager.CoverState.SEEKING_COVER);
                requestCoverSearch(soldier.hasValidAttackTarget()
                    ? QueuedSearchMode.ATTACK_SELECTING : QueuedSearchMode.NORMAL);
            }
        } else if (state == CoverBehaviorManager.CoverState.SEEKING_COVER ||
                   state == CoverBehaviorManager.CoverState.REPOSITIONING) {
            if (getCoverManager().getTargetCover() == null) {
                requestCoverSearch(soldier.hasValidAttackTarget()
                    ? QueuedSearchMode.ATTACK_SELECTING : QueuedSearchMode.NORMAL);
            } else {
                moveToCover(getCoverManager().getTargetCover());
            }
        }
    }
    
    @Override
    public void stop() {
        if (activeRouteCrawlMandatory) {
            activeRouteCrawlMandatory = false;
            soldier.getMovementController().setMandatoryCrawl(false, "cover-owner-stopped");
        }
        if (com.stevesarmy.debug.trace.SoldierFlightRecorder.isRecording())
            com.stevesarmy.debug.trace.SoldierFlightRecorder.event(soldier, "cover-goal", "stop", getCoverManager().getState().name());
        CoverSearchScheduler.cancel(this);
        coverSearchPending = false;
        asyncPilotPending = false;
        asyncPilotSubmittedTick = Long.MIN_VALUE;
        queuedSearchMode = null;
        queuedAttackGeneration = -1;
        queuedRelocationType = RelocationType.NONE;
        queuedRelocationCenter = null;
        boolean hadRelocation = relocationType != RelocationType.NONE;
        if (hadRelocation) {
            clearRelocationTarget();
            getCoverManager().setState(CoverBehaviorManager.CoverState.NO_COVER);
        }
        boolean wasHealing = soldier.isHealing();
        CoverBehaviorManager.CoverState state = getCoverManager().getState();
        boolean preserveCoverForHealing = wasHealing
            && (state == CoverBehaviorManager.CoverState.IN_COVER
                || state == CoverBehaviorManager.CoverState.SUPPRESSED_IN_COVER)
            && getCoverManager().getCurrentCover() != null;

        if (wasHealing) {
            soldier.getHealController().stop();
        }

        if (preserveCoverForHealing) {
            healingPosturePending = false;
            pendingRetryCover = null;
            isRetryAttempt = false;
            stuckTicks = 0;
            return;
        }
        
        // Don't clear cover if we're in ATTACK mode - preserve state across interruptions
        if (soldier.hasValidAttackTarget()) {
            return;
        }

        // A higher-priority behavior is taking over. Do not leave an orphaned
        // prone plan active after this goal stops being ticked.
        cancelProneFiringPlan();
        
        if (state == CoverBehaviorManager.CoverState.IN_COVER ||
            state == CoverBehaviorManager.CoverState.SUPPRESSED_IN_COVER) {
            getCoverManager().clearCover();
        } else if (state == CoverBehaviorManager.CoverState.SEEKING_COVER ||
                   state == CoverBehaviorManager.CoverState.REPOSITIONING) {
            getCoverManager().clearTargetCover();
        }

        // A stopped goal cannot own a spacing reservation or authorize prone.

        pendingRetryCover = null;
        isRetryAttempt = false;
        healingPosturePending = false;
        cooldown = COOLDOWN_TICKS;
        stuckTicks = 0;
    }
    
    @Override
    public void tick() {
        PerformanceMetrics.recordCoverTick(getCoverManager().getState().name(), machineGunnerPipeline);
        CoverBehaviorManager.CoverState state = getCoverManager().getState();
        PerformanceMetrics.recordCoverPopulation(state.name(), coverSearchPending, asyncPilotPending,
            getCoverManager().getTargetCover() != null);
        trackSuppressionEpisode();
        sampleSuppressionFiringOrigin();
        // Suppressed-open-ground escape commits dissolve with the suppression
        // that justified them: a recovered soldier behaves exactly as before
        // the gate existed (suppression-state change re-opens evaluation).
        if (escapeCommitCoverPos != null && canLeaveCoverNow()) {
            clearSuppressedEscapeCommit("suppression recovered");
        }
        refreshCloseCombatContext();

        if (soldier.isHealing()) {
            if (canContinueHealingInCover()) {
                soldier.getHealController().tick();
                CoverPoint currentCover = getCoverManager().getCurrentCover();
                if (currentCover != null) {
                    maintainCoverAnchorIfHiding(currentCover);
                }
                tickProneFiringPlan();
                populateCoverDebugData();
                return;
            }
            soldier.getHealController().stop();
        }

        if (relocationType != RelocationType.NONE && !isRelocationStillValid()) {
            logDockTransition("RELOCATION_INVALID");
            navigation.stop();
            getPositionController().clear();
            clearRelocationTarget();
            getCoverManager().setState(CoverBehaviorManager.CoverState.NO_COVER);
            return;
        }

        if (relocationType == RelocationType.GO_TO) {
            // Seek-starvation bail: while no cover route has committed, the
            // relocation is just the SEEKING/NO_COVER flash. Keyed on the
            // destination so re-pinging the same spot cannot restart the
            // hunt — the mashed-ping strand — and the direct walk in
            // SoldierMoveToPingGoal takes over the same generation.
            if (!relocationCenter.equals(goToStallDestination)) {
                goToStallDestination = relocationCenter;
                goToSeekStallTicks = 0;
            }
            if (getCoverManager().getTargetCover() == null) {
                if (++goToSeekStallTicks >= StevesArmyConfig.getGoToSeekGraceTicks()) {
                    if (DiagnosticLogManager.isCoverLoggingEnabled()) {
                        StevesArmyMod.LOGGER.info(
                            "[CoverRelocation] Soldier {} GO_TO seek starved {}t without a cover commit - direct walk",
                            soldier.getId(), goToSeekStallTicks);
                    }
                    failGoToRelocation();
                    return;
                }
            } else {
                goToSeekStallTicks = 0;
            }
            if (++goToRelocationTicks > goToRelocationMaxTicks) {
                if (DiagnosticLogManager.isCoverLoggingEnabled()) {
                    StevesArmyMod.LOGGER.info("[CoverRelocation] Soldier {} GO_TO relocation timed out after {} ticks",
                        soldier.getId(), goToRelocationTicks);
                }
                failGoToRelocation();
                return;
            }
        }

        // Suppressed-traveler doctrine: a near-miss during a GO_TO ping move
        // raised a reroute request (the manager accepts it while a relocation is
        // in flight). Re-path to the claimed cover - the async search bakes the
        // squad map's fresh shadow into the new route's danger corridor.
        if (relocationType == RelocationType.GO_TO
            && getCoverManager().consumeTravelRerouteRequest()) {
            CoverPoint rerouteTarget = getCoverManager().getTargetCover();
            if (rerouteTarget != null) {
                moveToCover(rerouteTarget);
                if (DiagnosticLogManager.isCoverLoggingEnabled()) {
                    StevesArmyMod.LOGGER.info("[TravelResponse] Soldier {} re-routing GO_TO move to {} under fire (suppression={})",
                        soldier.getId(), rerouteTarget.getPosition(),
                        String.format("%.2f", getCoverManager().getSuppressionLevel()));
                }
            }
        }

        if (relocationType == RelocationType.FOLLOW && relocationCenter != null) {
            LivingEntity owner = soldier.getOwner();
            if (owner != null) {
                BlockPos ownerPos = owner.blockPosition().immutable();
                relocationCenter = ownerPos;

                CoverPoint targetCover = getCoverManager().getTargetCover();
                if (targetCover != null && !getCoverManager().isInCover()
                    && followReplanCooldownTicks <= 0
                    && ownerPos.distSqr(targetCover.getPosition()) > followTargetStaleDistance() * followTargetStaleDistance()) {
                    CoverReservationManager.release(targetCover.getPosition(), soldier);
                    getCoverManager().clearTargetCover();
                    getPositionController().clear();
                    followReplanCooldownTicks = FOLLOW_REPLAN_COOLDOWN_TICKS;
                    if (DiagnosticLogManager.isCoverLoggingEnabled()) {
                        StevesArmyMod.LOGGER.info("[CoverRelocation] Soldier {} FOLLOW target stale (owner moved), replacing",
                            soldier.getId());
                    }
                }
                if (followReplanCooldownTicks > 0) {
                    followReplanCooldownTicks--;
                }
            }
        }

        // Command-owned retries continue independently of combat-goal cadence.
        tickSuppressionPositionRetry();
        
        // Sync threat direction to client for debug rendering
        Vec3 threatDir = getThreats().getThreatDirectionForProactivePeek(soldier.position());
        soldier.syncThreatDirection(threatDir);
        
        PeekController peekCtrl = getPeekController();

        // NO_COVER can be a transient handoff, but a retained destination is
        // not evidence that anyone still owns its movement. Service a live
        // approach through the ordinary arrival checks; release abandoned ones.
        if (state == CoverBehaviorManager.CoverState.NO_COVER
            && getCoverManager().getCurrentCover() == null) {
            CoverPoint target = getCoverManager().getTargetCover();
            if (target != null) {
                if (!soldier.getNavigation().isDone()
                    || getPositionController().getLastResult() == CoverPositionController.MovementResult.IN_PROGRESS
                    || soldier.position().distanceToSqr(getCoverStandingPosition(target.getPosition()))
                        <= POSITIONING_TOLERANCE * POSITIONING_TOLERANCE) {
                    getCoverManager().setState(CoverBehaviorManager.CoverState.SEEKING_COVER);
                } else {
                    CoverReservationManager.release(target.getPosition(), soldier);
                    getCoverManager().clearTargetCover();
                    getPositionController().clear();
                }
            }
            if (getCoverManager().getTargetCover() == null && docklessSuppressedSearchActive()) {
                runDocklessSuppressedSearch();
            }
            state = getCoverManager().getState();
        }

        // Reloading keeps a soldier protected in occupied cover, but must not
        // strand one in the open after a cover destination has been chosen.
        if (soldier.isPreparingOrReloading()) {
            reloadHoldActive = true;
            CoverPoint currentCover = getCoverManager().getCurrentCover();
            if (currentCover != null) {
                holdForReload(currentCover);
            } else if (state == CoverBehaviorManager.CoverState.SEEKING_COVER) {
                continueCoverMovementDuringReload(state);
                tickSeekingCover();
            } else if (state == CoverBehaviorManager.CoverState.REPOSITIONING) {
                continueCoverMovementDuringReload(state);
                tickRepositioning();
            } else {
                // Preserve the defensive fallback while a dockless search is
                // paced or pending; reload must not force an upright stand.
                if (docklessSuppressedSearchActive()) enterOpenGroundFallbackPosture();
                else holdForReload(null);
            }
            tickProneFiringPlan();
            populateCoverDebugData();
            return;
        }

        if (reloadHoldActive) {
            reloadHoldActive = false;
            resumeMovementAfterReload();
        }

        if (state != CoverBehaviorManager.CoverState.SEEKING_COVER) {
            seekingTicks = 0;
        }
        if (state == CoverBehaviorManager.CoverState.IN_COVER
            || state == CoverBehaviorManager.CoverState.SUPPRESSED_IN_COVER) {
            lastInCoverTick = soldier.tickCount;
        }
        if (state != CoverBehaviorManager.CoverState.REPOSITIONING) {
            repositioningTicks = 0;
        }
        if (searchExhaustionCooldown > 0) {
            searchExhaustionCooldown--;
        }
        
        if (DiagnosticLogManager.isCoverLoggingEnabled()) {
            tickLogCounter++;
            if (tickLogCounter >= SNAPSHOT_INTERVAL) {
                tickLogCounter = 0;
                StevesArmyMod.LOGGER.info("[CoverGoal] Soldier {} tick: coverState={}, peekState={}, hasThreat={}, suppression={}",
                    soldier.getId(), state, peekCtrl.getState(),
                    getThreats().hasActiveThreat(),
                    String.format("%.2f", getCoverManager().getSuppressionTracker().getSuppressionLevel()));
            }

            peekLogCounter++;
            if (peekLogCounter >= SNAPSHOT_INTERVAL) {
                peekLogCounter = 0;
                CoverPositionController ctrl = getPositionController();
                CoverPoint cover = getCoverManager().getCurrentCover();
                double distToCover = cover != null ? soldier.position().distanceTo(cover.getPosition().getCenter()) : -1;
                Vec3 vel = soldier.getDeltaMovement();
                double speed = Math.sqrt(vel.x * vel.x + vel.z * vel.z);
                Vec3 ctrlTarget = ctrl.getDebugTargetPos();
                double ctrlDist = ctrlTarget != null ?
                    Math.sqrt(Math.pow(ctrlTarget.x - soldier.getX(), 2) + Math.pow(ctrlTarget.z - soldier.getZ(), 2)) : -1;
                StevesArmyMod.LOGGER.info("[PeekCycle] Soldier {} state={} peek={} ctrlResult={} ctrlDist={} distToCover={} speed={} nonPeekable={} peekCount={}",
                    soldier.getId(), state, peekCtrl.getState(),
                    ctrl.getLastResult(), String.format("%.2f", ctrlDist), String.format("%.2f", distToCover), String.format("%.4f", speed),
                    getCoverManager().isNonPeekableCover(), peekCtrl.getPeekCountSameCover());
            }
        }
        
        switch (state) {
            case SEEKING_COVER:
                tickSeekingCover();
                break;
            case REPOSITIONING:
                tickRepositioning();
                break;
            case IN_COVER:
                tickInCover();
                break;
            case SUPPRESSED_IN_COVER:
                tickSuppressedInCover();
                break;
            case NO_COVER:
                // Attack mode: trigger immediate cover search
                if (soldier.hasValidAttackTarget() && attackPhase == AttackPhase.NONE) {
                    initAttackPhase();
                }
                break;
        }

        // Cover owns the defensive position, so its prone settling timer must
        // continue even when CombatGoal has temporarily stopped for lack of a target.
        tickProneFiringPlan();
        
        // Attack mode: run phase logic after state handling
        if (soldier.hasValidAttackTarget()) {
            // Periodic attack-mode snapshot every 20 ticks
            if (soldier.tickCount % 20 == 0) {
                CoverPoint tgt = getCoverManager().getTargetCover();
                CoverPoint cur = getCoverManager().getCurrentCover();
                BlockPos targetPos = tgt != null ? tgt.getPosition() : null;
                double dist = targetPos != null ? soldier.position().distanceTo(targetPos.getCenter()) : -1;
                StevesArmyMod.LOGGER.info("[CoverNav] Soldier {} ({}) phase={} state={} targetCover={} currentCover={} distToTarget={} isCQB={}",
                    soldier.getId(), soldier.getName().getString(), attackPhase, getCoverManager().getState(),
                    targetPos, cur != null ? cur.getPosition() : null,
                    String.format("%.2f", dist), soldier.isCQB());
            }
            tickAttackPhase();
        } else {
            // Non-ATTACK: log structured transition if debug enabled (rate-limited)
            if (DiagnosticLogManager.isCoverLoggingEnabled()) {
                snapshotCounter++;
                if (snapshotCounter >= SNAPSHOT_INTERVAL) {
                    snapshotCounter = 0;
                    CoverPoint cur = getCoverManager().getCurrentCover();
                    CoverPoint tgt = getCoverManager().getTargetCover();
                    StevesArmyMod.LOGGER.info("[CoverSnapshot] Soldier {} state={} attackPhase={} current={} target={} sup={} recovered={}",
                        soldier.getId(), state, attackPhase,
                        cur != null ? cur.getPosition() : "null",
                        tgt != null ? tgt.getPosition() : "null",
                        String.format("%.2f", getCoverManager().getSuppressionTracker().getSuppressionLevel()),
                        getCoverManager().getSuppressionTracker().isRecovered());
                }
            }
        }
        
        populateCoverDebugData();
    }
    
    private void tickSeekingCover() {
        // Mid-approach re-suppression: a soldier already walking to a
        // selected/claimed dock is in the "cover close" branch of the
        // suppressed-in-the-open doctrine BY CONSTRUCTION — his pending dock
        // is the dash/crawl target, so the approach completes instead of
        // being aborted (the round-1 abort stranded reload/knockback/
        // close-protect dockings mid-transit). Walk-OUT protection lives at
        // the dock: the exit-cover channels stay withheld while suppressed.
        tickSuppressedEscapeCrawlToDash();
        if (proneFiringDestination != null) {
            tickProneFiringMovement();
            return;
        }
        if (proneFiringController.isPlanActive()) return;
        // Handle pending retry from previous tick
        if (pendingRetryCover != null) {
            if (DiagnosticLogManager.isCoverLoggingEnabled()) {
                StevesArmyMod.LOGGER.info("[PathDebug] Soldier {} retrying path to cover {}", 
                    soldier.getId(), pendingRetryCover.getPosition());
            }
            isRetryAttempt = true;
            boolean movementStarted = moveToCover(pendingRetryCover);
            isRetryAttempt = false;
            pendingRetryCover = null;
            if (!movementStarted && !isReloadBlockedMove() && relocationType == RelocationType.GO_TO) {
                failGoToRelocation();
            }
            return;
        }
        
        CoverPoint targetCover = getCoverManager().getTargetCover();
        
        if (targetCover == null) {
            if (asyncPilotPending) {
                if (soldier.level().getGameTime() - asyncPilotSubmittedTick > 40L) {
                    asyncPilotPending = false;
                    asyncPilotSubmittedTick = Long.MIN_VALUE;
                    PerformanceMetrics.recordPhase6FallbackTimeout();
                    consecutiveFailedSearches++;
                    runAsyncPilotFallback();
                    return;
                }
                enterOpenGroundFallbackPosture();
                return;
            }

            // If we are in search-exhaustion cooldown, wait without re-requesting.
            // Waiting is done low, not standing in the open.
            if (searchExhaustionCooldown > 0) {
                enterOpenGroundFallbackPosture();
                return;
            }

            // No cover claim for SEEK_ESCALATION_TICKS: widen the next search
            // toward the squad instead of re-scanning the same empty radius. A
            // soldier stranded beyond the normal search radius (the MG
            // follow-formation rim-corner case) would otherwise re-request
            // identical failing searches until something external changes.
            if (!seekEscalated
                && soldier.tickCount - lastInCoverTick >= SEEK_ESCALATION_TICKS) {
                seekEscalated = true;
            }

            requestCoverSearch(soldier.hasValidAttackTarget()
                ? QueuedSearchMode.ATTACK_SELECTING : QueuedSearchMode.NORMAL);
            seekingTicks++;
            noProgressTicks = 0;
            lastSeekingPosition = null;
            return;
        }

        // Revalidate at the actual dock: threat direction/intel may have
        // changed while navigation was in flight, and a stale target must not
        // become a wrong-side cover claim.
        CoverFinder arrivalFinder = new CoverFinder(soldier.level());
        if (!isUsableAgainstThreat(arrivalFinder, targetCover, getCoverSearchDirection())) {
            CoverReservationManager.release(targetCover.getPosition(), soldier);
            getCoverManager().clearTargetCover();
            blacklistCover(targetCover.getPosition(), BlacklistReason.POSITIONING_BLOCKED);
            enterOpenGroundFallbackPosture();
            requestCoverSearch(soldier.hasValidAttackTarget()
                ? QueuedSearchMode.ATTACK_SELECTING : QueuedSearchMode.NORMAL);
            return;
        }

        ensureMovementAttemptTarget(targetCover);
        if (movementAttemptCount == 0) {
            moveToCover(targetCover);
            return;
        }

        seekingTicks++;
        
        CoverPositionController moveControl = getPositionController();
        CoverPositionController.MovementResult moveResult = moveControl.getLastResult();
        Vec3 standingPos = getCoverStandingPosition(targetCover.getPosition());
        double horizontalDist = Math.sqrt(
            Math.pow(soldier.position().x - standingPos.x, 2) +
            Math.pow(soldier.position().z - standingPos.z, 2));
        
        // 1. Position controller reached the target or soldier is already at standing pos
        if (isCoverFloorReached(targetCover) && (moveResult == CoverPositionController.MovementResult.REACHED_TARGET
            || horizontalDist < POSITIONING_TOLERANCE)) {
            if (soldier.hasValidAttackTarget()) {
                StevesArmyMod.LOGGER.info("[CoverNav] Soldier {} ({}) reached cover at hDist={} cover={}",
                    soldier.getId(), soldier.getName().getString(), String.format("%.2f", horizontalDist), targetCover.getPosition());
            }
            onCoverReached(targetCover);
            seekingTicks = 0;
            noProgressTicks = 0;
            lastSeekingPosition = null;
            return;
        }
        
        // 2. Position controller is still working — wait
        if (moveResult == CoverPositionController.MovementResult.IN_PROGRESS) {
            return;
        }
        
        // 3. Position controller failed — geometry rejections blacklist the cover
        // instead of re-attempting the same blocked approach every tick.
        if (moveResult == CoverPositionController.MovementResult.FAILED) {
            CoverPositionController.FailureReason failReason = moveControl.getLastFailureReason();
            if (failReason == CoverPositionController.FailureReason.HAZARD
                || failReason == CoverPositionController.FailureReason.BLOCKED_PATH
                || failReason == CoverPositionController.FailureReason.NO_PROGRESS) {
                if (soldier.hasValidAttackTarget()) {
                    StevesArmyMod.LOGGER.info("[CoverNav] Soldier {} ({}) approach blocked (reason={}) for cover={}, blacklisting",
                        soldier.getId(), soldier.getName().getString(), failReason, targetCover.getPosition());
                }
                blacklistCover(targetCover.getPosition(), BlacklistReason.POSITIONING_BLOCKED);
                stuckTicks = 0;
                noProgressTicks = 0;
                lastSeekingPosition = null;
                requestCoverSearch(soldier.hasValidAttackTarget()
                    ? QueuedSearchMode.ATTACK_SELECTING : QueuedSearchMode.NORMAL);
                return;
            }
            if (soldier.hasValidAttackTarget()) {
                StevesArmyMod.LOGGER.info("[CoverNav] Soldier {} ({}) position controller FAILED (reason={}) for cover={}, retrying navigation",
                    soldier.getId(), soldier.getName().getString(), failReason, targetCover.getPosition());
            }
            moveControl.clear();
            navigation.stop();
            moveToCover(targetCover);
            return;
        }
        
        // Measure distance to the standing block position, not just the cover center
        if (isCoverFloorReached(targetCover) && horizontalDist < COVER_REACHED_DISTANCE) {
            if (soldier.hasValidAttackTarget()) {
                StevesArmyMod.LOGGER.info("[CoverNav] Soldier {} ({}) reached standing pos at hDist={} cover={}",
                    soldier.getId(), soldier.getName().getString(), String.format("%.2f", horizontalDist), targetCover.getPosition());
            }
            onCoverReached(targetCover);
            seekingTicks = 0;
            noProgressTicks = 0;
            lastSeekingPosition = null;
            return;
        }
        
        // Handoff to position controller when close to standing position
        if (isCoverFloorReached(targetCover) && horizontalDist < COVER_VALID_DISTANCE) {
            if (soldier.hasValidAttackTarget()) {
                StevesArmyMod.LOGGER.info("[CoverNav] Soldier {} ({}) handoff to position controller at hDist={} cover={}",
                    soldier.getId(), soldier.getName().getString(), String.format("%.2f", horizontalDist), targetCover.getPosition());
            }
            navigation.stop();
            moveControl.moveTo(standingPos, POSITIONING_TOLERANCE, POSITIONING_SPEED, "tickSeekingCover", "recenter to target cover");
            if (moveControl.getLastResult() == CoverPositionController.MovementResult.FAILED) {
                CoverPositionController.FailureReason handoffFailReason = moveControl.getLastFailureReason();
                if (isReloadBlockedMove()
                    || handoffFailReason == CoverPositionController.FailureReason.RELOAD_INTERRUPTED) {
                    // Reload hold, not a cover problem: wait for the reload; the
                    // approach resumes afterwards.
                    return;
                }
                // Navigation is already stopped, so a rejected handoff leaves no
                // movement driver. The A*-validated route may simply not be
                // straight-line visible from here, so retry via navigation before
                // condemning the cover.
                moveControl.resetFailureState();
                if (!moveToCover(targetCover) && pendingRetryCover == null && !isReloadBlockedMove()) {
                    if (DiagnosticLogManager.isCoverLoggingEnabled()) {
                        StevesArmyMod.LOGGER.info("[CoverGoal] Soldier {} handoff rejected (reason={}) for cover={}, blacklisting",
                            soldier.getId(), handoffFailReason, targetCover.getPosition());
                    }
                    blacklistCover(targetCover.getPosition(), BlacklistReason.POSITIONING_BLOCKED);
                    stuckTicks = 0;
                    noProgressTicks = 0;
                    lastSeekingPosition = null;
                    requestCoverSearch(soldier.hasValidAttackTarget()
                        ? QueuedSearchMode.ATTACK_SELECTING : QueuedSearchMode.NORMAL);
                }
                return;
            }
        }

        // Normal navigation-driven approach
        Vec3 currentPos = soldier.position();
        tryOpenDoorOnPath();
        
        if (navigation.isDone()) {
            if (relocationType != RelocationType.NONE) {
                // A staged path has ended. Recalculate immediately: the next route
                // may now be short enough to require exact cover validation.
                moveToCover(targetCover);
                stuckTicks = 0;
                noProgressTicks = 0;
                lastSeekingPosition = currentPos;
                return;
            }
            if (movementAttemptCount == 1) {
                if (DiagnosticLogManager.isCoverLoggingEnabled()) {
                    StevesArmyMod.LOGGER.info("[CoverNav] Soldier {} retrying cover path after it ended before arrival: target={}",
                        soldier.getId(), targetCover.getPosition());
                }
                moveToCover(targetCover);
                stuckTicks = 0;
                return;
            }
            stuckTicks++;
            noProgressTicks = 0;
            lastSeekingPosition = null;
            if (stuckTicks > MAX_STUCK_TICKS) {
                if (targetCover != null) {
                    if (soldier.hasValidAttackTarget()) {
                        StevesArmyMod.LOGGER.info("[CoverNav] Soldier {} ({}) stuck seeking cover, blacklisting. cover={}",
                            soldier.getId(), soldier.getName().getString(), targetCover.getPosition());
                    }
                    blacklistCover(targetCover.getPosition(), BlacklistReason.STUCK_SEEKING);
                }
                getCoverManager().clearTargetCover();
                stuckTicks = 0;
                requestCoverSearch(soldier.hasValidAttackTarget()
                    ? QueuedSearchMode.ATTACK_SELECTING : QueuedSearchMode.NORMAL);
            }
        } else {
            stuckTicks = 0;
            
            if (lastSeekingPosition != null) {
                double moved = currentPos.distanceTo(lastSeekingPosition);
                if (moved < 0.1) {
                    noProgressTicks++;
                    if (noProgressTicks > 40) {
                        if (DiagnosticLogManager.isCoverLoggingEnabled()) {
                            StevesArmyMod.LOGGER.info("[CoverGoal] Soldier {} not progressing toward cover ({} ticks, moved {}), retrying navigation",
                                soldier.getId(), noProgressTicks, String.format("%.2f", moved));
                        }
                        navigation.stop();
                        moveToCover(targetCover);
                        noProgressTicks = 0;
                        lastSeekingPosition = currentPos;
                    }
                } else {
                    noProgressTicks = 0;
                    lastSeekingPosition = currentPos;
                }
            } else {
                lastSeekingPosition = currentPos;
            }
        }
        
        int seekingTimeout = relocationType != RelocationType.NONE ? MAX_SEEKING_TICKS * 3 : MAX_SEEKING_TICKS;
        if (seekingTicks > seekingTimeout) {
            if (soldier.hasValidAttackTarget()) {
                StevesArmyMod.LOGGER.info("[CoverNav] Soldier {} ({}) seeking timeout, resetting. cover={}",
                    soldier.getId(), soldier.getName().getString(), targetCover != null ? targetCover.getPosition() : "null");
            }
            getCoverManager().resetPeekState();
            getPositionController().clear();
            getCoverManager().clearTargetCover();
            if (suppressedDockHoldActive() && getCoverManager().getCurrentCover() != null) {
                // Pinned: the seek timed out but the dock claim stands — re-hold
                // suppressed-in-cover instead of resetting to NO_COVER, which
                // used to re-seed the machine into another exposed walk while
                // the soldier never left the fire.
                getCoverManager().setState(CoverBehaviorManager.CoverState.SUPPRESSED_IN_COVER);
            } else {
                getCoverManager().setState(CoverBehaviorManager.CoverState.NO_COVER);
            }
            seekingTicks = 0;
            noProgressTicks = 0;
            lastSeekingPosition = null;
            pressuredPeekStallStartTick = -1;
            consecutiveFailedSearches = 0;
            searchExhaustionCooldown = getCoverManager().isSuppressed()
                ? SEARCH_EXHAUSTION_COOLDOWN_SUPPRESSED_TICKS
                : SEARCH_EXHAUSTION_COOLDOWN_TICKS;
            enterOpenGroundFallbackPosture();
        }
    }
    
private void tickRepositioning() {
    // Mid-move re-suppression: same doctrine as tickSeekingCover — a
    // reposition caught in the open completes its crossing to the selected
    // dock (the pending dock is the escape target by construction). Relaunch
    // protection lives at the origin dock, where the exit-cover channels are
    // withheld while suppressed.
    tickSuppressedEscapeCrawlToDash();

    // Handle pending retry from previous tick
    if (pendingRetryCover != null) {
            if (DiagnosticLogManager.isCoverLoggingEnabled()) {
                StevesArmyMod.LOGGER.info("[PathDebug] Soldier {} retrying path to cover {}",
                    soldier.getId(), pendingRetryCover.getPosition());
            }
            isRetryAttempt = true;
            boolean movementStarted = moveToCover(pendingRetryCover);
            isRetryAttempt = false;
            pendingRetryCover = null;
            if (!movementStarted && !isReloadBlockedMove() && relocationType == RelocationType.GO_TO) {
                failGoToRelocation();
            }
            return;
        }

        CoverPoint targetCover = getCoverManager().getTargetCover();
        CoverPoint currentCover = getCoverManager().getCurrentCover();

        // ATTACK owns the chosen bound until deterministic path recovery rejects it.
        // Its path may temporarily lead away from the objective to exit a structure,
        // so the generic threat-shift reconsideration must not replace it mid-route.
        // A suppress-area order likewise owns its destination: the smooth threat
        // direction rotating under fire must not abandon a ping-directed move.
        boolean suppressionMoveInFlight = suppressionPositionStatus == SuppressionPositionStatus.MOVING
            && soldier.getSuppressionOrder().getGeneration() == suppressionPositionGeneration;
        if (!soldier.hasValidAttackTarget() && !suppressionMoveInFlight && soldier.getRandom().nextFloat() < 0.5f) {
            Vec3 currentThreatDir = getThreats().getPrimaryDirection(soldier.position());
            Vec3 entryThreatDir = getCoverManager().getEntryThreatDirection();
            
            if (currentThreatDir != null && entryThreatDir != null && 
                currentThreatDir.lengthSqr() > 0.01 && entryThreatDir.lengthSqr() > 0.01) {
                double dot = currentThreatDir.dot(entryThreatDir) / (currentThreatDir.length() * entryThreatDir.length());
                double angle = Math.acos(net.minecraft.util.Mth.clamp(dot, -1.0, 1.0));
                
                if (angle > MID_MOVE_ANGLE_THRESHOLD) {
                    if (soldier.getRandom().nextFloat() < 0.5f) {
                        if (DiagnosticLogManager.isCoverLoggingEnabled()) {
                            StevesArmyMod.LOGGER.info("[CoverGoal] Soldier {} mid-move threat shift, cancelling reposition",
                                soldier.getId());
                        }
                        getCoverManager().clearTargetCover();
                        requestCoverSearch(soldier.hasValidAttackTarget()
                            ? QueuedSearchMode.ATTACK_SELECTING : QueuedSearchMode.NORMAL);
                        return;
                    } else {
                        if (DiagnosticLogManager.isCoverLoggingEnabled()) {
                            StevesArmyMod.LOGGER.info("[CoverGoal] Soldier {} mid-move threat shift, committing to move",
                                soldier.getId());
                        }
                    }
                }
            }
        }
        
        if (targetCover == null) {
            if (currentCover != null) {
                getCoverManager().setState(CoverBehaviorManager.CoverState.IN_COVER);
            } else {
                getCoverManager().setState(CoverBehaviorManager.CoverState.SEEKING_COVER);
                // Immediately request a new search so the soldier doesn't idle
                requestCoverSearch(soldier.hasValidAttackTarget()
                    ? QueuedSearchMode.ATTACK_SELECTING : QueuedSearchMode.NORMAL);
            }
            return;
        }
        
        if (currentCover != null && isCoverFloorReached(targetCover) && targetCover.getPosition().equals(currentCover.getPosition())) {
            onCoverReached(targetCover);
            return;
        }

        ensureMovementAttemptTarget(targetCover);

        if (isReloadBlockedMove()) {
            // Reload hold: keep the current cover and pause reposition bookkeeping
            // (no re-path churn, no stuck accumulation) until the reload finishes.
            getPositionController().resetFailureState();
            return;
        }

        // Repositioning timeout: if we've been repositioning too long, abort.
        // Reload pauses return above, so a reload never burns the window. The
        // budget scales with the bound's length — a flat cap blacklists covers
        // mid-walk on long corridor bounds that are walking fine.
        repositioningTicks++;
        double timeoutBudget = 100 + Math.max(2, repositioningStartDist) * 30;
        if (repositioningTicks > timeoutBudget) {
            if (DiagnosticLogManager.isCoverLoggingEnabled()) {
                StevesArmyMod.LOGGER.info("[CoverNav] Soldier {} repositioning timeout after {} ticks, target={}",
                    soldier.getId(), repositioningTicks, targetCover != null ? targetCover.getPosition() : "null");
            }
            if (targetCover != null) {
                blacklistCover(targetCover.getPosition(), BlacklistReason.STUCK_REPOSITIONING);
            }
            noteSuppressionMoveAborted();
            getCoverManager().clearTargetCover();
            getPositionController().clear();
            if (currentCover != null) {
                getCoverManager().setState(CoverBehaviorManager.CoverState.IN_COVER);
            } else {
                getCoverManager().setState(CoverBehaviorManager.CoverState.SEEKING_COVER);
                requestCoverSearch(soldier.hasValidAttackTarget()
                    ? QueuedSearchMode.ATTACK_SELECTING : QueuedSearchMode.NORMAL);
            }
            repositioningTicks = 0;
            stuckTicks = 0;
            noProgressTicks = 0;
            lastSeekingPosition = null;
            return;
        }

        if (movementAttemptCount == 0) {
            moveToCover(targetCover);
            return;
        }

        CoverPositionController moveControl = getPositionController();
        CoverPositionController.MovementResult moveResult = moveControl.getLastResult();
        Vec3 standingPos = getCoverStandingPosition(targetCover.getPosition());
        double horizontalDist = Math.sqrt(
            Math.pow(soldier.position().x - standingPos.x, 2) +
            Math.pow(soldier.position().z - standingPos.z, 2));

        // 1. Position controller reached the target or soldier is already at standing pos
        if (isCoverFloorReached(targetCover) && (moveResult == CoverPositionController.MovementResult.REACHED_TARGET
            || horizontalDist < POSITIONING_TOLERANCE)) {
            onCoverReached(targetCover);
            noProgressTicks = 0;
            lastSeekingPosition = null;
            return;
        }

        // 2. Position controller is still working — wait
        if (moveResult == CoverPositionController.MovementResult.IN_PROGRESS) {
            return;
        }

        // 3. Position controller failed — geometry rejections blacklist the cover
        // instead of re-attempting the same blocked approach every tick.
        if (moveResult == CoverPositionController.MovementResult.FAILED) {
            CoverPositionController.FailureReason failReason = moveControl.getLastFailureReason();
            if (failReason == CoverPositionController.FailureReason.HAZARD
                || failReason == CoverPositionController.FailureReason.BLOCKED_PATH
                || failReason == CoverPositionController.FailureReason.NO_PROGRESS) {
                // The velocity handoff can reject a spot the soldier is
                // effectively standing on: the destination sweep clips the
                // cover block's own collision, or the approach grinds to a
                // halt against it. Within the arrival distance the goal
                // already accepts below, treat it as arrived — onCoverReached
                // still re-validates suppression lanes from the real eye.
                if (isCoverFloorReached(targetCover) && horizontalDist < COVER_REACHED_DISTANCE) {
                    onCoverReached(targetCover);
                    noProgressTicks = 0;
                    lastSeekingPosition = null;
                    return;
                }
                if (soldier.hasValidAttackTarget()) {
                    StevesArmyMod.LOGGER.info("[CoverNav] Soldier {} ({}) reposition blocked (reason={}) for cover={}, blacklisting",
                        soldier.getId(), soldier.getName().getString(), failReason, targetCover.getPosition());
                }
                blacklistCover(targetCover.getPosition(), BlacklistReason.POSITIONING_BLOCKED);
                noteSuppressionMoveAborted();
                stuckTicks = 0;
                noProgressTicks = 0;
                lastSeekingPosition = null;
                if (getCoverManager().getCurrentCover() != null) {
                    getCoverManager().setState(CoverBehaviorManager.CoverState.IN_COVER);
                }
                return;
            }
            if (soldier.hasValidAttackTarget()) {
                StevesArmyMod.LOGGER.info("[CoverNav] Soldier {} ({}) reposition controller FAILED (reason={}) for cover={}, retrying nav",
                    soldier.getId(), soldier.getName().getString(), moveControl.getLastFailureReason(), targetCover.getPosition());
            }
            moveControl.clear();
            navigation.stop();
            moveToCover(targetCover);
            return;
        }
        
        if (isCoverFloorReached(targetCover) && horizontalDist < COVER_REACHED_DISTANCE) {
            onCoverReached(targetCover);
            noProgressTicks = 0;
            lastSeekingPosition = null;
            return;
        }
        
        // Handoff to position controller when close to standing position
        if (isCoverFloorReached(targetCover) && horizontalDist < COVER_VALID_DISTANCE) {
            if (soldier.hasValidAttackTarget()) {
                StevesArmyMod.LOGGER.info("[CoverNav] Soldier {} ({}) reposition handoff to position controller at hDist={} cover={}",
                    soldier.getId(), soldier.getName().getString(), String.format("%.2f", horizontalDist), targetCover.getPosition());
            }
            navigation.stop();
            moveControl.moveTo(standingPos, POSITIONING_TOLERANCE,
                activeSuppressionRouteMovement == RouteMovement.CRAWL ? CRAWL_ROUTE_SPEED : POSITIONING_SPEED,
                "tickRepositioning", "recenter to target cover");
            if (moveControl.getLastResult() == CoverPositionController.MovementResult.FAILED) {
                CoverPositionController.FailureReason handoffFailReason = moveControl.getLastFailureReason();
                if (isReloadBlockedMove()
                    || handoffFailReason == CoverPositionController.FailureReason.RELOAD_INTERRUPTED) {
                    // Reload hold, not a cover problem: wait for the reload.
                    return;
                }
                // Navigation is already stopped. Retry the final stretch via
                // navigation before blacklisting a cover the pathfinder reached.
                moveControl.resetFailureState();
                if (!moveToCover(targetCover) && pendingRetryCover == null && !isReloadBlockedMove()) {
                    // The pathfinder delivered the soldier to the cover; a
                    // rejected final alignment within arrival distance is an
                    // arrival, not a bad cover.
                    if (isCoverFloorReached(targetCover) && horizontalDist < COVER_REACHED_DISTANCE) {
                        onCoverReached(targetCover);
                        noProgressTicks = 0;
                        lastSeekingPosition = null;
                        return;
                    }
                    if (DiagnosticLogManager.isCoverLoggingEnabled()) {
                        StevesArmyMod.LOGGER.info("[CoverGoal] Soldier {} reposition handoff rejected (reason={}) for cover={}, blacklisting",
                            soldier.getId(), handoffFailReason, targetCover.getPosition());
                    }
                    blacklistCover(targetCover.getPosition(), BlacklistReason.POSITIONING_BLOCKED);
                    noteSuppressionMoveAborted();
                    stuckTicks = 0;
                    noProgressTicks = 0;
                    lastSeekingPosition = null;
                    if (getCoverManager().getCurrentCover() != null) {
                        getCoverManager().setState(CoverBehaviorManager.CoverState.IN_COVER);
                    }
                }
                return;
            }
        }

        // Normal navigation-driven approach
        Vec3 currentPos = soldier.position();
        tryOpenDoorOnPath();

        if (navigation.isDone()) {
            if (relocationType != RelocationType.NONE) {
                // A staged path has ended. Recalculate immediately: the next route
                // may now be short enough to require exact cover validation.
                // (Parity with tickSeekingCover — without this, every leg end
                // past the single retry idled stuckTicks toward blacklisting a
                // cover the march was walking to just fine.)
                moveToCover(targetCover);
                stuckTicks = 0;
                noProgressTicks = 0;
                lastSeekingPosition = currentPos;
                return;
            }
            if (movementAttemptCount == 1) {
                if (DiagnosticLogManager.isCoverLoggingEnabled()) {
                    StevesArmyMod.LOGGER.info("[CoverNav] Soldier {} retrying cover path after it ended before arrival: target={}",
                        soldier.getId(), targetCover.getPosition());
                }
                moveToCover(targetCover);
                stuckTicks = 0;
                return;
            }
            stuckTicks++;
            noProgressTicks = 0;
            lastSeekingPosition = null;
            if (stuckTicks > MAX_STUCK_TICKS) {
                if (targetCover != null) {
                    blacklistCover(targetCover.getPosition(), BlacklistReason.STUCK_REPOSITIONING);
                }
                getCoverManager().clearTargetCover();
                if (currentCover != null) {
                    getCoverManager().setState(CoverBehaviorManager.CoverState.IN_COVER);
                } else {
                    getCoverManager().setState(CoverBehaviorManager.CoverState.SEEKING_COVER);
                    // Immediately request a search so the soldier doesn't idle
                    requestCoverSearch(soldier.hasValidAttackTarget()
                        ? QueuedSearchMode.ATTACK_SELECTING : QueuedSearchMode.NORMAL);
                }
                stuckTicks = 0;
            }
        } else {
            stuckTicks = 0;

            if (lastSeekingPosition != null) {
                double moved = currentPos.distanceTo(lastSeekingPosition);
                if (moved < 0.1) {
                    noProgressTicks++;
                    if (noProgressTicks > 40) {
                        // An accepted path that moves the soldier nowhere is a
                        // dead bound: one re-issue gives the pathfinder a second
                        // chance, a third stall condemns the cover. Without this
                        // escalation the re-issue loop resets its own counter
                        // forever and the soldier stands at the old cover
                        // "moving" to the new one until something else interrupts.
                        noProgressTicks = 0;
                        lastSeekingPosition = currentPos;
                        int stalledReissues = ++noProgressReissues;
                        if (stalledReissues >= 2) {
                            noProgressReissues = 0;
                            if (DiagnosticLogManager.isCoverLoggingEnabled()) {
                                StevesArmyMod.LOGGER.info("[CoverGoal] Soldier {} cover {} unreachable ({} stalled re-issues), blacklisting and researching",
                                    soldier.getId(), targetCover.getPosition(), stalledReissues);
                            }
                            blacklistCover(targetCover.getPosition(), BlacklistReason.POSITIONING_BLOCKED);
                            noteSuppressionMoveAborted();
                            stuckTicks = 0;
                            getCoverManager().clearTargetCover();
                            if (getCoverManager().getCurrentCover() != null) {
                                getCoverManager().setState(CoverBehaviorManager.CoverState.IN_COVER);
                            } else {
                                getCoverManager().setState(CoverBehaviorManager.CoverState.SEEKING_COVER);
                                requestCoverSearch(soldier.hasValidAttackTarget()
                                    ? QueuedSearchMode.ATTACK_SELECTING : QueuedSearchMode.NORMAL);
                            }
                        } else {
                            if (DiagnosticLogManager.isCoverLoggingEnabled()) {
                                StevesArmyMod.LOGGER.info("[CoverGoal] Soldier {} not progressing toward target cover ({} ticks, moved {}), retrying navigation",
                                    soldier.getId(), noProgressTicks, String.format("%.2f", moved));
                            }
                            navigation.stop();
                            moveToCover(targetCover);
                        }
                    }
                } else {
                    noProgressTicks = 0;
                    noProgressReissues = 0;
                    lastSeekingPosition = currentPos;
                }
            } else {
                lastSeekingPosition = currentPos;
            }
        }
    }

    private void tickProneFiringMovement() {
        Vec3 destination = Vec3.atBottomCenterOf(proneFiringDestination);
        if (soldier.position().distanceToSqr(destination) <= POSITIONING_TOLERANCE * POSITIONING_TOLERANCE) {
            navigation.stop();
            if (buildSquadCoverContext().violatesDefensiveSpacing(soldier.position())) {
                proneFiringController.cancel("lane_spacing_conflict");
                proneFiringDestination = null;
                getCoverManager().setState(CoverBehaviorManager.CoverState.SEEKING_COVER);
                requestCoverSearch(soldier.hasValidAttackTarget()
                    ? QueuedSearchMode.ATTACK_SELECTING : QueuedSearchMode.NORMAL);
                if (DiagnosticLogManager.isCoverLoggingEnabled()) {
                    StevesArmyMod.LOGGER.info("[DefensivePosition] Soldier {} rejected arrived prone lane for spacing conflict",
                        soldier.getId());
                }
                return;
            }
            getPositionController().clear();
            getCoverManager().setState(CoverBehaviorManager.CoverState.NO_COVER);
            proneFiringController.onReached();
            if (DiagnosticLogManager.isCoverLoggingEnabled()) {
                StevesArmyMod.LOGGER.info("[DefensivePosition] Soldier {} reached prone lane {}", soldier.getId(), proneFiringDestination);
            }
            proneFiringDestination = null;
            return;
        }
        if (navigation.isDone() && soldier.position().distanceToSqr(destination) < 2.25D) {
            getPositionController().moveTo(destination, POSITIONING_TOLERANCE, POSITIONING_SPEED,
                "prone-lane", "finish spaced prone positioning");
            return;
        }
        if (navigation.isDone()) {
            proneFiringController.cancel("path_failed");
            proneFiringDestination = null;
            getCoverManager().setState(CoverBehaviorManager.CoverState.SEEKING_COVER);
        }
    }

    private void tickProneFiringPlan() {
        if (proneFiringController.isPlanActive() && soldier.hasValidPingMoveTarget()) {
            cancelProneFiringPlan();
            getPositionController().clear();
            return;
        }
        if (proneFiringDestination == null) {
            if (proneFiringController.isPlanActive()
                && buildSquadCoverContext().violatesDefensiveSpacing(soldier.position())) {
                cancelProneFiringPlan();
                getCoverManager().setState(CoverBehaviorManager.CoverState.SEEKING_COVER);
                requestCoverSearch(QueuedSearchMode.NORMAL);
                return;
            }
            proneFiringController.tick(soldier.getTarget());
        }
    }
    
    private void tickInCover() {
        CoverPoint currentCover = getCoverManager().getCurrentCover();
        if (soldier.isPreparingOrReloading()) {
            holdForReload(currentCover);
            return;
        }

        if (currentCover != null && currentCover.getType() == CoverType.HALF
            && soldier.isLowCrouching() && !getCoverManager().isSuppressed()
            && !healingPosturePending && !soldier.isPeekDisabled()) {
            getPeekController().recoverStandingInHalfCover(soldier, "unsuppressed-fallback");
        }

        if (currentCover != null) {
            Vec3 standingPos = getCoverStandingPosition(currentCover.getPosition());
            double distance = soldier.position().distanceTo(currentCover.getPosition().getCenter());
            double standingDist = soldier.position().distanceTo(standingPos);
            PeekController peekCtrl = getPeekController();
            boolean peeking = peekCtrl.isExposed() || peekCtrl.isMovingToPeek() || peekCtrl.isReturning();
            if (DiagnosticLogManager.isCoverLoggingEnabled()) {
                tickLogCounter++;
                if (tickLogCounter >= SNAPSHOT_INTERVAL) {
                    tickLogCounter = 0;
                    StevesArmyMod.LOGGER.info("[CoverGoal] Soldier {} tickInCover: dist={}, standingDist={}, abandon={}, valid={}, peeking={}, target={}",
                        soldier.getId(), String.format("%.2f", distance), String.format("%.2f", standingDist),
                        distance > COVER_ABANDON_DISTANCE,
                        standingDist > COVER_VALID_DISTANCE,
                        peeking,
                        (soldier.getTarget() != null ? soldier.getTarget().getName().getString() : "null"));
                }
            }
            if (distance > COVER_ABANDON_DISTANCE) {
                if (suppressedDockHoldActive()) {
                    // Pinned: drift must not strip the dock. Keep the claim,
                    // stop the steering, and duck via the suppressed hold until
                    // recovery re-validates the claim exactly as before.
                    if (DiagnosticLogManager.isCoverLoggingEnabled()) {
                        StevesArmyMod.LOGGER.info("[CoverTacticalGoal] Soldier {} drifted from cover ({} > {}) while pinned, holding",
                            soldier.getId(), String.format("%.1f", distance), COVER_ABANDON_DISTANCE);
                    }
                    getPositionController().clear();
                    holdSuppressedAtDock(currentCover);
                    return;
                }
                if (DiagnosticLogManager.isCoverLoggingEnabled()) {
                    StevesArmyMod.LOGGER.info("[CoverTacticalGoal] Soldier {} drifted too far from cover ({} > {}), abandoning",
                        soldier.getId(), String.format("%.1f", distance), COVER_ABANDON_DISTANCE);
                }
                getCoverManager().clearCover();
                getPositionController().clear();
                return;
            }
            if (standingDist > COVER_VALID_DISTANCE && !peeking) {
                if (suppressedDockHoldActive()) {
                    // Pinned: a push-off does not re-seek while under fire —
                    // hold the claim (ducked) until recovery.
                    if (DiagnosticLogManager.isCoverLoggingEnabled()) {
                        StevesArmyMod.LOGGER.info("[CoverTacticalGoal] Soldier {} pushed from cover standing pos ({} > {}) while pinned, holding",
                            soldier.getId(), String.format("%.1f", standingDist), COVER_VALID_DISTANCE);
                    }
                    getPositionController().clear();
                    holdSuppressedAtDock(currentCover);
                    return;
                }
                if (DiagnosticLogManager.isCoverLoggingEnabled()) {
                    StevesArmyMod.LOGGER.info("[CoverTacticalGoal] Soldier {} got pushed from cover standing pos ({} > {}), re-seeking",
                        soldier.getId(), String.format("%.1f", standingDist), COVER_VALID_DISTANCE);
                }
                getCoverManager().clearCover();
                getCoverManager().setState(CoverBehaviorManager.CoverState.SEEKING_COVER);
                getPositionController().clear();
                return;
            }

            // Recenter to cover when idle
            CoverPositionController.MovementResult recenterResult = getPositionController().getLastResult();
            if (!peeking && recenterResult != CoverPositionController.MovementResult.IN_PROGRESS) {
                if (recenterResult == CoverPositionController.MovementResult.FAILED) {
                    if (suppressedDockHoldActive()) {
                        // Pinned: no blacklist (the dock must stay eligible for
                        // the post-recovery evaluation) and no re-seek — stop
                        // the failed steering and hold.
                        if (DiagnosticLogManager.isCoverLoggingEnabled()) {
                            StevesArmyMod.LOGGER.info("[CoverGoal] Soldier {} tickInCover recenter FAILED (reason={}) while pinned, holding",
                                soldier.getId(), getPositionController().getLastFailureReason(), currentCover.getPosition());
                        }
                        getPositionController().clear();
                        holdSuppressedAtDock(currentCover);
                        return;
                    }
                    CoverPositionController.FailureReason failReason = getPositionController().getLastFailureReason();
                    if (DiagnosticLogManager.isCoverLoggingEnabled()) {
                        StevesArmyMod.LOGGER.info("[CoverGoal] Soldier {} tickInCover recenter FAILED (reason={}) for cover={}, blacklisting and re-seeking",
                            soldier.getId(), failReason, currentCover.getPosition());
                    }
                    blacklistCover(currentCover.getPosition(), BlacklistReason.POSITIONING_BLOCKED);
                    getPositionController().clear();
                    getCoverManager().clearCover();
                    getCoverManager().setState(CoverBehaviorManager.CoverState.SEEKING_COVER);
                    return;
                }
                if (!getPositionController().isWithinCoverAnchorDeadzone(standingPos)) {
                    navigation.stop();
                    getPositionController().moveTo(getCoverStandingPosition(currentCover.getPosition()), POSITIONING_TOLERANCE, POSITIONING_SPEED, "tickInCover", "recenter to cover");
                }
            }
// Renew current cover reservation every 5 seconds so it doesn't expire
            // while the soldier is still occupying it
            if (soldier.tickCount % 100 == 0) {
                CoverReservationManager.reserve(currentCover.getPosition(), soldier);
            }
        }

// Flank detection (skip during ATTACK — attack phase owns movement decisions)
        if (!soldier.hasValidAttackTarget()) {
            Optional<CoverPoint> flankCover = shouldRepositionForFlank();
            if (flankCover.isPresent()) {
                if (DiagnosticLogManager.isCoverLoggingEnabled()) {
                    StevesArmyMod.LOGGER.info("[CoverGoal] Soldier {} flanked, repositioning to {}",
                        soldier.getId(), flankCover.get().getPosition());
                }
                lastFlankRepositionTime = GameClock.nowMs();
                startRepositioning(flankCover.get());
                return;
            }
        }

// Suppression transition must run BEFORE pending reposition requests,
        // so that a suppressed soldier immediately gets the correct posture
        // and state transition even if a reposition request is pending.
        if (getCoverManager().isSuppressed()) {
            // The continuous-suppression emergency channel is designed to run
            // while pinned — a pinged soldier under fire is exactly who needs
            // a new lane. Convert the request here; the routine (suppression-
            // unsafe) request types stay behind the recovery gate below.
            if (getCoverManager().isContinuousSuppressionRepositionRequested()
                && soldier.tickCount >= nextSuppressionRouteSearchTick) {
                requestEmergencySearch(QueuedSearchMode.CONTINUOUS_SUPPRESSION);
            }
            soldier.tracePeek("cover-suppression", "tickInCover transition");
            enforceSuppressedHalfCoverPosture(currentCover);
            if (getPeekController().isExposed() && !soldier.hasEmergencyEngagementPosture()) {
                getPeekController().tick(soldier, currentCover, getPositionController());
            } else if (getPeekController().isExposed()) {
                soldier.tracePeek("suppression-override", "reason=emergency-engagement blocks exposed tick");
            }
            getCoverManager().setState(CoverBehaviorManager.CoverState.SUPPRESSED_IN_COVER);
            if (currentCover != null && currentCover.getType() == CoverType.HALF
                && getPeekController().isStandingInHalfCover()) {
                getPeekController().enterHiding(soldier);
            }
            return;
        }

        // Process pending reposition requests. A compromised-cover request may move
        // immediately; routine requests still wait for full suppression recovery.
        PendingRepositionResult requestResult = processPendingRepositionRequests();
        if (requestResult == PendingRepositionResult.MOVEMENT_STARTED) {
            return;
        }
        // BLOCKED: fall through to allow peek/external evaluation

        if (shouldExitCoverForFollow()) {
            getCoverManager().resetPeekState();
            getPositionController().clear();
            getCoverManager().clearCover();
            return;
        }

        // Delegate peek to PeekController
        if (currentCover != null) {
            if (tryStartHealing(currentCover)) {
                return;
            }
            if (!soldier.isPeekDisabled()) {
                getPeekController().tick(soldier, currentCover, getPositionController());
            }
            maintainCoverAnchorIfHiding(currentCover);
        }

        reevaluateCounter++;
        if (reevaluateCounter >= REEVALUATE_INTERVAL_TICKS) {
            reevaluateCounter = 0;
            evaluateCoverState();
        }
    }

    private void holdForReload(CoverPoint currentCover) {
        if (currentCover == null) {
            // A soldier is not protected until a cover point is physically
            // reached. Never enter the prone pose while reloading in the open.
            soldier.setLowCrouching(false);
            soldier.holdMovementForReload();
            return;
        }

        PeekController peekCtrl = getPeekController();
        if (peekCtrl.isExposed() || peekCtrl.isMovingToPeek()) {
            peekCtrl.forceReturnToCoverDuringReload(soldier, currentCover, getPositionController());
        }

        if (peekCtrl.isReturning()) {
            peekCtrl.forceReturnToCoverDuringReload(soldier, currentCover, getPositionController());
            peekCtrl.tick(soldier, currentCover, getPositionController());
        }

        if (currentCover.getType() == CoverType.HALF) {
            soldier.clearEmergencyEngagementPosture();
            soldier.setLowCrouching(true);
            peekCtrl.enterHiding(soldier);
        } else {
            soldier.setLowCrouching(soldier.isFiringProne());
        }

        // A reload that starts during the claim→dock transit must not strand
        // the soldier crouched outside its cover cell for the whole reload:
        // the anchor finishes the alignment under the same exception as the
        // approach (maintainCoverAnchor arms it via isFinishingCoverDockDuringReload).
        getPositionController().maintainCoverAnchor(getCoverStandingPosition(currentCover.getPosition()));

        soldier.holdMovementForReload();
    }

    private void resumeMovementAfterReload() {
        CoverBehaviorManager.CoverState state = getCoverManager().getState();
        if (state != CoverBehaviorManager.CoverState.SEEKING_COVER &&
            state != CoverBehaviorManager.CoverState.REPOSITIONING) {
            return;
        }

        soldier.setLowCrouching(false);
        CoverPoint targetCover = getCoverManager().getTargetCover();
        if (targetCover != null) {
            moveToCover(targetCover);
        }
    }

    private void continueCoverMovementDuringReload(CoverBehaviorManager.CoverState state) {
        // Keep the approach upright. Firing-prone posture is only valid after
        // onCoverReached() has promoted the target to current cover.
        soldier.setLowCrouching(false);
        if (DiagnosticLogManager.isCoverLoggingEnabled() && reloadMovementLogCooldown-- <= 0) {
            reloadMovementLogCooldown = 20;
            CoverPoint targetCover = getCoverManager().getTargetCover();
            StevesArmyMod.LOGGER.info("[ReloadCover] Soldier {} continuing {} during reload, target={}",
                soldier.getId(), state, targetCover != null ? targetCover.getPosition() : "searching");
        }
    }
    
    private void tickSuppressedInCover() {
        CoverBehaviorManager coverManager = getCoverManager();
        CoverPoint currentCover = getCoverManager().getCurrentCover();

        enforceSuppressedHalfCoverPosture(currentCover);

        // Concealment stops line of sight, not bullets: a suppressed soldier
        // HIDING at a concealment dock keeps the lowest profile too. The
        // half-cover enforcement above ignores the type, and a standing hold
        // there left body rays visible to the threat through the whole
        // suppression run (mg_suppression_round_robin). Pinned soldiers duck
        // unconditionally; PRESSURED ones keep the pressured-peek machinery
        // below in charge unless already hiding.
        if (currentCover != null
            && currentCover.getType() == CoverType.CONCEALMENT
            && getPeekController().isHiding()
            && (coverManager.isPinned()
                || (coverManager.isSuppressed() && !soldier.hasEmergencyEngagementPosture()))) {
            if (coverManager.isPinned()) {
                soldier.clearEmergencyEngagementPosture();
            }
            soldier.setLowCrouching(true);
        }

        // A hit while hidden means this cover is compromised. Unlike routine cover
        // changes, this relocation may start while suppressed.
        if (processPendingRepositionRequests() == PendingRepositionResult.MOVEMENT_STARTED) {
            return;
        }

        if (!coverManager.isSuppressed()) {
            if (currentCover != null && currentCover.getType() == CoverType.HALF) {
                getPeekController().recoverStandingInHalfCover(soldier, "suppression-recovery");
            }
            coverManager.setState(CoverBehaviorManager.CoverState.IN_COVER);
            return;
        }

        // Force duck-back if soldier was exposed or moving to peek when suppressed.
        // Pinned duck-back has no exceptions: an emergency-engagement window must
        // never keep a pinned soldier standing above a half-cover wall.
        PeekController peekCtrl = getPeekController();
        if (coverManager.isPinned()
            && (peekCtrl.isExposed() || peekCtrl.isMovingToPeek())) {
            soldier.tracePeek("pinned-return", "action=force-return");
            peekCtrl.forceReturnToCover(soldier, currentCover, getPositionController());
        }

        // Let peek controller handle ongoing duck back
        if (peekCtrl.isReturning()) {
            peekCtrl.tick(soldier, currentCover, getPositionController());
        }

        maintainCoverAnchorIfHiding(currentCover);

        // Compromised-cover check while suppressed: if the threat has crossed
        // to the blocker's own side, this cover no longer shields and escape
        // outranks recovery. isExposedToFlank's own cooldown bounds the check;
        // the continuous-suppression channel may start relocation while
        // suppressed, which is exactly the point.
        if (currentCover != null && isExposedToFlank()) {
            coverManager.requestContinuousSuppressionReposition();
        }

        if (currentCover != null && tryStartHealing(currentCover)) {
            return;
        }

        if (!coverManager.isPinned() && peekCtrl.isHiding() && !soldier.isPeekDisabled()) {
            boolean allowPressuredPeek = shouldAllowPressuredPeek();
            if (currentCover != null && currentCover.getType() == CoverType.HALF) {
                soldier.setLowCrouching(!allowPressuredPeek);
            }
            peekCtrl.tick(soldier, currentCover, getPositionController(), allowPressuredPeek);
        } else if (!coverManager.isPinned() && peekCtrl.isReturning()) {
            peekCtrl.tick(soldier, currentCover, getPositionController());
        }
    }

    private boolean canContinueHealingInCover() {
        CoverBehaviorManager.CoverState state = getCoverManager().getState();
        if (state != CoverBehaviorManager.CoverState.IN_COVER
            && state != CoverBehaviorManager.CoverState.SUPPRESSED_IN_COVER) {
            return false;
        }

        CoverPoint currentCover = getCoverManager().getCurrentCover();
        if (currentCover == null || !getCoverManager().isInCover()) return false;
        if (!soldier.getHealController().canContinue()) return false;
        if (!isHealingPosture(currentCover)) return false;
        if (relocationType != RelocationType.NONE || hasPendingCoverReposition()) return false;
        if (!isCoverStillValid()) return false;
        return isCoverAnchorSettled(currentCover);
    }

    private boolean tryStartHealing(CoverPoint currentCover) {
        if (!canAttemptHealingInCover(currentCover)) {
            healingPosturePending = false;
            return false;
        }

        // Eligibility must be checked before changing half-cover posture. An
        // available item alone must not keep a healthy soldier hidden forever.
        if (!soldier.getHealController().canStart()) {
            healingPosturePending = false;
            return false;
        }

        PeekController peekController = getPeekController();
        if (currentCover.getType() == CoverType.HALF && peekController.isStandingInHalfCover()) {
            soldier.clearEmergencyEngagementPosture();
            soldier.setLowCrouching(true);
            peekController.enterHiding(soldier);
            healingPosturePending = true;
            return true;
        }

        if (!peekController.isHiding()) {
            healingPosturePending = false;
            return false;
        }
        if (currentCover.getType() == CoverType.HALF && !soldier.isLowCrouching()) {
            soldier.setLowCrouching(true);
            healingPosturePending = true;
            return true;
        }

        healingPosturePending = false;
        return soldier.getHealController().start();
    }

    private boolean canAttemptHealingInCover(CoverPoint currentCover) {
        CoverBehaviorManager.CoverState state = getCoverManager().getState();
        if (state != CoverBehaviorManager.CoverState.IN_COVER
            && state != CoverBehaviorManager.CoverState.SUPPRESSED_IN_COVER) {
            return false;
        }
        if (currentCover == null || !getCoverManager().isInCover()) return false;
        if (relocationType != RelocationType.NONE || hasPendingCoverReposition()) return false;
        if (!isCoverStillValid() || !isCoverAnchorSettled(currentCover)) return false;
        PeekController.State peekState = getPeekController().getState();
        return peekState == PeekController.State.HIDING
            || (currentCover.getType() == CoverType.HALF
                && peekState == PeekController.State.STANDING_IN_HALF_COVER);
    }

    private boolean isHealingPosture(CoverPoint currentCover) {
        if (!getPeekController().isHiding()) return false;
        return currentCover.getType() != CoverType.HALF || soldier.isLowCrouching();
    }

    private boolean isCoverAnchorSettled(CoverPoint currentCover) {
        if (getPositionController().getLastResult() == CoverPositionController.MovementResult.IN_PROGRESS) {
            return false;
        }
        return getPositionController().isWithinCoverAnchorDeadzone(
            getCoverStandingPosition(currentCover.getPosition()));
    }

    private boolean hasPendingCoverReposition() {
        CoverBehaviorManager manager = getCoverManager();
        return manager.isRepositionRequested()
            || manager.isShotInCoverRepositionRequested()
            || manager.isContinuousSuppressionRepositionRequested();
    }

    /**
     * Keeps the defensive low-crouch authoritative for a suppressed soldier at
     * half cover. PINNED suppression always ducks — no engagement posture or
     * active peek may keep a pinned soldier standing above the wall. PRESSURED
     * soldiers may continue an actively progressing peek, but a peek that
     * stalls exposed for the whole grace window is folded back into cover.
     */
    private void enforceSuppressedHalfCoverPosture(CoverPoint currentCover) {
        if (currentCover == null || currentCover.getType() != CoverType.HALF) {
            return;
        }
        if (!getCoverManager().isSuppressed()) {
            pressuredPeekStallStartTick = -1;
            return;
        }

        PeekController peekController = getPeekController();

        if (getCoverManager().isPinned()) {
            pressuredPeekStallStartTick = -1;
            soldier.clearEmergencyEngagementPosture();
            soldier.setLowCrouching(true);
            if (!peekController.isIdleInCover() && !peekController.isReturning()) {
                soldier.tracePeek("pinned-return", "action=force-return");
                peekController.forceReturnToCover(soldier, currentCover, getPositionController());
            }
            if (peekController.isStandingInHalfCover()) {
                peekController.enterHiding(soldier);
            }
            return;
        }

        if (soldier.hasEmergencyEngagementPosture()) {
            pressuredPeekStallStartTick = -1;
            soldier.tracePeek("suppression-override", "reason=emergency-engagement blocks low-crouch");
            return;
        }

        if (peekController.isExposed() || peekController.isMovingToPeek()) {
            if (pressuredPeekStallStartTick < 0) {
                pressuredPeekStallStartTick = soldier.tickCount;
            }
            if (soldier.tickCount - pressuredPeekStallStartTick < PRESSURED_PEEK_STALL_GRACE_TICKS) {
                return;
            }
            pressuredPeekStallStartTick = -1;
            soldier.tracePeek("suppression-override", "reason=stalled-pressured-peek returns to cover");
            peekController.forceReturnToCover(soldier, currentCover, getPositionController());
        } else {
            pressuredPeekStallStartTick = -1;
        }

        soldier.setLowCrouching(true);
        if (peekController.isStandingInHalfCover()) {
            peekController.enterHiding(soldier);
        }
    }

    private boolean shouldAllowPressuredPeek() {
        // A suppress ping is an explicit order to fire into the zone: peek
        // deterministically instead of gambling on the pressured-peek roll.
        // Pinned soldiers never reach this call (the caller excludes them).
        if (soldier.hasValidPingSuppressPos()) {
            return true;
        }
        float ftLevel = FireTeamSuppressionTracker.getLevel(soldier);
        if (ftLevel >= StevesArmyConfig.getFireteamPeekBlockThreshold()) {
            if (DiagnosticLogManager.isCoverLoggingEnabled()) {
                StevesArmyMod.LOGGER.info("[SuppressionPeek] Soldier {} fireteam blocked peek: ftLevel={}",
                    soldier.getId(), String.format("%.2f", ftLevel));
            }
            return false;
        }
        if (soldier.tickCount < nextPressuredPeekDecisionTick) {
            return false;
        }
        nextPressuredPeekDecisionTick = soldier.tickCount + PRESSURED_PEEK_DECISION_INTERVAL_TICKS;

        float suppression = getCoverManager().getSuppressionTracker().getSuppressionLevel();
        float recovery = Math.max(0.0f, Math.min(1.0f, (0.90f - suppression) / 0.40f));
        int nearbyPeekers = countNearbyPeekers();
        float baseChance = calculatePressuredPeekChance(suppression, nearbyPeekers);
        float chance = baseChance * (1.0f - ftLevel * 0.8f);
        float roll = soldier.getRandom().nextFloat();
        boolean allowed = roll < chance;

        if (DiagnosticLogManager.isCoverLoggingEnabled()) {
            StevesArmyMod.LOGGER.info("[SuppressionPeek] Soldier {} pressured peek: suppression={}, recovery={}, nearby={}, baseChance={}, ftLevel={}, chance={}, roll={}, allowed={}",
                soldier.getId(), String.format("%.2f", suppression), String.format("%.2f", recovery),
                nearbyPeekers, String.format("%.2f", baseChance), String.format("%.2f", ftLevel), String.format("%.2f", chance), String.format("%.2f", roll), allowed);
        }
        return allowed;
    }

    private int countNearbyPeekers() {
        if (!(soldier.level() instanceof ServerLevel serverLevel)) {
            return 0;
        }

        UUID squadId = soldier.getSquadId();
        if (squadId == null) {
            return 0;
        }

        double radiusSqr = PRESSURED_PEEK_RADIUS * PRESSURED_PEEK_RADIUS;
        return (int) SquadManager.get(serverLevel)
            .getSquadMembers(serverLevel, squadId, soldier.getUUID()).stream()
            .filter(SoldierEntity.class::isInstance)
            .map(SoldierEntity.class::cast)
            .filter(member -> member.isAlive() && member.distanceToSqr(soldier) <= radiusSqr)
            .filter(member -> {
                PeekController.State state = member.getPeekController().getState();
                return state == PeekController.State.MOVING_TO_PEEK
                    || state == PeekController.State.EXPOSED;
            })
            .count();
    }

    /**
     * Routine-reposition gate for P1 advances (non-peekable cover reposition,
     * normal forward pickups). P0 emergency moves (shot-in-cover, continuous
     * suppression, compromised cover) bypass this entirely and are handled
     * separately. Blocks (returns false) until:
     *   - the fireteam drops below HEAVY (if configured), and
     *   - a post-recovery safety peek is completed without a new suppression
     *     event (or the safety-peek timeout is reached), and
     *   - a nearby teammate is covering, or the covering wait times out.
     * Returning false keeps the request pending.
     */
    private boolean routineRepositionGateAllows() {

        // Fireteam HEAVY hold: keep routine requests pending while the team is
        // heavily suppressed so the unit does not scatter under heavy fire.
        if (StevesArmyConfig.isFireteamHeavyHoldReposition()
            && FireTeamSuppressionTracker.isHeavilySuppressed(soldier)) {
            return false;
        }

        // Peek-first: after suppression recovery, complete one safety peek that
        // is not re-suppressed before moving. Tracked here so it runs once per
        // routine reposition attempt.
        SuppressionTracker tr = getCoverManager().getSuppressionTracker();
        if (tr.isSuppressed()) {
            return false;
        }
        if (!recoverySafetyPeekDone) {
            if (!recoverySafetyPeekInProgress) {
                recoverySafetyPeekInProgress = true;
                recoverySafetyPeekStartMs = GameClock.nowMs();
                recoverySafetyPeekSeqSnapshot = tr.getSuppressionEventSequence();
            }
            // Suppressed during the peek -> peek was unsafe; reset and retry later.
            if (tr.getSuppressionEventSequence() != recoverySafetyPeekSeqSnapshot
                && tr.isRecovered()) {
                recoverySafetyPeekInProgress = false;
                return false;
            }
            long elapsed = GameClock.nowMs() - recoverySafetyPeekStartMs;
            if (elapsed < StevesArmyConfig.getRecoverySafetyPeekMs()) {
                return false;
            }
            recoverySafetyPeekDone = true;
            recoverySafetyPeekInProgress = false;
        }

        // Squad street-crossing doctrine: an overwatcher holds its routine
        // repositions while a teammate is mid-bound on the lane it covers
        // (the coordinator's own bound timeout prevents a permanent hold), and
        // a bounder without live covering fire waits out the soft cover
        // window before advancing anyway.
        if (StevesArmyConfig.isSquadBoundingEnabled()) {
            if (com.stevesarmy.squad.SquadMovementCoordinator.isOverwatching(soldier)) {
                return false;
            }
            if (com.stevesarmy.squad.SquadMovementCoordinator.awaitingCoveringFire(soldier)) {
                return false;
            }
        }

        // Soft covering-fire requirement: multiply move chance when no teammate
        // is covering; after a timeout, advance regardless so the squad does not
        // stall forever behind an inactive fireteam.
        return true;
    }

    /**
     * Multipler applied to routine-advance dwell to keep the squad cohesive:
     * far-ahead isolated soldiers wait for the fireteam to catch up; far-behind
     * soldiers catch up quickly.
     */
    private float groupCohesionDwellMult() {
        Vec3 centroid = FireTeamSuppressionTracker.getCentroid(soldier);
        if (centroid == null) {
            return 1.0f;
        }
        BlockPos objective = soldier.getAttackTargetPos();
        Vec3 objectiveDir;
        if (objective == null) {
            objectiveDir = null;
        } else {
            Vec3 soldierPos = soldier.position();
            double dx = objective.getX() + 0.5 - soldierPos.x;
            double dz = objective.getZ() + 0.5 - soldierPos.z;
            if (dx * dx + dz * dz <= 1e-4) {
                objectiveDir = null;
            } else {
                objectiveDir = new Vec3(dx, 0, dz).normalize();
            }
        }
        if (objectiveDir == null) {
            return 1.0f;
        }
        Vec3 toCentroid = centroid.subtract(soldier.position());
        double offset;
        try {
            offset = toCentroid.dot(objectiveDir);
        } catch (RuntimeException ex) {
            return 1.0f;
        }
        float band = StevesArmyConfig.getGroupCohesionBandBlocks();
        if (offset > band) {
            // Centroid is ahead → soldier is behind group → catch up quickly
            return StevesArmyConfig.getGroupBehindDwellMult();
        }
        if (offset < -band) {
            // Centroid is behind → soldier is ahead of group → wait for group
            return StevesArmyConfig.getGroupAheadDwellMult();
        }
        return 1.0f;
    }

    /** Clears the post-recovery safety-peek latch so the peek runs again. */
    private void resetRecoverySafetyPeek() {
        recoverySafetyPeekStartMs = 0L;
        recoverySafetyPeekSeqSnapshot = -1L;
        recoverySafetyPeekDone = false;
        recoverySafetyPeekInProgress = false;
    }

    /**
     * Consolidated handling of pending reposition requests (shot-in-cover, non-peekable).
     * Returns NONE, BLOCKED (still waiting, but allow other cover processing),
     * or MOVEMENT_STARTED (soldier is now repositioning).
     * Routine requests remain pending while suppressed; a compromised cover is an
     * emergency exception because remaining there has already failed.
     */
    private enum PendingRepositionResult { NONE, BLOCKED, MOVEMENT_STARTED }

    private PendingRepositionResult processPendingRepositionRequests() {
        CoverPoint currentCover = getCoverManager().getCurrentCover();

        // Shot-in-cover request
        if (getCoverManager().isShotInCoverRepositionRequested()) {
            if (soldier.tickCount < nextShotInCoverSearchTick) {
                return PendingRepositionResult.BLOCKED;
            }
            requestEmergencySearch(QueuedSearchMode.SHOT_IN_COVER);
            return PendingRepositionResult.BLOCKED;
        }

        // Continuous suppression is an emergency response. Unlike the normal
        // repeated-episode request, it may begin while the soldier is pinned.
        if (getCoverManager().isContinuousSuppressionRepositionRequested()) {
            if (soldier.tickCount < nextSuppressionRouteSearchTick) {
                return PendingRepositionResult.BLOCKED;
            }
            requestEmergencySearch(QueuedSearchMode.CONTINUOUS_SUPPRESSION);
            return PendingRepositionResult.BLOCKED;
        }

// Non-peekable cover reposition request (routine P1 advance: fireteam
        // HEAVY hold and post-recovery safety peek apply).
        if (getCoverManager().isRepositionRequested()) {
            if (!canLeaveCoverNow()) {
                return PendingRepositionResult.BLOCKED;
            }
            if (!routineRepositionGateAllows()) {
                return PendingRepositionResult.BLOCKED;
            }
            if (soldier.tickCount < nextSuppressionRouteSearchTick) {
                return PendingRepositionResult.BLOCKED;
            }
            requestEmergencySearch(QueuedSearchMode.SUPPRESSION_REPOSITION);
            return PendingRepositionResult.BLOCKED;
        }

        return PendingRepositionResult.NONE;
    }
    
    private boolean shouldSeekCover() {
        ThreatAwareness threats = getThreats();

        // An exposed-combat doctrine move (bounded sidestep, withdraw) owns the
        // legs until it lands or times out; re-seeking mid-nudge is churn.
        if (StevesArmyConfig.isExposedCombatEnabled()
            && relocationType == RelocationType.NONE
            && ExposedCombatController.hasActiveMove(soldier)) {
            lastWantCoverReason = "exposed-move";
            return false;
        }

        // After a failed seek round the exposed doctrine plant owns the soldier
        // for a stability window - attack-driven seeks included, or a coverless
        // fight churns seek rounds against terrain that has nothing to find.
        // Each new failed round re-arms the window.
        if (StevesArmyConfig.isExposedCombatEnabled()
            && relocationType == RelocationType.NONE
            && ExposedCombatController.plantHoldActive(soldier)) {
            lastWantCoverReason = "planted-after-failed-seek";
            return false;
        }

        if (relocationType != RelocationType.NONE) {
            lastWantCoverReason = "reloc";
            return true;
        }

        if (soldier.hasValidAttackTarget()) {
            if (DiagnosticLogManager.isCoverLoggingEnabled()) {
                StevesArmyMod.LOGGER.info("[CoverGoal] shouldSeekCover=true (ATTACK mode)");
            }
            lastWantCoverReason = "attack";
            return true;
        }

        if (soldier.isCQB() || soldier.hasCloseRangeTarget()) {
            // Close combat keeps protection reasoning - the closer the threat,
            // the more urgent cover becomes, not less. While the emergency
            // engagement hold is latched it owns the decision: stand and try
            // to produce fire first; cover seeking acts after the no-shot
            // release, so seeks never race a hold that is about to freeze
            // their moves.
            if (soldier.isCqbEngagementHold()) {
                lastWantCoverReason = "";
                return false;
            }
            boolean hasValid = getCoverManager().getCurrentCover() != null && isCoverStillValid();
            if (hasValid) {
                lastWantCoverReason = "";
                return false;
            }
            if (DiagnosticLogManager.isCoverLoggingEnabled()) {
                StevesArmyMod.LOGGER.info("[CoverGoal] shouldSeekCover=true (close combat, CQB mode={}, closeRangeTarget={})",
                    soldier.isCQB(), soldier.hasCloseRangeTarget());
            }
            lastWantCoverReason = "close-no-protection";
            return true;
        }

        if (soldier.getSquadMode() == SquadMode.HOLD) {
            // Suppressed-traveler doctrine: a soldier marching to a hold objective
            // beyond the hold radius keeps moving through pressure -
            // SoldierHoldPositionGoal re-routes around the squad map's shadow and
            // crawls stretches where crawling hides. Cover-seek resumes when pinned
            // or on arrival.
            if (StevesArmyConfig.isDangerTravelResponseEnabled()
                    && !getCoverManager().isPinned()
                    && SoldierHoldPositionGoal.isTravelingToObjective(soldier)) {
                lastWantCoverReason = "";
                return false;
            }
            boolean hasValid = getCoverManager().getCurrentCover() != null && isCoverStillValid();
            boolean result = !hasValid;
            if (DiagnosticLogManager.isCoverLoggingEnabled()) {
                StevesArmyMod.LOGGER.info("[CoverGoal] shouldSeekCover={} (HOLD mode, hasValidCover={})", result, hasValid);
            }
            lastWantCoverReason = result ? "hold-invalid" : "";
            return result;
        }

        if (soldier.getSquadMode() == SquadMode.FOLLOW) {
            boolean suppressed = getCoverManager().isSuppressed();
            float healthRatio = soldier.getHealth() / soldier.getMaxHealth();
            boolean lowHealth = healthRatio < LOW_HEALTH_THRESHOLD;

            LivingEntity owner = soldier.getOwner();
            boolean closeToOwner = owner != null &&
                soldier.distanceToSqr(owner) < FOLLOW_COVER_DISTANCE * FOLLOW_COVER_DISTANCE;

            boolean result;
            if (closeToOwner) {
                boolean hasThreat = threats.hasActiveThreat();
                result = (suppressed || lowHealth) || hasThreat;
                lastWantCoverReason = result ? joinSeekReasons(suppressed, lowHealth, hasThreat) : "";
                if (DiagnosticLogManager.isCoverLoggingEnabled()) {
                    StevesArmyMod.LOGGER.info("[CoverGoal] shouldSeekCover={} (FOLLOW close, suppressed={}, lowHealth={} health={}, hasThreat={})",
                        result, suppressed, lowHealth, String.format("%.2f", healthRatio), hasThreat);
                }
            } else {
                result = suppressed || lowHealth;
                lastWantCoverReason = result ? joinSeekReasons(suppressed, lowHealth, false) : "";
                if (DiagnosticLogManager.isCoverLoggingEnabled()) {
                    StevesArmyMod.LOGGER.info("[CoverGoal] shouldSeekCover={} (FOLLOW far, suppressed={}, lowHealth={} health={})",
                        result, suppressed, lowHealth, String.format("%.2f", healthRatio));
                }
            }
            return result;
        }

        boolean suppressed = getCoverManager().isSuppressed();
        float healthRatio = soldier.getHealth() / soldier.getMaxHealth();
        boolean lowHealth = healthRatio < LOW_HEALTH_THRESHOLD;
        boolean hasThreat = threats.hasActiveThreat();

        boolean result = (suppressed || lowHealth) || hasThreat;
        lastWantCoverReason = result ? joinSeekReasons(suppressed, lowHealth, hasThreat) : "";
        if (DiagnosticLogManager.isCoverLoggingEnabled()) {
            StevesArmyMod.LOGGER.info("[CoverGoal] shouldSeekCover={} (suppressed={}, lowHealth={} health={}, hasThreat={})",
                result, suppressed, lowHealth, String.format("%.2f", healthRatio), hasThreat);
        }
        return result;
    }

    /** Compact reason tags for the debug card, e.g. "supp,threat". */
    private static String joinSeekReasons(boolean suppressed, boolean lowHealth, boolean hasThreat) {
        StringBuilder reasons = new StringBuilder();
        if (suppressed) reasons.append("supp,");
        if (lowHealth) reasons.append("lowHP,");
        if (hasThreat) reasons.append("threat,");
        return reasons.length() == 0 ? "" : reasons.substring(0, reasons.length() - 1);
    }
    
    private boolean isCoverStillValid() {
        CoverPoint currentCover = getCoverManager().getCurrentCover();
        if (currentCover == null) return false;

        double distance = soldier.position().distanceTo(currentCover.getPosition().getCenter());
        if (distance > COVER_ABANDON_DISTANCE) return false;

        PeekController peekCtrl = getPeekController();
        boolean peeking = peekCtrl.isExposed() || peekCtrl.isMovingToPeek() || peekCtrl.isReturning();
        if (peeking) return true;

        if (getCoverManager().getTimeInCover() >= MIN_COVER_DWELL_TIME_MS) {
            double maxDistance = soldier.getTarget() != null ? COMBAT_COVER_VALID_DISTANCE : COVER_VALID_DISTANCE;
            if (distance > maxDistance) return false;
        }

        // FOLLOW mode: invalidate cover if player has moved too far away
        if (soldier.getSquadMode() == SquadMode.FOLLOW) {
            LivingEntity owner = soldier.getOwner();
            if (owner != null) {
                double distToOwner = currentCover.getPosition().distSqr(owner.blockPosition());
                if (distToOwner > followOwnerMaxDistanceSqr()) {
                    if (DiagnosticLogManager.isCoverLoggingEnabled()) {
                        StevesArmyMod.LOGGER.info("[CoverGoal] Cover invalid: too far from owner (dist={})",
                            String.format("%.1f", Math.sqrt(distToOwner)));
                    }
                    return false;
                }
            }
        }

        return true;
    }
    
    private void evaluateCoverState() {
        CoverPoint currentCover = getCoverManager().getCurrentCover();
        if (currentCover == null) {
            // A doctrine-owned exposed fight (plant window, bounded sidestep,
            // withdrawal) is deliberate exposed combat, not a seek: labelling
            // it SEEKING_COVER stalls the follow gate and reads as a seek
            // that never converges.
            if (StevesArmyConfig.isExposedCombatEnabled()
                && relocationType == RelocationType.NONE
                && (ExposedCombatController.hasActiveMove(soldier)
                    || ExposedCombatController.plantHoldActive(soldier))) {
                return;
            }
            getCoverManager().setState(CoverBehaviorManager.CoverState.SEEKING_COVER);
            return;
        }

        // Skip when peeking
        PeekController peekCtrl = getPeekController();
        boolean peeking = peekCtrl.isExposed() || peekCtrl.isMovingToPeek() || peekCtrl.isReturning();
        if (peeking) return;

        if (!isCoverStillValid()) {
            if (suppressedDockHoldActive()) {
                // Pinned: an invalidated dock must not launch a replacement
                // relocation under fire — hold (the suppressed branch re-ducks)
                // until recovery re-runs this evaluation exactly as before.
                getPositionController().clear();
                return;
            }
            startRepositioning();
            return;
        }

        if (getCoverManager().getTimeInCover() < MIN_COVER_DWELL_TIME_MS) return;

        // Delegate pending reposition requests to the consolidated handler
        PendingRepositionResult requestResult = processPendingRepositionRequests();
        if (requestResult == PendingRepositionResult.MOVEMENT_STARTED) return;

        // Threat direction change (only when recovered)
        if (canLeaveCoverNow()) {
            Vec3 currentThreatDir = getThreats().getPrimaryDirection(soldier.position());
            Vec3 entryThreatDir = getCoverManager().getEntryThreatDirection();
            if (currentThreatDir != null && entryThreatDir != null && currentThreatDir.lengthSqr() > 0.01 && entryThreatDir.lengthSqr() > 0.01) {
                double dot = currentThreatDir.dot(entryThreatDir) / (currentThreatDir.length() * entryThreatDir.length());
                double angle = Math.acos(net.minecraft.util.Mth.clamp(dot, -1.0, 1.0));
                if (angle > THREAT_ANGLE_REPOSITION_THRESHOLD) {
                    if (DiagnosticLogManager.isCoverLoggingEnabled()) {
                        StevesArmyMod.LOGGER.info("[CoverGoal] Soldier {} threat direction changed, repositioning",
                            soldier.getId());
                    }
                    startRepositioning();
                    return;
                }
            }
        }

        if (DiagnosticLogManager.isCoverLoggingEnabled()) {
            tickLogCounter++;
            if (tickLogCounter >= SNAPSHOT_INTERVAL) {
                tickLogCounter = 0;
                StevesArmyMod.LOGGER.info("[CoverGoal] Soldier {} tick: coverState={}, peekState={}, hasThreat={}, suppression={}",
                    soldier.getId(), getCoverManager().getState(), soldier.getPeekController().getState(),
                    soldier.getThreatAwareness().hasActiveThreat(), String.format("%.2f", getCoverManager().getSuppressionTracker().getSuppressionLevel()));
            }
        }

        // Check for better cover (only when recovered from suppression).
        // Peek-disabled roles (support) skip the opportunistic hop entirely:
        // their score inputs drift constantly, so a marginal edge would reshuffle
        // them every evaluation. Real invalidation still repositions below.
        // A soldier fighting a vehicle hull is in the same situation: its aim
        // point moves along the hull every scan, so marginal hops would churn.
        // A clearing order also skips the hop: under an order of record the
        // dock changes are coordinator-driven, and marginal hops around an
        // unobservable job orbit the building as cover churn.
        if (clearingView == null
            && canLeaveCoverNow() && !soldier.isPeekDisabled() && !soldier.isInVehicleEngagement()) {
            Optional<CoverPoint> betterCover = findBetterCover();
            if (betterCover.isPresent()) {
                CoverPoint newCover = betterCover.get();

                if (newCover.getPosition().equals(currentCover.getPosition())) return;

                float penalty = getCoverManager().getCoverQualityPenalty();
                float hysteresis = penalty > 0 ? 1.0f : 1.0f + HYSTERESIS_THRESHOLD;

                // In attack mode, penalize backward cover switching
                if (soldier.hasValidAttackTarget() && penalty <= 0) {
                    BlockPos attackPos = soldier.getAttackTargetPos();
                    Vec3 soldierPos = soldier.position();
                    Vec3 toObjective = new Vec3(
                        attackPos.getX() - soldierPos.x, 0, attackPos.getZ() - soldierPos.z);
                    Vec3 toCandidate = newCover.getPosition().getCenter().subtract(soldierPos);
                    boolean isBackward = toObjective.dot(toCandidate) < 0;
                    if (isBackward) {
                        hysteresis = 1.0f + BACKWARD_HYSTERESIS_THRESHOLD;
                    }
                }

                float currentScore = currentCover.getQuality() * hysteresis - penalty;
                float newScore = newCover.getQuality();

                if (newScore > currentScore) {
                    startRepositioning(newCover);
                }
            }
        }
    }
    
private boolean shouldExitCoverForFollow() {
        if (soldier.getSquadMode() != SquadMode.FOLLOW) return false;

        if (!canLeaveCoverNow()) return false;

        float healthPercent = soldier.getHealth() / soldier.getMaxHealth();
        if (healthPercent < LOW_HEALTH_THRESHOLD) return false;

        if (getCoverManager().getTimeInCover() < MIN_COVER_DWELL_TIME_MS) return false;

        LivingEntity owner = soldier.getOwner();
        if (owner instanceof Player) {
            double distanceToOwner = soldier.distanceTo(owner);
            if (distanceToOwner > FOLLOW_REGROUP_DISTANCE) return true;
        }

        if (getThreats().hasActiveThreat()) return false;

        return true;
    }

    /** Tick counts of recent reposition decisions, for churn diagnostics. */
    private final java.util.ArrayDeque<Integer> recentRepositionTicks = new java.util.ArrayDeque<>();
    private static final int REPOSITION_WINDOW_TICKS = 100;

    private void noteReposition() {
        int now = soldier.tickCount;
        recentRepositionTicks.addLast(now);
        while (!recentRepositionTicks.isEmpty()
            && now - recentRepositionTicks.peekFirst() > REPOSITION_WINDOW_TICKS) {
            recentRepositionTicks.removeFirst();
        }
    }

    /** Reposition decisions over the last {@value #REPOSITION_WINDOW_TICKS} ticks. */
    public int getRecentRepositionCount() {
        if (!recentRepositionTicks.isEmpty()) {
            int now = soldier.tickCount;
            while (!recentRepositionTicks.isEmpty()
                && now - recentRepositionTicks.peekFirst() > REPOSITION_WINDOW_TICKS) {
                recentRepositionTicks.removeFirst();
            }
        }
        return recentRepositionTicks.size();
    }

    private void startRepositioning() {
        if (getCoverManager().getCurrentCover() != null && suppressedDockHoldActive()) {
            logDockTransition("ROUTINE_REPOSITION_HELD");
            holdSuppressedAtDock(getCoverManager().getCurrentCover());
            return;
        }
        noteReposition();
        // Normal cover navigation uses standing/crouching dimensions. Do not
        // carry the suppressed half-cover prone posture into full-speed travel.
        activeSuppressionRouteMovement = RouteMovement.NORMAL;
        activeRouteCrawlMandatory = false;
        soldier.getMovementController().setMandatoryCrawl(false, "route-released");
        selectedSuppressionRoute = null;
        soldier.setLowCrouching(false);
        getCoverManager().resetPeekState();
        getCoverManager().setPeekPosition(null);
        getPositionController().clear();
        requestCoverSearch(soldier.hasValidAttackTarget()
            ? QueuedSearchMode.ATTACK_SELECTING : QueuedSearchMode.REPOSITION);
        if (getCoverManager().getTargetCover() != null) {
            getCoverManager().setState(CoverBehaviorManager.CoverState.REPOSITIONING);
        } else {
            getCoverManager().setState(CoverBehaviorManager.CoverState.SEEKING_COVER);
        }
    }
    
    private boolean startRepositioning(CoverPoint newCover) {
        noteReposition();
        CoverPoint currentCover = getCoverManager().getCurrentCover();
        
        if (currentCover != null && newCover.getPosition().equals(currentCover.getPosition())) return false;

        CoverFinder admissionFinder = new CoverFinder(soldier.level());
        if (!isUsableAgainstThreat(admissionFinder, newCover, getCoverSearchDirection())
            || buildSquadCoverContext().violatesDefensiveSpacing(newCover.getPosition())) {
            if (DiagnosticLogManager.isCoverLoggingEnabled()) {
                StevesArmyMod.LOGGER.info("[CoverGoal] Soldier {} rejected reposition cover {} before reservation",
                    soldier.getId(), newCover.getPosition());
            }
            return false;
        }

        // This is the ordinary cover-to-cover path, not a protected low-crouch
        // trench shift. Restore normal movement dimensions before pathfinding.
        activeSuppressionRouteMovement = RouteMovement.NORMAL;
        activeRouteCrawlMandatory = false;
        soldier.getMovementController().setMandatoryCrawl(false, "route-released");
        selectedSuppressionRoute = null;
        soldier.setLowCrouching(false);
        
        // Release old target cover reservation (we're choosing a new target)
        CoverPoint oldTarget = getCoverManager().getTargetCover();
        if (oldTarget != null) {
            CoverReservationManager.release(oldTarget.getPosition(), soldier);
        }
        getCoverManager().clearTargetCover();
        getCoverManager().resetPeekState();
        getCoverManager().setPeekPosition(null);
        getPositionController().clear();
        
        if (CoverReservationManager.reserve(newCover.getPosition(), soldier)) {
            if (currentCover != null) {
                getCoverManager().setLastCover(currentCover);
            }
            getCoverManager().setTargetCover(newCover);
            getCoverManager().setState(CoverBehaviorManager.CoverState.REPOSITIONING);
            boolean movementStarted = moveToCover(newCover);
            if (!movementStarted && pendingRetryCover == null && !isReloadBlockedMove()) {
                if (getCoverManager().getTargetCover() != null) {
                    blacklistCover(newCover.getPosition(), BlacklistReason.PATH_FAILED);
                }
                getCoverManager().setState(currentCover != null
                    ? CoverBehaviorManager.CoverState.IN_COVER
                    : CoverBehaviorManager.CoverState.SEEKING_COVER);
                return false;
            }
            return true;
        }
        return false;
    }
    /**
     * Finds a position for an explicit suppress-area order. Its bounds and
     * firing lane are command data; HOLD/FOLLOW anchors and live threat
     * centroids must not influence this selection.
     */
    private CoverMoveResult findAndMoveToSuppressionPosition() {
        if (suppressionPositionArea == null || suppressionPositionOrigin == null) {
            return CoverMoveResult.NO_ELIGIBLE_COVER;
        }

        validatedCoverPaths.clear();
        unreachableCoverPaths.clear();
        validatedCoverPathSource = null;
        validatedCoverPathTick = Long.MIN_VALUE;
        exactPathValidationBudget = new ExactPathValidationBudget();
        CoverFinder finder = new CoverFinder(soldier.level());
        Vec3 direction = Vec3.atCenterOf(suppressionPositionArea)
            .subtract(Vec3.atCenterOf(suppressionPositionOrigin));
        if (direction.lengthSqr() > 0.001D) {
            direction = direction.normalize();
        }

        List<CoverFinder.ScoredCover> candidates = finder.evaluateAndScoreAllFromCenter(
            suppressionPositionOrigin, soldier, direction, List.of(), RELOCATION_SEARCH_RADIUS,
            buildSquadCoverContext());
        CoverPoint currentCover = getCoverManager().getCurrentCover();
        debugSearchCenter = suppressionPositionOrigin;

        for (CoverFinder.ScoredCover scored : candidates) {
            CoverPoint cover = scored.cover;
            if (failedCoverPositions.contains(cover.getPosition())
                || (currentCover != null && currentCover.getPosition().equals(cover.getPosition()))
                || !isUsableAgainstThreat(finder, cover, getCoverSearchDirection())
                || buildSquadCoverContext().violatesDefensiveSpacing(cover.getPosition())
                || !hasSuppressionFiringLaneFrom(getCoverStandingPosition(cover.getPosition()))) {
                continue;
            }
            if (!isExactCoverPathReachable(cover)) {
                if (!hasExactPathValidationBudget()) break;
                continue;
            }
            if (!CoverReservationManager.reserve(cover.getPosition(), soldier)) {
                continue;
            }

            getCoverManager().setTargetCover(cover);
            if (moveToCover(cover)) {
                if (DiagnosticLogManager.isCoverLoggingEnabled()) {
                    StevesArmyMod.LOGGER.info(
                        "[SuppressPosition] soldier={} generation={} selected={} origin={} area={}",
                        soldier.getId(), suppressionPositionGeneration, cover.getPosition(),
                        suppressionPositionOrigin, suppressionPositionArea);
                }
                return CoverMoveResult.COVER_STARTED;
            }
            CoverReservationManager.release(cover.getPosition(), soldier);
            getCoverManager().clearTargetCover();
            blacklistCover(cover.getPosition(), BlacklistReason.PATH_FAILED);
        }
        return candidates.isEmpty() ? CoverMoveResult.NO_COVER_FOUND : CoverMoveResult.NO_ELIGIBLE_COVER;
    }

    /**
     * Validates a suppression approach from a prospective standing position.
     * Siting uses the machine-gun near-LOS contract: a clear lane into the
     * zone counts, and so does a lane blocked within
     * {@link #SUPPRESSION_SIGHTING_TOLERANCE} of a sample — suppressing fire
     * lands on or beside the target, so a wall face at the zone edge is a
     * valid lane rather than a blocked one. Demanding a clear view *into* the
     * zone rejected good positions (the zone is where the enemy cover is) and
     * accepted useless ones (open sight through zone air) that then arrived
     * blind. Smoke is ignored here; mode-correct checks still gate the
     * actual shot at firing time.
     */
    private boolean hasSuppressionFiringLaneFrom(Vec3 standingPosition) {
        if (suppressionPositionArea == null) return false;
        Vec3 eye = standingPosition.add(0.0D, soldier.getEyeHeight(), 0.0D);
        Vec3 center = Vec3.atCenterOf(suppressionPositionArea).add(0.0D, 0.75D, 0.0D);
        double radius = SoldierEntity.SUPPRESSION_ZONE_RADIUS * 0.65D;
        Vec3[] samples = {
            center, center.add(0.0D, 0.75D, 0.0D),
            center.add(radius, 0.0D, 0.0D), center.add(-radius, 0.0D, 0.0D),
            center.add(0.0D, 0.0D, radius), center.add(0.0D, 0.0D, -radius)
        };
        for (Vec3 sample : samples) {
            if (TargetAcquisition.hasSuppressionSightingLane(soldier.level(), eye, sample,
                SUPPRESSION_SIGHTING_TOLERANCE, true, soldier)) {
                return true;
            }
        }
        return false;
    }

    private CoverMoveResult findAndMoveToCover() {
        PerformanceMetrics.recordRoleCoverSearch(machineGunnerPipeline);
        long searchStarted = System.nanoTime();
        validatedCoverPaths.clear();
        unreachableCoverPaths.clear();
        validatedCoverPathSource = null;
        validatedCoverPathTick = Long.MIN_VALUE;
        exactPathValidationBudget = new ExactPathValidationBudget();
        searchReserveAttempts = 0;
        Level level = soldier.level();
        CoverFinder finder = new CoverFinder(level);
        // Exposure gate: the interior-walk doctrine owns the legs while the
        // soldier has no route LoS, no contact and no suppression — a search
        // here can only dock the start building's own walls (the turn-around),
        // and its failure path must not run exposed-combat against the walk.
        if (spineInteriorWalkGate()) {
            getCoverManager().setState(CoverBehaviorManager.CoverState.NO_COVER);
            logCoverSearchPerformance(finder, searchStarted, CoverMoveResult.NO_COVER_FOUND, "spine-walk-gate");
            return CoverMoveResult.NO_COVER_FOUND;
        }
        long now = GameClock.nowMs();
        if (now - lastBlacklistClearTime > BLACKLIST_CLEAR_INTERVAL_MS) {
            failedCoverPositions.removeIf(pos -> !pos.equals(compromisedCoverPosition));
            blacklistReasons.entrySet().removeIf(entry -> !entry.getKey().equals(compromisedCoverPosition));
            lastBlacklistClearTime = now;
            if (DiagnosticLogManager.isCoverLoggingEnabled()) {
                StevesArmyMod.LOGGER.info("[CoverGoal] Soldier {} cleared failed cover blacklist", soldier.getId());
            }
        }
        
        Vec3 threatDirection = getCoverSearchDirection();
        List<LivingEntity> threats = getThreatList();
        SquadCoverContext squadCtx = buildSquadCoverContext();

        if (relocationType != RelocationType.NONE && relocationCenter != null) {
            debugSearchCenter = relocationCenter;
            debugSearchRadius = relocationType == RelocationType.FOLLOW
                ? (int) FOLLOW_COVER_SEARCH_RADIUS : RELOCATION_SEARCH_RADIUS;
            List<CoverFinder.ScoredCover> relocationCovers = finder.evaluateAndScoreAllFromCenter(
                relocationCenter, soldier, threatDirection, threats,
                relocationType == RelocationType.FOLLOW ? (int) FOLLOW_COVER_SEARCH_RADIUS : RELOCATION_SEARCH_RADIUS,
                squadCtx);

            CoverPoint currentCover = getCoverManager().getCurrentCover();
            for (CoverFinder.ScoredCover scoredCover : relocationCovers) {
                CoverPoint cover = scoredCover.cover;
                if (failedCoverPositions.contains(cover.getPosition())
                    || (currentCover != null && cover.getPosition().equals(currentCover.getPosition()))) {
                    continue;
                }
                if (!isDistantRelocationCover(cover)) {
                    if (!isExactCoverPathReachable(cover)) {
                        if (!hasExactPathValidationBudget()) break;
                        continue;
                    }
                }
                if (CoverReservationManager.reserve(cover.getPosition(), soldier)) {
                    getCoverManager().clearCoverQualityPenalty();
                    getCoverManager().setTargetCover(cover);
                    if (DiagnosticLogManager.isCoverLoggingEnabled()) {
                        StevesArmyMod.LOGGER.info("[CoverRelocation] Soldier {} selected {} cover={} score={} distance={} pathMode={}",
                            soldier.getId(), relocationType, cover.getPosition(), String.format("%.2f", scoredCover.score),
                            String.format("%.1f", horizontalDistanceToCover(cover)),
                            isDistantRelocationCover(cover) ? "staged" : "exact");
                    }
                    boolean movementStarted = moveToCover(cover);
                    if (!movementStarted && pendingRetryCover == null && !isReloadBlockedMove()) {
                        failGoToRelocation();
                        logCoverSearchPerformance(finder, searchStarted, CoverMoveResult.NO_COVER_FOUND,
                            "relocation-path-failed");
                        return CoverMoveResult.NO_COVER_FOUND;
                    }
                    logCoverSearchPerformance(finder, searchStarted, CoverMoveResult.COVER_STARTED, "relocation");
                    return CoverMoveResult.COVER_STARTED;
                }
            }

            if (relocationType == RelocationType.GO_TO) {
                failedGoToRelocationGeneration = relocationCommandGeneration;
            } else {
                nextFollowRelocationSearchTick = soldier.tickCount + FOLLOW_COVER_RETRY_TICKS;
            }
            clearRelocationTarget();
            getCoverManager().setState(CoverBehaviorManager.CoverState.NO_COVER);
            logCoverSearchPerformance(finder, searchStarted, CoverMoveResult.NO_COVER_FOUND, "relocation-none");
            return CoverMoveResult.NO_COVER_FOUND;
        }
        int searchRadius = SEARCH_RADIUS;
        BlockPos searchCenter = soldier.blockPosition();

        if (soldier.hasValidAttackTarget()) {
            if (clearingHold()) {
                // Secured: watch coverage near the current position, not the
                // corridor advance's forward bias.
                searchCenter = soldier.blockPosition();
            } else if (clearingPoiTarget != null) {
                // Clearing job: dock near the assigned blind spot.
                searchCenter = clearingPoiTarget;
            } else {
                BlockPos attackPos = soldier.getAttackTargetPos();
                // Spine frame: center the candidate pool ON THE ROUTE one hop
                // ahead — the straight-line bias points at the objective,
                // but the route (exits away from the objective first) leaves
                // that pool with nothing spine-forward in it and the search
                // degrades to distance-scoring whatever is nearby.
                if (attackSpine != null) {
                    // Base-of-fire row discipline: the MG's candidate pool must
                    // hold covers BEHIND the rifleman line, but the spine-ahead
                    // center pools only forward rows — the row filter then
                    // rejects the whole pool and the base fallback charges
                    // anyway (run: candidates=9 rejectedAhead=9). Center the
                    // gunner's pool on himself so behind-line rows exist in it.
                    if (mgBackRowRuleActive()) {
                        searchCenter = soldier.blockPosition();
                    } else {
                        double prog = attackSpine.progress(soldier.blockPosition());
                        searchCenter = attackSpine.pointAt(
                            Math.min(attackSpine.length(), prog + 12.0D),
                            soldier.blockPosition().getY());
                    }
                } else if (!mgBackRowRuleActive()) {
                    Vec3 toTarget = new Vec3(
                        attackPos.getX() - soldier.getX(),
                        0,
                        attackPos.getZ() - soldier.getZ());
                    double distToTarget = toTarget.length();
                    if (distToTarget > 1.0) {
                        toTarget = toTarget.normalize();
                        double ahead = Math.min(distToTarget * 0.25, 6.0);
                        searchCenter = soldier.blockPosition().offset(
                            (int)(toTarget.x * ahead), 0, (int)(toTarget.z * ahead));
                    }
                }
            }
        } else if (soldier.getSquadMode() == SquadMode.HOLD) {
            BlockPos holdPos = soldier.getHoldPosition();
            if (holdPos != null && !holdPos.equals(BlockPos.ZERO)) {
                searchCenter = holdPos;
            }
        } else if (soldier.getSquadMode() == SquadMode.FOLLOW) {
            LivingEntity owner = soldier.getOwner();
            if (owner instanceof Player) {
                if (getCoverManager().isSuppressed()) {
                    searchRadius = SEARCH_RADIUS;
                    searchCenter = soldier.blockPosition();
                } else {
                    searchCenter = owner.blockPosition();
                    searchRadius = (int) FOLLOW_COVER_SEARCH_RADIUS;
                }
            }
        }

        BlockPos machineGunnerAnchor = getMachineGunnerSearchCenter();
        if (machineGunnerAnchor != null && clearingPoiTarget == null) {
            searchCenter = machineGunnerAnchor;
            if (soldier.hasValidAttackTarget()) {
                searchRadius = ATTACK_CORRIDOR_SEARCH_RADIUS;
            }
        }

        // Close-combat doctrine: protection near a close threat must be a
        // short, useful movement, not a long relocation under fire. Bound the
        // radius only when the search is centered near the soldier - an
        // owner-anchored FOLLOW search 15 blocks out must keep its full span
        // or nearby protection becomes undiscoverable.
        if (soldier.isInCloseCombatContext() || soldier.hasCloseRangeTarget()) {
            double bound = StevesArmyConfig.getCloseCombatSeekRadius();
            if (searchCenter.distSqr(soldier.blockPosition()) <= Math.max(4.0, bound * bound)) {
                searchRadius = Math.min(searchRadius, (int) bound);
            }
        } else if (seekEscalated) {
            // Stranded-seeker escalation: the normal radius from here holds no
            // cover, so reach back toward the squad (FOLLOW/ATTACK) or widen
            // around the hold anchor (HOLD). Escalation never redirects the
            // relocation pipeline, which already searches from its own center.
            if (soldier.getSquadMode() == SquadMode.HOLD) {
                BlockPos holdPos = soldier.getHoldPosition();
                if (holdPos != null && !holdPos.equals(BlockPos.ZERO)) {
                    searchCenter = holdPos;
                }
            } else {
                LivingEntity owner = soldier.getOwner();
                if (owner != null && owner.blockPosition().distSqr(soldier.blockPosition()) > 4) {
                    searchCenter = owner.blockPosition();
                }
            }
        }
        // Widen even with an anchor: the rear anchor can point away from every
        // cover (the solo-MG rim case), so the radius must stretch past it.
        if (seekEscalated) {
            searchRadius = Math.max(searchRadius, (int) FOLLOW_COVER_SEARCH_RADIUS);
        }
        this.debugSearchCenter = searchCenter;
        this.debugSearchRadius = searchRadius;
        
        Optional<CoverPoint> bestCover = Optional.empty();
        List<CoverFinder.ScoredCover> reusableScored = null;

        // Suppressed relocation is fully safe or does not happen: the route
        // classifier below accepts only PROTECTED / CRAWL_SAFE paths and
        // withholds everything else, so the soldier stays at his current
        // cover instead of walking an unclassified attack-corridor dock
        // (the pinned walk-outs: attack-target soldiers used to skip this
        // entire pass). suppressedRelocationSafeRoute=false restores the
        // legacy exemption for attack-target soldiers.
        if (suppressionRouteSearchActive
            && (StevesArmyConfig.isSuppressedRelocationSafeRoute() || !soldier.hasValidAttackTarget())) {
            if (suppressionRouteFiringOrigins.isEmpty() && !suppressionEscapeSearchActive) {
                if (DiagnosticLogManager.isCoverLoggingEnabled()) {
                    StevesArmyMod.LOGGER.info("[CoverSuppression] Soldier {} withheld reposition: no firing origin is available",
                        soldier.getId());
                }
                logCoverSearchPerformance(finder, searchStarted, CoverMoveResult.NO_ELIGIBLE_COVER, "suppression-no-origin");
                return CoverMoveResult.NO_ELIGIBLE_COVER;
            }
            SuppressionRoutePlan routePlan = selectSuppressionRoute(finder, threatDirection, threats,
                searchRadius, squadCtx, suppressionRouteFiringOrigins);
            if (routePlan != null) {
                selectedSuppressionRoute = routePlan;
                bestCover = Optional.of(routePlan.cover());
            } else {
                if (DiagnosticLogManager.isCoverLoggingEnabled()) {
                    StevesArmyMod.LOGGER.info("[CoverSuppression] Soldier {} withheld reposition: no protected or crawl-safe route found",
                        soldier.getId());
                }
                logCoverSearchPerformance(finder, searchStarted, CoverMoveResult.NO_ELIGIBLE_COVER, "suppression-no-safe-route");
                return CoverMoveResult.NO_ELIGIBLE_COVER;
            }
        }

        if (bestCover.isPresent()) {
            // The suppression route pass has already selected and path-validated this cover.
        } else if (soldier.hasValidAttackTarget() && clearingPoiTarget != null && !clearingHold()) {
            // Clearing job: protection near the assigned blind spot. Covers
            // inside the objective area are valid now — the area IS the
            // objective, so the corridor's beyond-the-objective rejection and
            // its monotonic frontier do not apply here.
            CoverPoint activeCover = getCoverManager().getCurrentCover();
            List<CoverFinder.ScoredCover> scored = finder.evaluateAndScoreAllFromCenter(
                searchCenter, soldier, threatDirection, threats, ATTACK_CORRIDOR_SEARCH_RADIUS, squadCtx);
            List<CoverFinder.ScoredCover> eligible = new ArrayList<>();
            for (CoverFinder.ScoredCover sc : scored) {
                CoverPoint cover = sc.cover;
                if (activeCover != null && cover.getPosition().equals(activeCover.getPosition())) continue;
                if (failedCoverPositions.contains(cover.getPosition())) continue;
                // A blind spot reached from outside the wall observes nothing:
                // the dock must stand inside the space being cleared.
                if (!ClearingCoordinator.isInsideClearingArea(soldier, cover.getPosition())) continue;
                // Never take cover on top of a live contact's last-known spot.
                if (ClearingCoordinator.nearLiveContact(soldier, cover.getPosition(), 2.25)) continue;
                if (cover.getPosition().distSqr(clearingPoiTarget) > 144) continue;
                eligible.add(sc);
            }

            List<CoverFinder.ScoredCover> protectedEligible = new ArrayList<>();
            for (CoverFinder.ScoredCover sc : eligible) {
                if (finder.isPrimaryThreatProtected(sc.cover, soldier, threatDirection)) {
                    protectedEligible.add(sc);
                }
            }
            // Directional protection is mandatory. If no candidate protects the
            // active threat, leave the pool empty so the caller reaches prone
            // fallback instead of claiming an unverified side of a block.
            List<CoverFinder.ScoredCover> pool = protectedEligible;
            // Prefer docks that can actually observe the blind spot — a dock
            // within range but with no line of sight to it keeps the soldier
            // busy without contributing a check.
            List<CoverFinder.ScoredCover> observing = new ArrayList<>();
            for (CoverFinder.ScoredCover sc : pool) {
                if (ClearingCoordinator.dockObservesTarget(soldier, sc.cover.getPosition(), clearingPoiTarget)) {
                    observing.add(sc);
                }
            }
            if (!observing.isEmpty()) {
                pool = observing;
            }
            bestCover = selectPreferredCover(pool);
            if (bestCover.isEmpty() && !pool.isEmpty()) {
                pool.sort(java.util.Comparator.comparingDouble(
                    sc -> sc.cover.getPosition().distSqr(clearingPoiTarget)));
                bestCover = Optional.of(pool.get(0).cover);
            }
        } else if (soldier.hasValidAttackTarget() && clearingHold()) {
            // Secured area: hold-style coverage near the current position —
            // the plain protected search, no corridor filter, no advance bias.
            CoverPoint activeCover = getCoverManager().getCurrentCover();
            List<CoverFinder.ScoredCover> scoredNearby = finder.evaluateAndScoreAll(
                soldier, threatDirection, threats, SEARCH_RADIUS, true, squadCtx);
            for (CoverFinder.ScoredCover sc : scoredNearby) {
                CoverPoint cover = sc.cover;
                if (activeCover != null && cover.getPosition().equals(activeCover.getPosition())) continue;
                if (failedCoverPositions.contains(cover.getPosition())) continue;
                if (!finder.isPrimaryThreatProtected(cover, soldier, threatDirection)) continue;
                bestCover = Optional.of(cover);
                break;
            }
        } else if (soldier.hasValidAttackTarget()) {
            // ATTACK mode: forward-biased search from the beginning
            List<CoverFinder.ScoredCover> scored = finder.evaluateAndScoreAllFromCenter(
                searchCenter, soldier, threatDirection, threats, ATTACK_CORRIDOR_SEARCH_RADIUS, squadCtx);

            CoverPoint currentCover = getCoverManager().getCurrentCover();
            Vec3 soldierPos = soldier.position();
            Vec3 objectiveDir = null;
            if (soldier.hasValidAttackTarget()) {
                BlockPos obj = soldier.getAttackTargetPos();
                objectiveDir = new Vec3(obj.getX() - soldierPos.x, 0, obj.getZ() - soldierPos.z).normalize();
            }

            Direction threatDir = (threatDirection != null && threatDirection.lengthSqr() > 0.001)
                ? CoverFinder.getDirectionFromVector(threatDirection) : null;

            // Filter: require forward progress AND primary-threat protection,
            // skip current/blacklisted covers. Collect every eligible cover so a
            // role strategy can pick the best fire lane; the first eligible is
            // the unchanged base fallback.
            List<CoverFinder.ScoredCover> eligible = new ArrayList<>();
            for (CoverFinder.ScoredCover sc : scored) {
                CoverPoint cover = sc.cover;
                if (currentCover != null && cover.getPosition().equals(currentCover.getPosition())) continue;
                if (failedCoverPositions.contains(cover.getPosition())) continue;
                // Base-of-fire row discipline: an MG candidate pool centered on
                // himself still holds ahead-of-line covers; they never dock.
                if (violatesMgBackRow(cover.getPosition())) continue;

                if (!isAttackCorridorCandidate(cover, soldier.getAttackTargetPos(), objectiveDir)) {
                    logRejectedAttackCover(cover, soldier.getAttackTargetPos(), objectiveDir);
                    continue;
                }

                // Hard primary-threat protection preference
                if (!finder.isPrimaryThreatProtected(cover, soldier, threatDirection)) {
                    continue;
                }

                eligible.add(sc);
            }

            bestCover = selectPreferredCover(eligible);
            if (bestCover.isEmpty() && !eligible.isEmpty()) {
                bestCover = Optional.of(eligible.get(0).cover);
            }

            // If forward-biased found nothing protected, search from soldier position as fallback
            // (still requires primary-threat protection)
            if (bestCover.isEmpty()) {
                List<CoverFinder.ScoredCover> localScored = finder.evaluateAndScoreAll(
                    soldier, threatDirection, threats, ATTACK_CORRIDOR_SEARCH_RADIUS, true, squadCtx);
                for (CoverFinder.ScoredCover sc : localScored) {
                    CoverPoint cover = sc.cover;
                    if (currentCover != null && cover.getPosition().equals(currentCover.getPosition())) continue;
                    if (failedCoverPositions.contains(cover.getPosition())) continue;

                    if (!isAttackCorridorCandidate(cover, soldier.getAttackTargetPos(), objectiveDir)) {
                        logRejectedAttackCover(cover, soldier.getAttackTargetPos(), objectiveDir);
                        continue;
                    }

                    // Fallback still requires primary-threat protection
                    if (!finder.isPrimaryThreatProtected(cover, soldier, threatDirection)) {
                        continue;
                    }

                    bestCover = Optional.of(cover);
                    break;
                }

                // The preferred assault lane may be blocked by a structure.
                // Before walking uncovered, accept a reachable forward cover in
                // a wider sector even when its protection is not an exact match.
                if (bestCover.isEmpty()) {
                    bestCover = findWideForwardAttackCover(localScored, currentCover,
                        soldier.getAttackTargetPos(), objectiveDir, threatDir);
                }
            }
        } else {
            if (!asyncPilotFallback && StevesArmyConfig.isAsyncCoverPilotEnabled()
                && isAsyncCoverPilotEligible()) {
                // Classify against the live threat: the direction-blind
                // discovery fallback types every cell next to a tall wall as
                // FULL, which let rim cells 10 blocks off-axis outrank the
                // nearby half cover in the pilot's coarse ranking.
                List<CoverPoint> discovered = finder.discoverCoverPoints(searchCenter, searchRadius,
                    threats.isEmpty() ? null : threats.get(0));
                if (discovered.isEmpty()) {
                    PerformanceMetrics.recordPhase6FallbackDiscoveryEmpty();
                    PerformanceMetrics.recordPhase6Fallback();
                } else {
                    CoverProtectionContext protection = soldier.getCombatGoal() != null
                        ? soldier.getCombatGoal().resolveCoverProtectionContext()
                        : CoverProtectionContext.NONE;
                    long captureStarted = System.nanoTime();
                    try {
                        CoverSnapshotCapture.Capture capture = CoverSnapshotCapture.captureRaw(
                            soldier.level(), soldier, threatDirection, protection, threats, squadCtx,
                            discovered, searchCenter, searchRadius);
                        PerformanceMetrics.recordPhase6Snapshot(System.nanoTime() - captureStarted);
                        if (soldier.level() instanceof ServerLevel serverLevel
                            && AsyncCoverShadowService.submitPilot(serverLevel, soldier.getUUID(), capture)) {
                            asyncPilotPending = true;
                            asyncPilotSubmittedTick = soldier.level().getGameTime();
                            return CoverMoveResult.ASYNC_PENDING;
                        }
                    } catch (RuntimeException exception) {
                        PerformanceMetrics.recordPhase6SnapshotFailure();
                        StevesArmyMod.LOGGER.warn("Cover pilot snapshot failed for soldier {}", soldier.getId(), exception);
                    }
                    PerformanceMetrics.recordPhase6FallbackSubmissionFailed();
                    PerformanceMetrics.recordPhase6Fallback();
                }
            }
            reusableScored = finder.evaluateAndScoreAll(
                soldier, threatDirection, threats, searchRadius, true, squadCtx);
            runPureCoverShadow(threatDirection, threats, squadCtx, reusableScored,
                searchCenter, searchRadius);
            if (finder.hasPrimaryThreat(soldier, threatDirection)) {
                List<CoverFinder.ScoredCover> protectedCovers = reusableScored.stream()
                    .filter(sc -> finder.isPrimaryThreatProtected(sc.cover, soldier, threatDirection))
                    .collect(java.util.stream.Collectors.toList());
                reusableScored = protectedCovers;
            }
            bestCover = selectPreferredCover(reusableScored);
            if (bestCover.isEmpty()) {
                bestCover = selectBestAvailableCover(finder, reusableScored, threatDirection);
            }

            if (bestCover.isEmpty()) {
                PerformanceMetrics.recordCoverFullSearchAttempt();
                // Last-resort center search scored with the same tactical
                // weights as the primary pass (the legacy quality×10 scorer
                // here let any FULL classification outrank every HALF
                // regardless of distance).
                CoverPoint claimedCover = getCoverManager().getCurrentCover();
                List<CoverFinder.ScoredCover> centerScored = finder.evaluateAndScoreAllFromCenter(
                    searchCenter, soldier, threatDirection, threats, searchRadius, squadCtx);
                for (CoverFinder.ScoredCover sc : centerScored) {
                    CoverPoint cover = sc.cover;
                    if (claimedCover != null && cover.getPosition().equals(claimedCover.getPosition())) continue;
                    if (failedCoverPositions.contains(cover.getPosition())) continue;
                    if (!finder.isPrimaryThreatProtected(cover, soldier, threatDirection)) continue;
                    bestCover = Optional.of(cover);
                    break;
                }
            }

            if (bestCover.isEmpty() && squadCtx.inSquad()) {
                PerformanceMetrics.recordCoverFullSearchAttempt();
                bestCover = finder.findBestCover(
                    soldier,
                    threatDirection,
                    threats,
                    searchRadius
                );
            }
        }
        
        if (bestCover.isPresent()) {
            CoverPoint cover = bestCover.get();

            // A cover claim is legal only when its physical geometry blocks the
            // currently known threat direction. Unknown direction is
            // fail-closed: keep searching/prone fallback rather than claiming
            // an arbitrary side of a block.
            if (!isUsableAgainstThreat(finder, cover, threatDirection)
                || squadCtx.violatesDefensiveSpacing(cover.getPosition())) {
                if (DiagnosticLogManager.isCoverLoggingEnabled()) {
                    StevesArmyMod.LOGGER.info("[CoverGoal] Soldier {} rejected cover {} before reservation (protection/spacing)",
                        soldier.getId(), cover.getPosition());
                }
                bestCover = Optional.empty();
            }
        }

        if (bestCover.isPresent()) {
            CoverPoint cover = bestCover.get();

            if (reusableScored == null) {
                reusableScored = finder.evaluateAndScoreAll(
                    soldier, threatDirection, threats, searchRadius, true, squadCtx);
            }
            List<CoverFinder.ScoredCover> tacticalCovers;
            if (soldier.hasValidAttackTarget() && relocationType == RelocationType.NONE) {
                tacticalCovers = new ArrayList<>();
                for (CoverFinder.ScoredCover sc : reusableScored) {
                    if (isExactCoverPathReachable(sc.cover)) {
                        tacticalCovers.add(sc);
                    } else if (!hasExactPathValidationBudget()) {
                        break;
                    }
                }
            } else {
                // No attack target: still feed the scored list to the prone
                // gate. An empty list makes its physical-cover check vacuous
                // and the soldier deploys prone in the open next to usable
                // cover (the stranded-MG wander).
                tacticalCovers = reusableScored;
            }
            Optional<DefensivePositionCandidate.ProneFiringCandidate> prone =
                DefensivePositionSelector.selectProne(soldier, soldier.getTarget(), getThreats(), tacticalCovers,
                    squadCtx, exactPathValidationBudget, threatDirection);
            if (prone.isPresent() && relocationType == RelocationType.NONE) {
                startProneFiringMovement(prone.get());
                logCoverSearchPerformance(finder, searchStarted, CoverMoveResult.COVER_STARTED, "prone-lane");
                return CoverMoveResult.COVER_STARTED;
            }
            
            boolean wantsDebug = DiagnosticLogManager.isCoverScoreLoggingEnabled()
                || CoverDebugManager.isShowSoldierCover();
            if (wantsDebug) {
                cachedTopCovers = reusableScored.stream().limit(5)
                    .toArray(CoverFinder.ScoredCover[]::new);
            }
            
            CoverPoint currentCover = getCoverManager().getCurrentCover();
            boolean excludesCurrentCover = emergencyCoverSearchActive && currentCover != null
                && cover.getPosition().equals(currentCover.getPosition());
            if (failedCoverPositions.contains(cover.getPosition()) || excludesCurrentCover) {
                List<CoverFinder.ScoredCover> scored = reusableScored;
                
                scored = scored.stream()
                    .filter(sc -> !failedCoverPositions.contains(sc.cover.getPosition()))
                    .filter(sc -> !emergencyCoverSearchActive || currentCover == null
                        || !sc.cover.getPosition().equals(currentCover.getPosition()))
                    .collect(java.util.stream.Collectors.toList());
                
                if (scored.isEmpty()) {
                    if (DiagnosticLogManager.isCoverLoggingEnabled()) {
                        StevesArmyMod.LOGGER.info("[CoverGoal] Soldier {} no valid covers after filtering blacklist", soldier.getId());
                    }
                    logCoverSearchPerformance(finder, searchStarted, CoverMoveResult.NO_ELIGIBLE_COVER, "blacklist");
                    return CoverMoveResult.NO_ELIGIBLE_COVER;
                }
                
                cover = scored.get(0).cover;
                if (DiagnosticLogManager.isCoverLoggingEnabled()) {
                    StevesArmyMod.LOGGER.info("[CoverGoal] Soldier {} selected fallback cover {} (score={})",
                        soldier.getId(), cover.getPosition(), String.format("%.2f", scored.get(0).score));
                }
            }
            
            if (currentCover != null && cover.getPosition().equals(currentCover.getPosition())) {
                if (emergencyCoverSearchActive) {
                    logCoverSearchPerformance(finder, searchStarted, CoverMoveResult.NO_ELIGIBLE_COVER, "emergency-current");
                    return CoverMoveResult.NO_ELIGIBLE_COVER;
                }
                onCoverReached(cover);
                logCoverSearchPerformance(finder, searchStarted, CoverMoveResult.COVER_STARTED, "already-current");
                return CoverMoveResult.COVER_STARTED;
            }
            
            if (currentCover != null) {
                double distToSoldier = soldier.position().distanceTo(cover.getPosition().getCenter());
                if (distToSoldier < COVER_REACHED_DISTANCE) {
                    if (DiagnosticLogManager.isCoverLoggingEnabled()) {
                        StevesArmyMod.LOGGER.info("[CoverGoal] Soldier {} selected cover {} too close, blacklisting and falling back to seek",
                            soldier.getId(), cover.getPosition());
                    }
                    blacklistCover(cover.getPosition(), BlacklistReason.STUCK_REPOSITIONING);
                    getCoverManager().clearTargetCover();
                    getCoverManager().setState(CoverBehaviorManager.CoverState.SEEKING_COVER);
                    logCoverSearchPerformance(finder, searchStarted, CoverMoveResult.NO_COVER_FOUND, "too-close");
                    return CoverMoveResult.NO_COVER_FOUND;
                }
            }
            
            getCoverManager().clearCoverQualityPenalty();
            cancelProneFiringPlan();

            // Reserve the best cover that is actually claimable. A taken best
            // cover (a squadmate claimed it first) must fall through to the
            // next candidate instead of failing the whole search: reservation
            // failures never blacklist, so the old single-candidate attempt
            // re-selected the same reserved cover forever and the soldier
            // stranded in SEEKING_COVER with no movement.
            //
            // Candidate pools, in order: the selected best, then the
            // soldier-centered scored list, then — when the soldier has
            // drifted away from the intended search center (MG rear anchor,
            // hold position) — a protection-filtered pool from that center.
            int reserveAttempts = 0;
            final BlockPos selectedPos = cover.getPosition();
            CoverMoveResult outcome = tryReservePool(
                java.util.List.of(new CoverFinder.ScoredCover(cover, Float.MAX_VALUE)),
                currentCover, reserveAttemptsCap(searchCenter));
            if (outcome == CoverMoveResult.COVER_STARTED) {
                logCoverSearchPerformance(finder, searchStarted, CoverMoveResult.COVER_STARTED, "selected");
                return CoverMoveResult.COVER_STARTED;
            }
            List<CoverFinder.ScoredCover> soldierPool = reusableScored == null
                ? List.of() : reusableScored.stream()
                    .filter(sc -> !sc.cover.getPosition().equals(selectedPos))
                    // Advance doctrine: the fallback pools may hold adjacent
                    // on-route protection, never a cover behind the advance —
                    // protection alone pulled followers back into the start
                    // building whenever the forward row was reserved.
                    .filter(sc -> !isBehindAttackSpine(sc.cover.getPosition()))
                    // Base-of-fire row discipline: the pool walk commits the
                    // first claimable candidate — without this filter a failed
                    // reservation on a behind cover would let the gunner charge.
                    .filter(sc -> !violatesMgBackRow(sc.cover.getPosition()))
                    .toList();
            outcome = tryReservePool(soldierPool, currentCover, reserveAttemptsCap(searchCenter));
            if (outcome == CoverMoveResult.COVER_STARTED) {
                logCoverSearchPerformance(finder, searchStarted, CoverMoveResult.COVER_STARTED, "reserve-fallback");
                return CoverMoveResult.COVER_STARTED;
            }
            if (searchCenter != null && searchCenter.distSqr(soldier.blockPosition()) > 4) {
                List<CoverFinder.ScoredCover> centerPool = finder.evaluateAndScoreAllFromCenter(
                    searchCenter, soldier, threatDirection, threats, searchRadius, squadCtx);
                if (finder.hasPrimaryThreat(soldier, threatDirection)) {
                    centerPool = centerPool.stream()
                        .filter(sc -> finder.isPrimaryThreatProtected(sc.cover, soldier, threatDirection))
                        .collect(java.util.stream.Collectors.toList());
                }
                centerPool = centerPool.stream()
                    .filter(sc -> !sc.cover.getPosition().equals(selectedPos))
                    .filter(sc -> !isBehindAttackSpine(sc.cover.getPosition()))
                    .toList();
                outcome = tryReservePool(centerPool, currentCover, reserveAttemptsCap(searchCenter));
                if (outcome == CoverMoveResult.COVER_STARTED) {
                    logCoverSearchPerformance(finder, searchStarted, CoverMoveResult.COVER_STARTED, "center-reserve-fallback");
                    return CoverMoveResult.COVER_STARTED;
                }
            }
            // Every candidate was unusable (taken, unreachable, out of bound):
            // same doctrine answer as a search that found nothing at all —
            // but only for a soldier who is actually exposed. A docked
            // soldier's failed better-cover search means "keep the dock":
            // condemning it here re-entered the seek mill every investigate
            // window (dock stripped -> re-search -> re-dock around an
            // unreachable job — the blocked-door orbit).
            if (!dockedForSearch()) {
                runExposedCombatFallback();
                getCoverManager().setState(CoverBehaviorManager.CoverState.NO_COVER);
            }
            logCoverSearchPerformance(finder, searchStarted, CoverMoveResult.NO_COVER_FOUND, "reservation");
            return CoverMoveResult.NO_COVER_FOUND;
        }
        if (reusableScored == null) {
            reusableScored = finder.evaluateAndScoreAll(
                soldier, threatDirection, threats, searchRadius, true, squadCtx);
        }
        List<CoverFinder.ScoredCover> tacticalCovers = new ArrayList<>();
        for (CoverFinder.ScoredCover sc : reusableScored) {
            if (isExactCoverPathReachable(sc.cover)) {
                tacticalCovers.add(sc);
            } else if (!hasExactPathValidationBudget()) {
                break;
            }
        }
        Optional<DefensivePositionCandidate.ProneFiringCandidate> prone =
            DefensivePositionSelector.selectProne(soldier, soldier.getTarget(), getThreats(), tacticalCovers,
                squadCtx, exactPathValidationBudget, threatDirection);
        if (prone.isPresent() && relocationType == RelocationType.NONE) {
            startProneFiringMovement(prone.get());
            logCoverSearchPerformance(finder, searchStarted, CoverMoveResult.COVER_STARTED, "prone-no-cover");
            return CoverMoveResult.COVER_STARTED;
        }
        // No cover is a supported combat situation: consult the exposed-combat
        // doctrine for a deliberate action (plant and engage, bounded sidestep,
        // withdraw, deliberate hold) instead of standing frozen at the search
        // failure point. The seek lifecycle cooldown still applies, so a failed
        // adjustment never loops. A docked soldier is not exposed: the failure
        // of a speculative search must not condemn the dock he is holding
        // (same keep-the-dock rule as the reservation exit above).
        if (!dockedForSearch()) {
            runExposedCombatFallback();
            // Leave the active seeking state when this search found no route. The goal's
            // normal stop/cooldown lifecycle prevents a stationary soldier from rebuilding
            // the same failed candidate paths every tick.
            getCoverManager().setState(CoverBehaviorManager.CoverState.NO_COVER);
        }
        logCoverSearchPerformance(finder, searchStarted, CoverMoveResult.NO_COVER_FOUND, "none");
        return CoverMoveResult.NO_COVER_FOUND;
    }

    /**
     * Tries to reserve and start moving to the first usable candidate in the
     * pool. PATH/reject outcomes leave the candidate blacklisted or skipped so
     * the next pool gets its turn. Bounds total movement attempts across all
     * pools of one search — every attempt runs a real path calculation.
     */
    private CoverMoveResult tryReservePool(List<CoverFinder.ScoredCover> pool,
                                           CoverPoint currentCover, int attemptCap) {
        CoverPoint starvedCandidate = null;
        CoverFinder admissionFinder = new CoverFinder(soldier.level());
        Vec3 admissionDirection = getCoverSearchDirection();
        SquadCoverContext admissionSquad = buildSquadCoverContext();
        for (CoverFinder.ScoredCover candidate : pool) {
            CoverPoint candidateCover = candidate.cover;
            if (!isUsableAgainstThreat(admissionFinder, candidateCover, admissionDirection)
                || admissionSquad.violatesDefensiveSpacing(candidateCover.getPosition())) {
                if (DiagnosticLogManager.isCoverLoggingEnabled()) {
                    StevesArmyMod.LOGGER.info("[CoverGoal] Soldier {} rejected pool candidate {} before reservation",
                        soldier.getId(), candidateCover.getPosition());
                }
                continue;
            }
            if (failedCoverPositions.contains(candidateCover.getPosition())) {
                if (attackDebugLog()) {
                    StevesArmyMod.LOGGER.info("[ReservePool] {} skip {} blacklisted",
                        soldier.getId(), candidateCover.getPosition().toShortString());
                }
                continue;
            }
            // Advance doctrine, ALL pools including the top-scored one: a
            // cover behind the advance is the turn-around, and protection
            // scoring loves it (the wall the squad just passed). A suppressed
            // soldier may keep near-side protection but not retreat down the
            // route — the 8-block pullback to the start building's face is
            // the in-game "he went back into the house" report.
            if (isBehindAttackSpine(candidateCover.getPosition())) {
                if (attackDebugLog()) {
                    StevesArmyMod.LOGGER.info("[ReservePool] {} skip {} behind-spine (prog {} vs {})",
                        soldier.getId(), candidateCover.getPosition().toShortString(),
                        String.format("%.1f", attackSpine != null
                            ? attackSpine.progress(candidateCover.getPosition()) : -1.0),
                        String.format("%.1f", attackSpine != null
                            ? attackSpine.progress(soldier.blockPosition()) : -1.0));
                }
                continue;
            }
            if (currentCover != null
                && candidateCover.getPosition().equals(currentCover.getPosition())) continue;
            if (currentCover != null
                && soldier.position().distanceTo(candidateCover.getPosition().getCenter())
                    < COVER_REACHED_DISTANCE) {
                continue;
            }
            // Base-of-fire row discipline, ALL pools: this is the single
            // choke point every dock attempt passes through, so the gunner
            // never commits a cover ahead of the squad's rifleman line no
            // matter which search branch produced it.
            if (violatesMgBackRow(candidateCover.getPosition())) {
                if (attackDebugLog()) {
                    StevesArmyMod.LOGGER.info("[ReservePool] {} skip {} mg-back-row",
                        soldier.getId(), candidateCover.getPosition().toShortString());
                }
                continue;
            }
            // Advance doctrine: a dock the navigation cannot EXACTLY reach is
            // not a dock. A partial A* path out of an enclosed pocket walks
            // the soldier the WRONG WAY — deeper into the building the route
            // is leaving — and the move still "starts", so the dock ladder
            // re-anchors him inside (the re-entry + in-place pinball). Budget
            // exhaustion is not a verdict: stop the pool rather than treat
            // every unprobed candidate as unreachable.
            if (attackSpineFramed()) {
                if (!hasExactPathValidationBudget()) {
                    if (attackDebugLog()) {
                        StevesArmyMod.LOGGER.info("[ReservePool] {} budget out at {}",
                            soldier.getId(), candidateCover.getPosition().toShortString());
                    }
                    starvedCandidate = candidateCover;
                    break;
                }
                if (!isExactCoverPathReachable(candidateCover)) {
                    if (attackDebugLog()) {
                        StevesArmyMod.LOGGER.info("[ReservePool] {} skip {} not-exact-reachable",
                            soldier.getId(), candidateCover.getPosition().toShortString());
                    }
                    continue;
                }
            }
            if (searchReserveAttempts >= attemptCap) break;
            if (commitCoverMove(candidateCover) == CoverMoveResult.COVER_STARTED) {
                return CoverMoveResult.COVER_STARTED;
            }
        }
        if (starvedCandidate == null) {
            return CoverMoveResult.NO_COVER_FOUND;
        }
        // Budget-starvation fallback: the exact-reach budget is shared with
        // the finder's own corridor validation, so a cover-rich stretch (the
        // street cover rows) drains all 16 during pool construction and every
        // pool walk then breaks at its first candidate — the search fails
        // without a single movement attempt (run 103206: all four of the
        // leader's mid-street searches starved and he crossed the street
        // dockless). The starved candidate already passed the behind-spine
        // and blacklist filters (they run before the budget check), and the
        // advance's spine hop legs service the approach, so attempt it
        // blind: a genuine unreachable dock still blacklists here and the
        // next search tries the next candidate.
        if (attackDebugLog()) {
            StevesArmyMod.LOGGER.info("[ReservePool] {} budget-starved, attempting {} blind",
                soldier.getId(), starvedCandidate.getPosition().toShortString());
        }
        return commitCoverMove(starvedCandidate);
    }

    /**
     * Reserves and starts movement to a candidate the pool filters already
     * accepted. Both failure modes (reserve conflict, failed path start)
     * blacklist/release/clear as needed and report NO_COVER_FOUND so the
     * caller can move to the next candidate or end the pool.
     */
    private CoverMoveResult commitCoverMove(CoverPoint candidateCover) {
        if (!CoverReservationManager.reserve(candidateCover.getPosition(), soldier)) {
            if (attackDebugLog()) {
                StevesArmyMod.LOGGER.info("[ReservePool] {} skip {} reserve-conflict",
                    soldier.getId(), candidateCover.getPosition().toShortString());
            }
            return CoverMoveResult.NO_COVER_FOUND;
        }
        searchReserveAttempts++;
        getCoverManager().setTargetCover(candidateCover);
        if (soldier.hasValidAttackTarget()) {
            attackExpectedCover = candidateCover.getPosition();
        }
        boolean movementStarted = moveToCover(candidateCover);
        if (!movementStarted && pendingRetryCover == null && !isReloadBlockedMove()) {
            blacklistCover(candidateCover.getPosition(), BlacklistReason.PATH_FAILED);
            CoverReservationManager.release(candidateCover.getPosition(), soldier);
            getCoverManager().clearTargetCover();
            return CoverMoveResult.NO_COVER_FOUND;
        }
        return CoverMoveResult.COVER_STARTED;
    }

    /**
     * Runs the exposed-combat doctrine for a soldier whose search produced no
     * usable cover: a deliberate action (plant and engage, bounded sidestep,
     * withdraw, deliberate hold) instead of a frozen seek state.
     */
    private void runExposedCombatFallback() {
        if (!StevesArmyConfig.isExposedCombatEnabled() || relocationType != RelocationType.NONE) {
            return;
        }
        double nearestDistSq = Double.MAX_VALUE;
        for (ThreatAwareness.ThreatInfo info : getThreats().getThreatInfos()) {
            double d = soldier.distanceToSqr(Vec3.atCenterOf(info.position));
            if (d < nearestDistSq) nearestDistSq = d;
        }
        boolean hasLoS = false;
        LivingEntity combatTarget = soldier.getTarget();
        if (combatTarget != null && combatTarget.isAlive()) {
            hasLoS = TargetAcquisition.hasLineOfSight(soldier, combatTarget);
        }
        boolean gunReady = GunIntegration.isAnyGunLoaded() && GunIntegration.hasGun(soldier)
            && !soldier.isPreparingOrReloading();
        ExposedCombatController.Decision decision = ExposedCombatController.decide(
            soldier, Math.sqrt(nearestDistSq), hasLoS, gunReady, getCoverManager().isSuppressed());
        Vec3 move = decision.moveTarget;
        // Advance doctrine: a withdraw target behind the spine is the
        // mid-advance turn-around — hold the plant instead of retreating
        // into the route's rear.
        if (move != null && isBehindAttackSpine(BlockPos.containing(move.x, move.y, move.z))) {
            move = null;
        }
        if (move != null) {
            // Plain vanilla navigation: the controller's freeze gates must
            // not apply to doctrine moves, and short nudges do not need
            // the cover-path machinery.
            soldier.getNavigation().moveTo(move.x, soldier.getY(), move.z, 1.0);
        } else {
            // Stationary doctrine action: hold the plant against immediate
            // seek re-entry so a coverless fight doesn't churn position.
            ExposedCombatController.armPlantHold(soldier);
            soldier.getNavigation().stop();
        }
        if (DiagnosticLogManager.isCoverLoggingEnabled()) {
            StevesArmyMod.LOGGER.info("[ExposedCombat] Soldier {} -> {} ({})",
                soldier.getId(), decision.action, decision.reason);
        }
    }

    private int reserveAttemptsCap(BlockPos searchCenter) {
        // Close combat bounds the churn as well as the distance: a close-range
        // seek that falls through many candidates in one round reads as cover
        // hopping. Two attempts, then the seek lifecycle's cooldown applies.
        if ((soldier.isInCloseCombatContext() || soldier.hasCloseRangeTarget())
            && (searchCenter == null || searchCenter.distSqr(soldier.blockPosition()) <= 4)) {
            return Math.min(2, MAX_RESERVE_CANDIDATE_ATTEMPTS);
        }
        return MAX_RESERVE_CANDIDATE_ATTEMPTS;
    }

    private Optional<CoverPoint> selectBestAvailableCover(CoverFinder finder,
                                                            List<CoverFinder.ScoredCover> scored,
                                                            Vec3 threatDirection) {
        if (scored == null || scored.isEmpty()) {
            return Optional.empty();
        }

        if (getThreats().hasActiveThreat() && threatDirection != null && threatDirection.lengthSqr() > 0.001) {
            List<CoverFinder.ScoredCover> protectedCovers = scored.stream()
                .filter(sc -> CoverReservationManager.isAvailable(sc.cover.getPosition()))
                .filter(sc -> finder.isPrimaryThreatProtected(sc.cover, soldier, threatDirection))
                .toList();
            if (!protectedCovers.isEmpty()) {
                return Optional.of(protectedCovers.get(0).cover);
            }
            return Optional.empty();
        }

        return scored.stream()
            .filter(sc -> CoverReservationManager.isAvailable(sc.cover.getPosition()))
            .map(sc -> sc.cover)
            .findFirst();
    }

    private boolean isUsableAgainstThreat(CoverFinder finder, CoverPoint cover, Vec3 threatDirection) {
        if (cover == null || threatDirection == null || threatDirection.lengthSqr() < 0.001D) {
            return false;
        }
        return finder.isPrimaryThreatProtected(cover, soldier, threatDirection);
    }

    /** Includes failed suppression searches that return before the normal prone selector. */
    private boolean tryStartSpacedProneFallback() {
        if (relocationType != RelocationType.NONE || getCoverManager().getCurrentCover() != null
            || getCoverManager().getTargetCover() != null || proneFiringController.isPlanActive()) return false;
        if (soldier.tickCount - lastProneFallbackSearchTick < 20) return false;
        lastProneFallbackSearchTick = soldier.tickCount;
        SquadCoverContext squad = buildSquadCoverContext();
        Vec3 direction = getCoverSearchDirection();
        CoverFinder finder = new CoverFinder(soldier.level());
        ExactPathValidationBudget budget = new ExactPathValidationBudget();
        for (CoverFinder.ScoredCover scored : finder.evaluateAndScoreAll(soldier, direction,
            getThreatList(), SEARCH_RADIUS, true, squad)) {
            CoverPoint cover = scored.cover;
            if (!isUsableAgainstThreat(finder, cover, direction)
                || squad.violatesDefensiveSpacing(cover.getPosition())
                || !CoverReservationManager.isAvailableFor(cover.getPosition(), soldier)) continue;
            if (!budget.tryAcquire()) return false;
            Path path = navigation.createPath(cover.getPosition(), 0);
            if (path != null && path.canReach()) return false;
        }
        var prone = DefensivePositionSelector.selectProne(soldier, soldier.getTarget(), getThreats(),
            List.of(), squad, new ExactPathValidationBudget(), direction);
        if (prone.isEmpty()) return false;
        startProneFiringMovement(prone.get());
        return proneFiringController.isPlanActive();
    }

    private void startProneFiringMovement(DefensivePositionCandidate.ProneFiringCandidate candidate) {
        SquadCoverContext spacing = buildSquadCoverContext();
        Vec3 spacingPosition = candidate.destination().equals(soldier.blockPosition())
            ? soldier.position() : Vec3.atBottomCenterOf(candidate.destination());
        if (spacing.violatesDefensiveSpacing(spacingPosition)) return;
        if (candidate.destination().equals(soldier.blockPosition())
            && !spacing.violatesDefensiveSpacing(soldier.position())) {
            navigation.stop();
            proneFiringDestination = null;
            getPositionController().clear();
            getCoverManager().setState(CoverBehaviorManager.CoverState.NO_COVER);
            if (proneFiringController.begin(candidate, true) && DiagnosticLogManager.isCoverLoggingEnabled()) {
                StevesArmyMod.LOGGER.info("[DefensivePosition] Soldier {} selected current prone lane {} ({})",
                    soldier.getId(), candidate.destination(), candidate.diagnostics());
            }
            return;
        }
        if (!proneFiringController.begin(candidate, false)) {
            return;
        }
        proneFiringDestination = candidate.destination();
        Path path = navigation.createPath(candidate.destination(), 0);
        if (path == null || !path.canReach()) {
            proneFiringController.cancel("path_failed");
            proneFiringDestination = null;
            return;
        }
        navigation.moveTo(path, 1.0D);
        getCoverManager().clearTargetCover();
        getCoverManager().setState(CoverBehaviorManager.CoverState.SEEKING_COVER);
        if (DiagnosticLogManager.isCoverLoggingEnabled()) {
            StevesArmyMod.LOGGER.info("[DefensivePosition] Soldier {} selected prone lane {} access={} protection={} cost={} ({})",
                soldier.getId(), candidate.destination(), candidate.firingAccess(), candidate.protection(),
                candidate.movementCost(), candidate.diagnostics());
        }
    }

    private void cancelProneFiringPlan() {
        proneFiringDestination = null;
        proneFiringController.cancel("physical_cover_selected");
    }

    /** Exposes both pending and occupied prone lanes to squadmate spacing checks. */
    public BlockPos getProneDefensivePosition() {
        return proneFiringDestination != null ? proneFiringDestination : proneFiringController.getDestination();
    }

    private void logCoverSearchPerformance(CoverFinder finder, long started,
                                            CoverMoveResult result, String phase) {
        long totalNanos = System.nanoTime() - started;
        String mode = getExecutingSearchMode().name();
        debugLastSearchMode = mode;
        debugLastSearchResult = result.name();
        debugLastSearchPhase = phase;
        debugLastSearchTick = soldier.tickCount;
        if (com.stevesarmy.debug.trace.SoldierFlightRecorder.isRecording()) {
            com.stevesarmy.debug.trace.SoldierFlightRecorder.event(soldier, "cover-search-result", result.name(),
                java.util.Map.of("mode", mode, "phase", phase, "center", String.valueOf(debugSearchCenter),
                    "radius", debugSearchRadius, "candidates", finder.getCandidatesDiscovered(),
                    "evaluated", finder.getCandidatesEvaluated(), "elapsedNanos", totalNanos));
        }
        PerformanceMetrics.recordCoverSearchOutcome(mode, result.name(), phase,
            exactPathValidationBudget.getUsed(), exactPathValidationBudget.isExhausted());
        if (result == CoverMoveResult.COVER_STARTED) {
            noCoverSearchStreak = 0;
            clearFailedSearch();
        } else {
            if (result == CoverMoveResult.NO_COVER_FOUND
                || result == CoverMoveResult.NO_ELIGIBLE_COVER) {
                noCoverSearchStreak++;
            }
            recordFailedSearch(getExecutingSearchMode(), result, phase);
        }
        if (!DiagnosticLogManager.isCoverPerformanceLoggingEnabled()) return;

        StevesArmyMod.LOGGER.info(
            "[CoverPerf] soldier={} name={} tick={} mode={} phase={} result={} totalMs={} discoveryMs={} scoringMs={} candidates={} evaluated={} target={} pos={}",
            soldier.getId(), soldier.getName().getString(), soldier.tickCount, mode, phase, result,
            formatMillis(totalNanos), formatMillis(finder.getCandidateDiscoveryNanos()),
            formatMillis(finder.getTacticalScoringNanos()), finder.getCandidatesDiscovered(),
            finder.getCandidatesEvaluated(),
            getCoverManager().getTargetCover() != null ? getCoverManager().getTargetCover().getPosition() : "null",
            soldier.blockPosition());
    }

    private QueuedSearchMode getExecutingSearchMode() {
        if (executingSearchMode != null) return executingSearchMode;
        if (suppressionRouteSearchActive) {
            return emergencyCoverSearchActive ? QueuedSearchMode.SHOT_IN_COVER
                : QueuedSearchMode.SUPPRESSION_REPOSITION;
        }
        if (relocationType == RelocationType.GO_TO) return QueuedSearchMode.REPOSITION;
        if (relocationType == RelocationType.FOLLOW) return QueuedSearchMode.REPOSITION;
        return soldier.hasValidAttackTarget() ? QueuedSearchMode.ATTACK_SELECTING : QueuedSearchMode.NORMAL;
    }

    private static String formatMillis(long nanos) {
        return String.format(java.util.Locale.ROOT, "%.2f", nanos / 1_000_000.0);
    }

    /** Runs Phase 4 and/or Phase 5 beside routine rifleman NORMAL searches. */
    private void runPureCoverShadow(Vec3 threatDirection, List<LivingEntity> threats,
                                    SquadCoverContext squadContext,
                                    List<CoverFinder.ScoredCover> legacyScored,
                                    BlockPos searchCenter, int searchRadius) {
        boolean phase4Enabled = StevesArmyConfig.isPureEvaluatorShadowEnabled();
        boolean phase5Enabled = StevesArmyConfig.isAsyncCoverShadowEnabled() && !machineGunnerPipeline;
        if (!phase4Enabled && !phase5Enabled) {
            PerformanceMetrics.recordPhase4Skip();
            return;
        }
        if (legacyScored == null || legacyScored.isEmpty()) {
            if (phase4Enabled) {
                PerformanceMetrics.recordPhase4Skip();
            }
            return;
        }

        CoverProtectionContext protection = soldier.getCombatGoal() != null
            ? soldier.getCombatGoal().resolveCoverProtectionContext()
            : CoverProtectionContext.NONE;
        long captureStarted = System.nanoTime();
        CoverSnapshotCapture.Capture capture;
        try {
            capture = CoverSnapshotCapture.capture(
                soldier.level(), soldier, threatDirection, protection, threats, squadContext,
                legacyScored, searchCenter, searchRadius);
        } catch (RuntimeException exception) {
            if (phase4Enabled) {
                PerformanceMetrics.recordPhase4Skip();
            }
            if (phase5Enabled) {
                PerformanceMetrics.recordPhase5SnapshotFailure();
            }
            StevesArmyMod.LOGGER.warn("Cover shadow snapshot failed for soldier {}", soldier.getId(), exception);
            return;
        }
        long captureNanos = System.nanoTime() - captureStarted;
        if (phase4Enabled) {
            PerformanceMetrics.recordPhase4Capture(captureNanos,
                capture.input().candidates().size());
        }
        if (phase5Enabled) {
            PerformanceMetrics.recordPhase5Snapshot(captureNanos);
        }

        if (phase4Enabled) {
            List<BlockPos> legacyPositions = legacyScored.stream()
                .map(scored -> scored.cover.getPosition()).toList();
            long evaluationStarted = System.nanoTime();
            CoverSearchResult pure = PureCoverEvaluator.evaluate(capture.input(), capture.terrain());
            long evaluationNanos = System.nanoTime() - evaluationStarted;
            PerformanceMetrics.recordPhase4Evaluation(evaluationNanos);

            CoverSearchResult.RankedCandidate pureTop = pure.top();
            BlockPos legacyTop = legacyPositions.get(0);
            boolean topMatches = pureTop != null && legacyTop.equals(pureTop.candidate().position());
            PerformanceMetrics.recordPhase4Top1Comparison(topMatches);

            int comparableCount = Math.min(legacyPositions.size(), pure.positions().size());
            boolean orderingMatches = comparableCount > 0
                && legacyPositions.subList(0, comparableCount).equals(pure.positions().subList(0, comparableCount));
            PerformanceMetrics.recordPhase4OrderingComparison(orderingMatches);
        }

        if (phase5Enabled && soldier.level() instanceof ServerLevel serverLevel) {
            List<BlockPos> legacyPositions = legacyScored.stream()
                .map(scored -> scored.cover.getPosition()).toList();
            AsyncCoverShadowService.submit(serverLevel, soldier.getUUID(), capture, legacyPositions);
        }
    }
    
private Optional<CoverPoint> findBetterCover() {
        Level level = soldier.level();
        CoverFinder finder = new CoverFinder(level);

        Vec3 threatDirection = getCoverSearchDirection();
        List<LivingEntity> threats = getThreatList();
        SquadCoverContext squadCtx = buildSquadCoverContext();

        if (DiagnosticLogManager.isCoverLoggingEnabled()) {
            StevesArmyMod.LOGGER.info("[CoverGoal] Soldier {} finding cover: soldierPos={}, threatDirection=({}, {}, {}), threats={}",
                soldier.getId(),
                soldier.blockPosition(),
                threatDirection != null ? String.format("%.2f", threatDirection.x) : "null",
                threatDirection != null ? String.format("%.2f", threatDirection.y) : "null",
                threatDirection != null ? String.format("%.2f", threatDirection.z) : "null",
                threats.size());
        }

        CoverPoint currentCover = getCoverManager().getCurrentCover();

        Optional<CoverPoint> result = finder.findBestCover(soldier, threatDirection, threats, SEARCH_RADIUS, squadCtx);

        if (result.isPresent() && currentCover != null && result.get().getPosition().equals(currentCover.getPosition())) {
            List<CoverFinder.ScoredCover> top2 = finder.findTopCovers(soldier, threatDirection, threats, SEARCH_RADIUS, 2, false);
            if (top2.size() >= 2) {
                result = Optional.of(top2.get(1).cover);
            } else {
                result = Optional.empty();
            }
        }

        boolean wantsDebug = DiagnosticLogManager.isCoverLoggingEnabled() || CoverDebugManager.isShowSoldierCover();
        if (wantsDebug) {
            List<CoverFinder.ScoredCover> top = finder.findTopCovers(soldier, threatDirection, threats, SEARCH_RADIUS, 5, true);
            cachedTopCovers = top.toArray(new CoverFinder.ScoredCover[0]);
        }

        return result;
    }

    private void populateCoverDebugData() {
        CoverPoint currentCover = getCoverManager().getCurrentCover();
        CoverPoint targetCover = getCoverManager().getTargetCover();
        
        boolean wantsDebug = DiagnosticLogManager.isCoverScoreLoggingEnabled()
            || CoverDebugManager.isShowSoldierCover() || CoverDebugManager.isVisualizationEnabled();
        if (wantsDebug && (cachedTopCovers.length == 0 || soldier.tickCount % 10 == 0)) {
            CoverFinder finder = new CoverFinder(soldier.level());
Vec3 threatDirection = getThreats().getPrimaryDirection(soldier.position());
        List<LivingEntity> threats = getThreatList();
        SquadCoverContext squadCtx = buildSquadCoverContext();
            List<CoverFinder.ScoredCover> top = finder.findTopCovers(soldier, threatDirection, threats, SEARCH_RADIUS, 5, true);
            cachedTopCovers = top.toArray(new CoverFinder.ScoredCover[0]);
        }
        
        if (cachedTopCovers.length == 0) return;
        
        BlockPos chosenPos = targetCover != null ? targetCover.getPosition() : 
                            (currentCover != null ? currentCover.getPosition() : null);
        
        int[] rejectionReasons = new int[cachedTopCovers.length];
        for (int i = 0; i < cachedTopCovers.length; i++) {
            BlockPos pos = cachedTopCovers[i].cover.getPosition();
            if (chosenPos != null && pos.equals(chosenPos)) {
                rejectionReasons[i] = CoverDebugManager.TopCoversDebugData.REASON_CHOSEN;
            } else if (currentCover != null && pos.equals(currentCover.getPosition())) {
                rejectionReasons[i] = CoverDebugManager.TopCoversDebugData.REASON_ALREADY_CURRENT;
            } else if (failedCoverPositions.contains(pos)) {
                rejectionReasons[i] = CoverDebugManager.TopCoversDebugData.REASON_BLACKLISTED;
            } else if (!CoverReservationManager.isAvailable(pos)) {
                rejectionReasons[i] = CoverDebugManager.TopCoversDebugData.REASON_RESERVED;
            } else {
                rejectionReasons[i] = CoverDebugManager.TopCoversDebugData.REASON_NONE;
            }
        }
        
        long now = GameClock.nowMs();
        java.util.Map<BlockPos, CoverDebugManager.BlacklistDebugEntry> blacklistInfo = new java.util.HashMap<>();
        for (java.util.Map.Entry<BlockPos, BlacklistEntry> entry : blacklistReasons.entrySet()) {
            int ageSeconds = (int)(entry.getValue().getAgeMs(now) / 1000);
            blacklistInfo.put(entry.getKey(), new CoverDebugManager.BlacklistDebugEntry(entry.getValue().reason.label, ageSeconds));
        }
        
        CoverDebugManager.setSoldierTopCovers(soldier.getId(),
            new CoverDebugManager.TopCoversDebugData(
                cachedTopCovers,
                rejectionReasons,
                chosenPos,
                currentCover != null ? currentCover.getCombatScore() : 0,
                getCoverManager().getCoverQualityPenalty(),
                getCoverManager().getPeekCountSameCover(),
                blacklistInfo
            ));
        
        if (CoverDebugManager.isShowSearchCenter() && debugSearchCenter != null) {
            CoverDebugManager.setSearchCenterPos(debugSearchCenter);
        }
    }
    
    // --- Attack Phase Methods ---

    /**
     * Unified forward-progress predicate for attack-mode cover candidates.
     * A candidate is valid only if it moves the soldier toward the objective
     * and does not regress behind the best progress made this command.
     */
    private boolean isForwardCoverCandidate(CoverPoint candidate, BlockPos objective, Vec3 objectiveDir) {
        BlockPos candidatePos = candidate.getPosition();
        if (objectiveDir == null) return false;

        // Path-based frame: progress is walked distance gained along the
        // advance spine, so a cover that only "advances" on the straight
        // line (across an interior wall) is rejected and the true exit
        // route's covers qualify even while they locally walk away from
        // the objective. The minimum gain is a FULL HOP of route: docks
        // that buy less turn the route's interior corridor into a dock
        // relay (the house-interior orbit) instead of a walk to the exit.
        // A candidate must also sit AHEAD of the spine frontier —
        // regressing behind the best reached point is the pocket orbit,
        // not progress.
        if (attackSpine != null) {
            // Dock gain is measured against the FRONTIER (best dock progress
            // this command), not the soldier's current position: hop legs
            // legitimately carry the soldier past the frontier, and the row
            // he lands beside must still be dockable — while wall micro-docks
            // a few blocks ahead of the frontier stay rejected.
            double candProg = attackSpine.progress(candidatePos);
            double frontier = Math.max(attackSpineProgressFrontier,
                attackSpine.progress(soldier.blockPosition()));
            // The long interior hop prevents relaying around the same house
            // wall. In an open street it instead rejected the next cover row
            // (often only five blocks away), forcing uncovered fallback legs.
            boolean openLowCover = soldier.level().canSeeSky(BlockPos.containing(soldier.getEyePosition()))
                && soldier.level().canSeeSky(candidatePos.above(2))
                && candidate.getType() == CoverType.HALF;
            double minimumGain = openLowCover
                ? ATTACK_MIN_FORWARD_PROGRESS : ATTACK_SPINE_HOP_LENGTH;
            if (candProg < frontier + minimumGain) {
                return false;
            }
            if (attackSpineProgressFrontier > -Double.MAX_VALUE / 2.0D
                && candProg < attackSpineProgressFrontier - ATTACK_FRONTIER_TOLERANCE) {
                return false;
            }
            return true;
        }

        // Minimum projected forward progress from current position
        Vec3 candidateCenter = candidatePos.getCenter();
        Vec3 disp = candidateCenter.subtract(soldier.position());
        double forwardProgress = disp.x * objectiveDir.x + disp.z * objectiveDir.z;
        if (forwardProgress < ATTACK_MIN_FORWARD_PROGRESS) {
            return false;
        }

        // Must be closer to objective than soldier currently is
        double distToObj = candidatePos.distSqr(objective);
        double soldierDist = soldier.blockPosition().distSqr(objective);
        if (distToObj >= soldierDist - 0.01) {
            return false;
        }

        // Must not regress behind the forward frontier (best progress this command)
        if (attackFrontierDistance < Double.MAX_VALUE && distToObj > attackFrontierDistance + ATTACK_FRONTIER_TOLERANCE * ATTACK_FRONTIER_TOLERANCE) {
            return false;
        }

        return true;
    }

    private boolean isAttackCorridorCandidate(CoverPoint candidate, BlockPos objective, Vec3 objectiveDir) {
        BlockPos candidatePos = candidate.getPosition();
        if (!isForwardCoverCandidate(candidate, objective, objectiveDir)) return false;

        // Spine frame: the corridor is a band along the route, and the next
        // dock may not be more than one corridor-length of route ahead.
        if (attackSpine != null) {
            double delta = attackSpine.progress(candidatePos)
                - attackSpine.progress(soldier.blockPosition());
            return delta <= ATTACK_CORRIDOR_FORWARD_LENGTH
                && attackSpine.corridorDistance(candidatePos) <= ATTACK_SPINE_CORRIDOR_WIDTH;
        }

        Vec3 displacement = candidatePos.getCenter().subtract(soldier.position());
        double forward = displacement.x * objectiveDir.x + displacement.z * objectiveDir.z;
        double lateral = Math.abs(displacement.x * objectiveDir.z - displacement.z * objectiveDir.x);
        return forward <= ATTACK_CORRIDOR_FORWARD_LENGTH && lateral <= ATTACK_CORRIDOR_HALF_WIDTH;
    }

    /**
     * True while the attack-spine frame should constrain dock acceptance:
     * an active corridor advance (valid target, live spine) with no clearing
     * job and no secured hold owning the soldier. Interior clearing docks and
     * SECURE watch positions are progression-neutral by design and stay
     * unframed.
     */
    private boolean attackSpineFramed() {
        return attackSpine != null
            && soldier.hasValidAttackTarget()
            && !clearingHold()
            && clearingPoiTarget == null;
    }

    /**
     * Mild spine frame for the RESERVATION FALLBACK pools. The primary
     * corridor pool demands a full hop of forward progress, but a follower
     * whose forward docks are taken may hold adjacent on-route protection —
     * he just may not take a cover meaningfully BEHIND him. Without this
     * filter the fallback pools score by protection alone, and the walls of
     * the building the squad just exited outrank every spine-forward
     * candidate (the mid-advance turn-around).
     *
     * When the spine is DOWN (end-of-route drop + re-probe backoff — the
     * whole final approach to an enclosed objective), the filter falls back
     * to the objective bearing. Otherwise the backward filter goes inert
     * exactly where protection scoring pulls hardest, and the last dock
     * before the objective is a cover behind the soldier (run 100647:
     * charlie re-docked 3 blocks west of his high-water on B's south-west
     * corner during the null window).
     */
    private boolean isBehindAttackSpine(BlockPos pos) {
        if (attackSpineFramed()) {
            return attackSpine.progress(pos)
                < attackSpine.progress(soldier.blockPosition()) - 2.0D;
        }
        return behindAlongObjectiveBearing(pos, 2.0D);
    }

    /**
     * Hard backward test for docks the cover system chose OUTSIDE the attack
     * search (suppression parking, emergency relocation): a dock half a
     * corridor behind the soldier is the building he came from, not route
     * protection, and must not be ratified as an attack arrival.
     */
    private boolean isBackwardAttackDock(BlockPos pos) {
        if (attackSpineFramed()) {
            return attackSpine.progress(pos)
                < attackSpine.progress(soldier.blockPosition()) - 6.0D;
        }
        return behindAlongObjectiveBearing(pos, 6.0D);
    }

    /**
     * Spineless "behind" test: signed distance along the straight bearing to
     * the attack objective. Only meaningful while the order is active and the
     * objective is still ahead of this soldier.
     */
    private boolean behindAlongObjectiveBearing(BlockPos pos, double blocks) {
        if (!StevesArmyConfig.isAttackPathSpineEnabled() || clearingPoiTarget != null) {
            return false;
        }
        BlockPos objective = soldier.getAttackTargetPos();
        if (objective == null) {
            return false;
        }
        Vec3 bearing = Vec3.atCenterOf(objective).subtract(soldier.position());
        double bearingLen = bearing.horizontalDistance();
        if (bearingLen < 1.0E-4) {
            return false;
        }
        Vec3 offset = Vec3.atCenterOf(pos).subtract(soldier.position());
        double along = (offset.x * bearing.x + offset.z * bearing.z) / bearingLen;
        return along < -blocks;
    }

    /**
     * Exposure gate (the interior-walk doctrine): with the spine alive but NO
     * line of sight to the objective — the start building's interior — and no
     * personal suppression, the interior segment of the route is WALKED along
     * the spine instead of relayed dock-to-dock. The only cover inside is the
     * building's own walls, so every dock the search can take there is the
     * deeper-into-the-house turn-around. Contact is deliberately NOT a veto:
     * it is squad-shared, so a front soldier's sighting would otherwise lift
     * the gate for everyone still inside; each walk leg is vetted per-tick by
     * ContactPlan.checkAdvance, and personally pinned soldiers keep the
     * suppression machinery (the gate lifts for them until they recover).
     */
    private boolean spineInteriorWalkGate() {
        return attackSpine != null
            && StevesArmyConfig.isAttackPathSpineEnabled()
            && !attackSpineExposed
            && !getCoverManager().isSuppressed()
            && clearingPoiTarget == null
            && !clearingHold();
    }

    /**
     * Base-of-fire row discipline (ContactPlan's "mg back row" gate mirrored
     * for cover selection): the machine gunner is the squad's support weapon —
     * he advances cover-to-cover BEHIND the squad's frontmost rifleman, never
     * into the assault line. Active whenever the gunner has an attack target
     * and at least one living non-MG squadmate; solo gunners and HOLD mode are
     * exempt.
     */
    private boolean mgBackRowRuleActive() {
        return soldier.getRole() == SoldierRole.MACHINE_GUNNER
            && soldier.hasValidAttackTarget()
            && ContactPlan.frontAssaultDistance(soldier,
                Vec3.atCenterOf(soldier.getAttackTargetPos())) != Double.MAX_VALUE;
    }

    /** True when this cover position sits ahead of the squad's rifleman line. */
    private boolean violatesMgBackRow(BlockPos coverPos) {
        if (!mgBackRowRuleActive()) return false;
        Vec3 reference = Vec3.atCenterOf(soldier.getAttackTargetPos());
        double frontDist = ContactPlan.frontAssaultDistance(soldier, reference);
        return Vec3.atCenterOf(coverPos).distanceTo(reference)
            < frontDist - MG_BACK_ROW_LAG_BLOCKS;
    }

    /**
     * Base-of-fire row hold for a DOCKED machine gunner: true while the
     * squad's rifleman line has not yet passed his current cover by the
     * leapfrog margin — the dock is still the back row, so his job there is
     * holding the firing lane, and the peek system's "blind dock is useless"
     * eviction and the dwell clock's cover-cycling do not apply. Static so
     * PeekController can consult it without a goal reference.
     */
    public static boolean mgRowHoldActive(SoldierEntity soldier) {
        if (soldier.getRole() != SoldierRole.MACHINE_GUNNER
            || !soldier.hasValidAttackTarget()) {
            return false;
        }
        CoverBehaviorManager manager = soldier.getCoverBehaviorManager();
        if (manager == null || manager.getCurrentCover() == null) {
            return false;
        }
        Vec3 reference = Vec3.atCenterOf(soldier.getAttackTargetPos());
        double frontDist = ContactPlan.frontAssaultDistance(soldier, reference);
        if (frontDist == Double.MAX_VALUE) {
            return false;
        }
        double dockDist = Vec3.atCenterOf(manager.getCurrentCover().getPosition())
            .distanceTo(reference);
        return frontDist > dockDist - MG_LEAPFROG_MARGIN_BLOCKS;
    }

    /**
     * Finds a path-reachable forward cover outside the preferred narrow corridor.
     * Protection is a preference here so a structure cannot trap an ATTACK soldier
     * when its usable exit cover is not aligned with the current threat direction.
     */
    private Optional<CoverPoint> findWideForwardAttackCover(List<CoverFinder.ScoredCover> scored,
                                                              CoverPoint currentCover, BlockPos objective,
                                                              Vec3 objectiveDir, Direction threatDir) {
        CoverPoint bestCover = null;
        int bestPathNodes = Integer.MAX_VALUE;
        boolean bestProtected = false;
        CoverFinder protectionFinder = new CoverFinder(soldier.level());
        boolean requiresProtection = protectionFinder.hasPrimaryThreat(soldier,
            getThreats().getPrimaryDirection(soldier.position()));

        for (CoverFinder.ScoredCover sc : scored) {
            CoverPoint cover = sc.cover;
            if (currentCover != null && cover.getPosition().equals(currentCover.getPosition())) continue;
            if (failedCoverPositions.contains(cover.getPosition())) continue;
            if (violatesMgBackRow(cover.getPosition())) continue;
            if (!isForwardCoverCandidate(cover, objective, objectiveDir)) continue;
            if (cover.getPosition().distSqr(objective) <= ATTACK_OBJECTIVE_RADIUS * ATTACK_OBJECTIVE_RADIUS) continue;

            Vec3 displacement = cover.getPosition().getCenter().subtract(soldier.position());
            double forward = displacement.x * objectiveDir.x + displacement.z * objectiveDir.z;
            double lateral = Math.abs(displacement.x * objectiveDir.z - displacement.z * objectiveDir.x);
            if (forward > ATTACK_CORRIDOR_FORWARD_LENGTH || lateral > ATTACK_WIDE_SECTOR_HALF_WIDTH) continue;

            // Reuse an exact path already validated this tick; an accuracy-1 probe
            // that cannot reach within one block could not reach exactly either,
            // so its miss feeds the shared negative cache.
            Path path = validatedCoverPaths.get(cover.getPosition());
            if (path == null) {
                if (!exactPathValidationBudget.tryAcquire()) {
                    PerformanceMetrics.recordExactCoverPathValidationBudgetExhausted();
                    break;
                }
                Vec3 standingPos = getCoverStandingPosition(cover.getPosition());
                path = navigation.createPath(standingPos.x, standingPos.y, standingPos.z, 1);
                if (path == null || !path.canReach()) {
                    unreachableCoverPaths.add(cover.getPosition().immutable());
                    continue;
                }
            }

            boolean protectedFromThreat = protectionFinder
                .isPrimaryThreatProtected(cover, soldier, getThreats().getPrimaryDirection(soldier.position()));
            int pathNodes = path.getNodeCount();
            if (bestCover == null || (protectedFromThreat && !bestProtected)
                || (protectedFromThreat == bestProtected && pathNodes < bestPathNodes)) {
                bestCover = cover;
                bestPathNodes = pathNodes;
                bestProtected = protectedFromThreat;
            }
        }

        return requiresProtection && !bestProtected ? Optional.empty() : Optional.ofNullable(bestCover);
    }

    private void logRejectedAttackCover(CoverPoint cover, BlockPos objective, Vec3 objectiveDir) {
        if (!attackDebugLog() || objectiveDir == null) return;

        Vec3 displacement = cover.getPosition().getCenter().subtract(soldier.position());
        double forwardProgress = displacement.x * objectiveDir.x + displacement.z * objectiveDir.z;
        double candidateDistance = cover.getPosition().distSqr(objective);
        double soldierDistance = soldier.blockPosition().distSqr(objective);
        boolean regressesFrontier = attackFrontierDistance < Double.MAX_VALUE
            && candidateDistance > attackFrontierDistance + ATTACK_FRONTIER_TOLERANCE * ATTACK_FRONTIER_TOLERANCE;

        StevesArmyMod.LOGGER.info("[AttackForward] Soldier {} ({}) rejected cover {}: progress={}, candidateDist={}, soldierDist={}, frontier={}, frontierRegression={}",
            soldier.getId(), soldier.getName().getString(), cover.getPosition(),
            String.format("%.1f", forwardProgress), String.format("%.1f", candidateDistance),
            String.format("%.1f", soldierDistance), String.format("%.1f", attackFrontierDistance),
            regressesFrontier);
    }

    /**
     * Update attack progress frontier when the soldier arrives at a cover
     * or completes a direct bound. This prevents regression behind this point.
     */
    private void updateAttackProgress(BlockPos objective) {
        double distSq = soldier.blockPosition().distSqr(objective);
        if (distSq < attackBestObjectiveDist) {
            attackBestObjectiveDist = distSq;
        }
        // Frontier is slightly ahead of best progress to allow some lateral movement
        attackFrontierDistance = attackBestObjectiveDist;
        // Spine-frame frontier: the furthest point along the advance route
        // this command has reached. Lateral movement along the route is
        // free; regressing behind it (pocket orbit) is filtered out.
        if (attackSpine != null) {
            double prog = attackSpine.progress(soldier.blockPosition());
            if (prog > attackSpineProgressFrontier) {
                attackSpineProgressFrontier = prog;
            }
        }
    }

    /**
     * Full reset for a new attack command. Called when attackGeneration changes
     * while the goal is already running. Cancels old movement, clears stale
     * state, but preserves current occupied cover if any so the soldier
     * doesn't abandon protection unnecessarily.
     */
    private void resetAttackCommand() {
        CoverSearchScheduler.cancel(this);
        coverSearchPending = false;
        asyncPilotPending = false;
        asyncPilotSubmittedTick = Long.MIN_VALUE;
        queuedSearchMode = null;
        queuedAttackGeneration = -1;
        queuedRelocationType = RelocationType.NONE;
        queuedRelocationCenter = null;
        // Cancel old movement
        navigation.stop();
        getPositionController().clear();

        // Cancel fallback advance
        fallbackAdvanceTarget = null;
        fallbackAdvanceAssemble = false;
        fallbackStuckTicks = 0;
        fallbackLastPosition = null;
        fallbackNoProgressResets = 0;
        clearingUnreachableUntil.clear();
        clearingEgressTicks = 0;
        egressRetryAfterTick = 0;
        clearingEgressBestDistSq = -1.0;
        clearingStaleBestJob = null;
        clearingStaleBestDistSq = -1.0;

        // Cancel pending retry
        pendingRetryCover = null;
        isRetryAttempt = false;

        // Clear old target-cover reservation and stale cover state
        CoverPoint oldTarget = getCoverManager().getTargetCover();
        if (oldTarget != null) {
            CoverReservationManager.release(oldTarget.getPosition(), soldier);
        }
        getCoverManager().clearTargetCover();

        // Reset attack phase fields (same as initAttackPhase but
        // we do NOT change attackCommandGeneration — that's done by caller)
        attackPhase = AttackPhase.SELECTING_COVER;
        clearingPoiTarget = null;
        clearingStaleTargetTicks = 0;
        clearingLastDockPos = null;
        clearingAssembleTicks = 0;
        investigateJob = null;
        investigateStartPos = null;
        attackPhaseStartTime = GameClock.nowMs();
        attackCoverArrivalTime = 0;
        attackExpectedCover = null;
        attackDwellEligible = false;
        attackHasPeekedThisCover = false;
        peekCompletedThisCover = false;
        attackBestObjectiveDist = Double.MAX_VALUE;
        attackFrontierDistance = Double.MAX_VALUE;
        attackSpine = null;
        spineRetryAfterTick = 0;
        spineWaitUntilTick = soldier.tickCount + 40;
        attackSpineProgressFrontier = -Double.MAX_VALUE;
        clearingEgressBestProgress = -Double.MAX_VALUE;

        // Stagger for this command
        attackAdvanceStaggerTicks = Math.abs(soldier.getUUID().hashCode() % 60);

        // Preserve current occupied cover — don't call clearCover() here.
        // The soldier can start from where they are. If the current cover
        // is invalid for the new objective, SELECTING_COVER will find a new one.

        // Reset progress/stuck trackers
        noProgressTicks = 0;
        lastSeekingPosition = null;
        stuckTicks = 0;
        nonPeekableTicks = 0;

        if (attackDebugLog()) {
            StevesArmyMod.LOGGER.info("[AttackPhase] Soldier {} reset attack command gen {}, phase={}, coverState={}",
                soldier.getId(), soldier.getAttackGeneration(), attackPhase, getCoverManager().getState());
        }
    }

    /**
     * The cover-to-cover advance is finished: the objective radius has been
     * reached. End the attack command on this tick instead of letting the 60s
     * attack memory keep attack logic alive, so a soldier caught in the open
     * starts a hold-style cover search immediately — the same immediacy a
     * GO_TO order gets — rather than waiting on suppression or the routine
     * in-cover reevaluation.
     */
    private void completeAttackAtObjective() {
        // Pending attack searches are stale by definition: the corridor filter
        // rejects every cover inside the objective radius.
        CoverSearchScheduler.cancel(this);
        coverSearchPending = false;
        asyncPilotPending = false;
        asyncPilotSubmittedTick = Long.MIN_VALUE;
        queuedSearchMode = null;
        queuedAttackGeneration = -1;
        queuedRelocationType = RelocationType.NONE;
        queuedRelocationCenter = null;

        // Attack-phase movement ownership ends here; do not keep driving an
        // open-ground fallback bound past the objective.
        fallbackAdvanceTarget = null;
        fallbackStuckTicks = 0;
        fallbackLastPosition = null;
        fallbackNoProgressResets = 0;
        pendingRetryCover = null;
        isRetryAttempt = false;
        attackExpectedCover = null;
        consecutiveFailedSearches = 0;
        searchExhaustionCooldown = 0;

        if (getCoverManager().getState() == CoverBehaviorManager.CoverState.NO_COVER) {
            if (getCoverManager().getTargetCover() != null) {
                // A cover was already selected; its movement handlers continue.
                getCoverManager().setState(CoverBehaviorManager.CoverState.SEEKING_COVER);
            } else if (getCoverManager().getCurrentCover() == null) {
                // Exposed: request a hold-style search before the attack target
                // is released so this goal keeps running instead of stopping
                // into its restart cooldown.
                navigation.stop();
                getPositionController().clear();
                getCoverManager().setState(CoverBehaviorManager.CoverState.SEEKING_COVER);
                requestCoverSearch(QueuedSearchMode.NORMAL);
            }
        }

        soldier.clearAttackTarget();
        attackPhase = AttackPhase.NONE;
        attackBestObjectiveDist = Double.MAX_VALUE;
        attackFrontierDistance = Double.MAX_VALUE;
        attackSpine = null;
        spineRetryAfterTick = 0;
        spineWaitUntilTick = soldier.tickCount + 40;
        attackSpineProgressFrontier = -Double.MAX_VALUE;
        clearingEgressBestProgress = -Double.MAX_VALUE;

        if (attackDebugLog()) {
            StevesArmyMod.LOGGER.info("[AttackPhase] Soldier {} objective complete -> hold at {} (exposed={}, searchQueued={})",
                soldier.getId(), soldier.getHoldPosition(),
                getCoverManager().getCurrentCover() == null, coverSearchPending);
        }
    }

    /** Attack phase ordinal used by the debug overlay. */
    public int getAttackPhaseOrdinal() {
        return attackPhase.ordinal();
    }

    /** Fraction of the minimum dwell elapsed (0-1+) used by the debug overlay. */
    public float getAttackDwellFraction() {
        if (attackPhase != AttackPhase.OCCUPYING_COVER || attackCoverArrivalTime <= 0) return 0.0f;
        long dwellTime = GameClock.nowMs() - attackCoverArrivalTime;
        float ftLevel = FireTeamSuppressionTracker.getLevel(soldier);
        float dwellMult = (1.0f + ftLevel * 1.5f) * groupCohesionDwellMult();
        long minDwell = (long)(ATTACK_MIN_DWELL_MS * dwellMult);
        return minDwell > 0 ? (float) dwellTime / minDwell : 1.0f;
    }

    public boolean isRecoverySafetyPeekDone() {
        return recoverySafetyPeekDone;
    }

    public boolean isPeeking() {
        PeekController peekCtrl = getPeekController();
        return peekCtrl.isExposed() || peekCtrl.isMovingToPeek() || peekCtrl.isReturning();
    }

    public boolean isAttackHasPeekedThisCover() {
        return attackHasPeekedThisCover;
    }

    public boolean isPeekCompletedThisCover() {
        return peekCompletedThisCover;
    }

    public boolean isAttackRecovered() {
        if (attackPhase != AttackPhase.OCCUPYING_COVER) return false;
        return getCoverManager().getSuppressionTracker().isRecovered();
    }

    public boolean isAttackPeeking() {
        if (attackPhase != AttackPhase.OCCUPYING_COVER) return false;
        PeekController peekCtrl = getPeekController();
        return peekCtrl.isExposed() || peekCtrl.isMovingToPeek() || peekCtrl.isReturning();
    }

    public boolean isAttackFireteamPinned() {
        if (attackPhase != AttackPhase.OCCUPYING_COVER) return false;
        return FireTeamSuppressionTracker.shouldPauseAttack(soldier);
    }

    public boolean isAttackHeavyHold() {
        if (attackPhase != AttackPhase.OCCUPYING_COVER) return false;
        return StevesArmyConfig.isFireteamHeavyHoldReposition()
            && FireTeamSuppressionTracker.isHeavilySuppressed(soldier);
    }

    public float getAttackDwellElapsedMs() {
        if (attackPhase != AttackPhase.OCCUPYING_COVER || attackCoverArrivalTime <= 0) return 0;
        return GameClock.nowMs() - attackCoverArrivalTime;
    }

    public float getAttackRequiredDwellMs() {
        if (attackPhase != AttackPhase.OCCUPYING_COVER) return 0;
        float ftLevel = FireTeamSuppressionTracker.getLevel(soldier);
        float dwellMult = (1.0f + ftLevel * 1.5f) * groupCohesionDwellMult();
        return (long)(ATTACK_MIN_DWELL_MS * dwellMult);
    }

    public float getSuppressionDwellMult() {
        float ftLevel = FireTeamSuppressionTracker.getLevel(soldier);
        return 1.0f + ftLevel * 1.5f;
    }

    public float getGroupCohesionDwellMultValue() {
        return groupCohesionDwellMult();
    }

    public net.minecraft.world.phys.Vec3 getFireteamCentroid() {
        return FireTeamSuppressionTracker.getCentroid(soldier);
    }

    public int getAttackCoverState() {
        return getCoverManager().getState().ordinal();
    }

    public boolean isCoverSearchPending() {
        return coverSearchPending;
    }

    public boolean isFallbackAdvanceActive() {
        return fallbackAdvanceTarget != null;
    }

    public long getAttackPhaseAgeMs() {
        if (attackPhaseStartTime <= 0) return 0;
        return GameClock.nowMs() - attackPhaseStartTime;
    }

    public long getLastAdvanceTriggerAgeMs() {
        if (lastAdvanceTriggerTime <= 0) return Long.MAX_VALUE;
        return GameClock.nowMs() - lastAdvanceTriggerTime;
    }

    /**
     * Called by PeekController.completeReturn() to explicitly signal that a
     * peek cycle finished. Replaces the fragile inferred-latch approach.
     */
    public void onPeekCycleCompleted() {
        if (attackPhase == AttackPhase.OCCUPYING_COVER && !peekCompletedThisCover) {
            peekCompletedThisCover = true;
            attackHasPeekedThisCover = true;
            if (attackDebugLog()) {
                StevesArmyMod.LOGGER.info("[AttackPhase] Soldier {} explicit peek completion event this cover",
                    soldier.getId());
            }
        }
    }

    public boolean isAttackDwellMet() {
        if (attackPhase != AttackPhase.OCCUPYING_COVER || attackCoverArrivalTime <= 0) return false;
        long dwellTime = GameClock.nowMs() - attackCoverArrivalTime;
        float ftLevel = FireTeamSuppressionTracker.getLevel(soldier);
        float dwellMult = (1.0f + ftLevel * 1.5f) * groupCohesionDwellMult();
        long minDwell = (long)(ATTACK_MIN_DWELL_MS * dwellMult);
        return dwellTime >= minDwell;
    }

    /**
     * Maintain the advance spine: the wide-lens route from this soldier to
     * the attack objective. Computed once per command (with a retry backoff
     * when the probe finds nothing), re-probed when it ages out, the order
     * moves, or the soldier drifts off the route. Every path-based
     * progression consumer (scoring, corridor filters, frontier, hop legs,
     * dwell) reads this; a null spine falls back to the straight-line math.
     */
    private void tickAttackSpine(BlockPos objective) {
        if (!StevesArmyConfig.isAttackPathSpineEnabled()) {
            if (attackSpine != null) {
                attackSpine = null;
                soldier.setAttackSpine(null);
            }
            return;
        }
        // The spine is an APPROACH structure. Within the investigate band the
        // clearing machinery owns docking (corner checks, settle, short-job
        // walks) and spine-frame progression only fragments the last blocks
        // into micro-docks and orbit relays — dissolve the spine there and
        // every consumer (filters, scoring, hop legs, windows) falls back to
        // the legacy behavior that already works at close range.
        if (objective != null
            && objective.distSqr(soldier.blockPosition()) <= CLEARING_INVESTIGATE_BAND_SQ) {
            if (attackSpine != null) {
                attackSpine = null;
                soldier.setAttackSpine(null);
            }
            return;
        }
        if (attackSpine != null) {
            if (attackSpine.isStale(soldier.tickCount, objective, soldier.getX(), soldier.getZ())) {
                attackSpine = null;
                soldier.setAttackSpine(null);
                spineRetryAfterTick = soldier.tickCount + 20;
            } else {
                refreshSpineExposure(objective);
                return;
            }
        }
        if (soldier.tickCount < spineRetryAfterTick) {
            // Intake window: the first search is held for the spine, so a
            // failed probe retries on a short cadence until the wait expires
            // instead of idling on the 100t backoff while the first dock
            // waits. Still paced (a wide probe is a real A*), just tighter.
            if (soldier.tickCount < spineWaitUntilTick) {
                spineRetryAfterTick = soldier.tickCount + 10;
                return;
            }
            return;
        }
        // The spine probe manages its OWN retry cadence (100t below); it must
        // not inherit clearingGuideRoute's 600t unreachable cache — a single
        // budget-starved probe (the wide lens explores a huge region from
        // inside a building and can come back empty on roulette) would
        // otherwise poison the spine AND every assemble walk for half a
        // minute.
        clearingUnreachableUntil.remove(objective.immutable());
        Path route = clearingGuideRoute(objective);
        com.stevesarmy.entity.ai.pathfinding.AdvanceSpine spine =
            com.stevesarmy.entity.ai.pathfinding.AdvanceSpine.of(route, objective, soldier.tickCount);
        // Stub acceptance: a "route" that neither reaches the objective nor
        // is long enough to be a real route head is the best-effort interior
        // collapse — accepting it drives dock filters with a frame that
        // covers 3 blocks of map and re-probe loops at its dead end.
        if (spine != null) {
            double guideDist = Math.sqrt(objective.distSqr(soldier.blockPosition()));
            boolean realRoute = spine.canReach()
                || spine.endHorizontalDist(objective) < Math.max(8.0D, guideDist - 8.0D)
                || spine.length() >= 16.0D;
            if (!realRoute) {
                spine = null;
            }
        }
        if (spine != null) {
            attackSpine = spine;
            soldier.setAttackSpine(spine);
            // The frontier is expressed in the spine's own progress frame;
            // a rebuilt spine re-bases that frame at the soldier, so the
            // frontier MUST reset with it — a frontier carried across a
            // rebuild compares coordinates from two different routes and
            // rejects every dock forever (the doorstep park).
            attackSpineProgressFrontier = spine.progress(soldier.blockPosition());
            // A rebuilt spine is a fresh enclosed-approach evaluation: the
            // sticky exposure flag belongs to the old route's premise.
            attackSpineExposed = false;
            spineExposureRefreshTick = 0;
            refreshSpineExposure(objective);
            // Spine-dock revalidation: a dock taken before the spine existed
            // (the spawn-era search scores by raw distance) must not survive
            // the route's arrival — if it sits off the route corridor, release
            // it so the next search picks a spine-forward dock. Under fire or
            // live contact the dock is a fighting position, not a progression
            // slot; doctrine yields to protection there.
            CoverPoint heldDock = getCoverManager().getCurrentCover();
            if (heldDock != null && !getCoverManager().isSuppressed()
                && !ContactPlan.hasLiveContact(soldier)
                && attackSpine.corridorDistance(heldDock.getPosition())
                    > ATTACK_SPINE_CORRIDOR_WIDTH) {
                getCoverManager().clearCover();
                if (attackDebugLog()) {
                    StevesArmyMod.LOGGER.info(
                        "[AttackAdvance] Soldier {} released pre-spine dock {} ({} blocks off route) for spine search",
                        soldier.getId(), heldDock.getPosition().toShortString(),
                        String.format("%.1f", attackSpine.corridorDistance(heldDock.getPosition())));
                }
            }
            if (attackDebugLog()) {
                StevesArmyMod.LOGGER.info(
                    "[AttackAdvance] Soldier {} spine to {} ({} blocks walked, canReach={})",
                    soldier.getId(), objective.toShortString(),
                    String.format("%.1f", spine.length()), spine.canReach());
            }
        } else {
            spineRetryAfterTick = soldier.tickCount + 100;
        }
    }

    /**
     * Whether the ROUTE AHEAD is exposed, refreshed at most every 40t. The
     * probe ray runs to the spine point one leg ahead — not to the objective:
     * an objective inside a building keeps that ray blocked from the whole
     * approach street, which would read "indoors" for an exposed crossing and
     * suspend docking for the entire advance (the dockless mid-street walk).
     * From an enclosed pocket the leg ray terminates on the walls the route
     * threads, so the interior stays "covered" and the walk owns the legs;
     * on an open street the ray clears and cover-hopping resumes.
     *
     * Two hardening terms, both from the mid-street dockless regression: the
     * probe targets HEAD height above the route point (the block center sits
     * at knee height, so a 1-high street cover row between walker and probe
     * read as "enclosed" and suspended docking across half the street), and
     * exposure is STICKY-once — the gate's premise is the enclosed approach
     * segment, and once the route has shown sky that premise never returns;
     * a fresh spine build (new enclosed approach) resets it.
     */
    private void refreshSpineExposure(BlockPos objective) {
        if (soldier.tickCount < spineExposureRefreshTick) return;
        spineExposureRefreshTick = soldier.tickCount + 40;
        // Near the objective the advance hands over to the arrival/clearing
        // machinery; the leg probe clamps to the spine's end there, which
        // lands INSIDE the target building and stays wall-blocked — without
        // this handover term the gate would read "indoors" for the whole
        // final stretch and the street stays dockless to the door.
        boolean nearObjective = soldier.blockPosition().distSqr(objective)
            <= ATTACK_SPINE_LEG_LENGTH * ATTACK_SPINE_LEG_LENGTH * 1.5;
        Vec3 probe = null;
        if (attackSpine != null && !nearObjective) {
            double ahead = Math.min(attackSpine.length(),
                attackSpine.progress(soldier.blockPosition()) + ATTACK_SPINE_LEG_LENGTH);
            BlockPos aheadPos = attackSpine.pointAt(ahead, soldier.blockPosition().getY());
            // Block center = knee height; 1-high cover rows blocked the ray
            // and re-closed the gate mid-street. Standing-eye height asks
            // the doctrine question: would the route ahead be exposed.
            probe = Vec3.atCenterOf(aheadPos).add(0.0D, 1.1D, 0.0D);
        }
        if (probe == null) {
            probe = Vec3.atCenterOf(objective);
        }
        // A blocked horizontal ray is not evidence of being indoors: low
        // street rows and rubble can occlude it. Sky above the current eye
        // is affirmative open-street evidence, independent of the objective.
        attackSpineExposed = attackSpineExposed
            || soldier.level().canSeeSky(BlockPos.containing(soldier.getEyePosition()))
            || nearObjective
            || VisibilityRay.trace(soldier.level(),
                soldier.getEyePosition(), probe, soldier).clear();
        if (attackDebugLog()) {
            StevesArmyMod.LOGGER.info("[SpineExposure] {} at {} probe {} exposed={} nearObj={} spine={}",
                soldier.getId(), soldier.blockPosition().toShortString(), probe != null ? "set" : "null",
                attackSpineExposed, nearObjective, attackSpine != null);
        }
    }

    private void initAttackPhase() {
        int gen = soldier.getAttackGeneration();
        if (attackCommandGeneration != gen) {
            attackCommandGeneration = gen;
            attackPhase = AttackPhase.SELECTING_COVER;
            attackPhaseStartTime = GameClock.nowMs();
            attackCoverArrivalTime = 0;
            attackExpectedCover = null;
            attackDwellEligible = false;
            attackHasPeekedThisCover = false;
            peekCompletedThisCover = false;
            attackBestObjectiveDist = Double.MAX_VALUE;
            attackFrontierDistance = Double.MAX_VALUE;
            attackSpine = null;
            spineRetryAfterTick = 0;
            spineWaitUntilTick = soldier.tickCount + 40;
            attackSpineProgressFrontier = -Double.MAX_VALUE;
            clearingEgressBestProgress = -Double.MAX_VALUE;
            fallbackAdvanceTarget = null;
            fallbackAdvanceAssemble = false;
                fallbackStuckTicks = 0;
            fallbackLastPosition = null;
            fallbackNoProgressResets = 0;
            // Stagger: deterministic delay based on UUID
            attackAdvanceStaggerTicks = Math.abs(soldier.getUUID().hashCode() % 60); // 0-3 seconds
            if (attackDebugLog()) {
                StevesArmyMod.LOGGER.info("[AttackPhase] Soldier {} init attack gen {} stagger={}",
                    soldier.getId(), gen, attackAdvanceStaggerTicks);
            }
        }
    }

    private void tickAttackPhase() {
        if (!soldier.hasValidAttackTarget()) {
            attackPhase = AttackPhase.NONE;
            return;
        }

        // Smoke evaluation runs in every attack phase: a fireteam pinned while
        // bounding between covers needs the screen as much as one holding it.
        SmokeDeploymentCoordinator.maybeDeploySmoke(soldier);

        // Detect new attack command while goal is already running
        int currentGen = soldier.getAttackGeneration();
        if (attackCommandGeneration != currentGen) {
            attackCommandGeneration = currentGen;
            resetAttackCommand();
            if (attackDebugLog()) {
                StevesArmyMod.LOGGER.info("[AttackPhase] Soldier {} new attack generation {} detected, resetting command",
                    soldier.getId(), currentGen);
            }
        }

        BlockPos objective = soldier.getAttackTargetPos();
        double distToObjective = soldier.distanceToSqr(
            objective.getX() + 0.5, objective.getY() + 0.5, objective.getZ() + 0.5);
        double objRadiusSq = ATTACK_OBJECTIVE_RADIUS * ATTACK_OBJECTIVE_RADIUS;

        tickAttackSpine(objective);

        // Clearing doctrine: a registered ATTACK order of record turns the
        // advance into reach-the-area -> clear -> secure. The coordinator
        // decides what progress the squad needs next and owns completion;
        // this goal executes it through the existing cover machinery.
        clearingView = ClearingCoordinator.viewFor(soldier);
        if (clearingView != null) {
            clearingPoiTarget = resolveClearingPoi(clearingView);
            // A fresh dock is a fresh observation attempt: the check needs
            // dwell time at the dock to land, so every clearing window
            // (investigate staleness and the SECURE assemble pull) restarts
            // at arrival. Without this, a window counter carried through the
            // travel fires the next move the instant the soldier docks, and
            // he never stays anywhere long enough to observe anything.
            CoverPoint arrivedDock = getCoverManager().getCurrentCover();
            if (arrivedDock == null) {
                clearingLastDockPos = null;
            } else if (!arrivedDock.getPosition().equals(clearingLastDockPos)) {
                clearingLastDockPos = arrivedDock.getPosition();
                clearingAssembleTicks = 0;
                // Dwell-clock churn grading: sideways and backward re-docks
                // (the pocket orbit) must not restart the egress/stale clocks
                // — the orbit re-docks faster than the windows expire, so an
                // unconditional reset here means the clocks never fire and
                // the soldier never leaves. A re-dock only counts as progress
                // when it closes on that clock's target past the best the
                // dwell has seen.
                BlockPos egressGuide = soldier.getAttackTargetPos();
                double egressDistSq = egressGuide == null
                    ? Double.MAX_VALUE : egressGuide.distSqr(soldier.blockPosition());
                if (clearingEgressBestDistSq < 0) {
                    clearingEgressBestDistSq = egressDistSq;
                } else {
                    // Spine frame: a dock "bought approach" when it advanced
                    // the route by a full block — straight-line distance to
                    // the ping lies inside buildings (the exit route walks
                    // AWAY from the ping first).
                    boolean boughtApproach = egressDistSq
                        < clearingEgressBestDistSq - CLEARING_DOCK_PROGRESS_DELTA_SQ;
                    if (attackSpine != null) {
                        double dockProgress = attackSpine.progress(arrivedDock.getPosition());
                        boughtApproach =
                            dockProgress > clearingEgressBestProgress + 1.0D;
                        clearingEgressBestProgress =
                            Math.max(clearingEgressBestProgress, dockProgress);
                    }
                    if (boughtApproach) {
                        clearingEgressTicks = 0;
                    }
                    clearingEgressBestDistSq = Math.min(clearingEgressBestDistSq, egressDistSq);
                }
                BlockPos staleJob = clearingView.assignedPoi();
                double staleDistSq = staleJob == null
                    ? Double.MAX_VALUE : staleJob.distSqr(soldier.blockPosition());
                if (staleJob == null || !staleJob.equals(clearingStaleBestJob)) {
                    clearingStaleBestJob = staleJob;
                    clearingStaleBestDistSq = staleDistSq;
                    clearingStaleTargetTicks = 0;
                } else if (staleDistSq
                    < clearingStaleBestDistSq - CLEARING_DOCK_PROGRESS_DELTA_SQ) {
                    clearingStaleTargetTicks = 0;
                    clearingStaleBestDistSq = staleDistSq;
                }
                // Grade the investigate delivery: a re-dock that bought no
                // approach toward the job means the reachability probe and
                // the walkable terrain disagree (pathfinder canReach vs the
                // standing-path validation the mover applies). Trust the
                // outcome: cache the guide unreachable so later windows hold
                // the dock instead of orbiting the building one dock per
                // window — cover churn around a wall nobody can pass.
                if (investigateJob != null && investigateStartPos != null) {
                    Vec3 jobCenter = Vec3.atCenterOf(investigateJob);
                    double before = investigateStartPos.distanceToSqr(jobCenter);
                    double now = arrivedDock.getPosition().distSqr(investigateJob);
                    if (now > before - 1.0D) {
                        clearingUnreachableUntil.put(investigateJob,
                            (long) soldier.tickCount + CLEARING_POI_UNREACHABLE_BACKOFF_TICKS);
                        // The assemble delivery grades through the same path:
                        // a no-progress re-dock must not re-arm on the next
                        // 30t assemble window.
                        assembleRetryAfterTick =
                            soldier.tickCount + CLEARING_ASSEMBLE_RETRY_BACKOFF_TICKS;
                        if (attackDebugLog()) {
                            StevesArmyMod.LOGGER.info(
                                "[AttackAdvance] Soldier {} investigate dock at {} bought no approach to {}, backing off {}t",
                                soldier.getId(), arrivedDock.getPosition().toShortString(),
                                investigateJob.toShortString(), CLEARING_POI_UNREACHABLE_BACKOFF_TICKS);
                        }
                    }
                    investigateJob = null;
                    investigateStartPos = null;
                }
            }
            // An assigned blind spot that stays unchecked while this soldier
            // sits at cover cannot be observed from where he is: standing
            // still is not investigating. After a long stale period, walk to
            // the target and look at it — arrival places the check within
            // observation range, which is the whole point of the claim.
            boolean staleTarget = clearingView.assignedPoi() != null
                && !clearingView.assignedPoiChecked()
                && clearingView.assignedPoi().equals(clearingPoiTarget);
            // A far job is egress, not churn: the walk is the pinned soldier's
            // way OUT of a fatal funnel, so heavy suppression must not veto it
            // (the travel machinery crawls him through; the doctrine is "pinned
            // = dive but approach low", never "pinned = stay pinned").
            boolean farEgressJob = StevesArmyConfig.isAttackClearDirectEgress()
                && clearingView.assignedPoi() != null
                && clearingView.assignedPoi().distSqr(soldier.blockPosition())
                    > CLEARING_INVESTIGATE_BAND_SQ;
            clearingStaleTargetTicks = staleTarget ? clearingStaleTargetTicks + 1 : 0;
            if (staleTarget && clearingStaleTargetTicks >= CLEARING_INVESTIGATE_TICKS
                // Never fight an in-flight walk for the legs either.
                && fallbackAdvanceTarget == null
                && !clearingHold()
                && (farEgressJob || !FireTeamSuppressionTracker.isHeavilySuppressed(soldier))
                // Never fight the cover system for the legs: an in-flight
                // reposition owns navigation, and two movers issuing paths
                // cancel each other's pending paths into a freeze.
                && getCoverManager().getState() != CoverBehaviorManager.CoverState.REPOSITIONING
                && getCoverManager().getState() != CoverBehaviorManager.CoverState.SEEKING_COVER
                && (attackPhase == AttackPhase.OCCUPYING_COVER
                    || attackPhase == AttackPhase.SELECTING_COVER)) {
                BlockPos assigned = clearingView.assignedPoi();
                if (farEgressJob) {
                    // Far job: dock-hopping cannot deliver it. The re-dock
                    // search only finds cover near the soldier, so every
                    // window misses the job, the delivery grade reads "bought
                    // no approach", and the route cache backs off 600t — the
                    // soldier orbits his start pocket for minutes. Walk the
                    // full route instead: the partial path is taken, the
                    // fallback machinery services arrival and stuck, and the
                    // in-band investigate re-dock takes over on arrival.
                    if (!clearingGuideReachable(assigned)) {
                        Long until = clearingUnreachableUntil.get(assigned);
                        if (attackDebugLog()) {
                            StevesArmyMod.LOGGER.info("[AttackAdvance] Soldier {} job {} unreachable (backoff {}t left), holding dock",
                                soldier.getId(), assigned.toShortString(),
                                until == null ? 0 : Math.max(0, until - soldier.tickCount));
                        }
                        clearingStaleTargetTicks = 0;
                    } else {
                        if (dockedForSearch()) {
                            if (attackDebugLog()) {
                                StevesArmyMod.LOGGER.info(
                                    "[AttackAdvance] Soldier {} releasing dock {} for far egress: suppression={} recovered={} reason=FAR_EGRESS",
                                    soldier.getId(), getCoverManager().getCurrentCover().getPosition(),
                                    String.format("%.2f", getCoverManager().getSuppressionLevel()),
                                    getCoverManager().getSuppressionTracker().isRecovered());
                            }
                            getCoverManager().clearCover();
                        }
                        // Job-directed: keep the full-route assemble walk —
                        // the spine points at the PING, but this window's
                        // target is an assigned corner job whose route can
                        // diverge from the ping spine; hopping along the
                        // ping route strands the corner unchecked (order
                        // never completes).
                        startAssembleAdvance();
                        if (fallbackAdvanceTarget != null) {
                            attackPhase = AttackPhase.SELECTING_COVER;
                        }
                        clearingStaleTargetTicks = 0;
                    }
                } else if (!clearingGuideReachable(assigned)) {
                    Long until = clearingUnreachableUntil.get(assigned);
                    if (attackDebugLog()) {
                        StevesArmyMod.LOGGER.info("[AttackAdvance] Soldier {} job {} unreachable (backoff {}t left), holding dock",
                            soldier.getId(), assigned.toShortString(),
                            until == null ? 0 : Math.max(0, until - soldier.tickCount));
                    }
                    // The job has no walkable route: standing at cover facing
                    // the wall is the correct posture, and re-seeking every
                    // window tears the dock down and re-docks somewhere else
                    // — cover churn around a wall the squad cannot pass. Back
                    // off; the STALLED report and a terrain change are the
                    // ways out.
                    clearingStaleTargetTicks = 0;
                } else if (startInvestigateReposition(assigned)) {
                    // Delivery is dock-driven: hand the legs to the cover
                    // system with a reposition whose search centers on the
                    // job. A direct fallback walk issued from a dock has no
                    // legs — the dock anchor owns movement — so the walk
                    // never moves and only blocks the servicing dispatch.
                    // Each window advances at most one dock, so the approach
                    // to an observing dock is gradual, not churn.
                    clearingStaleTargetTicks = 0;
                } else {
                    // Reposition refused (no step available right now):
                    // retry soon instead of waiting another full window —
                    // unless the soldier has no dock at all, in which case
                    // the refused reposition is the NO_COVER spin (the search
                    // from this pocket finds nothing and never will). A
                    // dockless soldier must not orbit his claim: walk the
                    // short in-band route to the job directly; arrival
                    // re-arms the normal dock machinery.
                    if (getCoverManager().getCurrentCover() == null) {
                        // Job-directed (same rule as the far-job window):
                        // the assemble walk targets the assigned job, not
                        // the ping spine.
                        startAssembleAdvance();
                        if (fallbackAdvanceTarget != null) {
                            attackPhase = AttackPhase.SELECTING_COVER;
                        }
                    }
                    clearingStaleTargetTicks = CLEARING_INVESTIGATE_TICKS / 2;
                }
            }
            // Direct egress (APPROACH, no in-band job): a soldier parked at a
            // dock with no resolved claim has no advance driver at all — the
            // stale window above needs a target, and the corridor search from
            // a pocket finds no forward cover. After a parked window, walk one
            // full route toward the objective: the partial path is taken, and
            // the in-band machinery resumes when a claim comes within range.
            // The same recovery covers the dockless NO_COVER spin anywhere in
            // the area: no claim, no dock, nothing to occupy, and the cover
            // search failing on repeat is not a state to stand in.
            BlockPos egressGuide = soldier.getAttackTargetPos();
            boolean joblessDockless = clearingPoiTarget == null
                && getCoverManager().getCurrentCover() == null
                && egressGuide != null
                && egressGuide.distSqr(soldier.blockPosition())
                    > CLEARING_INVESTIGATE_BAND_SQ;
            if (StevesArmyConfig.isAttackClearDirectEgress()
                && clearingPoiTarget == null
                // A forward street dock uses the normal successor search;
                // the interior escape timer must not strip that protection.
                && !(dockedForSearch()
                    && !isBackwardAttackDock(getCoverManager().getCurrentCover().getPosition())
                    && soldier.level().canSeeSky(BlockPos.containing(soldier.getEyePosition())))
                && (clearingView.stage() == ClearingCoordinator.ClearingStage.APPROACH
                    || joblessDockless)
                && (!clearingView.insideArea() || joblessDockless)
                && !clearingHold()
                && soldier.tickCount >= egressRetryAfterTick
                && fallbackAdvanceTarget == null
                // No suppression veto: this walk is the exit from the funnel
                // the soldier is being pinned in (same doctrine as above).
                && !ExposedCombatController.hasActiveMove(soldier)
                && getCoverManager().getState() != CoverBehaviorManager.CoverState.REPOSITIONING
                && getCoverManager().getState() != CoverBehaviorManager.CoverState.SEEKING_COVER
                && (attackPhase == AttackPhase.OCCUPYING_COVER
                    || attackPhase == AttackPhase.SELECTING_COVER)) {
                clearingEgressTicks++;
                if (clearingEgressTicks >= CLEARING_INVESTIGATE_TICKS) {
                    clearingEgressTicks = 0;
                    if (dockedForSearch()) {
                        if (attackDebugLog()) {
                            StevesArmyMod.LOGGER.info(
                                "[AttackAdvance] Soldier {} releasing dock {} for direct egress: suppression={} recovered={} reason=DIRECT_EGRESS",
                                soldier.getId(), getCoverManager().getCurrentCover().getPosition(),
                                String.format("%.2f", getCoverManager().getSuppressionLevel()),
                                getCoverManager().getSuppressionTracker().isRecovered());
                        }
                        getCoverManager().clearCover();
                    }
                    startWindowAdvance();
                    if (fallbackAdvanceTarget != null) {
                        attackPhase = AttackPhase.SELECTING_COVER;
                    } else {
                        // Route probe failed or the contact plan denied the
                        // walk: back off before re-querying next window.
                        egressRetryAfterTick = soldier.tickCount
                            + CLEARING_ASSEMBLE_RETRY_BACKOFF_TICKS;
                    }
                }
            }
            // No churn reset on the other phases: the MOVING_TO_COVER flapping
            // of the pocket orbit is exactly the no-progress time this clock
            // measures. It pauses while the soldier walks (the gate above only
            // accrues docked/seeking phases) and restarts only through the
            // dock-arrival grading above.
            // SECURE-phase assemble: every check ran and every contact is
            // resolved, so the coordinator has completion armed except for
            // squad members still OUTSIDE the area — a soldier parked in
            // cover just past the wall (his last checked-POI ping keeps the
            // 60s target memory "valid") starves the all-inside settle
            // forever. Walk him in with a plain fallback advance: no dock
            // selection (the ping-then-recover path just re-docks him on the
            // same sidewalk spot), and no reissue ping from the coordinator —
            // that re-runs cover search and cancels legs mid-approach. This
            // is an explicit executor action with a lifecycle: the advance is
            // serviced every tick (arrival / stuck below), interruptions by
            // the cover system are re-armed after the window, and repeated
            // stuck escalations back the retry off.
            boolean assemble = clearingView.secureAssemble() && !clearingView.insideArea();
            clearingAssembleTicks = assemble ? clearingAssembleTicks + 1 : 0;
            if (!assemble) {
                assembleDockFailures = 0;
            }
            if (assemble && clearingAssembleTicks >= CLEARING_ASSEMBLE_TICKS
                && soldier.tickCount >= assembleRetryAfterTick
                && fallbackAdvanceTarget == null
                && !ExposedCombatController.hasActiveMove(soldier)
                && !FireTeamSuppressionTracker.isHeavilySuppressed(soldier)
                && !suppressedDockHoldActive() && !dockAdvanceLaunchHeld()
                // Never fight the cover system for the legs (same rule as the
                // investigate advance above).
                && getCoverManager().getState() != CoverBehaviorManager.CoverState.REPOSITIONING
                && getCoverManager().getState() != CoverBehaviorManager.CoverState.SEEKING_COVER) {
                // A nonzero backoff past its expiry means the previous graded
                // window FAILED (unreachable probe or a re-dock that bought no
                // approach); consume it and count the failure.
                if (assembleRetryAfterTick > 0) {
                    assembleDockFailures++;
                    assembleRetryAfterTick = 0;
                }
                if (dockedForSearch() && assembleDockFailures < 2) {
                    // A dock anchors the legs: a direct assemble walk issued
                    // from it is cancelled by the position controller every
                    // tick, and the soldier sits just past the wall starving
                    // the all-inside settle forever. Hand the legs to the
                    // cover system instead — the re-dock search centers on
                    // the objective, so each window lands him closer to
                    // inside. The delivery is graded like the investigate
                    // window: a re-dock that bought no approach is treated
                    // as unreachable and backs the retry off, instead of
                    // re-docking around the wall every 30t window (the
                    // SECURE-stage dock churn).
                    BlockPos guide = clearingPoiTarget != null
                        ? clearingPoiTarget : soldier.getAttackTargetPos();
                    if (!clearingGuideReachable(guide)) {
                        assembleRetryAfterTick =
                            soldier.tickCount + CLEARING_ASSEMBLE_RETRY_BACKOFF_TICKS;
                    } else {
                        investigateJob = guide != null ? guide.immutable() : null;
                        investigateStartPos = soldier.position();
                        startRepositioning();
                    }
                } else {
                    // Escalation: the re-dock cannot recover him from here.
                    // Release the dock so the position controller stops
                    // cancelling the legs, and walk in directly — the raw
                    // route takes the partial path through the door. A failed
                    // direct attempt (null path) re-docks next tick, so the
                    // fallback state is no worse than the churn it replaces.
                    if (dockedForSearch()) {
                        if (attackDebugLog()) {
                            StevesArmyMod.LOGGER.info(
                                "[AttackAdvance] Soldier {} releasing dock {} for assemble egress: suppression={} recovered={} reason=ASSEMBLE_EGRESS",
                                soldier.getId(), getCoverManager().getCurrentCover().getPosition(),
                                String.format("%.2f", getCoverManager().getSuppressionLevel()),
                                getCoverManager().getSuppressionTracker().isRecovered());
                        }
                        getCoverManager().clearCover();
                    }
                    startAssembleAdvance();
                    if (fallbackAdvanceTarget != null) {
                        // Service the walk: tickFallbackAdvance only runs in
                        // this phase, and without it neither arrival nor stuck
                        // handling would ever see the assemble advance.
                        attackPhase = AttackPhase.SELECTING_COVER;
                    }
                }
                clearingAssembleTicks = 0;
            }
            if (clearingView.completed()) {
                if (attackPhase != AttackPhase.COMPLETE) {
                    attackPhase = AttackPhase.COMPLETE;
                    if (attackDebugLog()) {
                        StevesArmyMod.LOGGER.info("[AttackPhase] Soldier {} clearing order secured, completing", soldier.getId());
                    }
                    completeAttackAtObjective();
                }
                return;
            }
        } else {
            clearingPoiTarget = null;
            clearingStaleTargetTicks = 0;
            clearingLastDockPos = null;
            clearingAssembleTicks = 0;
            clearingEgressTicks = 0;
            clearingEgressBestDistSq = -1.0;
            clearingEgressBestProgress = -Double.MAX_VALUE;
            clearingStaleBestJob = null;
            clearingStaleBestDistSq = -1.0;
            investigateJob = null;
            investigateStartPos = null;
        }

        // Objective reached — cover-to-cover advance is complete. No further
        // final approach; soldiers hold the last cover near the objective.
        // Clearing orders skip this: inside the area the job is CLEAR/SECURE,
        // and SquadActivityManager finishes the order, not this radius.
        if (clearingView == null && distToObjective <= objRadiusSq) {
            // An order is not DONE while the soldier is pinned or suppressed
            // short of his dock: completing under fire hands control to
            // NORMAL-mode seeking, whose protection scoring then walks him
            // BACKWARD off the objective (the post-arrival backward drift).
            // The dock move continues under attack mode; completion waits
            // for the pin to lift.
            if (getCoverManager().isPinned() || getCoverManager().isSuppressed()) {
                if (attackDebugLog() && attackPhase != AttackPhase.COMPLETE
                    && soldier.tickCount % 100 == 0) {
                    StevesArmyMod.LOGGER.info(
                        "[AttackPhase] Soldier {} at objective but pinned/suppressed, holding attack mode",
                        soldier.getId());
                }
            } else if (attackPhase != AttackPhase.COMPLETE) {
                attackPhase = AttackPhase.COMPLETE;
                updateAttackProgress(objective);
                if (attackDebugLog()) {
                    StevesArmyMod.LOGGER.info("[AttackPhase] Soldier {} objective reached, completing", soldier.getId());
                }
                completeAttackAtObjective();
            }
            if (attackPhase == AttackPhase.COMPLETE) {
                return;
            }
        }

        CoverBehaviorManager.CoverState coverState = getCoverManager().getState();
        CoverPoint currentCover = getCoverManager().getCurrentCover();

        if (attackPhase == AttackPhase.SELECTING_COVER && fallbackAdvanceTarget != null
            && (!clearingHold() || fallbackAdvanceAssemble)) {
            tickFallbackAdvance();
            if (fallbackAdvanceTarget != null && fallbackAdvanceAssemble) {
                // Full-route walks service themselves to arrival (or stuck).
                // Dropping them to the corridor search every refresh tick
                // re-docks the soldier at the nearest cover — inside a
                // cover-rich pocket the re-dock wins every time and the walk
                // never leaves the building.
                return;
            }
            if (fallbackAdvanceTarget != null && soldier.tickCount % ATTACK_CORRIDOR_REFRESH_TICKS != 0) {
                return;
            }
            fallbackAdvanceTarget = null;
            fallbackAdvanceAssemble = false;
        }

        switch (attackPhase) {
            case SELECTING_COVER: {
                // Fallback walks retain their origin claim for a possible
                // return under fire. Once the leg ends, NO_COVER cannot use
                // that old claim as protection at its exposed endpoint.
                if (getCoverManager().getState() == CoverBehaviorManager.CoverState.NO_COVER
                    && fallbackAdvanceTarget == null && getCoverManager().getTargetCover() == null
                    && currentCover != null) {
                    getCoverManager().clearCover();
                    currentCover = null;
                }
                // If suppressed or not recovered, don't start a new move yet
                // A retained origin claim is not an occupied dock. Holding
                // NO_COVER here alternated SELECTING/OCCUPYING until recovery,
                // suppressing both cover searches and the next advance leg.
                if (!canLeaveCoverNow() && dockedForSearch()) {
                    attackPhase = AttackPhase.OCCUPYING_COVER;
                    attackCoverArrivalTime = GameClock.nowMs();
                    if (attackDebugLog()) {
                        StevesArmyMod.LOGGER.info("[AttackPhase] Soldier {} SELECTING_COVER -> OCCUPYING_COVER: suppressed, waiting at {}",
                            soldier.getId(), currentCover.getPosition());
                    }
                    break;
                }

                // Pinned and dockless (suppressedRelocationSafeRoute): the plain
                // ATTACK_SELECTING corridor search has no classifier and no
                // recovery wait, and its failure used to fall into the fallback
                // advance — an open-ground walk under fire. Route the
                // re-decision through the classified suppression search with its
                // retry pacing; a withheld verdict holds position ducked.
                if (docklessSuppressedSearchActive()) {
                    runDocklessSuppressedSearch();
                    break;
                }

                // Advance-launch hold (suppressedRelocationSafeRoute): a docked
                // soldier does not launch a corridor advance out of his dock
                // while (a) fire has been live inside the sustained-quiet
                // window, or (b) he was absolutely pinned at this dock and the
                // fight that pinned him is still live — the momentary recovery
                // gap while hidden (the t250-style relaunch at sup=0.00 that
                // the next burst caught mid-crossing) is not a safe launch
                // window. Hold the dock; the advance resumes once the fight is
                // genuinely over.
                if (dockAdvanceLaunchHeld()) {
                    break;
                }

                // Secured area: settle into a hold-style watch position instead
                // of continuing the corridor advance.
                if (clearingHold()) {
                    requestCoverSearch(QueuedSearchMode.NORMAL);
                    break;
                }

                // First-search spine wait: the spine probe may still be
                // running on the command's first ticks. Searching before it
                // lands scores the FIRST dock by raw distance and that dock
                // then defines the whole advance — hold the search briefly
                // (bounded) so it is spine-scored; legacy behavior after the
                // bound if the probe never lands.
                if (attackSpine == null && StevesArmyConfig.isAttackPathSpineEnabled()
                    && soldier.hasValidAttackTarget()
                    && soldier.tickCount < spineWaitUntilTick) {
                    break;
                }

                // Exposure gate: indoors (no LoS to the objective) with no
                // contact and no suppression, the corridor search must not
                // run — every dock it can take inside is a wall of the
                // building the route is leaving (the turn-around). Release
                // any dock and walk the spine instead; cover-hopping resumes
                // when refreshSpineExposure sees the open route.
                if (spineInteriorWalkGate() && !isReloadBlockedMove()) {
                    if (soldier.tickCount >= egressRetryAfterTick) {
                        if (dockedForSearch()) {
                            getCoverManager().clearCover();
                        }
                        attackExpectedCover = null;
                        startWindowAdvance();
                        if (fallbackAdvanceTarget == null) {
                            // Walk refused (contact plan, probe roulette):
                            // back off instead of re-issuing every tick.
                            egressRetryAfterTick = soldier.tickCount + 40;
                        }
                    }
                    break;
                }

                // Search execution is budgeted by CoverSearchScheduler. Do not
                // treat a queued search as a failed search and advance exposed.
                requestCoverSearch(QueuedSearchMode.ATTACK_SELECTING);
                break;
            }

            case MOVING_TO_COVER: {
                CoverPoint targetCover = getCoverManager().getTargetCover();

                if (targetCover != null && attackExpectedCover != null
                    && !attackExpectedCover.equals(targetCover.getPosition())) {
                    if (DiagnosticLogManager.isCoverLoggingEnabled()) {
                        StevesArmyMod.LOGGER.info("[AttackPhase] Soldier {} destination changed: {} -> {}",
                            soldier.getId(), attackExpectedCover, targetCover.getPosition());
                    }
                    attackExpectedCover = targetCover.getPosition().immutable();
                }

                // A fresh attack can clear the manager to NO_COVER after the
                // target was selected. Restore the movement state so the
                // normal cover navigation handlers can process arrival.
                if (coverState == CoverBehaviorManager.CoverState.NO_COVER &&
                    targetCover != null && currentCover == null) {
                    getCoverManager().setState(CoverBehaviorManager.CoverState.SEEKING_COVER);
                    if (attackDebugLog()) {
                        StevesArmyMod.LOGGER.info("[AttackPhase] Soldier {} MOVING_TO_COVER restored NO_COVER -> SEEKING_COVER for target {}",
                            soldier.getId(), targetCover.getPosition());
                    }
                }

                // Reconciliation: if the cover system has parked us in a cover
                // (e.g., suppression pulled us back while we were advancing),
                // treat it as arrival so the attack phase can recover. A dock
                // BEHIND the advance is the exception: parking in the building
                // the route just left is not an arrival, it is the mid-advance
                // turn-around — fall through to a fresh spine-framed search.
                // Under fire SELECTING_COVER settles straight back into
                // OCCUPYING via canLeaveCoverNow(), so this adds no churn
                // while suppressed.
                boolean currentCoverIsExpected = currentCover != null
                    && (attackExpectedCover == null || currentCover.getPosition().equals(attackExpectedCover));
                boolean backwardPark = currentCover != null
                    && isBackwardAttackDock(currentCover.getPosition());
                if (!backwardPark
                    && (coverState == CoverBehaviorManager.CoverState.IN_COVER ||
                        coverState == CoverBehaviorManager.CoverState.SUPPRESSED_IN_COVER) &&
                    currentCoverIsExpected) {
                    attackPhase = AttackPhase.OCCUPYING_COVER;
                    attackCoverArrivalTime = GameClock.nowMs();
                    attackExpectedCover = null;
                    attackDwellEligible = false;
                    attackHasPeekedThisCover = false;
                    peekCompletedThisCover = false;
                    updateAttackProgress(objective);
                    if (attackDebugLog()) {
                        StevesArmyMod.LOGGER.info("[AttackPhase] Soldier {} ({}) MOVING_TO_COVER -> OCCUPYING_COVER: cover state {} at {}",
                            soldier.getId(), soldier.getName().getString(), coverState, currentCover.getPosition());
                    }
                    break;
                }

                // CHECK ARRIVAL FIRST: promotion clears targetCover, so we must
                // detect arrival by currentCover matching expectedCover BEFORE
                // treating a null target as movement failure.
                boolean arrivedAtExpected = false;
                if (attackExpectedCover != null && currentCover != null) {
                    arrivedAtExpected = currentCover.getPosition().equals(attackExpectedCover);
                } else if (attackExpectedCover == null && currentCover != null && targetCover == null) {
                    // Expected not set (initial selection via findAndMoveToCover),
                    // and target was just promoted → we just arrived
                    arrivedAtExpected = true;
                }

                if (arrivedAtExpected && (currentCover == null
                    || !isBackwardAttackDock(currentCover.getPosition()))) {
                    attackPhase = AttackPhase.OCCUPYING_COVER;
                    attackCoverArrivalTime = GameClock.nowMs();
                    attackExpectedCover = null;
                    attackDwellEligible = false;
                    attackHasPeekedThisCover = false;
                    peekCompletedThisCover = false;
                    updateAttackProgress(objective);
                    if (attackDebugLog()) {
                        StevesArmyMod.LOGGER.info("[AttackPhase] Soldier {} MOVING_TO_COVER -> OCCUPYING_COVER: reached cover {}, dwell timer starts",
                            soldier.getId(), currentCover.getPosition());
                    }
                    break;
                }

                // Recovery: target cover was lost (e.g., blacklisted during navigation)
                if (targetCover == null) {
                    attackPhase = AttackPhase.SELECTING_COVER;
                    attackExpectedCover = null;
                    if (attackDebugLog()) {
                        StevesArmyMod.LOGGER.info("[AttackPhase] Soldier {} MOVING_TO_COVER -> SELECTING_COVER: target cover lost",
                            soldier.getId());
                    }
                    break;
                }

                // Movement is owned by tickSeekingCover() / tickRepositioning().
                // They handle navigation, micro-positioning, stuck detection,
                // retries, blacklisting, and timeout. ATTACK does NOT interpret
                // navigation.isDone() — that signal is unreliable because the
                // cover system intentionally stops vanilla navigation during the
                // micro-positioning handoff at COVER_VALID_DISTANCE.
                break;
            }

            case OCCUPYING_COVER: {
                if (coverState == CoverBehaviorManager.CoverState.NO_COVER) {
                    attackPhase = AttackPhase.SELECTING_COVER;
                    if (attackDebugLog()) {
                        StevesArmyMod.LOGGER.info("[AttackPhase] Soldier {} OCCUPYING_COVER -> SELECTING_COVER: cover state is NO_COVER",
                            soldier.getId());
                    }
                    break;
                }

                // Reconcile: if cover state indicates we're moving again (e.g., deferred
                // reposition request activated after recovery), don't try to advance here
                if (coverState == CoverBehaviorManager.CoverState.SEEKING_COVER ||
                    coverState == CoverBehaviorManager.CoverState.REPOSITIONING) {
                    attackPhase = AttackPhase.MOVING_TO_COVER;
                    if (attackDebugLog()) {
                        StevesArmyMod.LOGGER.info("[AttackPhase] Soldier {} OCCUPYING_COVER -> MOVING_TO_COVER: cover state changed to {}",
                            soldier.getId(), coverState);
                    }
                    break;
                }

                boolean suppressed = getCoverManager().isSuppressed();
                boolean pinned = getCoverManager().isPinned();
                boolean recovered = getCoverManager().getSuppressionTracker().isRecovered();
                if (!recovered) {
                    attackCoverArrivalTime = GameClock.nowMs();
                }
                long dwellTime = GameClock.nowMs() - attackCoverArrivalTime;
                PeekController peekCtrl = getPeekController();
                boolean peeking = peekCtrl.isExposed() || peekCtrl.isMovingToPeek() || peekCtrl.isReturning();
                float ftLevel = FireTeamSuppressionTracker.getLevel(soldier);
                boolean fireteamPinned = FireTeamSuppressionTracker.shouldPauseAttack(soldier);
                // An active smoke screen substitutes for personal recovery: bullets
                // through smoke still suppress, but the enemy can no longer observe
                // the advance route, so the team may bound forward through it.
                boolean smokeAdvance = StevesArmyConfig.isSmokeAdvanceUnderSmoke()
                    && SmokeDeploymentCoordinator.isScreenActive(soldier);

                // Explicit peek-completion event: set by PeekController via the
                // soldier when completeReturn() runs. No inference needed.
                // Fallback: infer from state if the event path was missed.
                if (!peekCompletedThisCover && !attackHasPeekedThisCover
                    && peekCtrl.getPeekCountSameCover() > 0 && !peeking
                    && peekCtrl.isIdleInCover()) {
                    attackHasPeekedThisCover = true;
                    peekCompletedThisCover = true;
                    if (attackDebugLog()) {
                        StevesArmyMod.LOGGER.info("[AttackPhase] Soldier {} inferred peek completion this cover (fallback)",
                            soldier.getId());
                    }
                }

                float dwellMult = (1.0f + ftLevel * 1.5f) * groupCohesionDwellMult();
                // Spine flow advance: hopping cover-to-cover along the route
                // with NO live contact is locomotion, not a fighting pause —
                // a glance per dock keeps the squad moving. Under contact,
                // or without a spine, the legacy fighting dwell applies
                // unchanged.
                boolean spineFlow = attackSpine != null
                    && !ContactPlan.hasLiveContact(soldier);
                long flowDwellMs = spineFlow
                    ? StevesArmyConfig.getAttackSpineFlowDwellMs() : ATTACK_MIN_DWELL_MS;
                long minDwell = (long)(flowDwellMs * dwellMult);
                long maxDwell = (long)((spineFlow ? flowDwellMs * 2L : ATTACK_MAX_DWELL_MS)
                    * dwellMult) + (attackAdvanceStaggerTicks * 50L);
                boolean dwellMet = dwellTime >= minDwell;
                boolean maxDwellReached = dwellTime >= maxDwell && (recovered || smokeAdvance)
                    && !peeking && (!fireteamPinned || smokeAdvance);
                boolean hardTimeout = dwellTime >= ATTACK_HARD_OCCUPANCY_TIMEOUT_MS;
                boolean heavyHold = StevesArmyConfig.isFireteamHeavyHoldReposition()
                    && FireTeamSuppressionTracker.isHeavilySuppressed(soldier);

                boolean canAdvance = dwellMet && (recovered || smokeAdvance)
                    && (!fireteamPinned || smokeAdvance) && (!heavyHold || smokeAdvance);

                // Base-of-fire dwell discipline: a docked MG is the squad's
                // support weapon — his job at a dock is to hold the firing
                // lane and keep the enemy pinned, not to cycle covers every
                // dwell window. The dwell clock alone churned him sideways
                // across a cover row (4 docks of 25t on one row: every
                // re-search's best behind-line candidate was the next spot on
                // the same row). He leaves a dock only when the rifleman line
                // has passed it by the leapfrog margin — the row gate then
                // hands him a cover behind the NEW line — or through the
                // repair paths below (reposition request, hard timeout).
                if (mgRowHoldActive(soldier)) {
                    canAdvance = false;
                    maxDwellReached = false;
                }

                // Secured area: this soldier's job is to hold a watch position,
                // not to keep advancing — every advance trigger below is a
                // clearing-advance trigger and stays off.
                if (clearingHold()) {
                    break;
                }

                // Cover-system repair moves: a dock the cover system itself
                // has condemned (lane lost, cover invalidated) must be able
                // to reposition even mid-clear.
                if (getCoverManager().isRepositionRequested() && recovered
                    && routineRepositionGateAllows()) {
                    if (attackDebugLog()) {
                        StevesArmyMod.LOGGER.info("[AttackPhase] Soldier {} OCCUPYING_COVER -> SELECTING_COVER: reposition requested, dwell={}ms",
                            soldier.getId(), dwellTime);
                    }
                    getCoverManager().clearRepositionRequest();
                    attackPhase = AttackPhase.SELECTING_COVER;
                    break;
                }

                // Clearing contribution: the assigned blind spot has been
                // observed, so this position no longer contributes to the
                // order. Move to the next useful thing once safety allows —
                // reaching cover is an intermediate success, never the goal.
                boolean clearingJobPending = clearingView != null
                    && clearingView.assignedPoi() != null
                    && !clearingView.assignedPoiChecked();

                // Coordinator-owned progression: a soldier HOLDING A DOCK in
                // CLEAR/STALLED no longer obeys the dwell clock. Jobs move
                // through the investigate advance (reachability-gated) and
                // the job-done transition below; the legacy peek-latch and
                // max-dwell watchdogs would tear down a contributing dock
                // every window and re-dock somewhere else — cover churn in a
                // quiet order. A dockless soldier keeps the legacy triggers:
                // re-searching is how he recovers a dock, and the search-fail
                // advance now converges on a job target instead of milling.
                // A pending ASSIGNED job is the only thing that holds the
                // dock — an order with no claim on this soldier (corner-less
                // areas) must keep the corridor advance alive, or the squad
                // strands outside a sparse objective: stage stays CLEAR
                // because nobody is inside, and the hold blocks the entry.
                if (clearingJobPending
                    && (clearingView.stage() == ClearingCoordinator.ClearingStage.CLEAR
                        || clearingView.stage() == ClearingCoordinator.ClearingStage.STALLED)
                    && (coverState == CoverBehaviorManager.CoverState.IN_COVER
                        || coverState == CoverBehaviorManager.CoverState.SUPPRESSED_IN_COVER)) {
                    break;
                }

                // A checked job frees the dock: the soldier contributes elsewhere
                // once safety allows (canAdvance).
                if (!clearingJobPending && clearingView != null
                    && clearingView.assignedPoi() != null
                    && canAdvance) {
                    lastAdvanceTriggerTime = GameClock.nowMs();
                    if (attackDebugLog()) {
                        StevesArmyMod.LOGGER.info("[AttackPhase] Soldier {} job target checked, advancing to next",
                            soldier.getId());
                    }
                    attackPhase = AttackPhase.SELECTING_COVER;
                    requestCoverSearch(QueuedSearchMode.ATTACK_SELECTING);
                    break;
                }

                // Hard watchdog: quiet docks may recover through the normal
                // launch gates, but live suppression must never force an exposed
                // attack advance merely because occupancy took too long.
                if (dwellMet && canAdvance && dwellTime > 10000
                    && (!dockAdvanceLaunchHeld() || smokeAdvance)) {
                    lastAdvanceTriggerTime = GameClock.nowMs();
                    if (attackDebugLog()) {
                        StevesArmyMod.LOGGER.info("[AttackPhase] Soldier {} OCCUPYING watchdog: stuck {}ms with all gates pass, forcing advance",
                            soldier.getId(), dwellTime);
                    }
                    attackPhase = AttackPhase.SELECTING_COVER;
                    requestCoverSearch(QueuedSearchMode.ATTACK_SELECTING);
                    break;
                }

                // The next bound must begin from cover. A delayed peek ducks back
                // at maximum dwell instead of blocking attack progression forever.
                if (dwellTime >= maxDwell && recovered && peeking) {
                    if (!peekCtrl.isReturning()) {
                        peekCtrl.forceReturnToCover(soldier, currentCover, getPositionController());
                    }
                    break;
                }

                if (attackDebugLog() && dwellMet && !recovered) {
                    StevesArmyMod.LOGGER.info("[AttackPhase] Soldier {} dwell met but blocked: recovered={}, suppression={}",
                        soldier.getId(), recovered,
                        String.format("%.2f", getCoverManager().getSuppressionTracker().getSuppressionLevel()));
                }

                // Recovery and the dock launch policy gate every trigger.
                // Timeouts may bypass a missing peek completion at a quiet dock.
                boolean peekLatchBypass = dwellMet && (recovered || smokeAdvance)
                    && (!fireteamPinned || smokeAdvance) && (!heavyHold || smokeAdvance)
                    && !peekCompletedThisCover && dwellTime >= (long)(minDwell * 2);
                // A hard timeout may recover a genuinely quiet, non-peekable
                // dock, but it must not launch a pinned soldier into the open.
                // The normal peek/max-dwell gates already enforce recovery;
                // keep this watchdog consistent with that doctrine.
                boolean hardTimeoutBlocked = (!canLeaveCoverNow() || dockAdvanceLaunchHeld()) && !smokeAdvance;
                if (hardTimeout && hardTimeoutBlocked && attackDebugLog()) {
                    StevesArmyMod.LOGGER.info(
                        "[AttackPhase] Soldier {} hard occupancy timeout held at dock: dwell={}ms suppression={} reason=HARD_OCCUPANCY_TIMEOUT",
                        soldier.getId(), dwellTime,
                        String.format("%.2f", getCoverManager().getSuppressionLevel()));
                }
                if (!hardTimeoutBlocked && (hardTimeout || maxDwellReached
                    || (canAdvance && peekCompletedThisCover) || peekLatchBypass)) {
                    lastAdvanceTriggerTime = GameClock.nowMs();
                    if (attackDebugLog() && hardTimeout) {
                        StevesArmyMod.LOGGER.info("[AttackPhase] Soldier {} hard occupancy timeout after {}ms, forcing advance",
                            soldier.getId(), dwellTime);
                    }
                    attackPhase = AttackPhase.SELECTING_COVER;
                    requestCoverSearch(QueuedSearchMode.ATTACK_SELECTING);
                }
                break;
            }

            case COMPLETE: {
                // Attack goal handles final approach
                break;
            }

            case NONE: {
                initAttackPhase();
                break;
            }
        }
    }

    /**
     * SECURE-stage hold: the squad-level area is checked and contact
     * resolved, so the soldier's job is to hold a watch position and every
     * clearing advance trigger stays off until the order completes.
     * STALLED deliberately does NOT hold — it is a report, not a stop. A
     * stalled squad keeps pursuing its assigned jobs (the coordinator keeps
     * them open), so a change in conditions — a door opened, suppression
     * lifted — finds the soldiers already moving instead of frozen behind a
     * hold they can never check their way out of.
     */
    private boolean clearingHold() {
        return clearingView != null
            && clearingView.stage() == ClearingCoordinator.ClearingStage.SECURE;
    }

    /**
     * Coordinator-job reachability with a cached verdict: a guide with no
     * walkable route is remembered for
     * {@link #CLEARING_POI_UNREACHABLE_BACKOFF_TICKS} so the executor holds
     * instead of stepping at a wall every window (the dockless mill) and the
     * path query is not re-run per failed search. A partial route (nodes
     * toward the guide but {@code canReach()} false — cross-building probes
     * fail accuracy-1 all the time) counts as reachable: the advance takes
     * the walkable part and re-probes when it ends.
     */
    private boolean clearingGuideReachable(BlockPos guide) {
        return clearingGuideRoute(guide) != null;
    }

    /**
     * Route probe for clearing guides. Returns the path when a walkable route
     * (full or partial) exists; only a null/nodeless path — no walkable node
     * toward the guide at all — is remembered as unreachable for
     * {@link #CLEARING_POI_UNREACHABLE_BACKOFF_TICKS}. The old behavior cached
     * the 600t backoff on a failed {@code canReach()} probe, which is how a
     * soldier inside a house ended up pinned at the interior wall nearest the
     * ping instead of taking the partial path out through the door behind him.
     */
    @javax.annotation.Nullable
    private Path clearingGuideRoute(BlockPos guide) {
        if (guide == null) {
            return null;
        }
        Long until = clearingUnreachableUntil.get(guide);
        if (until != null) {
            if (soldier.tickCount < until) {
                return null;
            }
            clearingUnreachableUntil.remove(guide);
        }
        Path path = soldier.getNavigation().createPath(
            guide.getX() + 0.5, guide.getY(), guide.getZ() + 0.5, 1);
        // Vanilla PathNavigation short-circuits a probe whose target matches
        // its cached targetPos while a walk is in flight: any earlier probe
        // to this guide (a rejected assemble window, a discarded
        // reachability check) caches the guide, and every later mid-walk
        // probe then replays the SOLDIER'S CURRENT DOCK WALK — a 1-5 node
        // path ending at his own dock — as the "route". That dock walk is
        // not a route anywhere: re-probe against offset targets, which the
        // short-circuit cannot have cached.
        if (path != null && path == soldier.getNavigation().getPath()
            && !soldier.getNavigation().isDone()) {
            int[][] probeOffsets = {{1, 0}, {0, 1}, {-1, 0}};
            for (int[] offset : probeOffsets) {
                Path retried = soldier.getNavigation().createPath(
                    guide.getX() + 0.5 + offset[0], guide.getY(),
                    guide.getZ() + 0.5 + offset[1], 1);
                if (retried == null || retried != soldier.getNavigation().getPath()) {
                    path = retried;
                    break;
                }
            }
        }
        // Wide-lens retry for far guides. The soldier A* caps BOTH the search
        // region and the walked-path-length at FOLLOW_RANGE (32): from inside
        // a building the door detour spends ~20 walked blocks before the route
        // even heads at the guide, so every cross-building probe ends as a
        // best-effort stub at the interior wall nearest the straight line —
        // the real exit walks AWAY from the guide until it rounds the
        // building, so it never wins best-effort. Re-probe with the lens
        // widened to the guide distance plus detour headroom (bounded): the
        // real route becomes reachable and the search returns the full path.
        net.minecraft.world.level.pathfinder.Node pathEnd =
            path == null ? null : path.getEndNode();
        double guideDx = guide.getX() + 0.5 - soldier.getX();
        double guideDz = guide.getZ() + 0.5 - soldier.getZ();
        double guideDistSq = guideDx * guideDx + guideDz * guideDz;
        // A stub is not just a path that ends at the soldier's feet: the
        // best-effort interior collapse can end several blocks away (the
        // partition gap, a far wall) and still leave the guide exactly as
        // far off as before. A real egress route must CUT the guide
        // distance; anything that barely dents it is the same collapse in
        // a longer costume and gets the wide lens too.
        double guideDist = Math.sqrt(guideDistSq);
        double endGuideDist = pathEnd == null ? Double.MAX_VALUE
            : Math.sqrt(pathEnd.asBlockPos().distSqr(guide));
        boolean stubRoute = pathEnd == null
            || pathEnd.asBlockPos().distSqr(soldier.blockPosition()) < 9.0D
            || endGuideDist > guideDist - 8.0D;
        if (guideDistSq > 64.0D && (path == null || path.getNodeCount() == 0 || stubRoute)) {
            float lensRange = (float) Math.min(96.0D, guideDist + 24.0D);
            Path widened = soldier.getNavigation() instanceof SoldierGroundNavigation nav
                ? nav.createWidePath(guide, 1, lensRange)
                : null;
            net.minecraft.world.level.pathfinder.Node wideEnd =
                widened == null ? null : widened.getEndNode();
            if (widened != null && widened.getNodeCount() > 0 && wideEnd != null
                && wideEnd.asBlockPos().distSqr(soldier.blockPosition()) > 9.0D
                && Math.sqrt(wideEnd.asBlockPos().distSqr(guide)) < guideDist - 8.0D) {
                if (attackDebugLog()) {
                    StevesArmyMod.LOGGER.info(
                        "[AttackAdvance] Soldier {} wide-lens route to {} ({} nodes, canReach={}, lens={})",
                        soldier.getId(), guide.toShortString(), widened.getNodeCount(),
                        widened.canReach(), lensRange);
                }
                return widened;
            }
        }
        if (path == null || path.getNodeCount() == 0) {
            clearingUnreachableUntil.put(guide.immutable(),
                (long) soldier.tickCount + CLEARING_POI_UNREACHABLE_BACKOFF_TICKS);
            if (attackDebugLog()) {
                StevesArmyMod.LOGGER.info("[AttackAdvance] Soldier {} guide {} has no route, backing off {}t",
                    soldier.getId(), guide.toShortString(), CLEARING_POI_UNREACHABLE_BACKOFF_TICKS);
            }
            return null;
        }
        return path;
    }

    /**
     * CLEAR-stage job target: the coordinator-assigned blind spot while it is
     * still unchecked, falling through to the nearest unclaimed unchecked one.
     * The nearest-unchecked tie is deliberately sticky: a soldier standing
     * between two unchecked clusters is near-equidistant to both, and re-
     * resolving the pick every tick dithers his advance (target flapping east
     * and west, search centers churning, short back-and-forth fallback walks).
     * The held target is only given up when it gets checked, an assigned
     * claim replaces it, or a candidate is meaningfully closer — the
     * comparison runs on squared distances, so the 0.5 factor switches at
     * ~0.71x the old distance (sqrt(0.5)).
     * null means advance the plain way (approach corridor or area reposition).
     */
    private BlockPos resolveClearingPoi(ClearingCoordinator.ClearingView view) {
        // STALLED keeps resolving jobs on purpose: it is a report, not a hold,
        // and the stalled squad must still be working its check targets.
        if (view.stage() != ClearingCoordinator.ClearingStage.CLEAR
            && view.stage() != ClearingCoordinator.ClearingStage.STALLED) {
            // APPROACH's plain objective-advance stalls when the ping is
            // CLOSE but through a wall: the soldier reads "at the objective"
            // from Euclidean distance, docks, and no driver walks the last
            // stretch into the area (the stale-target investigate needs a
            // resolved job, the assemble pull needs a healthy area). Resolve
            // his claim when it is within investigate range, so the stale
            // window carries him in — gated like every advance. Far from the
            // area the plain advance still owns the march; leave it alone.
            if (view.stage() != ClearingCoordinator.ClearingStage.APPROACH) {
                return null;
            }
            BlockPos mine = view.assignedPoi();
            if (mine == null || view.assignedPoiChecked()
                || mine.distSqr(soldier.blockPosition()) > CLEARING_INVESTIGATE_BAND_SQ) {
                return null;
            }
            return mine;
        }
        BlockPos mine = view.assignedPoi();
        if (mine != null && !view.assignedPoiChecked()) {
            return mine;
        }
        // No live claim (or the claim was just consumed): hold the previous
        // open target rather than free-picking nearest every tick.
        if (clearingPoiTarget != null
            && ClearingCoordinator.isTargetStillOpen(soldier, clearingPoiTarget)) {
            BlockPos next = view.nextPoi();
            if (next == null || next.equals(clearingPoiTarget)) {
                return clearingPoiTarget;
            }
            double keep = clearingPoiTarget.distSqr(soldier.blockPosition());
            double candidate = next.distSqr(soldier.blockPosition());
            return candidate < keep * 0.5 ? next : clearingPoiTarget;
        }
        return view.nextPoi();
    }

    /**
     * Select forward cover biased toward the objective.
     * Returns true if cover was found and navigation started.
     */
    private boolean selectForwardCover() {
        if (!soldier.hasValidAttackTarget()) return false;
        exactPathValidationBudget = new ExactPathValidationBudget();
        BlockPos objective = soldier.getAttackTargetPos();

        // Compute forward-biased search center
        Vec3 toTarget = new Vec3(
            objective.getX() - soldier.getX(),
            0,
            objective.getZ() - soldier.getZ());
        double distToTarget = toTarget.length();
        if (distToTarget < 1.0) return false;

        toTarget = toTarget.normalize();
        double ahead = Math.min(distToTarget * 0.25, ATTACK_FORWARD_BIAS_BLOCKS);
        BlockPos searchCenter = soldier.blockPosition().offset(
            (int)(toTarget.x * ahead), 0, (int)(toTarget.z * ahead));

        BlockPos machineGunnerAnchor = getMachineGunnerSearchCenter();
        if (machineGunnerAnchor != null && clearingPoiTarget == null) {
            searchCenter = machineGunnerAnchor;
        }

        Level level = soldier.level();
        CoverFinder finder = new CoverFinder(level);
        Vec3 threatDirection = getThreats().getPrimaryDirection(soldier.position());
        List<LivingEntity> threats = getThreatList();
        SquadCoverContext squadCtx = buildSquadCoverContext();

        List<CoverFinder.ScoredCover> scored = finder.evaluateAndScoreAllFromCenter(
            searchCenter, soldier, threatDirection, threats, ATTACK_CORRIDOR_SEARCH_RADIUS, squadCtx);

        CoverPoint currentCover = getCoverManager().getCurrentCover();
        Vec3 soldierPos = soldier.position();
        Vec3 objectiveDir = new Vec3(
            objective.getX() - soldierPos.x, 0, objective.getZ() - soldierPos.z).normalize();

        Direction threatDir = (threatDirection != null && threatDirection.lengthSqr() > 0.001)
            ? CoverFinder.getDirectionFromVector(threatDirection) : null;

        // Filter: require forward progress AND primary-threat protection,
        // reject current/blacklisted covers
        for (CoverFinder.ScoredCover sc : scored) {
            CoverPoint cover = sc.cover;

            // Skip current cover
            if (currentCover != null && cover.getPosition().equals(currentCover.getPosition())) continue;

            // Skip blacklisted
            if (failedCoverPositions.contains(cover.getPosition())) continue;

            // Hard forward progress filter
            Vec3 candidateDisp = cover.getPosition().getCenter().subtract(soldierPos);
            double forwardProgress = candidateDisp.x * objectiveDir.x + candidateDisp.z * objectiveDir.z;
            if (!isAttackCorridorCandidate(cover, objective, objectiveDir)) continue;

            // Don't go beyond the objective
            double distToObj = cover.getPosition().distSqr(objective);
            if (distToObj <= ATTACK_OBJECTIVE_RADIUS * ATTACK_OBJECTIVE_RADIUS) continue;

            // Hard primary-threat protection preference
            if (!finder.isPrimaryThreatProtected(cover, soldier, threatDirection)) {
                continue;
            }

            // Use canonical repositioning transition instead of direct moveToCover
            if (startRepositioning(cover)) {
                attackExpectedCover = cover.getPosition();
                if (attackDebugLog()) {
                    StevesArmyMod.LOGGER.info("[AttackForward] Soldier {} selected forward cover {} progress={}",
                        soldier.getId(), cover.getPosition(), String.format("%.1f", forwardProgress));
                }
                return true;
            }
        }

        List<CoverFinder.ScoredCover> localScored = finder.evaluateAndScoreAll(
            soldier, threatDirection, threats, ATTACK_CORRIDOR_SEARCH_RADIUS, true, squadCtx);
        Optional<CoverPoint> wideCover = findWideForwardAttackCover(localScored, currentCover,
            objective, objectiveDir, threatDir);
        if (wideCover.isPresent() && startRepositioning(wideCover.get())) {
            attackExpectedCover = wideCover.get().getPosition();
            if (attackDebugLog()) {
                StevesArmyMod.LOGGER.info("[AttackForward] Soldier {} selected wide-sector cover {}",
                    soldier.getId(), wideCover.get().getPosition());
            }
            return true;
        }

        return false;
    }

    /**
     * Advance through a short uncovered segment using the same navigation owner
     * as cover movement. The next attack tick immediately searches the corridor
     * again, so a newly available cover can interrupt this fallback naturally.
     */
    /**
     * SECURE-phase assemble: path the WHOLE way to the guide in one order —
     * the chunked fallback advance (short legs plus a cooldown between them)
     * crosses a building at a snail's pace and can run out of scenario clock.
     * Arrival and stuck handling are the shared fallback machinery.
     */
    /**
     * Window-driven advance toward a far target (investigate far-job,
     * refused reposition, direct egress): hop along the advance spine when
     * one exists — dock-to-dock between hops is the cover machinery's job,
     * and the covers between here and the objective get USED. The full-route
     * assemble walk is the spine-less fallback only: it crosses the street
     * in one unprotected sprint and is exactly the "direct pathfind" the
     * path-based progression exists to replace.
     */
    private void startWindowAdvance() {
        if (attackSpine != null) {
            startFallbackAdvance();
        } else {
            startAssembleAdvance();
        }
    }

    private void startAssembleAdvance() {
        if (!soldier.hasValidAttackTarget()) return;
        BlockPos guide = clearingPoiTarget != null
            ? clearingPoiTarget : soldier.getAttackTargetPos();
        // Partial routes are taken too: the walk follows the path out through
        // the door and the window machinery re-probes when the path ends.
        Path path = clearingGuideRoute(guide);
        if (path == null) {
            // Unreachable for now: back off before hammering the same query.
            assembleRetryAfterTick = soldier.tickCount + CLEARING_ASSEMBLE_RETRY_BACKOFF_TICKS;
            if (attackDebugLog()) {
                StevesArmyMod.LOGGER.info("[AttackAdvance] Soldier {} assemble path unreachable to {}, backing off",
                    soldier.getId(), guide);
            }
            return;
        }
        // Stub guard: a "route" that ends where the soldier already stands
        // while the guide is far away is not an egress — and neither is one
        // that shuffles a few blocks to a partition gap without cutting the
        // guide distance (clearingGuideRoute's lens then failed too). A*
        // found nothing walkable toward the guide (boxed-in start cell,
        // degenerate probe) — none of that proves the guide unreachable, so
        // retry the window later but do NOT arm the 600t unreachable cache:
        // the cache turns one bad probe into a half-minute freeze that
        // repeats.
        net.minecraft.world.level.pathfinder.Node stubEnd = path.getEndNode();
        double guideDistSq = guide.distSqr(soldier.blockPosition());
        double endGuideDist = stubEnd == null ? Double.MAX_VALUE
            : Math.sqrt(stubEnd.asBlockPos().distSqr(guide));
        if (stubEnd != null && guideDistSq > 36.0D
            && (stubEnd.asBlockPos().distSqr(soldier.blockPosition()) < 9.0D
                || endGuideDist > Math.sqrt(guideDistSq) - 8.0D)) {
            assembleRetryAfterTick = soldier.tickCount + CLEARING_ASSEMBLE_RETRY_BACKOFF_TICKS;
            if (attackDebugLog()) {
                StevesArmyMod.LOGGER.info(
                    "[AttackAdvance] Soldier {} stub route to {} ({} nodes from {}), retrying",
                    soldier.getId(), guide.toShortString(), path.getNodeCount(),
                    stubEnd.asBlockPos().toShortString());
            }
            return;
        }
        ContactPlan.MovePermission permission = ContactPlan.checkAdvance(soldier, guide);
        if (!permission.allowed) {
            soldier.getEngagementTelemetry().setMovingSupported(false, permission.reason, "contact-plan");
            assembleRetryAfterTick = soldier.tickCount + CLEARING_ASSEMBLE_RETRY_BACKOFF_TICKS;
            return;
        }
        soldier.getEngagementTelemetry().setMovingSupported(true, "", "contact-plan");
        fallbackAdvanceTarget = guide;
        fallbackAdvanceAssemble = true;
        fallbackAdvanceArriveDistSq = 4.0;
        fallbackStuckTicks = 0;
        fallbackLastPosition = soldier.position();
        fallbackNoProgressResets = 0;
        soldier.getNavigation().moveTo(path, 1.2D);
        if (attackDebugLog()) {
            StevesArmyMod.LOGGER.info("[AttackAdvance] Soldier {} assembling into the cleared area at {}",
                soldier.getId(), guide);
        }
    }

    private void startFallbackAdvance() {
        if (!soldier.hasValidAttackTarget()) return;
        fallbackAdvanceAssemble = false;
        // Clearing jobs advance toward the assigned blind-spot check instead
        // of the raw objective: an unchecked corner can sit far past the
        // legacy 4-block objective stop, so the stop radius only applies to
        // plain objective advances.
        BlockPos guide = clearingPoiTarget != null
            ? clearingPoiTarget : soldier.getAttackTargetPos();
        double stopRadius = clearingPoiTarget != null ? 1.0 : ATTACK_OBJECTIVE_RADIUS;

        Vec3 toTarget = new Vec3(
            guide.getX() - soldier.getX(),
            0,
            guide.getZ() - soldier.getZ());
        double dist = toTarget.length();
        if (dist < stopRadius) return;

        // Spine hop: with an advance spine, legs walk ALONG the route — a
        // straight-line leg from inside a building points at a wall, and the
        // whole point of the spine is that the real route is known. The leg
        // ends at route-progress +HOP; docking between hops is the cover
        // machinery's job (the next ATTACK_SELECTING search is spine-filtered).
        if (attackSpine != null) {
            double soldierProg = attackSpine.progress(soldier.blockPosition());
            if (soldierProg >= attackSpine.length() - 2.0D) {
                // End of the spine while the objective is still beyond the
                // stop radius: the probe returned a PARTIAL route (node
                // budget, walked-cap roulette) and its end is a dead point —
                // clamped hops would loop here forever. Drop the spine and
                // re-probe from this advanced position; the wide lens from
                // mid-route usually reaches the rest of the way.
                attackSpine = null;
                soldier.setAttackSpine(null);
                spineRetryAfterTick = 0;
                if (attackDebugLog()) {
                    StevesArmyMod.LOGGER.info(
                        "[AttackAdvance] Soldier {} reached end of partial spine at progress {} — re-probing",
                        soldier.getId(), String.format("%.1f", soldierProg));
                }
                return;
            }
            double legEnd = Math.min(attackSpine.length(), soldierProg + ATTACK_SPINE_LEG_LENGTH);
            BlockPos destBlock = attackSpine.pointAt(legEnd, soldier.blockPosition().getY());
            Path path = soldier.getNavigation().createPath(
                destBlock.getX() + 0.5, destBlock.getY(), destBlock.getZ() + 0.5, 1);
            if (path != null && path.canReach()) {
                ContactPlan.MovePermission permission = ContactPlan.checkAdvance(soldier, destBlock);
                if (permission.allowed) {
                    soldier.getEngagementTelemetry().setMovingSupported(true, "", "contact-plan");
                    fallbackAdvanceTarget = destBlock;
                    fallbackAdvanceAssemble = true;
                    fallbackAdvanceArriveDistSq = 4.0;
                    fallbackStuckTicks = 0;
                    fallbackLastPosition = soldier.position();
                    fallbackNoProgressResets = 0;
                    soldier.getNavigation().moveTo(path, 1.2D);
                    if (attackDebugLog()) {
                        StevesArmyMod.LOGGER.info(
                            "[AttackAdvance] Soldier {} spine hop to {} (route {}+{} blocks)",
                            soldier.getId(), destBlock.toShortString(),
                            String.format("%.1f", soldierProg),
                            String.format("%.1f", ATTACK_SPINE_HOP_LENGTH));
                    }
                    return;
                }
                soldier.getEngagementTelemetry().setMovingSupported(false, permission.reason, "contact-plan");
                // Row gate on a full leg: fall back to a shortened catch-up
                // step that the same gate allows, so the gunner trails the
                // squad instead of freezing until the front is a leg-length
                // ahead. Full legs resume once the squad stretches out.
                if ("mg back row".equals(permission.reason)) {
                    for (double frac : CATCHUP_LEG_FRACTIONS) {
                        double shortEnd = Math.min(attackSpine.length(),
                            soldierProg + ATTACK_SPINE_LEG_LENGTH * frac);
                        if (shortEnd <= soldierProg + 1.0D) {
                            continue;
                        }
                        BlockPos shortDest = attackSpine.pointAt(shortEnd,
                            soldier.blockPosition().getY());
                        if (!ContactPlan.checkAdvance(soldier, shortDest).allowed) {
                            continue;
                        }
                        Path shortPath = soldier.getNavigation().createPath(
                            shortDest.getX() + 0.5, shortDest.getY(), shortDest.getZ() + 0.5, 1);
                        if (shortPath == null || !shortPath.canReach()) {
                            continue;
                        }
                        soldier.getEngagementTelemetry().setMovingSupported(true, "", "contact-plan");
                        fallbackAdvanceTarget = shortDest;
                        fallbackAdvanceAssemble = true;
                        fallbackAdvanceArriveDistSq = 4.0;
                        fallbackStuckTicks = 0;
                        fallbackLastPosition = soldier.position();
                        fallbackNoProgressResets = 0;
                        soldier.getNavigation().moveTo(shortPath, 1.2D);
                        return;
                    }
                }
                return;
            }
            // Spine hop unpathable (transient terrain): fall through to the
            // legacy straight-line leg below.
        }

        Vec3 dir = toTarget.normalize();
        double advanceLen = Math.min(ATTACK_FALLBACK_ADVANCE_LENGTH, dist - stopRadius);
        if (advanceLen < 1.0) return;

        Vec3 dest = soldier.position().add(dir.x * advanceLen, 0, dir.z * advanceLen);
        BlockPos destBlock = new BlockPos((int)Math.floor(dest.x), soldier.blockPosition().getY(), (int)Math.floor(dest.z));

        Path path = soldier.getNavigation().createPath(destBlock.getX() + 0.5, destBlock.getY(), destBlock.getZ() + 0.5, 1);
        if (path == null || !path.canReach()) {
            // The straight-line chunk destination can sit behind a wall even
            // when a walkable route to the guide exists (interior rooms, L-
            // shaped streets) — silently aborting here is how soldiers ended
            // up pinned at the interior wall nearest the ping. Retry the full
            // route to the guide and make the path end the segment target.
            Path fullRoute = clearingGuideRoute(guide);
            if (fullRoute == null) {
                fallbackAdvanceTarget = null;
                return;
            }
            var end = fullRoute.getNode(fullRoute.getNodeCount() - 1);
            destBlock = new BlockPos(end.x, end.y, end.z);
            path = fullRoute;
        }

        // Contact plan: no unsupported soldier crosses the threat's danger
        // arc, even with a walkable route in hand.
        ContactPlan.MovePermission permission = ContactPlan.checkAdvance(soldier, destBlock);
        if (!permission.allowed) {
            soldier.getEngagementTelemetry().setMovingSupported(false, permission.reason, "contact-plan");
            fallbackAdvanceTarget = null;
            return;
        }
        soldier.getEngagementTelemetry().setMovingSupported(true, "", "contact-plan");

        fallbackAdvanceTarget = destBlock;
        fallbackAdvanceArriveDistSq = 4.0;
        fallbackStuckTicks = 0;
        fallbackLastPosition = soldier.position();
        fallbackNoProgressResets = 0;
        soldier.getNavigation().moveTo(path, 1.2D);

        if (attackDebugLog()) {
            StevesArmyMod.LOGGER.info("[AttackAdvance] Soldier {} advancing to {} (len={}, objDist={})",
                soldier.getId(), destBlock, String.format("%.1f", advanceLen), String.format("%.1f", dist));
        }
    }

    /**
     * CLEAR-phase investigate step: release the dock and let the cover system
     * re-dock this soldier nearer the assigned check target (the reposition
     * search centers on the clearing target). Walking directly is not an
     * option from a dock — the dock anchor owns movement — so the reposition
     * is the only legal way to hand over the legs.
     */
    private boolean startInvestigateReposition(BlockPos poi) {
        // The clearing JOB licenses the walk even before anyone has sighted
        // anything: an ATTACK order's blind spots must be walked without a
        // live target, or never-sighted rooms never get checked (the
        // checker-death finding — the order latched STALLED and the squad
        // still would not move because no target ever existed to gate on).
        if (poi == null) return false;
        if (!soldier.hasValidAttackTarget() && !ClearingCoordinator.hasActiveClearing(soldier)) {
            return false;
        }
        // Contact plan (INC 2): the assigned blind spot is a task, not a
        // movement permission. A denial holds the dock — the re-dock search
        // would otherwise walk the soldier across the danger arc alone.
        ContactPlan.MovePermission permission = ContactPlan.checkAdvance(soldier, poi);
        if (!permission.allowed) {
            soldier.getEngagementTelemetry().setMovingSupported(false, permission.reason, "contact-plan");
            if (attackDebugLog()) {
                StevesArmyMod.LOGGER.info("[AttackAdvance] Soldier {} investigate {} denied by contact plan: {}",
                    soldier.getId(), poi.toShortString(), permission.reason);
            }
            return false;
        }
        soldier.getEngagementTelemetry().setMovingSupported(true, "", "contact-plan");
        if (attackDebugLog()) {
            StevesArmyMod.LOGGER.info("[AttackAdvance] Soldier {} investigating job {} (repositioning closer)",
                soldier.getId(), poi.toShortString());
        }
        // Arm the delivery grade: when the re-dock lands, the dock-arrival
        // block measures whether this window actually approached the job.
        investigateJob = poi.immutable();
        investigateStartPos = soldier.position();
        startRepositioning();
        return true;
    }

    private void tickFallbackAdvance() {
        if (fallbackAdvanceTarget == null) return;

        // Mid-walk re-suppression (suppressedRelocationSafeRoute): an exposed
        // open-ground advance leg caught by resumed fire is NOT a dock
        // approach — the doctrine escape owns it. With the origin dock claim
        // still held he returns to it (re-hold suppressed-in-cover, the
        // verified no-walk-out behavior); dockless, the handoff runs the
        // dockless suppressed search, whose escape branch dash/crawls to the
        // best available cover instead of freezing him in the open. Player-
        // ordered moves never walk fallback legs, so the relocation exemption
        // is implicit.
        if (StevesArmyConfig.isSuppressedRelocationSafeRoute()
            && relocationType == RelocationType.NONE
            && !soldier.hasValidPingSuppressPos()
            && getCoverManager().getTargetCover() == null
            && getCoverManager().isSuppressed()) {
            if (attackDebugLog()) {
                StevesArmyMod.LOGGER.info("[AttackAdvance] Soldier {} advance leg to {} halted: re-suppressed mid-walk",
                    soldier.getId(), fallbackAdvanceTarget.toShortString());
            }
            fallbackAdvanceTarget = null;
            fallbackAdvanceAssemble = false;
            fallbackLastPosition = null;
            fallbackStuckTicks = 0;
            navigation.stop();
            CoverPoint originDock = getCoverManager().getCurrentCover();
            if (originDock != null) {
                holdSuppressedAtDock(originDock);
            } else {
                runDocklessSuppressedSearch();
            }
            return;
        }

        // Keep the exposure gate live while the walk owns the legs: the spine
        // only refreshes it on rebuilds, and a stale "indoors" verdict would
        // keep the search suspended long after the soldier is in the open.
        BlockPos walkObjective = soldier.getAttackTargetPos();
        if (attackSpine != null && walkObjective != null) {
            refreshSpineExposure(walkObjective);
        }

        // Contact-plan mid-walk check: if support was lost while advancing,
        // the segment completes only when continuing increases the distance
        // to the threat; otherwise stop at once — walking into the danger
        // arc alone is exactly the lone-rush death this gate exists for.
        if (!ContactPlan.checkAdvance(soldier, fallbackAdvanceTarget).allowed) {
            Vec3 danger = ContactPlan.dangerPoint(soldier);
            boolean completesToSafety = danger == null
                || Vec3.atCenterOf(fallbackAdvanceTarget).distanceToSqr(danger)
                    >= soldier.position().distanceToSqr(danger);
            if (!completesToSafety) {
                if (attackDebugLog()) {
                    StevesArmyMod.LOGGER.info(
                        "[AttackAdvance] Soldier {} advance to {} halted mid-walk: contact-plan support lost",
                        soldier.getId(), fallbackAdvanceTarget.toShortString());
                }
                soldier.getEngagementTelemetry().setMovingSupported(
                    false, "support lost mid-walk", "contact-plan");
                fallbackAdvanceTarget = null;
                fallbackAdvanceAssemble = false;
                fallbackLastPosition = null;
                fallbackStuckTicks = 0;
                navigation.stop();
                return;
            }
        }

        double distance = soldier.distanceToSqr(
            fallbackAdvanceTarget.getX() + 0.5,
            fallbackAdvanceTarget.getY() + 0.5,
            fallbackAdvanceTarget.getZ() + 0.5);
        if (distance <= fallbackAdvanceArriveDistSq) {
            if (fallbackAdvanceAssemble && attackDebugLog()) {
                StevesArmyMod.LOGGER.info("[AttackAdvance] Soldier {} assemble arrived at {}",
                    soldier.getId(), fallbackAdvanceTarget);
            }
            fallbackAdvanceTarget = null;
            fallbackAdvanceAssemble = false;
                fallbackLastPosition = null;
            fallbackStuckTicks = 0;
            return;
        }

        if (fallbackLastPosition != null && soldier.position().distanceToSqr(fallbackLastPosition) < 0.01) {
            fallbackStuckTicks++;
        } else {
            fallbackStuckTicks = 0;
        }
        fallbackLastPosition = soldier.position();

        if (fallbackStuckTicks >= ATTACK_FALLBACK_STUCK_TICKS) {
            if (fallbackAdvanceAssemble) {
                // Assemble legs interrupted (cover arbitration, blocked path):
                // report the failure and back the retry off instead of
                // re-pathing into the same obstruction every window.
                assembleRetryAfterTick = soldier.tickCount + CLEARING_ASSEMBLE_RETRY_BACKOFF_TICKS;
                if (attackDebugLog()) {
                    StevesArmyMod.LOGGER.info("[AttackAdvance] Soldier {} assemble advance stalled at {}, backing off",
                        soldier.getId(), soldier.blockPosition());
                }
            }
            fallbackAdvanceTarget = null;
            fallbackAdvanceAssemble = false;
                fallbackLastPosition = null;
            fallbackStuckTicks = 0;
            fallbackNoProgressResets++;
            navigation.stop();
            if (attackDebugLog() && !fallbackAdvanceAssemble) {
                StevesArmyMod.LOGGER.info("[AttackAdvance] Soldier {} fallback advance stopped after no progress (reset {})",
                    soldier.getId(), fallbackNoProgressResets);
            }
            return;
        }

        if (navigation.isDone()) {
            navigation.moveTo(
                fallbackAdvanceTarget.getX() + 0.5,
                fallbackAdvanceTarget.getY(),
                fallbackAdvanceTarget.getZ() + 0.5,
                1.2D);
        }
    }

    private CoverPositionController getPositionController() {
        return (CoverPositionController) soldier.getMoveControl();
    }

    private void maintainCoverAnchorIfHiding(CoverPoint cover) {
        if (cover != null && getPeekController().isIdleInCover()) {
            getPositionController().maintainCoverAnchor(getCoverStandingPosition(cover.getPosition()));
        }
    }
    
public static Vec3 getCoverStandingPositionStatic(BlockPos coverPos) {
        return new Vec3(coverPos.getX() + 0.5, coverPos.getY(), coverPos.getZ() + 0.5);
    }

    private Vec3 getCoverStandingPosition(BlockPos coverPos) {
        return getCoverStandingPositionStatic(coverPos);
    }

    private double horizontalDistanceToCover(CoverPoint cover) {
        Vec3 standingPos = getCoverStandingPosition(cover.getPosition());
        double x = soldier.getX() - standingPos.x;
        double z = soldier.getZ() - standingPos.z;
        return Math.sqrt(x * x + z * z);
    }

    private boolean isDistantRelocationCover(CoverPoint cover) {
        return relocationType != RelocationType.NONE
            && horizontalDistanceToCover(cover) > RELOCATION_EXACT_PATH_DISTANCE;
    }

    private boolean isExactCoverPathReachable(CoverPoint cover) {
        BlockPos source = soldier.blockPosition();
        BlockPos target = cover.getPosition();
        if (soldier.tickCount != validatedCoverPathTick
            || !source.equals(validatedCoverPathSource)) {
            validatedCoverPaths.clear();
            unreachableCoverPaths.clear();
            validatedCoverPathSource = source.immutable();
            validatedCoverPathTick = soldier.tickCount;
        }
        if (validatedCoverPaths.containsKey(target)) {
            return true;
        }
        // Unreachable targets are the expensive probes (A* exhausts the whole
        // region), so a miss is remembered for this tick and source block instead
        // of being re-charged by later passes over the same candidates.
        if (unreachableCoverPaths.contains(target)) {
            return false;
        }

        if (!exactPathValidationBudget.tryAcquire()) {
            PerformanceMetrics.recordExactCoverPathValidationBudgetExhausted();
            return false;
        }

        Vec3 standingPos = getCoverStandingPosition(cover.getPosition());
        long pathStarted = System.nanoTime();
        Path path = navigation.createPath(standingPos.x, standingPos.y, standingPos.z, 0);
        PerformanceMetrics.recordStageTime(PerformanceMetrics.Stage.PATH_REQUEST,
            System.nanoTime() - pathStarted);
        boolean reachable = path != null && path.canReach() && path.getNodeCount() > 0
            && path.getNode(path.getNodeCount() - 1).asBlockPos().equals(cover.getPosition());
        PerformanceMetrics.recordExactCoverPathValidation(reachable);
        if (reachable) {
            validatedCoverPaths.put(target.immutable(), path);
        } else {
            unreachableCoverPaths.add(target.immutable());
        }
        return reachable;
    }

    private boolean hasExactPathValidationBudget() {
        return exactPathValidationBudget.hasRemaining();
    }

    /**
     * Evaluates only the highest-scoring suppression candidates. The exposure cache
     * belongs to this search, so it is discarded before terrain or fire sources can
     * make it stale.
     */
    @javax.annotation.Nullable
    private SuppressionRoutePlan selectSuppressionRoute(CoverFinder finder, Vec3 threatDirection,
                                                         List<LivingEntity> threats, int searchRadius,
                                                         SquadCoverContext squadCtx, List<Vec3> firingOrigins) {
        List<CoverFinder.ScoredCover> candidates = finder.evaluateAndScoreAll(
            soldier, threatDirection, threats, searchRadius, true, squadCtx);
        CoverPoint currentCover = getCoverManager().getCurrentCover();
        Map<BlockPos, RouteNodeExposure> exposureCache = new HashMap<>();
        SuppressionRoutePlan protectedPlan = null;
        SuppressionRoutePlan crawlPlan = null;
        // Escape mode only: best-scored path-validated candidate regardless of
        // exposure — when the classifier withholds everything, the doctrine
        // still says MOVE (see startSuppressedEscapeMove).
        SuppressionRoutePlan escapePlan = null;
        int validPathsEvaluated = 0;

        for (CoverFinder.ScoredCover scored : candidates) {
            if (validPathsEvaluated >= SUPPRESSION_ROUTE_CANDIDATE_LIMIT) {
                break;
            }
            CoverPoint cover = scored.cover;
            if (failedCoverPositions.contains(cover.getPosition())
                || (currentCover != null && cover.getPosition().equals(currentCover.getPosition()))
                || (emergencyCoverSearchActive && currentCover != null
                    && cover.getPosition().equals(currentCover.getPosition()))) {
                continue;
            }
            if (!isUsableAgainstThreat(finder, cover, threatDirection)
                || squadCtx.violatesDefensiveSpacing(cover.getPosition())) {
                continue;
            }

            if (!hasExactPathValidationBudget()) {
                break;
            }
            if (!isExactCoverPathReachable(cover)) {
                continue;
            }
            Path path = validatedCoverPaths.get(cover.getPosition());
            validPathsEvaluated++;

            RouteNodeExposure exposure = classifySuppressionRoute(path, firingOrigins, exposureCache);
            if (suppressionEscapeSearchActive && escapePlan == null) {
                escapePlan = new SuppressionRoutePlan(cover, path,
                    escapeMovementFor(cover, firingOrigins), false, firingOrigins);
            }
            SuppressionRoutePlan plan = new SuppressionRoutePlan(cover, path,
                exposure == RouteNodeExposure.CRAWL_SAFE ? RouteMovement.CRAWL : RouteMovement.NORMAL,
                exposure == RouteNodeExposure.CRAWL_SAFE, firingOrigins);
            if (exposure == RouteNodeExposure.PROTECTED && protectedPlan == null) {
                protectedPlan = plan;
            } else if (exposure == RouteNodeExposure.CRAWL_SAFE && crawlPlan == null) {
                crawlPlan = plan;
            }
        }

        SuppressionRoutePlan selected = protectedPlan != null ? protectedPlan
            : crawlPlan != null ? crawlPlan
            : escapePlan;
        if (selected != null && DiagnosticLogManager.isCoverLoggingEnabled()) {
            StevesArmyMod.LOGGER.info("[CoverSuppression] Soldier {} selected {} route to {} after evaluating {} candidates",
                soldier.getId(), selected.movement().name().toLowerCase(java.util.Locale.ROOT),
                selected.cover().getPosition(), validPathsEvaluated);
        }
        return selected;
    }

    /**
     * Route exposure against EVERY known firing origin: suppression fire often
     * comes from several shooters along a line, so a lane that dodges only the
     * latest origin can still cross a second shooter's sight. A node must be
     * shielded from all origins to be PROTECTED; any eye-only lane makes the
     * route CRAWL_SAFE; any lower-body lane is EXPOSED.
     */
    private RouteNodeExposure classifySuppressionRoute(Path path, List<Vec3> firingOrigins,
                                                        Map<BlockPos, RouteNodeExposure> exposureCache) {
        boolean hasCrawlSafeNode = false;
        for (int i = 0; i < path.getNodeCount(); i++) {
            BlockPos nodePos = path.getNode(i).asBlockPos();
            RouteNodeExposure nodeExposure = exposureCache.computeIfAbsent(nodePos,
                pos -> classifySuppressionNode(Vec3.atCenterOf(pos), firingOrigins));
            if (nodeExposure == RouteNodeExposure.EXPOSED) {
                return RouteNodeExposure.EXPOSED;
            }
            hasCrawlSafeNode |= nodeExposure == RouteNodeExposure.CRAWL_SAFE;
            if (i > 0) {
                Vec3 previous = Vec3.atCenterOf(path.getNode(i - 1).asBlockPos());
                Vec3 current = Vec3.atCenterOf(nodePos);
                Vec3 midpoint = previous.lerp(current, 0.5);
                RouteNodeExposure midpointExposure = classifySuppressionNode(midpoint, firingOrigins);
                if (midpointExposure == RouteNodeExposure.EXPOSED) {
                    return RouteNodeExposure.EXPOSED;
                }
                if (midpointExposure == RouteNodeExposure.CRAWL_SAFE) {
                    hasCrawlSafeNode = true;
                }
            }
        }
        return hasCrawlSafeNode ? RouteNodeExposure.CRAWL_SAFE : RouteNodeExposure.PROTECTED;
    }

    private RouteNodeExposure classifySuppressionNode(Vec3 pathPosition, List<Vec3> firingOrigins) {
        RouteNodeExposure worst = RouteNodeExposure.PROTECTED;
        for (Vec3 firingOrigin : firingOrigins) {
            RouteNodeExposure exposure = classifySuppressionNode(pathPosition, firingOrigin);
            if (exposure == RouteNodeExposure.EXPOSED) {
                return RouteNodeExposure.EXPOSED;
            }
            if (exposure == RouteNodeExposure.CRAWL_SAFE) {
                worst = RouteNodeExposure.CRAWL_SAFE;
            }
        }
        return worst;
    }

    private RouteNodeExposure classifySuppressionNode(Vec3 pathPosition, Vec3 firingOrigin) {
        Vec3 horizontal = new Vec3(pathPosition.x - firingOrigin.x, 0, pathPosition.z - firingOrigin.z);
        Vec3 lateral = horizontal.lengthSqr() > 0.001
            ? new Vec3(-horizontal.z, 0, horizontal.x).normalize().scale(0.25)
            : Vec3.ZERO;
        boolean allLowerBlocked = true;
        boolean allEyeBlocked = true;
        for (double offset : new double[] { -1.0, 0.0, 1.0 }) {
            Vec3 sample = pathPosition.add(lateral.scale(offset));
            Vec3 lowerBody = sample.add(0, -0.15, 0);
            Vec3 standingEye = sample.add(0, 1.05, 0);
            allLowerBlocked &= !VisibilityRay.trace(soldier.level(), firingOrigin, lowerBody, soldier).clear();
            allEyeBlocked &= !VisibilityRay.trace(soldier.level(), firingOrigin, standingEye, soldier).clear();
        }
        if (allLowerBlocked && allEyeBlocked) {
            return RouteNodeExposure.PROTECTED;
        }
        return allLowerBlocked ? RouteNodeExposure.CRAWL_SAFE : RouteNodeExposure.EXPOSED;
    }

    private void ensureMovementAttemptTarget(CoverPoint cover) {
        BlockPos target = cover.getPosition();
        if (!target.equals(movementAttemptTarget)) {
            movementAttemptTarget = target.immutable();
            movementAttemptCount = 0;
            noProgressReissues = 0;
            repositioningStartDist = soldier.position().distanceTo(
                net.minecraft.world.phys.Vec3.atCenterOf(target));
            // A new cover must not inherit the previous cover's FAILED verdict,
            // or the goal blacklists every candidate in a row (cover churn loop).
            getPositionController().resetFailureState();
        }
    }

    /**
     * True when a reload/preparation hold (not the cover itself) rejected the
     * move. The rejection is transient: keep the target cover and reservation
     * and retry after the reload instead of blacklisting reachable covers.
     */
    private boolean isReloadBlockedMove() {
        return soldier.isPreparingOrReloading()
            && !soldier.isMovingToUnoccupiedCoverDuringReload();
    }

    private boolean moveToCover(CoverPoint cover) {
        // A concrete physical-cover destination always outranks prone firing.
        cancelProneFiringPlan();
        return startCoverPath(cover);
    }

    /** Starts navigation without re-entering tactical-bound admission. */
    private boolean startCoverPath(CoverPoint cover) {
        if (isReloadBlockedMove()) {
            if (DiagnosticLogManager.isCoverLoggingEnabled()) {
                StevesArmyMod.LOGGER.info("[PathDebug] Soldier {} cover path to {} held by reload, will retry after reload",
                    soldier.getId(), cover.getPosition());
            }
            return false;
        }
        PerformanceMetrics.recordRolePathRequest(machineGunnerPipeline);
        PerformanceMetrics.recordCoverPathRequest();
        BlockPos wallPos = cover.getPosition();
        ensureMovementAttemptTarget(cover);
        movementAttemptCount++;

        long pathStarted = System.nanoTime();
        
        if (StevesArmyMod.teleportOnlyMode) {
            soldier.moveTo(wallPos.getX() + 0.5, wallPos.getY(), wallPos.getZ() + 0.5, soldier.getYRot(), soldier.getXRot());
            onCoverReached(cover);
            if (DiagnosticLogManager.isCoverPerformanceLoggingEnabled()) {
                StevesArmyMod.LOGGER.info("[CoverPerf] soldier={} tick={} path=teleport result=REACHED totalMs={} cover={}",
                    soldier.getId(), soldier.tickCount, formatMillis(System.nanoTime() - pathStarted), wallPos);
            }
            return true;
        }
        
        Vec3 standingPos = getCoverStandingPosition(wallPos);
        // Use tolerance 0 so the pathfinder must route to the exact standing block,
        // not to an adjacent block that may be on the wrong side of cover.
        SuppressionRoutePlan routePlan = selectedSuppressionRoute != null
            && selectedSuppressionRoute.cover().getPosition().equals(wallPos)
            ? selectedSuppressionRoute : null;
        Path path;
        if (routePlan != null) {
            path = routePlan.path();
        } else if (soldier.blockPosition().equals(validatedCoverPathSource)
            && soldier.tickCount == validatedCoverPathTick
            && (path = validatedCoverPaths.get(wallPos)) != null) {
            PerformanceMetrics.recordCoverPathReuseHit();
        } else {
            long routePathStart = System.nanoTime();
            path = navigation.createPath(standingPos.x, standingPos.y, standingPos.z, 0);
            PerformanceMetrics.recordStageTime(PerformanceMetrics.Stage.PATH_REQUEST,
                System.nanoTime() - routePathStart);
        }

        if (routePlan != null
            && classifySuppressionRoute(path, routePlan.firingOrigins(), new HashMap<>()) == RouteNodeExposure.EXPOSED) {
            if (DiagnosticLogManager.isCoverLoggingEnabled()) {
                StevesArmyMod.LOGGER.info("[CoverSuppression] Soldier {} withheld retry to {}: route is now exposed",
                    soldier.getId(), wallPos);
            }
            selectedSuppressionRoute = null;
            activeSuppressionRouteMovement = RouteMovement.NORMAL;
            activeRouteCrawlMandatory = false;
            soldier.getMovementController().setMandatoryCrawl(false, "route-rejected");
            soldier.setLowCrouching(false);
            PerformanceMetrics.recordRolePathFailure(machineGunnerPipeline);
            PerformanceMetrics.recordCoverPathFailure();
            return false;
        }
        
        boolean isReachable = false;
        boolean isStagedPath = false;
        String failReason = "null path";

        if (isDistantRelocationCover(cover)
            && (path == null || !path.canReach() || path.getNodeCount() == 0
                || !path.getNode(path.getNodeCount() - 1).asBlockPos().equals(wallPos))) {
            Path stagedPath = createRelocationStagingPath(standingPos);
            if (stagedPath != null && stagedPath.canReach() && stagedPath.getNodeCount() > 0) {
                path = stagedPath;
                isReachable = true;
                isStagedPath = true;
                BlockPos endPos = path.getNode(path.getNodeCount() - 1).asBlockPos();
                if (DiagnosticLogManager.isCoverLoggingEnabled()) {
                    StevesArmyMod.LOGGER.info("[CoverRelocation] Soldier {} staging toward {} via {}",
                        soldier.getId(), wallPos, endPos);
                }
            }
        }
        
        if (!isReachable && path != null) {
            if (path.canReach()) {
                // Verify the final node is the intended standing block, not an adjacent one
                BlockPos endPos = path.getNode(path.getNodeCount() - 1).asBlockPos();
                if (endPos.equals(wallPos)) {
                    isReachable = true;
                    if (DiagnosticLogManager.isCoverLoggingEnabled()) {
                        StevesArmyMod.LOGGER.info("[PathDebug] Soldier {} at {} path REACHED standing {} (canReach=true, endpoint=wallPos)",
                            soldier.getId(), soldier.blockPosition(), standingPos);
                    }
                } else {
                    failReason = String.format("canReach=true but endpoint %s != wallPos %s", endPos, wallPos);
                    if (DiagnosticLogManager.isCoverLoggingEnabled()) {
                        StevesArmyMod.LOGGER.info("[PathDebug] Soldier {} at {} path REJECTED: {}", 
                            soldier.getId(), soldier.blockPosition(), failReason);
                    }
                }
            } else {
                failReason = "path cannot reach";
                if (isDistantRelocationCover(cover) && path.getNodeCount() > 0) {
                    BlockPos endPos = path.getNode(path.getNodeCount() - 1).asBlockPos();
                    double currentDistance = horizontalDistanceToCover(cover);
                    double endpointDistance = Math.sqrt(endPos.distSqr(wallPos));
                    if (currentDistance - endpointDistance >= MIN_STAGED_PATH_PROGRESS) {
                        isReachable = true;
                        isStagedPath = true;
                        if (DiagnosticLogManager.isCoverLoggingEnabled()) {
                            StevesArmyMod.LOGGER.info("[CoverRelocation] Soldier {} staged path to {} endpoint={} distance={} -> {}",
                                soldier.getId(), wallPos, endPos, String.format("%.1f", currentDistance),
                                String.format("%.1f", endpointDistance));
                        }
                    } else {
                        failReason = String.format("partial path endpoint %s makes insufficient progress (%.1f -> %.1f)",
                            endPos, currentDistance, endpointDistance);
                    }
                }
                if (!isReachable && DiagnosticLogManager.isCoverLoggingEnabled()) {
                    StevesArmyMod.LOGGER.info("[PathDebug] Soldier {} at {} path FAILED: {} for standing {}",
                        soldier.getId(), soldier.blockPosition(), failReason, standingPos);
                }
            }
        }
        
        if (isReachable) {
            pendingRetryCover = null; // Clear any pending retry on success
            activeSuppressionRouteMovement = routePlan != null ? routePlan.movement() : RouteMovement.NORMAL;
            activeRouteCrawlMandatory = routePlan != null && routePlan.classifierRequiresCrawl();
            soldier.getMovementController().setMandatoryCrawl(activeRouteCrawlMandatory,
                activeRouteCrawlMandatory ? "suppression-route-classifier" : "route-released");
            soldier.setLowCrouching(activeSuppressionRouteMovement == RouteMovement.CRAWL);
            boolean accepted = navigation.moveTo(path, activeSuppressionRouteMovement == RouteMovement.CRAWL
                ? CRAWL_ROUTE_SPEED : 1.2D);
            if (!accepted && soldier.getNavigation().getPath() != null
                && soldier.getNavigation().getPath().sameAs(path)) {
                // 1.20.1 PathNavigation.moveTo returns false when the requested
                // path is the SAME one already being followed. That is the
                // movement already underway — a spine walk leg to this very
                // dock — not a start failure; reading it as one blacklisted the
                // dock, released the reservation, and kept the walk dockless.
                accepted = true;
            }
            if (DiagnosticLogManager.isCoverPerformanceLoggingEnabled()) {
                StevesArmyMod.LOGGER.info(
                    "[CoverPerf] soldier={} tick={} path={} accepted={} nodes={} buildMs={} cover={} from={}",
                    soldier.getId(), soldier.tickCount, isStagedPath ? "staged" : "exact", accepted, path.getNodeCount(),
                    formatMillis(System.nanoTime() - pathStarted), wallPos, soldier.blockPosition());
            }
            if (accepted && soldier.hasValidAttackTarget()) {
                StevesArmyMod.LOGGER.info("[CoverNav] Soldier {} ({}) ATTACK nav to cover {} from pos {} dist={}",
                    soldier.getId(), soldier.getName().getString(), wallPos, soldier.blockPosition(),
                    String.format("%.2f", soldier.position().distanceTo(standingPos)));
            }
            if (DiagnosticLogManager.isCoverLoggingEnabled()) {
                StevesArmyMod.LOGGER.info("[PathDebug] Soldier {} navigation {} {} path to cover {} from pos {} (path nodes={})",
                    soldier.getId(), accepted ? "started" : "rejected", isStagedPath ? "staged" : "exact",
                    wallPos, soldier.blockPosition(), path.getNodeCount());
            }
            if (!accepted) {
                PerformanceMetrics.recordRolePathFailure(machineGunnerPipeline);
                PerformanceMetrics.recordCoverPathFailure();
            }
            return accepted;
        } else {
            if (DiagnosticLogManager.isCoverPerformanceLoggingEnabled()) {
                StevesArmyMod.LOGGER.info(
                    "[CoverPerf] soldier={} tick={} path=REJECTED reason={} buildMs={} cover={} from={}",
                    soldier.getId(), soldier.tickCount, failReason,
                    formatMillis(System.nanoTime() - pathStarted), wallPos, soldier.blockPosition());
            }
            // If this is a null path and NOT already a retry, schedule retry for next tick
            if (path == null && !isRetryAttempt && !emergencyCoverSearchActive) {
                if (DiagnosticLogManager.isCoverLoggingEnabled()) {
                    StevesArmyMod.LOGGER.info("[PathDebug] Soldier {} at {} null path to cover {}, scheduling retry next tick", 
                        soldier.getId(), soldier.blockPosition(), wallPos);
                }
                pendingRetryCover = cover;
                getCoverManager().setTargetCover(cover);
                PerformanceMetrics.recordRolePathRetry(machineGunnerPipeline);
                PerformanceMetrics.recordCoverPathRetry();
                return false;
            }
            
            if (DiagnosticLogManager.isCoverLoggingEnabled()) {
                StevesArmyMod.LOGGER.info("[PathDebug] Soldier {} at {} BLACKLISTED cover {} reason: {}{}", 
                    soldier.getId(), soldier.blockPosition(), wallPos, failReason, isRetryAttempt ? " (after retry)" : "");
            }
            blacklistCover(wallPos, BlacklistReason.PATH_FAILED);
            PerformanceMetrics.recordRolePathFailure(machineGunnerPipeline);
            PerformanceMetrics.recordCoverPathFailure();
        }
        return false;
    }

    /**
     * Dockless + pinned re-decision ({@code suppressedRelocationSafeRoute}):
     * run the classified suppression relocation search on the existing
     * emergency retry pacing (20t between attempts, 3 consecutive failures
     * then a 100t cooldown — shared with the other suppression channels).
     * A withheld verdict is NOT a dead stop: the doctrine escape below runs
     * before the hold, so a pinned soldier in the open always either moves
     * toward the best available cover or holds ducked with the search re-armed
     * — never a frozen open-ground stand.
     */
    private void runDocklessSuppressedSearch() {
        CoverPoint retainedTarget = getCoverManager().getTargetCover();
        if (retainedTarget != null) {
            if (!soldier.getNavigation().isDone()
                || getPositionController().getLastResult() == CoverPositionController.MovementResult.IN_PROGRESS
                || soldier.position().distanceToSqr(getCoverStandingPosition(retainedTarget.getPosition()))
                    <= POSITIONING_TOLERANCE * POSITIONING_TOLERANCE) {
                // Resume the state that services both movement and arrival.
                getCoverManager().setState(CoverBehaviorManager.CoverState.SEEKING_COVER);
                tickSuppressedEscapeCrawlToDash();
                return;
            }
            // No navigation/controller owner remains. A stale target must not
            // suppress every future defensive search.
            CoverReservationManager.release(retainedTarget.getPosition(), soldier);
            getCoverManager().clearTargetCover();
        }
        if (escapeCommitCoverPos != null) {
            // The committed escape move died without arriving (blacklist,
            // path loss) while the suppression still holds: invalidation
            // re-opens the target selection on this pass.
            clearSuppressedEscapeCommit("move invalidated");
        }
        if (soldier.tickCount < nextSuppressionRouteSearchTick) {
            enterOpenGroundFallbackPosture();
            return;
        }
        if (startSuppressionRepositioning() && getCoverManager().getTargetCover() != null) {
            emergencySearchFailureCount = 0;
            return;
        }
        // Classifier withheld every route. Doctrine (suppressed in the open,
        // no held cover): MOVE anyway — dash/crawl to the best available
        // cover per the composed policy instead of freezing.
        if (startSuppressedEscapeMove()) {
            emergencySearchFailureCount = 0;
            return;
        }
        // Escape also refused (no cover anywhere / no valid path): restore the
        // dockless hold instead of the "in cover" state the shared starter
        // picked while there is no cover to be in.
        getCoverManager().setState(CoverBehaviorManager.CoverState.NO_COVER);
        enterOpenGroundFallbackPosture();
        emergencySearchFailureCount++;
        if (emergencySearchFailureCount >= EMERGENCY_SEARCH_MAX_CONSECUTIVE_FAILURES) {
            emergencySearchFailureCount = 0;
            nextSuppressionRouteSearchTick = soldier.tickCount + EMERGENCY_SEARCH_FAILURE_COOLDOWN_TICKS;
            if (DiagnosticLogManager.isCoverLoggingEnabled()) {
                StevesArmyMod.LOGGER.info("[CoverSuppression] Soldier {} dockless suppressed search failed {} times, holding in place",
                    soldier.getId(), EMERGENCY_SEARCH_MAX_CONSECUTIVE_FAILURES);
            }
        } else {
            nextSuppressionRouteSearchTick = soldier.tickCount + SHOT_IN_COVER_RETRY_TICKS;
        }
    }

    /**
     * Doctrine escape for a suppressed soldier in the open whose classified
     * relocation was withheld ({@code suppressedRelocationSafeRoute}). Runs the
     * existing suppression search with the classifier veto downgraded to a
     * preference, so the best-scored path-validated cover is taken even when
     * its route classifies EXPOSED. Movement follows the composed policy
     * (user doctrine): dash when the cover is within {@link #ESCAPE_DASH_RANGE};
     * else crawl low when the nearest live firing origin is at least
     * {@link #ESCAPE_CRAWL_SHOOTER_MIN_DIST} away (crawling makes him much
     * less likely to be hit at range); else dash anyway — movement is the only
     * remaining option once the enemy is close AND no cover is in dash range.
     * The chosen dock is committed (see {@link #escapeCommitCoverPos}); the
     * crawl upgrades to a dash for the final stretch
     * ({@link #tickSuppressedEscapeCrawlToDash()}).
     */
    private boolean startSuppressedEscapeMove() {
        if (!StevesArmyConfig.isSuppressedRelocationSafeRoute()
            || relocationType != RelocationType.NONE
            || getCoverManager().getCurrentCover() != null) {
            return false;
        }
        // Firing origins are the shooter-distance input of the doctrine. With
        // none recorded, the crawl branch cannot be evaluated — fall through
        // to the dash-anyway movement (the last-resort branch) rather than
        // withholding the escape entirely.
        suppressionEscapeSearchActive = true;
        boolean started = false;
        try {
            started = startSuppressionRepositioning() && getCoverManager().getTargetCover() != null;
        } finally {
            suppressionEscapeSearchActive = false;
        }
        if (started) {
            CoverPoint escapeCover = getCoverManager().getTargetCover();
            escapeCommitCoverPos = escapeCover.getPosition().immutable();
            escapeCrawlToDashPending = activeSuppressionRouteMovement == RouteMovement.CRAWL
                && !activeRouteCrawlMandatory
                && horizontalDistanceToCover(escapeCover) > ESCAPE_DASH_RANGE;
            if (DiagnosticLogManager.isCoverLoggingEnabled()) {
                StevesArmyMod.LOGGER.info("[CoverSuppression] Soldier {} escape move to {} ({}), commit",
                    soldier.getId(), escapeCommitCoverPos,
                    activeSuppressionRouteMovement == RouteMovement.CRAWL ? "crawl" : "dash");
            }
        }
        return started;
    }

    /**
     * Doctrine movement for an escape dock: dash within
     * {@link #ESCAPE_DASH_RANGE} (accept brief exposure to minimize time in
     * the open); crawl low when the nearest live shooter is at least
     * {@link #ESCAPE_CRAWL_SHOOTER_MIN_DIST} blocks away; dash otherwise.
     */
    private RouteMovement escapeMovementFor(CoverPoint cover, List<Vec3> firingOrigins) {
        if (horizontalDistanceToCover(cover) <= ESCAPE_DASH_RANGE) {
            return RouteMovement.NORMAL;
        }
        double nearestShooterDistSq = Double.MAX_VALUE;
        for (Vec3 origin : firingOrigins) {
            double dx = origin.x - soldier.position().x;
            double dz = origin.z - soldier.position().z;
            nearestShooterDistSq = Math.min(nearestShooterDistSq, dx * dx + dz * dz);
        }
        LivingEntity target = soldier.getTarget();
        if (target != null && target.isAlive()) {
            double dx = target.position().x - soldier.position().x;
            double dz = target.position().z - soldier.position().z;
            nearestShooterDistSq = Math.min(nearestShooterDistSq, dx * dx + dz * dz);
        }
        if (nearestShooterDistSq == Double.MAX_VALUE
            || nearestShooterDistSq >= ESCAPE_CRAWL_SHOOTER_MIN_DIST * ESCAPE_CRAWL_SHOOTER_MIN_DIST) {
            // No known shooter, or every shooter far: crawling is the hit-
            // profile play. Unknown distance is treated as far — standing is
            // the riskier default for a soldier already being fired on.
            return RouteMovement.CRAWL;
        }
        // Enemy inside 32 blocks and no cover within dash range: movement is
        // the only remaining option — sprint for it (documented doctrine
        // corner: freezing here is the dead escape chain the sim flags).
        return RouteMovement.NORMAL;
    }

    /**
     * Final stretch of a doctrine crawl escape: once the committed crawl
     * brings the soldier within {@link #ESCAPE_DASH_RANGE} of the escape
     * dock, upgrade to a dash (posture up, full speed) through the existing
     * navigation path. No-op for classifier-approved CRAWL routes — those are
     * crawl because the lane is eye-exposed, and standing would expose.
     */
    private void tickSuppressedEscapeCrawlToDash() {
        if (!escapeCrawlToDashPending || activeSuppressionRouteMovement != RouteMovement.CRAWL) {
            return;
        }
        CoverPoint target = getCoverManager().getTargetCover();
        if (target == null
            || escapeCommitCoverPos == null
            || !escapeCommitCoverPos.equals(target.getPosition())) {
            // Commit invalidated (target changed/released) — stop servicing.
            escapeCrawlToDashPending = false;
            return;
        }
        if (horizontalDistanceToCover(target) > ESCAPE_DASH_RANGE) {
            return;
        }
        escapeCrawlToDashPending = false;
        activeSuppressionRouteMovement = RouteMovement.NORMAL;
        activeRouteCrawlMandatory = false;
        soldier.getMovementController().setMandatoryCrawl(false, "escape-dash-release");
        soldier.setLowCrouching(false);
        Path path = navigation.getPath();
        if (path != null && !path.isDone()) {
            navigation.moveTo(path, 1.2D);
        }
        if (DiagnosticLogManager.isCoverLoggingEnabled()) {
            StevesArmyMod.LOGGER.info("[CoverSuppression] Soldier {} escape crawl upgraded to dash for the final stretch to {}",
                soldier.getId(), escapeCommitCoverPos);
        }
    }

    /** Dissolves every escape commitment once suppression no longer holds it. */
    private void clearSuppressedEscapeCommit(String reason) {
        if (escapeCommitCoverPos == null && !escapeCrawlToDashPending) {
            return;
        }
        if (DiagnosticLogManager.isCoverLoggingEnabled()) {
            StevesArmyMod.LOGGER.info("[CoverSuppression] Soldier {} escape commit to {} dissolved: {}",
                soldier.getId(), escapeCommitCoverPos, reason);
        }
        escapeCommitCoverPos = null;
        escapeCrawlToDashPending = false;
    }

    private void logDockTransition(String reason) {
        if (!DiagnosticLogManager.isCoverLoggingEnabled() && !attackDebugLog()) return;
        CoverPoint current = getCoverManager().getCurrentCover();
        CoverPoint target = getCoverManager().getTargetCover();
        StevesArmyMod.LOGGER.info(
            "[CoverTransition] Soldier {} reason={} state={} phase={} suppression={} recovered={} peek={} dock={} target={} relocation={}",
            soldier.getId(), reason, getCoverManager().getState(), attackPhase,
            getCoverManager().getSuppressionLevel(), canLeaveCoverNow(),
            getPeekController().getState(), current == null ? null : current.getPosition(),
            target == null ? null : target.getPosition(), relocationType);
    }

    /**
     * Pinned hold at the claimed dock: flip to the suppressed-in-cover branch
     * (posture + duck) without touching the claim. Used by the dock-strip
     * guards; from the next tick the normal suppressed branch runs its designed
     * channels (peek return, compromised-cover relocation) on top of the hold.
     * A hold at CONCEALMENT cover ducks as well — concealment stops LoS, not
     * bullets, so the held soldier keeps the lowest profile (the standing
     * held-at-concealment pose left body rays visible in sim).
     */
    private void holdSuppressedAtDock(CoverPoint currentCover) {
        soldier.tracePeek("cover-suppression", "pinned dock hold");
        enforceSuppressedHalfCoverPosture(currentCover);
        if (currentCover != null && currentCover.getType() == CoverType.CONCEALMENT
            && getCoverManager().isSuppressed()) {
            soldier.setLowCrouching(true);
        }
        if (currentCover != null) {
            // The hold keeps the slot anchor armed: being shoved off the slot
            // while pinned must pull the soldier back into the exact slot
            // block (the knockback-recovery anchor), which is slot discipline,
            // not a relocation — the claim is kept precisely so this recovery
            // can run while re-seeks stay withheld.
            getPositionController().maintainCoverAnchor(getCoverStandingPosition(currentCover.getPosition()));
        }
        getCoverManager().setState(CoverBehaviorManager.CoverState.SUPPRESSED_IN_COVER);
    }

    private boolean startSuppressionRepositioning() {
        CoverMoveResult result = findSuppressionMoveToCover();
        if (getCoverManager().getTargetCover() != null) {
            getCoverManager().setState(CoverBehaviorManager.CoverState.REPOSITIONING);
            return true;
        }
        getCoverManager().setState(getCoverManager().isSuppressed()
            ? CoverBehaviorManager.CoverState.SUPPRESSED_IN_COVER
            : CoverBehaviorManager.CoverState.IN_COVER);
        return result == CoverMoveResult.COVER_STARTED;
    }

    private CoverMoveResult findSuppressionMoveToCover() {
        // A ping relocation has no incoming-fire origin to route around — the
        // soldier simply cannot see into the zone. ThreatAwareness already
        // aims the normal search at the ping and its scoring prefers covers
        // with firing lanes toward the threat, so use it instead of failing
        // the whole relocation with "no firing origin" — but only for
        // PLAYER-ORDERED relocations. An autonomous suppressed relocation
        // with no recorded firing origin cannot be classified as safe
        // (safe-route mode): withhold it and stay at the current cover
        // rather than walk an unclassified search.
        if (getCoverManager().getRecentSuppressionFiringOrigin() == null
            && soldier.hasValidPingSuppressPos()) {
            if (StevesArmyConfig.isSuppressedRelocationSafeRoute()
                && relocationType == RelocationType.NONE) {
                if (DiagnosticLogManager.isCoverLoggingEnabled()) {
                    StevesArmyMod.LOGGER.info("[CoverSuppression] Soldier {} withheld suppression reposition: "
                        + "no firing origin is available (safe-route mode)", soldier.getId());
                }
                return CoverMoveResult.NO_ELIGIBLE_COVER;
            }
            soldier.setLowCrouching(false);
            getCoverManager().resetPeekState();
            getCoverManager().setPeekPosition(null);
            getPositionController().clear();
            return findAndMoveToCover();
        }
        suppressionRouteFiringOrigins = suppressionFiringOriginsForRoute();
        suppressionRouteSearchActive = true;
        activeSuppressionRouteMovement = RouteMovement.NORMAL;
        activeRouteCrawlMandatory = false;
        soldier.getMovementController().setMandatoryCrawl(false, "route-released");
        selectedSuppressionRoute = null;
        soldier.setLowCrouching(false);
        getCoverManager().resetPeekState();
        getCoverManager().setPeekPosition(null);
        getPositionController().clear();
        try {
            return findAndMoveToCover();
        } finally {
            suppressionRouteSearchActive = false;
            suppressionRouteFiringOrigins = List.of();
        }
    }
    
    private boolean isCoverFloorReached(CoverPoint cover) {
        return cover != null && Math.abs(soldier.getY() - getCoverStandingPosition(cover.getPosition()).y) <= 0.75;
    }

    private void onCoverReached(CoverPoint cover) {
        // Every arrival channel must verify the standing floor before stopping navigation.
        if (!isCoverFloorReached(cover)) {
            getPositionController().clear();
            moveToCover(cover);
            return;
        }
        if (suppressionPositionStatus == SuppressionPositionStatus.MOVING
            && suppressionPositionGeneration == soldier.getSuppressionOrder().getGeneration()
            && !hasSuppressionFiringLaneFrom(soldier.getEyePosition())) {
            suppressionPositionFailures++;
            suppressionPositionLastFailure = "arrival lane blocked";
            boolean exhaustedAtArrival = suppressionPositionFailures >= EMERGENCY_SEARCH_MAX_CONSECUTIVE_FAILURES;
            suppressionPositionStatus = exhaustedAtArrival
                ? SuppressionPositionStatus.FAILED : SuppressionPositionStatus.BLOCKED;
            nextSuppressionPositionSearchTick = soldier.tickCount
                + (exhaustedAtArrival ? EMERGENCY_SEARCH_FAILURE_COOLDOWN_TICKS : SHOT_IN_COVER_RETRY_TICKS);
            blacklistCover(cover.getPosition(), BlacklistReason.PATH_FAILED);
            CoverReservationManager.release(cover.getPosition(), soldier);
            getCoverManager().clearTargetCover();
            getPositionController().clear();
            navigation.stop();
            getCoverManager().setState(getCoverManager().getCurrentCover() != null
                ? CoverBehaviorManager.CoverState.IN_COVER : CoverBehaviorManager.CoverState.NO_COVER);
            if (DiagnosticLogManager.isCoverLoggingEnabled()) {
                StevesArmyMod.LOGGER.info(
                    "[SuppressPosition] soldier={} generation={} rejected arrival={} status={} attempts={} reason={}",
                    soldier.getId(), suppressionPositionGeneration, cover.getPosition(),
                    suppressionPositionStatus, suppressionPositionFailures, suppressionPositionLastFailure);
            }
            return;
        }
        selectedSuppressionRoute = null;
        activeSuppressionRouteMovement = RouteMovement.NORMAL;
        activeRouteCrawlMandatory = false;
        soldier.getMovementController().setMandatoryCrawl(false, "route-released");
        soldier.setLowCrouching(false);
        clearSuppressedEscapeCommit("arrived at dock");
        // Reset search exhaustion state on successful cover acquisition
        consecutiveFailedSearches = 0;
        searchExhaustionCooldown = 0;
        seekEscalated = false;
        repositioningTicks = 0;
        // Promote target to current — releases old reservation, sets metadata
        getCoverManager().promoteTargetToCurrentCover();
        
        navigation.stop();
        
        getCoverManager().resetPeekState();
        getCoverManager().setNonPeekableCover(false);
        getCoverManager().clearRepositionRequest();
        getCoverManager().clearShotInCoverRepositionRequest();
        getCoverManager().clearContinuousSuppressionRepositionRequest();
        if (suppressionPositionStatus == SuppressionPositionStatus.MOVING
            && suppressionPositionGeneration == soldier.getSuppressionOrder().getGeneration()) {
            suppressionPositionStatus = SuppressionPositionStatus.ARRIVED;
            soldier.setSuppressionAimPoints(List.of());
        }
        nonPeekableTicks = 0;
        
        // Renew reservation for the new current cover
        CoverReservationManager.reserve(cover.getPosition(), soldier);
        
        getPositionController().moveTo(getCoverStandingPosition(cover.getPosition()), POSITIONING_TOLERANCE, POSITIONING_SPEED, "onCoverReached", "initial cover positioning");
        
        // Reset peek controller for new cover and seed the peek cooldown
        // so soldier settles before peeking — prevents immediate "jump out"
        getPeekController().resetForNewCover(soldier, cover.getPosition());
        getPeekController().setLastPeekEndTime(GameClock.nowMs());
        resetSuppressionEpisodes();
        latchedMachineGunnerSearchCenter = null;
        
        // Compute peek position with LOS validation for full cover
        if (cover.getType() == CoverType.FULL) {
            Vec3 threatDirection = suppressionPositionArea != null
                && soldier.hasValidPingSuppressPos()
                && suppressionPositionGeneration == soldier.getSuppressionOrder().getGeneration()
                    ? Vec3.atCenterOf(suppressionPositionArea).subtract(soldier.position()).normalize()
                    : getThreats().getPrimaryDirection(soldier.position());
            LivingEntity target = soldier.getTarget();
            if (threatDirection != null && threatDirection.lengthSqr() > 0.001) {
                BlockPos peekPos = computePeekPosition(cover, threatDirection, target);
                getCoverManager().setPeekPosition(peekPos);
                if (peekPos == null && DiagnosticLogManager.isCoverLoggingEnabled()) {
                    StevesArmyMod.LOGGER.info("[CoverGoal] Soldier {} full cover has no peekable adjacent block with LOS", soldier.getId());
                }
            }
        } else {
            getCoverManager().setPeekPosition(null);
        }
        
        if (getCoverManager().isSuppressed()) {
            getCoverManager().setState(CoverBehaviorManager.CoverState.SUPPRESSED_IN_COVER);
        } else {
            getCoverManager().setState(CoverBehaviorManager.CoverState.IN_COVER);
        }
        soldier.refreshDimensions();
        doLowCrouchIfHalfCover();
        if (cover.getType() == CoverType.HALF) {
            if (soldier.isPeekDisabled()) {
                // The peek state machine is never ticked for peek-disabled roles,
                // so they must enter HIDING here or nothing will ever settle them
                // below the half-cover wall.
                getPeekController().enterHiding(soldier);
                soldier.setLowCrouching(true);
                soldier.refreshDimensions();
            } else if (!getCoverManager().isSuppressed()) {
                getPeekController().enterStandingInHalfCover(soldier, "cover-arrival");
            }
        }

        if (relocationType == RelocationType.GO_TO) {
            // The cover selected in the destination search area is the GO_TO
            // endpoint. Requiring a centre visit would pull him out of this
            // occupied dock and then send him straight back to cover.
            handledGoToArrivalGeneration = relocationCommandGeneration;
            soldier.completeGoToIfGeneration(relocationCommandGeneration);
        }
        if (relocationType != RelocationType.NONE) {
            // Promotion above cleared the target; keep the current dock and
            // its reservation while releasing relocation ownership.
            clearRelocationTarget();
        }
    }

    private Path createRelocationStagingPath(Vec3 destination) {
        Vec3 offset = destination.subtract(soldier.position());
        double horizontalDistance = Math.sqrt(offset.x * offset.x + offset.z * offset.z);
        if (horizontalDistance <= RELOCATION_EXACT_PATH_DISTANCE) {
            return null;
        }

        double stageDistance = RELOCATION_EXACT_PATH_DISTANCE * 0.75D;
        double scale = stageDistance / horizontalDistance;
        Vec3 stage = soldier.position().add(offset.x * scale, offset.y * scale, offset.z * scale);
        return navigation.createPath(stage.x, stage.y, stage.z, 1);
    }
    
    private void blacklistCover(BlockPos pos, BlacklistReason reason) {
        if (com.stevesarmy.debug.trace.SoldierFlightRecorder.isRecording())
            com.stevesarmy.debug.trace.SoldierFlightRecorder.event(soldier, "cover-blacklist", reason.name(), pos);
        failedCoverPositions.add(pos);
        lastFailedCover = pos;
        blacklistRevision++;
        blacklistReasons.put(pos, new BlacklistEntry(reason, GameClock.nowMs()));
        // Release the old target cover reservation explicitly (clearTargetCover no longer releases)
        CoverPoint oldTarget = getCoverManager().getTargetCover();
        if (oldTarget != null) {
            CoverReservationManager.release(oldTarget.getPosition(), soldier);
        }
        // If the blacklisted cover matches the expected attack target, clear it
        if (attackExpectedCover != null && pos.equals(attackExpectedCover)) {
            attackExpectedCover = null;
        }
        getCoverManager().clearTargetCover();
        if (DiagnosticLogManager.isCoverLoggingEnabled()) {
            StevesArmyMod.LOGGER.info("[CoverGoal] Soldier {} blacklisted cover at {} reason={}",
                soldier.getId(), pos, reason.label);
        }
    }
    
    private void doLowCrouchIfHalfCover() {
        CoverPoint cover = getCoverManager().getCurrentCover();
        if (cover != null && cover.getType() == CoverType.HALF) {
            // Arrival posture is suppression-gated with no exceptions: a soldier
            // reaching half cover while suppressed settles low immediately.
            // enforceSuppressedHalfCoverPosture keeps it low until recovery.
            soldier.setLowCrouching(getCoverManager().isSuppressed());
            soldier.refreshDimensions();
        }
    }

    /** Search failure must never authorize an unreserved prone position. */
    private void enterOpenGroundFallbackPosture() {
        if (soldier.isPreparingOrReloading() || soldier.isHealing()
            || getCoverManager().getCurrentCover() != null) return;
        if (!proneFiringController.isPlanActive()) {
            soldier.setFiringProne(false);
            tryStartSpacedProneFallback();
        }
    }

    /**
     * CoverTacticalGoal holds the MOVE flag, so the vanilla OpenDoorGoal cannot
     * run while a cover route is active. Open a closed door sitting on the
     * active path directly instead of grinding into it until the stuck watchdog
     * fires. The pathfinder only routes through openable doors, so any door on
     * the path is wooden.
     */
    private void tryOpenDoorOnPath() {
        Path path = navigation.getPath();
        if (path == null || path.isDone()) {
            return;
        }
        BlockPos nodePos = path.getNode(path.getNextNodeIndex()).asBlockPos();
        net.minecraft.world.level.block.state.BlockState state = soldier.level().getBlockState(nodePos);
        if (state.getBlock() instanceof net.minecraft.world.level.block.DoorBlock door
            && !state.getValue(net.minecraft.world.level.block.DoorBlock.OPEN)) {
            door.setOpen(soldier, soldier.level(), state, nodePos, true);
        }
    }

    /**
     * Counts hostile hits taken while peeking or exposed at the occupied cover.
     * Peek exposure makes hits expected, so unlike a hit while hiding they do
     * not immediately compromise the cover — but repeated hits from the same
     * cover eventually rotate it.
     */
    @Override
    public void noteHitWhilePeekingAtCover() {
        CoverPoint currentCover = getCoverManager().getCurrentCover();
        if (currentCover == null || !getCoverManager().isInCover()) {
            return;
        }
        hitWhilePeekingCount++;
        if (hitWhilePeekingCount >= REPEATED_SUPPRESSION_EPISODE_THRESHOLD
            && !getCoverManager().isRepositionRequested()
            && !getCoverManager().isShotInCoverRepositionRequested()) {
            hitWhilePeekingCount = 0;
            getCoverManager().requestReposition();
            if (DiagnosticLogManager.isCoverLoggingEnabled()) {
                StevesArmyMod.LOGGER.info("[CoverSuppression] Soldier {} hit while peeking {} times at {}, queued reposition after recovery",
                    soldier.getId(), REPEATED_SUPPRESSION_EPISODE_THRESHOLD, currentCover.getPosition());
            }
        }
    }

    /**
     * Entity-level anti-stuck watchdog hook: the soldier has spent several
     * seconds in a moving cover state with no active movement driver and no
     * legitimate hold reason. Cancel every pending/retry artifact and return to
     * NO_COVER so the machine re-decides instead of standing forever.
     */
    @Override
    public void resetFromStuckWatchdog() {
        // A queued search executes within a tick or two of its due time; give it
        // its slot instead of cancelling and re-queueing behind the whole squad.
        if (coverSearchPending) {
            if (com.stevesarmy.debug.trace.SoldierFlightRecorder.isRecording())
                com.stevesarmy.debug.trace.SoldierFlightRecorder.event(soldier, "cover-watchdog", "reset deferred: search pending", null);
            return;
        }
        if (com.stevesarmy.debug.trace.SoldierFlightRecorder.isRecording())
            com.stevesarmy.debug.trace.SoldierFlightRecorder.event(soldier, "cover-watchdog", "reset stalled cover machine", getCoverManager().getState().name());
        logDockTransition("WATCHDOG");
        CoverSearchScheduler.cancel(this);
        coverSearchPending = false;
        asyncPilotPending = false;
        asyncPilotSubmittedTick = Long.MIN_VALUE;
        pendingRetryCover = null;
        isRetryAttempt = false;
        fallbackAdvanceTarget = null;
        fallbackAdvanceAssemble = false;
        clearFailedSearch();
        navigation.stop();
        getPositionController().clear();
        clearRelocationTarget();
        getCoverManager().clearTargetCover();
        getCoverManager().clearCover();
        cooldown = COOLDOWN_TICKS / 2;
        if (DiagnosticLogManager.isCoverLoggingEnabled()) {
            StevesArmyMod.LOGGER.info("[CoverGoal] Soldier {} watchdog reset from stuck cover state", soldier.getId());
        }
    }

    /**
     * Pinned variant of {@link #resetFromStuckWatchdog()}
     * ({@code suppressedRelocationSafeRoute}): the watchdog caught a stalled,
     * pathless move while the soldier is under fire. Cancel the stalled move,
     * but do NOT strip the dock — an absolutely pinned soldier stays at his
     * cover. Keep the current claim and re-hold suppressed-in-cover (or, when
     * dockless, hold position ducked and let the paced classified search
     * re-decide); if the claim is physically unreachable the recovery-gated
     * machinery re-evaluates it once suppression decays. Player-ordered
     * relocations keep the legacy full reset.
     */
    public void holdFromStuckWatchdog() {
        if (relocationType != RelocationType.NONE) {
            resetFromStuckWatchdog();
            return;
        }
        // Same courtesy as the legacy reset: a queued search executes within a
        // tick or two of its due time; give it its slot.
        if (coverSearchPending) {
            return;
        }
        logDockTransition("WATCHDOG");
        CoverSearchScheduler.cancel(this);
        coverSearchPending = false;
        asyncPilotPending = false;
        asyncPilotSubmittedTick = Long.MIN_VALUE;
        pendingRetryCover = null;
        isRetryAttempt = false;
        fallbackAdvanceTarget = null;
        fallbackAdvanceAssemble = false;
        clearFailedSearch();
        navigation.stop();
        getPositionController().clear();
        getCoverManager().clearTargetCover();
        if (getCoverManager().getCurrentCover() != null) {
            holdSuppressedAtDock(getCoverManager().getCurrentCover());
        } else {
            // Dockless: hold ducked in place — no NO_COVER re-seed into another
            // exposed walk; the dockless suppressed search paces from here.
            getCoverManager().setState(CoverBehaviorManager.CoverState.NO_COVER);
            enterOpenGroundFallbackPosture();
        }
        // No restart cooldown: unlike the legacy reset the machine keeps its
        // state, and the watchdog re-fires only if the held state stalls again.
        if (DiagnosticLogManager.isCoverLoggingEnabled()) {
            StevesArmyMod.LOGGER.info("[CoverGoal] Soldier {} watchdog hold from stuck cover state while pinned", soldier.getId());
        }
    }
    
    private List<LivingEntity> getThreatList() {
        List<LivingEntity> list = new ArrayList<>();
        LivingEntity target = soldier.getTarget();
        if (target != null && target.isAlive()) {
            list.add(target);
            return list;
        }

        ThreatAwareness threats = getThreats();
        if (!threats.hasActiveThreat()) return list;

        BlockPos threatPos = threats.getPrimaryThreatPosition();
        if (threatPos == null) return list;

        double searchRadius = 32.0;
        Vec3 center = Vec3.atCenterOf(threatPos);
        for (LivingEntity entity : soldier.level().getEntitiesOfClass(
                LivingEntity.class,
                soldier.getBoundingBox().inflate(searchRadius),
                e -> e.isAlive() && !e.is(soldier) && !(e instanceof SoldierEntity))) {
            if (entity.position().distanceToSqr(center) < searchRadius * searchRadius) {
                list.add(entity);
            }
        }

        return list;
    }
    
    public static BlockPos computePeekPositionStatic(CoverPoint cover, Vec3 threatDirection, LivingEntity target, net.minecraft.world.level.Level level, double soldierY) {
        return computePeekPositionStatic(cover, threatDirection, target, level, soldierY, -1);
    }
    
    public static BlockPos computePeekPositionStatic(CoverPoint cover, Vec3 threatDirection, LivingEntity target, 
                                                      net.minecraft.world.level.Level level, double soldierY, int debugSoldierId) {
        if (threatDirection == null || threatDirection.lengthSqr() < 0.001) {
            return null;
        }

        java.util.Set<net.minecraft.core.Direction> protectedDirs = cover.getProtectedDirections();
        if (protectedDirs == null || protectedDirs.isEmpty()) {
            return null;
        }
        
        BlockPos coverPos = cover.getPosition();
        BlockPos bestPeekPos = null;
        float bestPeekScore = 0.0f;
        
        List<BlockPos> debugCandidatePositions = new ArrayList<>();
        List<Integer> debugRejectionReasons = new ArrayList<>();
        List<Double> debugAngleScores = new ArrayList<>();
        List<Boolean> debugLosResults = new ArrayList<>();
        List<Vec3> debugPeekEyePositions = new ArrayList<>();
        List<Float> debugConeCoverageScores = new ArrayList<>();
        Vec3 debugTargetEye = null;
        
        for (net.minecraft.core.Direction peekDir : net.minecraft.core.Direction.Plane.HORIZONTAL) {
            if (protectedDirs.contains(peekDir)) {
                debugCandidatePositions.add(coverPos.relative(peekDir));
                debugRejectionReasons.add(CoverDebugManager.PeekCandidateDebugData.REASON_PROTECTED_DIR);
                debugAngleScores.add(0.0);
                debugLosResults.add(false);
                debugPeekEyePositions.add(null);
                debugConeCoverageScores.add(0.0f);
                continue;
            }
            
            BlockPos peekPos = coverPos.relative(peekDir);
            debugCandidatePositions.add(peekPos);
            
            if (!com.stevesarmy.combat.cover.CoverFinder.isValidPeekPosition(peekPos, level)) {
                debugRejectionReasons.add(CoverDebugManager.PeekCandidateDebugData.REASON_INVALID_POS);
                debugAngleScores.add(0.0);
                debugLosResults.add(false);
                debugPeekEyePositions.add(null);
                debugConeCoverageScores.add(0.0f);
                continue;
            }
            
            boolean losOk = true;
            float coneCoverageScore = 1.0f;
            Vec3 peekEye = null;
            Vec3 targetEye = null;
            
            if (target != null && target.isAlive()) {
                peekEye = new Vec3(peekPos.getX() + 0.5, soldierY + 1.62, peekPos.getZ() + 0.5);
                targetEye = new Vec3(target.getX(), target.getEyeY(), target.getZ());
                if (debugTargetEye == null) {
                    debugTargetEye = targetEye;
                }
                losOk = com.stevesarmy.combat.cover.CoverFinder.hasLineOfSightStatic(peekEye, targetEye, level);
                if (!losOk) {
                    coneCoverageScore = com.stevesarmy.combat.cover.CoverFinder.calculateConeCoverage(peekPos, threatDirection, level);
                    if (coneCoverageScore <= 0.01f) {
                        debugRejectionReasons.add(CoverDebugManager.PeekCandidateDebugData.REASON_NO_LOS);
                        debugAngleScores.add(0.0);
                        debugLosResults.add(false);
                        debugPeekEyePositions.add(peekEye);
                        debugConeCoverageScores.add(coneCoverageScore);
                        continue;
                    }
                }
            } else {
                coneCoverageScore = com.stevesarmy.combat.cover.CoverFinder.calculateConeCoverage(peekPos, threatDirection, level);
                if (coneCoverageScore <= 0.01f) {
                    debugRejectionReasons.add(CoverDebugManager.PeekCandidateDebugData.REASON_NO_LOS);
                    debugAngleScores.add(0.0);
                    debugLosResults.add(false);
                    debugPeekEyePositions.add(null);
                    debugConeCoverageScores.add(coneCoverageScore);
                    continue;
                }
            }
            
            Vec3 peekCenter = peekPos.getCenter();
            Vec3 toThreat = threatDirection.normalize();
            Vec3 fromPeekToCover = new Vec3(
                coverPos.getX() + 0.5 - peekCenter.x,
                0,
                coverPos.getZ() + 0.5 - peekCenter.z
            ).normalize();
            
            double dot = toThreat.dot(fromPeekToCover);
            dot = Math.max(-1.0, Math.min(1.0, dot));
            double angleBetween = Math.toDegrees(Math.acos(dot));
            
            if (angleBetween >= 45 && angleBetween <= 135) {
                float angleScore = 1.0f - (float)Math.abs(angleBetween - 90) / 90;
                float finalScore = angleScore * coneCoverageScore;
                
                debugLosResults.add(losOk);
                debugPeekEyePositions.add(peekEye);
                debugConeCoverageScores.add(coneCoverageScore);
                
                if (finalScore > bestPeekScore) {
                    bestPeekScore = finalScore;
                    bestPeekPos = peekPos;
                    debugRejectionReasons.add(CoverDebugManager.PeekCandidateDebugData.REASON_CHOSEN);
                    debugAngleScores.add((double)angleScore);
                } else {
                    debugRejectionReasons.add(CoverDebugManager.PeekCandidateDebugData.REASON_ACCEPTED);
                    debugAngleScores.add((double)angleScore);
                }
            } else {
                debugRejectionReasons.add(CoverDebugManager.PeekCandidateDebugData.REASON_BAD_ANGLE);
                debugAngleScores.add(0.0);
                debugLosResults.add(losOk);
                debugPeekEyePositions.add(peekEye);
                debugConeCoverageScores.add(coneCoverageScore);
            }
        }
        
        if (debugSoldierId >= 0) {
            CoverDebugManager.setSoldierPeekCandidates(debugSoldierId, 
                new CoverDebugManager.PeekCandidateDebugData(
                    coverPos, debugCandidatePositions, debugRejectionReasons, debugAngleScores,
                    debugLosResults, bestPeekPos, debugTargetEye, debugPeekEyePositions,
                    debugConeCoverageScores, soldierY
                ));
        }
        
        return bestPeekPos;
    }
    
    private BlockPos computePeekPosition(CoverPoint cover, Vec3 threatDirection, LivingEntity target) {
        return computePeekPositionStatic(cover, threatDirection, target, soldier.level(), soldier.getY(), soldier.getId());
    }
    
    public static boolean isPathClearStatic(BlockPos from, BlockPos to, net.minecraft.world.level.Level level) {
        int dx = to.getX() - from.getX();
        int dz = to.getZ() - from.getZ();
        int steps = Math.max(Math.abs(dx), Math.abs(dz));
        
        if (steps == 0) return true;
        
        for (int i = 1; i <= steps; i++) {
            int x = from.getX() + (dx * i) / steps;
            int z = from.getZ() + (dz * i) / steps;
            BlockPos checkPos = new BlockPos(x, from.getY(), z);
            
            net.minecraft.world.level.block.state.BlockState state = level.getBlockState(checkPos);
            if (!state.isAir() && !state.getCollisionShape(level, checkPos).isEmpty()) {
                return false;
            }
        }
        
        return true;
    }
    
    private boolean isPathClear(BlockPos from, BlockPos to) {
        return isPathClearStatic(from, to, soldier.level());
    }

    private SquadCoverContext buildSquadCoverContext() {
        Level level = soldier.level();
        UUID squadId = soldier.getSquadId();
        if (squadId == null || !(level instanceof ServerLevel serverLevel)) {
            return new SquadCoverContext(false, 0, 0, List.of(), List.of(), List.of(), List.of(), null, null);
        }

        SquadManager mgr = SquadManager.get(serverLevel);

        List<LivingEntity> members = mgr.getSquadMembers(serverLevel, squadId, soldier.getUUID());

        List<BlockPos> occupiedCovers = new ArrayList<>();
        List<BlockPos> defensivePositions = new ArrayList<>();
        List<Vec3> threatDirs = new ArrayList<>();
        List<Vec3> teammatePositions = new ArrayList<>();
        List<SquadCoverContext.FiringContact> firingContacts = new ArrayList<>();
        com.stevesarmy.squad.SquadCoverPeekabilityCache peekabilityCache = null;

        com.stevesarmy.squad.SquadData squadData = mgr.getSquadById(squadId).orElse(null);
        if (squadData != null) {
            peekabilityCache = squadData.getCoverPeekabilityCache();
            long now = level.getGameTime();
            squadData.getThreatIntel().getAllThreats().stream()
                .filter(threat -> threat.isAlive && threat.lastVisibleAimPoint != null)
                .filter(threat -> now - threat.lastSeenTime >= 0
                    && now - threat.lastSeenTime <= SquadCoverContext.FiringContact.MAX_AGE_TICKS)
                .sorted(java.util.Comparator.comparingLong((com.stevesarmy.squad.SquadThreatIntel.ThreatKnowledge threat)
                    -> threat.lastSeenTime).reversed())
                .limit(SquadCoverContext.FiringContact.MAX_CONTACTS)
                .forEach(threat -> firingContacts.add(new SquadCoverContext.FiringContact(
                    threat.threatEntityId, threat.lastVisibleAimPoint, threat.lastSeenTime)));
        }

        for (LivingEntity member : members) {
            if (member instanceof SoldierEntity ms) {
                teammatePositions.add(ms.position());
                CoverBehaviorManager cbm = ms.getCoverBehaviorManager();
                CoverPoint current = cbm.getCurrentCover();
                if (current != null) {
                    addSquadPosition(occupiedCovers, current.getPosition());
                    addSquadPosition(defensivePositions, current.getPosition());
                }
                CoverPoint target = cbm.getTargetCover();
                if (target != null) {
                    addSquadPosition(occupiedCovers, target.getPosition());
                    addSquadPosition(defensivePositions, target.getPosition());
                }
                CoverGoalController peerGoal = ms.getCoverTacticalGoal();
                BlockPos proneLane = peerGoal != null ? peerGoal.getProneDefensivePosition() : null;
                if (proneLane != null) {
                    addSquadPosition(defensivePositions, proneLane);
                } else if (current == null && target == null) {
                    // In open ground, a squadmate's current location is a temporary
                    // spacing signal until it selects its own prone lane this tick.
                    addSquadPosition(defensivePositions, ms.blockPosition());
                }
                Vec3 dir = ms.getThreatAwareness().getPrimaryDirection(member.position());
                if (dir != null && dir.lengthSqr() > 0.001) {
                    threatDirs.add(dir);
                }
            }
        }

        Vec3 ownerPos = null;
        if (soldier.getSquadMode() == SquadMode.FOLLOW) {
            LivingEntity owner = soldier.getOwner();
            if (owner != null) {
                ownerPos = owner.position();
            }
        }

        return new SquadCoverContext(true, 0, 0, occupiedCovers, defensivePositions, threatDirs,
            firingContacts, peekabilityCache, ownerPos, teammatePositions);
    }

    private static void addSquadPosition(List<BlockPos> positions, BlockPos position) {
        if (!positions.contains(position)) {
            positions.add(position.immutable());
        }
    }
}
