package com.stevesarmy.squad;

import com.stevesarmy.StevesArmyMod;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.nbt.Tag;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.level.saveddata.SavedData;
import net.minecraft.world.level.storage.DimensionDataStorage;

import java.util.*;

import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;

public class SquadManager extends SavedData {
    private final Map<UUID, SquadData> squadsByLeader = new HashMap<>();
    private final Map<UUID, SquadData> squadsByMember = new HashMap<>();
    private final Map<UUID, SquadData> squadsById = new HashMap<>();
    private final Map<String, SquadData> squadsByCallsign = new HashMap<>();

    public SquadData createSquad(UUID leaderId) {
        if (squadsByLeader.containsKey(leaderId)) {
            return squadsByLeader.get(leaderId);
        }
        
        SquadData squad = new SquadData(leaderId);
        squadsByLeader.put(leaderId, squad);
        squadsById.put(squad.getSquadId(), squad);
        this.setDirty();
        return squad;
    }

    public SquadData createCallsignSquad(UUID leaderId, String rawCallsign) {
        String n = SquadData.normalizeCallsign(rawCallsign);
        if (!SquadData.isValidCallsignNormalized(n)) throw new IllegalArgumentException("Invalid callsign: " + rawCallsign);
        SquadData existing = squadsByCallsign.get(n);
        if (existing != null) throw new IllegalStateException("Callsign already exists: " + rawCallsign);
        SquadData squad = new SquadData(leaderId, rawCallsign);
        squadsByCallsign.put(n, squad);
        squadsById.put(squad.getSquadId(), squad);
        squadsByLeader.putIfAbsent(leaderId, squad);
        this.setDirty();
        return squad;
    }

    public Optional<SquadData> getSquadByCallsign(String raw) {
        if (raw == null) return Optional.empty();
        String n = SquadData.normalizeCallsign(raw);
        return Optional.ofNullable(squadsByCallsign.get(n));
    }

    public SquadData getOrCreateCallsignSquad(String rawCallsign, UUID leaderId) {
        String n = SquadData.normalizeCallsign(rawCallsign);
        if (!SquadData.isValidCallsignNormalized(n)) throw new IllegalArgumentException("Invalid callsign: " + rawCallsign);
        SquadData existing = squadsByCallsign.get(n);
        if (existing != null) return existing;
        return createCallsignSquad(leaderId, rawCallsign);
    }

    public boolean disbandByCallsign(String raw) {
        String n = SquadData.normalizeCallsign(raw);
        SquadData squad = squadsByCallsign.remove(n);
        if (squad == null) return false;
        for (UUID memberId : squad.getMemberIds()) {
            squadsByMember.remove(memberId);
        }
        squadsById.remove(squad.getSquadId());
        squadsByLeader.entrySet().removeIf(e -> e.getValue() == squad);
        this.setDirty();
        return true;
    }

    public Optional<SquadData> getSquadByLeader(UUID leaderId) {
        return Optional.ofNullable(squadsByLeader.get(leaderId));
    }

    public Optional<SquadData> getSquadByMember(UUID memberId) {
        return Optional.ofNullable(squadsByMember.get(memberId));
    }

    public Optional<SquadData> getSquadById(UUID squadId) {
        return Optional.ofNullable(squadsById.get(squadId));
    }

    public boolean addMemberToSquad(UUID squadId, UUID memberId) {
        SquadData squad = squadsById.get(squadId);
        if (squad != null && squad.addMember(memberId)) {
            squadsByMember.put(memberId, squad);
            this.setDirty();
            return true;
        }
        return false;
    }

    public boolean removeMemberFromSquad(UUID memberId) {
        SquadData squad = squadsByMember.remove(memberId);
        if (squad != null) {
            squad.removeMember(memberId);
            this.setDirty();
            return true;
        }
        return false;
    }

    public void disbandSquad(UUID leaderId) {
        SquadData squad = squadsByLeader.remove(leaderId);
        if (squad != null) {
            for (UUID memberId : squad.getMemberIds()) {
                squadsByMember.remove(memberId);
            }
            squadsById.remove(squad.getSquadId());
            if (squad.getCallsign() != null) squadsByCallsign.remove(squad.getCallsign());
            this.setDirty();
        }
    }

    public boolean isSquadCQB(UUID squadId) {
        SquadData squad = squadsById.get(squadId);
        return squad != null && squad.isCQB();
    }

    public void setSquadCQB(UUID squadId, boolean cqb) {
        SquadData squad = squadsById.get(squadId);
        if (squad != null) {
            squad.setCQB(cqb);
            this.setDirty();
        }
    }

    public void setSquadCQBByLeader(UUID leaderId, boolean cqb) {
        SquadData squad = squadsByLeader.get(leaderId);
        if (squad != null) {
            squad.setCQB(cqb);
            this.setDirty();
        }
    }

    public SquadFormation getSquadFormation(UUID squadId) {
        SquadData squad = squadsById.get(squadId);
        return squad != null ? squad.getFormation() : SquadFormation.NONE;
    }

    public void setSquadFormation(UUID leaderId, SquadFormation formation) {
        SquadData squad = squadsByLeader.get(leaderId);
        if (squad != null) {
            squad.setFormation(formation);
            this.setDirty();
        }
    }

    public int getSquadSize(UUID squadId) {
        SquadData squad = squadsById.get(squadId);
        return squad != null ? squad.getMemberCount() + 1 : 0;
    }

    public int getMemberCount(UUID squadId) {
        SquadData squad = squadsById.get(squadId);
        return squad != null ? squad.getMemberCount() : 0;
    }

    public List<LivingEntity> getSquadMembers(ServerLevel level, UUID squadId, UUID excludeSelf) {
        SquadData squad = squadsById.get(squadId);
        if (squad == null) return List.of();
        List<UUID> ids = new ArrayList<>();
        ids.add(squad.getLeaderId());
        ids.addAll(squad.getMemberIds());
        List<LivingEntity> result = new ArrayList<>();
        for (UUID id : ids) {
            if (id.equals(excludeSelf)) continue;
            Entity entity = level.getEntity(id);
            if (entity instanceof LivingEntity le && le.isAlive()) {
                result.add(le);
            }
        }
        return result;
    }

    public int getMemberIndex(UUID squadId, UUID memberId) {
        SquadData squad = squadsById.get(squadId);
        if (squad == null) return 0;
        List<UUID> ids = new ArrayList<>();
        ids.add(squad.getLeaderId());
        ids.addAll(squad.getMemberIds());
        int idx = ids.indexOf(memberId);
        return idx >= 0 ? idx : 0;
    }

    public Collection<SquadData> getAllSquads() {
        return squadsById.values();
    }

    /** Simulation-harness isolation: drop all squads between scenarios. */
    public void resetForSim() {
        squadsById.clear();
        squadsByLeader.clear();
        squadsByCallsign.clear();
        squadsByMember.clear();
        setDirty();
    }

    /** Commits a successful autonomous grenade throw and persists its cooldown. */
    public SquadData.GrenadeThrowResult completeGrenadeThrow(SquadData squad,
                                                               UUID soldierId,
                                                               long gameTime,
                                                               boolean nativeThrowSucceeded) {
        if (squad == null || squadsById.get(squad.getSquadId()) != squad) {
            return new SquadData.GrenadeThrowResult(false, false,
                "squad no longer exists");
        }

        SquadData.GrenadeThrowResult result = squad.completeGrenadeThrow(
            soldierId, gameTime, nativeThrowSucceeded);
        if (result.committed()) {
            setDirty();
        }
        return result;
    }

    public static SquadManager get(ServerLevel level) {
        DimensionDataStorage storage = level.getDataStorage();
        return storage.computeIfAbsent(
            SquadManager::load,
            SquadManager::new,
            "steves_army_squads"
        );
    }

    public static SquadManager load(CompoundTag tag) {
        SquadManager manager = new SquadManager();
        ListTag squadsList = tag.getList("Squads", Tag.TAG_COMPOUND);
        
        for (int i = 0; i < squadsList.size(); i++) {
            CompoundTag squadTag = squadsList.getCompound(i);
            SquadData squad = SquadData.fromNBT(squadTag);
            manager.squadsById.put(squad.getSquadId(), squad);
            manager.squadsByLeader.putIfAbsent(squad.getLeaderId(), squad);
            if (squad.getCallsign() != null) manager.squadsByCallsign.put(squad.getCallsign(), squad);
            for (UUID memberId : squad.getMemberIds()) {
                manager.squadsByMember.put(memberId, squad);
            }
        }
        
        return manager;
    }

    @Override
    public CompoundTag save(CompoundTag tag) {
        ListTag squadsList = new ListTag();
        for (SquadData squad : squadsById.values()) {
            squadsList.add(squad.toNBT());
        }
        tag.put("Squads", squadsList);
        return tag;
    }
}