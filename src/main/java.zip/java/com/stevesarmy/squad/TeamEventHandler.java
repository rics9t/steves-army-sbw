package com.stevesarmy.squad;

import com.stevesarmy.StevesArmyMod;
import com.stevesarmy.entity.EnemySoldierEntity;
import com.stevesarmy.entity.SoldierEntity;
import com.stevesarmy.entity.SoldierRole;
import com.stevesarmy.entity.SoldierRoleHandler;
import com.stevesarmy.entity.TeamGarrisonEntity;
import com.stevesarmy.network.FireTeamScopeSyncPacket;
import com.stevesarmy.network.FofSyncPacket;
import com.stevesarmy.network.NetworkHandler;
import com.stevesarmy.respawn.SoldierSwapManager;
import com.stevesarmy.util.SoldierNameGenerator;
import net.minecraft.network.chat.Component;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.level.Level;
import net.minecraftforge.event.entity.EntityJoinLevelEvent;
import net.minecraftforge.event.entity.living.LivingDeathEvent;
import net.minecraftforge.event.entity.player.PlayerEvent;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

@Mod.EventBusSubscriber(modid = StevesArmyMod.MODID)
public class TeamEventHandler {
    private static final Map<UUID, String> LAST_PLAYER_TEAMS = new HashMap<>();

    @SubscribeEvent
    public static void onPlayerLoggedIn(PlayerEvent.PlayerLoggedInEvent event) {
        if (!(event.getEntity() instanceof ServerPlayer player)) return;
        MinecraftServer server = player.getServer();
        if (server == null) return;
        OwnerScoreboardIdentity.get(server).remember(player);
        TeamManager.synchronizeOwnedSoldiers(server, player);
        NetworkHandler.sendTo(player, FofSyncPacket.createFor(server, player.getUUID()));
    }

    @SubscribeEvent
    public static void onEntityJoin(EntityJoinLevelEvent event) {
        Level level = event.getLevel();
        if (level.isClientSide()) return;
        if (!(level instanceof ServerLevel)) return;

        var entity = event.getEntity();

        try {
            if (entity instanceof EnemySoldierEntity enemy) {
                TeamManager.assignToEnemyTeam(enemy);
                StevesArmyMod.LOGGER.info("TeamEventHandler: assigned enemy {} to enemy team", enemy.getName().getString());
            } else if (entity instanceof TeamGarrisonEntity teamGarrison) {
                // Team garrisons have no owner: they belong to a scoreboard team and are
                // never registered in the owner pipeline, squad screen, or recall system.
                String teamName = teamGarrison.getTeamName();
                if (teamName != null) {
                    TeamManager.assignToNamedTeam(teamGarrison, teamName);
                }
                teamGarrison.addEffect(new MobEffectInstance(MobEffects.GLOWING, Integer.MAX_VALUE, 0, false, false));
                if (!teamGarrison.hasCustomName()) {
                    teamGarrison.setCustomName(Component.literal(SoldierNameGenerator.generate(teamGarrison.getRandom())));
                }
                StevesArmyMod.LOGGER.info("TeamEventHandler: assigned team garrison {} to team {}", teamGarrison.getName().getString(), teamName);
            } else if (entity instanceof SoldierEntity soldier) {
                OwnedSoldierRegistry registry = OwnedSoldierRegistry.get(((ServerLevel) level).getServer());
                if (registry.isDismissed(soldier.getUUID())) {
                    soldier.discard();
                    return;
                }
                registry.refresh(soldier, (ServerLevel) level);

                OwnedSoldierRegistry.Entry entry = registry.get(soldier.getUUID());
                if (entry != null && entry.pendingRole() >= 0) {
                    SoldierRole[] roles = SoldierRole.values();
                    int pendingOrdinal = entry.pendingRole();
                    registry.clearPendingRole(soldier.getUUID());
                    if (pendingOrdinal < roles.length && soldier.getRole() != roles[pendingOrdinal]) {
                        SoldierRoleHandler.convertSoldier(soldier, roles[pendingOrdinal]);
                        return;
                    }
                }

                UUID ownerUUID = soldier.getOwnerUUID().orElseGet(() -> {
                    StevesArmyMod.LOGGER.warn("TeamEventHandler: soldier {} has no owner UUID, using random fallback", soldier.getName().getString());
                    return UUID.randomUUID();
                });
                TeamManager.assignToFriendlyTeam(soldier, ownerUUID);
                soldier.addEffect(new MobEffectInstance(MobEffects.GLOWING, Integer.MAX_VALUE, 0, false, false));

                if (level instanceof ServerLevel serverLevel) {
                    if (soldier instanceof com.stevesarmy.entity.GarrisonEntity) {
                        // Garrisons always keep the GARRISON fire team and are never
                        // stored in the maneuver fire-team buckets.
                        soldier.setFireTeam(FireTeam.GARRISON);
                    } else {
                        FireTeamAssignment fta = FireTeamAssignment.get(serverLevel, ownerUUID);
                        FireTeam savedTeam = fta.getTeamFor(soldier.getUUID());
                        soldier.setFireTeam(savedTeam);
                        fta.assignToTeam(soldier.getUUID(), savedTeam);
                    }
                }

                if (!soldier.hasCustomName()) {
                    soldier.setCustomName(Component.literal(SoldierNameGenerator.generateForOwner(soldier.getRandom(), ownerUUID)));
                }

                if (level instanceof ServerLevel serverLevel && serverLevel.getServer() != null) {
                    ServerPlayer ownerPlayer = serverLevel.getServer().getPlayerList().getPlayer(ownerUUID);
                    if (ownerPlayer != null) {
                        TeamManager.addPlayerToFriendlyTeam(ownerPlayer, ownerUUID);
                        FireTeamAssignment assignment = FireTeamAssignment.get(serverLevel, ownerUUID);
                        NetworkHandler.sendTo(ownerPlayer, new FireTeamScopeSyncPacket(assignment.getTeamCount()));
                    }
                }

                StevesArmyMod.LOGGER.info("TeamEventHandler: assigned soldier {} to friendly team for owner {}, added GLOWING effect", soldier.getName().getString(), ownerUUID);
            } else if (entity instanceof ServerPlayer player) {
                onPlayerLogin(player);
            }
        } catch (Exception e) {
            StevesArmyMod.LOGGER.error("Failed to assign team for entity {}: {}", entity, e.getMessage());
        }
    }

    @SubscribeEvent
    public static void onLivingDeath(LivingDeathEvent event) {
        if (event.getEntity() instanceof SoldierEntity soldier && soldier.level() instanceof ServerLevel level
            && level.getServer() != null) {
            FireTeamSuppressionTracker.recordCasualty(soldier);
            OwnedSoldierRegistry.get(level.getServer()).remove(soldier.getUUID());
            SquadActivityManager.removeSoldier(soldier.getUUID(), level.getServer());
            UUID ownerUUID = soldier.getOwnerUUID().orElse(null);
            if (ownerUUID != null) {
                FireTeamAssignment.get(level, ownerUUID).removeSoldier(soldier.getUUID());
                // Swap cargo is lost where the body is lost, and a swap-back
                // pointer aimed at this body goes with it.
                SwapStashStore.get(level.getServer()).pruneSoldier(soldier.getUUID());
                ServerPlayer ownerPlayer = level.getServer().getPlayerList().getPlayer(ownerUUID);
                if (ownerPlayer != null && soldier.getUUID().equals(SoldierSwapManager.getLastSwapped(ownerPlayer))) {
                    SoldierSwapManager.clearLastSwapped(ownerPlayer);
                }
            }
        }
    }

    private static void onPlayerLogin(ServerPlayer player) {
        UUID playerUUID = player.getUUID();
        TeamManager.addPlayerToFriendlyTeam(player, playerUUID);
        TeamManager.synchronizeOwnedSoldiers(player.getServer(), player);
        LAST_PLAYER_TEAMS.put(playerUUID, getTeamName(player));
        FireTeamAssignment assignment = FireTeamAssignment.get((ServerLevel) player.level(), playerUUID);
        NetworkHandler.sendTo(player, new FireTeamScopeSyncPacket(assignment.getTeamCount()));
        SquadActivityManager.sync(player);
    }

    @SubscribeEvent
    public static void onServerTick(TickEvent.ServerTickEvent event) {
        if (event.phase != TickEvent.Phase.END || event.getServer().getTickCount() % 10 != 0) return;

        for (ServerPlayer player : event.getServer().getPlayerList().getPlayers()) {
            UUID playerUUID = player.getUUID();
            OwnerScoreboardIdentity.get(event.getServer()).remember(player);
            String currentTeam = getTeamName(player);
            String previousTeam = LAST_PLAYER_TEAMS.put(playerUUID, currentTeam);
            if (previousTeam == null || previousTeam.equals(currentTeam)) continue;

            if (player.getTeam() == null) {
                TeamManager.addPlayerToFriendlyTeam(player, playerUUID);
            }
            TeamManager.synchronizeOwnedSoldiers(event.getServer(), player);
            StevesArmyMod.LOGGER.info("[SoldierTeam] player team changed: {} -> {} for owner {}",
                previousTeam, currentTeam, player.getScoreboardName());
        }
        LAST_PLAYER_TEAMS.keySet().removeIf(uuid -> event.getServer().getPlayerList().getPlayer(uuid) == null);
    }

    private static String getTeamName(ServerPlayer player) {
        return player.getTeam() == null ? "none" : player.getTeam().getName();
    }
}
