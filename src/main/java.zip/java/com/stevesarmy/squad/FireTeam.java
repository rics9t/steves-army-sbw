package com.stevesarmy.squad;

public enum FireTeam {
    ALL,
    ALPHA,
    BRAVO,
    CHARLIE,
    DELTA,
    GARRISON;

    public String getShortName() {
        return switch (this) {
            case ALL -> "ALL";
            case ALPHA -> "A";
            case BRAVO -> "B";
            case CHARLIE -> "C";
            case DELTA -> "D";
            case GARRISON -> "GAR";
        };
    }

    public String getDisplayName() {
        return switch (this) {
            case ALL -> "All";
            case ALPHA -> "Alpha";
            case BRAVO -> "Bravo";
            case CHARLIE -> "Charlie";
            case DELTA -> "Delta";
            case GARRISON -> "Garrison";
        };
    }
}