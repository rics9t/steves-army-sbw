package com.stevesarmy;

import com.mojang.logging.LogUtils;
import com.stevesarmy.command.CombatDebugCommand;
import com.stevesarmy.command.SimCommand;
import com.stevesarmy.command.StevesArmyCommand;
import com.stevesarmy.command.TransportCommand;
import com.stevesarmy.client.StevesArmyClientConfig;
import com.stevesarmy.combat.GunIntegration;
import com.stevesarmy.combat.GrenadeIntegration;
import com.stevesarmy.compat.ysm.YsmCompat;
import com.stevesarmy.network.NetworkHandler;
import com.stevesarmy.registry.ModEntities;
import com.stevesarmy.registry.ModItems;
import com.stevesarmy.registry.ModCreativeTab;
import com.stevesarmy.registry.ModMenuTypes;
import com.stevesarmy.squad.TeamEventHandler;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.common.world.ForgeChunkManager;
import net.minecraftforge.event.RegisterCommandsEvent;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.fml.ModLoadingContext;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.config.ModConfig;
import net.minecraftforge.fml.event.lifecycle.FMLCommonSetupEvent;
import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;
import org.slf4j.Logger;

@Mod(StevesArmyMod.MODID)
public class StevesArmyMod {
    public static final String MODID = "steves_army";
    public static final Logger LOGGER = LogUtils.getLogger();
    
    public static boolean teleportOnlyMode = false;

    public StevesArmyMod(FMLJavaModLoadingContext context) {
        IEventBus modEventBus = context.getModEventBus();

        ModEntities.register(modEventBus);
        ModItems.register(modEventBus);
        ModCreativeTab.register(modEventBus);
        ModMenuTypes.register(modEventBus);

        ModLoadingContext.get().registerConfig(ModConfig.Type.SERVER, StevesArmyConfig.SPEC);
        ModLoadingContext.get().registerConfig(ModConfig.Type.CLIENT, StevesArmyClientConfig.SPEC);

        modEventBus.addListener(this::commonSetup);
        modEventBus.addListener(this::processImc);

        MinecraftForge.EVENT_BUS.register(this);
        MinecraftForge.EVENT_BUS.register(TeamEventHandler.class);
        MinecraftForge.EVENT_BUS.register(com.stevesarmy.sim.SimManager.class);
        MinecraftForge.EVENT_BUS.addListener(this::registerCommands);
    }

    private void commonSetup(final FMLCommonSetupEvent event) {
        NetworkHandler.register();
        GunIntegration.init();
        GrenadeIntegration.init();
        YsmCompat.init();
        ForgeChunkManager.setForcedChunkLoadingCallback(MODID, (level, helper) -> {
            // Recall tickets are intentionally transient and are never resumed
            // after a server restart.
            for (java.util.UUID owner : new java.util.ArrayList<>(helper.getEntityTickets().keySet())) {
                helper.removeAllTickets(owner);
            }
        });
        LOGGER.info("Steve's Army mod initialized - Enlisted-style squad system ready!");
    }
    
    private void registerCommands(final RegisterCommandsEvent event) {
        CombatDebugCommand.register(event.getDispatcher());
        StevesArmyCommand.register(event.getDispatcher());
        TransportCommand.register(event.getDispatcher());
        SimCommand.register(event.getDispatcher());
        LOGGER.info("Registered commands: /stevesarmy, /steves_army, /stevesarmy_debug, /stevesarmy transport, /stevesarmy_sim");
    }

    /** IMC drain for the VehicleCrewApi contract (see api/VehicleCrewApi javadoc). */
    private void processImc(net.minecraftforge.fml.event.lifecycle.InterModProcessEvent event) {
        net.minecraftforge.fml.InterModComms.getMessages("vs_analog_warfare", "vehicleSetupCompleted"::equals)
            .forEach(imc -> {
                Object payload = imc.getMessageSupplier().get();
                if (payload instanceof Object[] parts && parts.length == 3
                    && parts[0] instanceof net.minecraft.server.level.ServerPlayer player
                    && parts[1] instanceof net.minecraft.world.level.Level level
                    && parts[2] instanceof net.minecraft.core.BlockPos pos) {
                    com.stevesarmy.api.VehicleCrewApi.onVehicleSetupCompleted(player, level, pos);
                }
            });
    }
}
