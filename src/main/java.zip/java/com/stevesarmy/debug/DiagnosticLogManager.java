package com.stevesarmy.debug;

import java.util.UUID;

/** Server-wide diagnostic log toggles. All default to false, reset on restart. */
public final class DiagnosticLogManager {
    private static boolean coverLoggingEnabled;
    private static boolean coverScoreLoggingEnabled;
    private static boolean coverPerformanceLoggingEnabled;
    private static boolean attackLoggingEnabled;
    private static boolean grenadeLoggingEnabled;
    private static boolean damageLoggingEnabled;
    private static boolean suppressionLoggingEnabled;
    private static boolean spacingLoggingEnabled;
    private static boolean holeRescueLoggingEnabled;
    private static boolean stationFireLoggingEnabled;
    private static boolean firingLoggingEnabled;
    private static UUID rotationTraceSoldierId;
    private static UUID peekTraceSoldierId;

    private DiagnosticLogManager() {}

    // Cover
    public static boolean isCoverLoggingEnabled() { return coverLoggingEnabled; }
    public static void setCoverLoggingEnabled(boolean v) { coverLoggingEnabled = v; }

    // Expensive per-candidate scoring and peek-ray traces are separate from cover events.
    public static boolean isCoverScoreLoggingEnabled() { return coverScoreLoggingEnabled; }
    public static void setCoverScoreLoggingEnabled(boolean v) { coverScoreLoggingEnabled = v; }

    // Cover search/path timing summaries without per-candidate traces.
    public static boolean isCoverPerformanceLoggingEnabled() { return coverPerformanceLoggingEnabled; }
    public static void setCoverPerformanceLoggingEnabled(boolean v) { coverPerformanceLoggingEnabled = v; }

    // Attack
    public static boolean isAttackLoggingEnabled() { return attackLoggingEnabled; }
    public static void setAttackLoggingEnabled(boolean v) { attackLoggingEnabled = v; }

    // Grenade planning and rejection diagnostics. Kept separate from general attack logging.
    public static boolean isGrenadeLoggingEnabled() { return grenadeLoggingEnabled; }
    public static void setGrenadeLoggingEnabled(boolean v) { grenadeLoggingEnabled = v; }

    // Damage and gun integration
    public static boolean isDamageLoggingEnabled() { return damageLoggingEnabled; }
    public static void setDamageLoggingEnabled(boolean v) { damageLoggingEnabled = v; }

    // Suppression and incoming fire
    public static boolean isSuppressionLoggingEnabled() { return suppressionLoggingEnabled; }
    public static void setSuppressionLoggingEnabled(boolean v) { suppressionLoggingEnabled = v; }

    // Spacing
    public static boolean isSpacingLoggingEnabled() { return spacingLoggingEnabled; }
    public static void setSpacingLoggingEnabled(boolean v) { spacingLoggingEnabled = v; }

    // Hole rescue
    public static boolean isHoleRescueLoggingEnabled() { return holeRescueLoggingEnabled; }
    public static void setHoleRescueLoggingEnabled(boolean v) { holeRescueLoggingEnabled = v; }

    // Vehicle crew station fire calls (hull MG / periscope). Correlates observed
    // gunfire with the AI's fire calls; tracer bursts with no fire lines are not ours.
    public static boolean isStationFireLoggingEnabled() { return stationFireLoggingEnabled; }
    public static void setStationFireLoggingEnabled(boolean v) { stationFireLoggingEnabled = v; }

    // Dynamic firing gate: burst rolls, threshold composition, streak ratchet.
    public static boolean isFiringLoggingEnabled() { return firingLoggingEnabled; }
    public static void setFiringLoggingEnabled(boolean v) { firingLoggingEnabled = v; }

    // Targeted rotation trace. A UUID is required to avoid per-tick squad-wide output.
    public static void setRotationTraceSoldierId(UUID soldierId) { rotationTraceSoldierId = soldierId; }
    public static void clearRotationTrace() { rotationTraceSoldierId = null; }
    public static UUID getRotationTraceSoldierId() { return rotationTraceSoldierId; }
    public static boolean isRotationTraceEnabledFor(UUID soldierId) {
        return rotationTraceSoldierId != null && rotationTraceSoldierId.equals(soldierId);
    }

    // Targeted peek/suppression trace. Kept separate from rotation because the two
    // diagnostics have different reproduction workflows and output volume.
    public static void setPeekTraceSoldierId(UUID soldierId) { peekTraceSoldierId = soldierId; }
    public static void clearPeekTrace() { peekTraceSoldierId = null; }
    public static UUID getPeekTraceSoldierId() { return peekTraceSoldierId; }
    public static boolean isPeekTraceEnabledFor(UUID soldierId) {
        return peekTraceSoldierId != null && peekTraceSoldierId.equals(soldierId);
    }

    /** Enable all diagnostic logging categories. */
    public static void enableAll() {
        coverLoggingEnabled = true;
        attackLoggingEnabled = true;
        grenadeLoggingEnabled = true;
        damageLoggingEnabled = true;
        suppressionLoggingEnabled = true;
        spacingLoggingEnabled = true;
        holeRescueLoggingEnabled = true;
        stationFireLoggingEnabled = true;
        firingLoggingEnabled = true;
    }

    /** Disable all diagnostic logging categories. */
    public static void disableAll() {
        coverLoggingEnabled = false;
        coverScoreLoggingEnabled = false;
        coverPerformanceLoggingEnabled = false;
        attackLoggingEnabled = false;
        grenadeLoggingEnabled = false;
        damageLoggingEnabled = false;
        suppressionLoggingEnabled = false;
        spacingLoggingEnabled = false;
        holeRescueLoggingEnabled = false;
        stationFireLoggingEnabled = false;
        firingLoggingEnabled = false;
        rotationTraceSoldierId = null;
        peekTraceSoldierId = null;
        PerformanceMetrics.setEnabled(false);
    }
}
