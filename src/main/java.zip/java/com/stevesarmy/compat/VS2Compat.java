package com.stevesarmy.compat;

import com.stevesarmy.StevesArmyConfig;
import com.stevesarmy.StevesArmyMod;
import com.stevesarmy.combat.StationGunnerAI;
import com.stevesarmy.compat.SbwCompat;
import com.stevesarmy.entity.SoldierEntity;
import com.stevesarmy.entity.SoldierRole;
import com.stevesarmy.squad.SquadMode;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.core.Vec3i;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.protocol.game.ClientboundSetPassengersPacket;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.Pose;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.level.ClipContext;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.ChunkPos;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.levelgen.Heightmap;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.fml.ModList;
import net.minecraftforge.registries.ForgeRegistries;

import javax.annotation.Nullable;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.UUID;

/** Optional VS2 integration. Ships are transport, never terrain for soldier AI. */
public final class VS2Compat {
    private static final String VS2_MOD_ID = "valkyrienskies";
    private static final String VS_UTILS_CLASS = "org.valkyrienskies.mod.common.VSGameUtilsKt";
    private static final String CONTRAPTION_ENTITY_CLASS =
        "com.simibubi.create.content.contraptions.AbstractContraptionEntity";
    private static final int[] ESCAPE_RADII = {2, 4, 6, 8, 12, 16, 24, 32};
    private static final int FULL_SEAT_RETRY_TICKS = 100;
    /** Ticks the owner must be off-ship before a FOLLOW soldier is released (debounce). */
    private static final int RELEASE_DEBOUNCE_TICKS = 40;
    /** Ticks between re-seat attempts while a reloaded soldier waits for its seat. */
    private static final int RESEAT_RETRY_INTERVAL_TICKS = 20;
    /** Ticks a reseat wait may run before giving up and extracting the soldier. */
    private static final int RESEAT_WAIT_TIMEOUT_TICKS = 600;
    /** Seat-distance beyond which a waiting soldier is re-pinned to the seat position. */
    private static final double RESEAT_PIN_EPSILON = 2.0;
    /** Ticks between station duty scans for a seated crew soldier without a station. */
    private static final int CREW_DUTY_SCAN_INTERVAL_TICKS = 20;
    /**
     * World-space distance within which a seat entity of unknown ship is attributed
     * to the clicked ship — its rendered world position matches the clicked seat block.
     */
    private static final double SEAT_CLICK_WORLD_TOLERANCE_SQR = 3.0 * 3.0;

    private static volatile boolean initialized;
    private static volatile boolean available;
    private static boolean reflectionFailureLogged;
    // VSGameUtilsKt methods: use MethodHandle to avoid ClientLevel class loading on dedicated server
    private static MethodHandle getShipMountedTo;
    private static MethodHandle getShipMountedToData;
    private static MethodHandle toWorldCoordinates;
    private static MethodHandle getShipsIntersecting;
    private static MethodHandle getShipObjectManagingPos;
    private static MethodHandle getShipObjectManagingPosDouble;
    private static MethodHandle clipIncludeShips;
    private static MethodHandle clipIncludeShipsOnly;
    private static MethodHandle vanillaClip;
    // Non-VSGameUtilsKt reflection (safe to use ordinary Method)
    private static Method getMountPosInShip;
    private static Method createSeatSitDown;
    private static Class<?> createSeatBlockClass;
    private static Class<?> createSeatEntityClass;
    private static Class<?> contraptionEntityClass;
    private static Class<?> shipMountedDataProviderClass;
    private static MethodHandle shipGetShipToWorld;
    private static MethodHandle shipGetWorldToShip;
    private static MethodHandle shipGetAABB;
    private static Method aabbMinX;
    private static Method aabbMinY;
    private static Method aabbMinZ;
    private static Method aabbMaxX;
    private static Method aabbMaxY;
    private static Method aabbMaxZ;
    private static Method getContraption;
    private static Method getSeats;
    private static Method getSeatMapping;
    private static Method addSittingPassenger;
    private static Method getShipId;
    private static Object createInteractiveUtil;
    private static Method getContraptionEntityForShip;
    private static final Map<UUID, SoldierState> states = new HashMap<>();
    private static final Map<UUID, UUID> authorizedMounts = new HashMap<>();
    private static final Map<UUID, BlockPos> authorizedStaticSeats = new HashMap<>();

    private VS2Compat() {}

    public static boolean isEnabled() {
        // Visibility rays call this several times per ray; enter the synchronized
        // initializer only before the first successful resolution.
        if (!initialized) {
            initialize();
        }
        return available && StevesArmyConfig.VS2_COMPAT_ENABLED.get();
    }

    public static boolean prepareSoldierAi(SoldierEntity soldier) {
        if (soldier.level().isClientSide || !isEnabled()) {
            return false;
        }

        SoldierState state = states.computeIfAbsent(soldier.getUUID(), ignored -> new SoldierState());
        if (state.transportAnchorId != null) {
            if (state.reboardBlockTicks > 0) {
                state.reboardBlockTicks--;
            }
            // True also while a reseat wait pins a reloaded soldier at its seat's
            // world position - the AI must stay frozen then, or its goals would
            // fight the pin.
            return updateTransport(soldier, state);
        }

        if (state.reboardBlockTicks > 0) {
            state.reboardBlockTicks--;
        }
        if (state.handleDismountGraceTicks > 0) {
            state.handleDismountGraceTicks--;
        }

        // A crew soldier saved aboard a ship reloads with vanilla's passenger link
        // intact but an empty state map. Re-adopt the seat instead of dismounting -
        // the dismount would strand it at shipyard coordinates, and crew mounts are
        // explicit-only so it could never re-board.
        if (soldier.isPassenger() && soldier.getRole() == SoldierRole.VEHICLE_CREW
            && adoptReloadedShipSeat(soldier, state)) {
            return updateTransport(soldier, state);
        }

        if (soldier.isPassenger()) {
            soldier.stopRiding();
        }

        // A soldier stranded at shipyard coordinates with no transport state (ship
        // scrapped while unloaded, or a pre-persistence save the adoption fallback
        // could not resolve) has no ground under it. Move it to its last on-foot
        // world position instead of letting it fall out of the world.
        if (!isSaneWorldPos(soldier.level(), soldier.position())) {
            recoverFromImplausiblePosition(soldier, state);
        }

        if (tryStartTransport(soldier, state)) {
            return true;
        }

        if (isInsideShip(soldier) || isBeingDraggedByShip(soldier)) {
            // A soldier just let off at a mount handle may stand aboard briefly
            // (e.g. the loading hatch) before ship-extraction moves it to safe ground.
            if (state.handleDismountGraceTicks <= 0) {
                extractToSafeWorldPosition(soldier, state);
                return true;
            }
            return false;
        }

        rememberSafeWorldPosition(soldier, state);
        return false;
    }

    public static void onSoldierRemoved(SoldierEntity soldier) {
        states.remove(soldier.getUUID());
        authorizedMounts.remove(soldier.getUUID());
        authorizedStaticSeats.remove(soldier.getUUID());
        AnalogWarfareCompat.forget(soldier.getUUID());
    }

    // ------------------------------------------------------------------
    // NBT persistence of transport state (survives server/world restarts)
    // ------------------------------------------------------------------

    /**
     * Saves the soldier's transport state so a crew soldier reloaded from disk
     * stays seated on its shipyard-space seat instead of being dismounted by the
     * empty-state path in {@link #prepareSoldierAi}.
     */
    public static void saveTransportState(SoldierEntity soldier, CompoundTag tag) {
        if (!isEnabled()) {
            return;
        }
        SoldierState state = states.get(soldier.getUUID());
        if (state == null || state.transportAnchorId == null) {
            return;
        }
        tag.putUUID("VsTransportAnchor", state.transportAnchorId);
        if (state.transportOwnerId != null) {
            tag.putUUID("VsTransportOwner", state.transportOwnerId);
        }
        if (state.transportShipId != null) {
            tag.putLong("VsTransportShipId", state.transportShipId);
        }
        if (state.transportSeatPosition != null) {
            tag.putLong("VsTransportSeatPos", state.transportSeatPosition.asLong());
        }
        if (state.lastSafeWorldPosition != null) {
            tag.putLong("VsTransportSafePos", state.lastSafeWorldPosition.asLong());
        }
        tag.putBoolean("VsTransportCrewSeated", state.crewSeated);
    }

    /** Restores the transport state written by {@link #saveTransportState} on world load. */
    public static void restoreTransportState(SoldierEntity soldier, CompoundTag tag) {
        if (soldier.level().isClientSide || !isEnabled() || !tag.hasUUID("VsTransportAnchor")) {
            return;
        }
        SoldierState state = getOrCreateState(soldier);
        if (state.transportAnchorId != null) {
            return;
        }
        state.transportAnchorId = tag.getUUID("VsTransportAnchor");
        if (tag.hasUUID("VsTransportOwner")) {
            state.transportOwnerId = tag.getUUID("VsTransportOwner");
        }
        if (tag.contains("VsTransportShipId")) {
            state.transportShipId = tag.getLong("VsTransportShipId");
        }
        if (tag.contains("VsTransportSeatPos")) {
            state.transportSeatPosition = BlockPos.of(tag.getLong("VsTransportSeatPos"));
        }
        if (tag.contains("VsTransportSafePos")) {
            state.lastSafeWorldPosition = BlockPos.of(tag.getLong("VsTransportSafePos"));
        }
        state.crewSeated = tag.getBoolean("VsTransportCrewSeated")
            || soldier.getRole() == SoldierRole.VEHICLE_CREW;
        StevesArmyMod.LOGGER.info("[VS2] Restored transport state soldier={} anchor={} shipId={} seat={} crewSeated={}",
            soldier.getId(), state.transportAnchorId, state.transportShipId,
            state.transportSeatPosition, state.crewSeated);
    }

    /**
     * Legacy-save adoption: a crew soldier that reloads seated on a Create ship
     * seat with no persisted state. Rebuilds the state from the seat so the
     * soldier stays aboard instead of being dismounted at shipyard coordinates.
     */
    private static boolean adoptReloadedShipSeat(SoldierEntity soldier, SoldierState state) {
        Entity vehicle = soldier.getVehicle();
        // Any seat-like entity: Create SeatEntities plus tallyho's FlexibleSeatEntity
        // (the raw fallback tier), both living at shipyard coordinates on ships.
        if (vehicle == null || !isSeatLikeEntity(vehicle)) {
            return false;
        }
        try {
            Vec3 seatPos = vehicle.position();
            Object ship = reflect(getShipObjectManagingPosDouble, soldier.level(), seatPos.x, seatPos.y, seatPos.z);
            if (ship == null) {
                return false;
            }
            state.transportAnchorId = vehicle.getUUID();
            state.transportOwnerId = null;
            state.transportShipId = getShipIdOf(ship);
            state.transportSeatPosition = soldier.blockPosition();
            state.crewSeated = true;
            StevesArmyMod.LOGGER.info("[VS2] Adopted reloaded ship seat soldier={} vehicle={} shipId={}",
                soldier.getId(), vehicle.getId(), state.transportShipId);
            return true;
        } catch (ReflectiveOperationException exception) {
            logReflectionFailure(exception);
            return false;
        }
    }

    /**
     * Recovers a soldier whose raw position is shipyard-scale with no transport
     * state. Prefers the last on-foot world position, falling back to the ship
     * conversion of the seat. Returns false (throttled WARN) when nothing works.
     */
    private static void recoverFromImplausiblePosition(SoldierEntity soldier, SoldierState state) {
        long now = System.currentTimeMillis();
        boolean logReady = now - state.lastRecoveryLog >= 5000L;
        if (logReady) {
            state.lastRecoveryLog = now;
        }
        BlockPos target = null;
        if (state.lastSafeWorldPosition != null
            && isWorldPlausible(Vec3.atBottomCenterOf(state.lastSafeWorldPosition))
            && isSafeWorldPosition(soldier, state.lastSafeWorldPosition)) {
            target = state.lastSafeWorldPosition;
        } else {
            Vec3 converted = convertShipyardPosition(soldier.level(), soldier.position(), state);
            if (converted != null && isWorldPlausible(converted)) {
                target = BlockPos.containing(converted.x, converted.y, converted.z);
            }
        }
        if (target == null) {
            if (logReady) {
                StevesArmyMod.LOGGER.warn("[VS2] Soldier stranded at implausible position {} with no recoverable target",
                    formatVec3(soldier.position()));
            }
            return;
        }
        StevesArmyMod.LOGGER.warn("[VS2] Recovered soldier={} stranded at implausible position: moved to {}",
            soldier.getId(), target);
        moveToWorldPosition(soldier, target);
    }

    /** True when the soldier is seated on a crew-claimed station seat (role keeps ticking AI). */
    public static boolean isCrewSeated(SoldierEntity soldier) {
        SoldierState state = states.get(soldier.getUUID());
        return state != null && state.crewSeated;
    }

    /** True while the post-dismount re-boarding cooldown is running. */
    public static boolean isAutoTransportBlocked(SoldierEntity soldier) {
        SoldierState state = states.get(soldier.getUUID());
        return state != null && state.reboardBlockTicks > 0;
    }

    /** The VS2 ship the entity is mounted to, or null. */
    @Nullable
    public static Object getMountedShip(Entity entity) {
        if (!isEnabled()) {
            return null;
        }
        try {
            return reflect(getShipMountedTo, entity);
        } catch (ReflectiveOperationException exception) {
            logReflectionFailure(exception);
            return null;
        }
    }

    /** Stable id of a VS2 ship object, or null. */
    @Nullable
    public static Long getShipIdOf(@Nullable Object ship) {
        if (ship == null) {
            return null;
        }
        try {
            return ((Number) getShipId.invoke(ship)).longValue();
        } catch (ReflectiveOperationException exception) {
            logReflectionFailure(exception);
            return null;
        }
    }

    /** Transforms a direction from ship-local space to world space. */
    public static Vec3 shipToWorldDirection(@Nullable Object ship, Vec3 direction) {
        if (ship == null || shipGetShipToWorld == null) {
            return direction;
        }
        try {
            Object matrix = shipGetShipToWorld.invoke(ship);
            if (matrix instanceof org.joml.Matrix4dc m) {
                org.joml.Vector3d v = new org.joml.Vector3d(direction.x, direction.y, direction.z);
                m.transformDirection(v);
                return new Vec3(v.x, v.y, v.z);
            }
        } catch (Throwable ignored) {
        }
        return direction;
    }

    /** Transforms a world position into ship-local space, or null when unavailable. */
    @Nullable
    public static Vec3 worldToShipLocal(@Nullable Object ship, Vec3 worldPos) {
        if (ship == null || shipGetWorldToShip == null) {
            return null;
        }
        try {
            Object matrix = shipGetWorldToShip.invoke(ship);
            if (matrix instanceof org.joml.Matrix4dc m) {
                org.joml.Vector3d v = new org.joml.Vector3d(worldPos.x, worldPos.y, worldPos.z);
                m.transformPosition(v);
                return new Vec3(v.x, v.y, v.z);
            }
        } catch (Throwable ignored) {
        }
        return null;
    }

    /**
     * Transforms a ship-local (shipyard) position to world space, or null when
     * unavailable. Ship-mounted entities like tallyho cameras live at shipyard
     * coordinates server-side; VS2 transforms them only for client tracking.
     */
    @Nullable
    public static Vec3 shipToWorldPosition(@Nullable Object ship, Vec3 localPos) {
        if (ship == null || shipGetShipToWorld == null) {
            return null;
        }
        try {
            Object matrix = shipGetShipToWorld.invoke(ship);
            if (matrix instanceof org.joml.Matrix4dc m) {
                org.joml.Vector3d v = new org.joml.Vector3d(localPos.x, localPos.y, localPos.z);
                m.transformPosition(v);
                return new Vec3(v.x, v.y, v.z);
            }
        } catch (Throwable ignored) {
        }
        return null;
    }

    /** Positions beyond this magnitude are VS2 shipyard allocations, not world coordinates. */
    private static final double WORLD_COORD_LIMIT = 1.0e6;

    /**
     * World-space position of a tallyho station camera. Tallyho keeps these entities
     * in world coordinates (handleShoot spawns projectiles at the raw position), so a
     * plausible raw position is used directly. A shipyard-scale position means the
     * entity was spawned into or left in VS2's allocation region: the ship transform
     * is tried as a fallback and accepted only if it lands back in the world, since
     * aiming or scanning on guessed coordinates is worse than refusing to run.
     */
    @Nullable
    public static Vec3 stationCameraWorldPos(@Nullable Object ship, Entity station) {
        Vec3 raw = station.position();
        if (isWorldPlausible(raw)) {
            return raw;
        }
        Vec3 transformed = shipToWorldPosition(ship, raw);
        return isWorldPlausible(transformed) ? transformed : null;
    }

    public static boolean isWorldPlausible(@Nullable Vec3 pos) {
        return pos != null
            && Math.abs(pos.x) <= WORLD_COORD_LIMIT
            && Math.abs(pos.z) <= WORLD_COORD_LIMIT;
    }

    /**
     * A position where the soldier can actually exist: world-plausible x/z and
     * inside the world vertically. A reload can leave a released soldier at the
     * seat's world y minus the ship's y-offset a second time (observed: y=-246
     * over a void world with the floor at -60) - plausible x/z, already in the
     * void. Only the full check may gate a recovery decision.
     */
    private static boolean isSaneWorldPos(Level level, @Nullable Vec3 pos) {
        return isWorldPlausible(pos)
            && pos.y >= level.getMinBuildHeight() - 8
            && pos.y <= level.getMaxBuildHeight() + 64;
    }

    /**
     * Minimum corner of the ship's AABB in shipyard (block) space — the origin that
     * ship-local offsets are added to in order to reach real block positions.
     */
    @Nullable
    public static BlockPos getShipyardMin(@Nullable Object ship) {
        if (ship == null || shipGetAABB == null) {
            return null;
        }
        try {
            Object box = shipGetAABB.invoke(ship);
            if (box == null) {
                return null;
            }
            synchronized (VS2Compat.class) {
                if (aabbMinX == null || aabbMinX.getDeclaringClass() != box.getClass()) {
                    aabbMinX = box.getClass().getMethod("minX");
                    aabbMinY = box.getClass().getMethod("minY");
                    aabbMinZ = box.getClass().getMethod("minZ");
                }
            }
            return new BlockPos(
                ((Number) aabbMinX.invoke(box)).intValue(),
                ((Number) aabbMinY.invoke(box)).intValue(),
                ((Number) aabbMinZ.invoke(box)).intValue());
        } catch (Throwable ignored) {
        }
        return null;
    }

    /**
     * Maximum corner of the ship's voxel AABB in shipyard (block) space; null when
     * VS2 has no AABB for the ship or reflection fails. Mirrors {@link #getShipyardMin}.
     */
    @Nullable
    public static BlockPos getShipyardMax(@Nullable Object ship) {
        if (ship == null || shipGetAABB == null) {
            return null;
        }
        try {
            Object box = shipGetAABB.invoke(ship);
            if (box == null) {
                return null;
            }
            synchronized (VS2Compat.class) {
                if (aabbMaxX == null || aabbMaxX.getDeclaringClass() != box.getClass()) {
                    aabbMaxX = box.getClass().getMethod("maxX");
                    aabbMaxY = box.getClass().getMethod("maxY");
                    aabbMaxZ = box.getClass().getMethod("maxZ");
                }
            }
            return new BlockPos(
                ((Number) aabbMaxX.invoke(box)).intValue(),
                ((Number) aabbMaxY.invoke(box)).intValue(),
                ((Number) aabbMaxZ.invoke(box)).intValue());
        } catch (Throwable ignored) {
        }
        return null;
    }

    /** True when the entity is a Create SeatEntity (includes tallyho's FlexibleSeatEntity). */
    public static boolean isCreateSeatEntity(Entity entity) {
        initialize();
        return createSeatEntityClass != null && createSeatEntityClass.isInstance(entity);
    }

    /**
     * The {@code /vs get-ship} lookup: the ship managing the exact block a world-space
     * ray hit. VS2 exposes ship blocks to the world at their transformed positions, so
     * a vanilla clip's hit block resolves directly through VS2's chunk map.
     */
    @Nullable
    public static Object getShipObjectAtBlockPos(Level level, BlockPos pos) {
        return getShipObjectAtWorldPos(level, pos.getX() + 0.5, pos.getY() + 0.5, pos.getZ() + 0.5);
    }

    /** Id of the ship managing the given world/shipyard position, or null. */
    @Nullable
    public static Long getShipIdAt(Level level, double x, double y, double z) {
        Object ship = getShipObjectAtWorldPos(level, x, y, z);
        return ship == null ? null : getShipIdOf(ship);
    }

    /** Ship object managing the given world position, or null. */
    @Nullable
    public static Object getShipObjectAtWorldPos(Level level, double x, double y, double z) {
        initialize();
        if (!available) {
            return null;
        }
        try {
            return reflect(getShipObjectManagingPosDouble, level, x, y, z);
        } catch (ReflectiveOperationException exception) {
            return null;
        }
    }

    /**
     * Resolves a ship from a clicked world-space anchor.
     *
     * <p>VS2's position-manager lookup is shipyard-chunk based, so it can return
     * an unrelated ship when the anchor is a world-space raycast hit. Reconcile
     * that result with VS2's world-space intersection query before falling back
     * to the legacy result.</p>
     */
    @Nullable
    public static Object resolveShipAtWorldAnchor(Level level, Vec3 anchor) {
        initialize();
        Object managingShip = getShipObjectAtWorldPos(level, anchor.x, anchor.y, anchor.z);
        if (!available || getShipsIntersecting == null) {
            StevesArmyMod.LOGGER.info(
                "[VS2] crew anchor resolver: world intersection unavailable, using managing shipId={}",
                getShipIdOf(managingShip));
            return managingShip;
        }

        try {
            Object ships = reflect(getShipsIntersecting, level, new AABB(anchor, anchor));
            List<Object> intersecting = new ArrayList<>();
            List<String> candidateIds = new ArrayList<>();
            if (ships instanceof Iterable<?> iterable) {
                for (Object candidate : iterable) {
                    if (candidate == null) {
                        continue;
                    }
                    intersecting.add(candidate);
                    Long candidateId = getShipIdOf(candidate);
                    candidateIds.add(candidateId == null ? "unknown" : candidateId.toString());
                }
            }

            // Geometric pick for multi-ship builds (tanks assembled as several stacked
            // ships): the ship the player actually clicked is the one whose own voxel
            // body contains the anchor, judged by the LOCAL block at the transformed
            // position — not just AABB overlap, which every stacked sub-ship satisfies.
            // A raycast hit lies on a block face, so BlockPos.containing can land in the
            // neighbouring air block; the six face neighbours are checked too.
            // Unloaded/no-transform candidates are "unavailable": invisible to the
            // geometric tiers but still reachable through the legacy fallbacks.
            List<String> geoVerdicts = new ArrayList<>();
            Object solidCandidate = null;
            Object airCandidate = null;
            Object managingInIntersecting = null;
            ServerLevel serverLevel = level instanceof ServerLevel ? (ServerLevel) level : null;
            for (Object candidate : intersecting) {
                Long candidateId = getShipIdOf(candidate);
                if (managingShip != null && managingInIntersecting == null
                    && getShipIdOf(managingShip) != null && getShipIdOf(managingShip).equals(candidateId)) {
                    managingInIntersecting = candidate;
                }
                String verdict;
                Vec3 local = worldToShipLocal(candidate, anchor);
                BlockPos converted = local == null ? null
                    : BlockPos.containing(local.x, local.y, local.z);
                BlockPos aabbMin = converted == null ? null : getShipyardMin(candidate);
                BlockPos aabbMax = converted == null ? null : getShipyardMax(candidate);
                boolean contained = converted != null && aabbMin != null && aabbMax != null
                    && converted.getX() >= aabbMin.getX() - 1 && converted.getX() <= aabbMax.getX() + 1
                    && converted.getY() >= aabbMin.getY() - 1 && converted.getY() <= aabbMax.getY() + 1
                    && converted.getZ() >= aabbMin.getZ() - 1 && converted.getZ() <= aabbMax.getZ() + 1;
                if (!contained) {
                    verdict = local == null ? "no-transform" : "outside";
                } else if (serverLevel == null || !isChunkLoaded(serverLevel, converted)) {
                    verdict = "unloaded";
                } else if (hasSolidBlockNear(serverLevel, converted)) {
                    verdict = "contains-anchor-solid";
                    if (solidCandidate == null) {
                        solidCandidate = candidate;
                    }
                } else {
                    verdict = "contains-anchor-air";
                    if (airCandidate == null) {
                        airCandidate = candidate;
                    }
                }
                geoVerdicts.add((candidateId == null ? "?" : candidateId) + ":" + verdict);
            }

            Long managingId = getShipIdOf(managingShip);
            Object selected;
            String decision;
            if (solidCandidate != null) {
                selected = solidCandidate;
                decision = "contains-anchor-solid";
            } else if (airCandidate != null) {
                selected = airCandidate;
                decision = "contains-anchor-air";
            } else if (managingInIntersecting != null) {
                selected = managingInIntersecting;
                decision = "managing-match";
            } else if (intersecting.size() == 1) {
                selected = intersecting.get(0);
                decision = "sole-intersection";
            } else if (intersecting.isEmpty()) {
                selected = managingShip;
                decision = "no-intersection-managing-fallback";
            } else {
                selected = null;
                decision = "ambiguous-intersection-near-player-fallback";
            }

            StevesArmyMod.LOGGER.info(
                "[VS2] crew anchor resolver: anchor={} managingShipId={} intersectingShipIds=[{}] geo=[{}] selectedShipId={} decision={}",
                formatVec3(anchor), managingId, String.join(", ", candidateIds),
                String.join(", ", geoVerdicts), getShipIdOf(selected), decision);
            return selected;
        } catch (ReflectiveOperationException | RuntimeException exception) {
            StevesArmyMod.LOGGER.warn(
                "[VS2] crew anchor resolver failed; using managing shipId={}: {}",
                getShipIdOf(managingShip), exception.toString());
            return managingShip;
        }
    }

    /** Grants a soldier a grace period to stand at a handle after a handle dismount. */
    public static void markHandleDismount(SoldierEntity soldier) {
        getOrCreateState(soldier).handleDismountGraceTicks =
            StevesArmyConfig.VEHICLE_HANDLES_DISMOUNT_GRACE.get();
    }

    /**
     * True when the block at {@code pos} or any face neighbour is non-air. Raycast hits
     * lie on block faces, so {@code BlockPos.containing} at the hit point can land in
     * the adjacent air block; the neighbours decide whether the hit touched this ship.
     */
    private static boolean hasSolidBlockNear(ServerLevel level, BlockPos pos) {
        if (!level.getBlockState(pos).isAir()) {
            return true;
        }
        for (Direction direction : Direction.values()) {
            if (!level.getBlockState(pos.relative(direction)).isAir()) {
                return true;
            }
        }
        return false;
    }

    /** Remembers the handle owning a just-attached seat so later releases can exit at it. */
    private static void recordHandleLink(ServerLevel level, Object ship, SoldierEntity soldier, BlockPos seatPos) {
        if (StevesArmyConfig.VEHICLE_HANDLES_ENABLED.get()) {
            AnalogWarfareCompat.recordHandleForSeat(level, ship, soldier, seatPos);
        }
    }

    /**
     * World-space position of a seat entity. Create SeatEntities on ships live at
     * shipyard coordinates; VS2 data-provider seats (e.g. tallyho's FlexibleSeatEntity)
     * are already tracked at world coordinates.
     */
    public static Vec3 getSeatWorldPosition(Entity seat) {
        if (shipMountedDataProviderClass != null && shipMountedDataProviderClass.isInstance(seat)) {
            return seat.position();
        }
        if (seat.level() instanceof ServerLevel serverLevel) {
            try {
                Object ship = reflect(getShipObjectManagingPosDouble, serverLevel,
                    seat.getX(), seat.getY(), seat.getZ());
                if (ship != null) {
                    Object world = reflect(toWorldCoordinates, ship,
                        seat.getX(), seat.getY(), seat.getZ());
                    if (world instanceof org.joml.Vector3dc v) {
                        return new Vec3(v.x(), v.y(), v.z());
                    }
                }
            } catch (ReflectiveOperationException ignored) {
            }
        }
        return seat.position();
    }

    /**
     * Nearest unoccupied Create seat entity (includes tallyho's FlexibleSeatEntity,
     * which extends Create's SeatEntity) within the radius of the soldier.
     */
    @Nullable
    public static Entity findFreeSeatEntityNear(SoldierEntity soldier, double radius) {
        if (!(soldier.level() instanceof ServerLevel level)) {
            return null;
        }
        initialize();
        if (!available || createSeatEntityClass == null) {
            return null;
        }
        Entity best = null;
        double bestDistSqr = radius * radius;
        for (Entity entity : level.getAllEntities()) {
            if (!createSeatEntityClass.isInstance(entity) || entity.isRemoved()
                || !entity.getPassengers().isEmpty()) {
                continue;
            }
            Vec3 worldPos = getSeatWorldPosition(entity);
            double distSqr = worldPos.distanceToSqr(soldier.position());
            if (distSqr < bestDistSqr) {
                bestDistSqr = distSqr;
                best = entity;
            }
        }
        return best;
    }

    /**
     * Mounts the soldier onto a specific seat entity as command-driven transport,
     * mirroring {@link #seatSoldierDirect} but for existing seat entities (tallyho
     * FlexibleSeatEntity instances have no SeatBlock behind them). The soldier keeps
     * ticking its AI, so the vehicle crew goal can man stations while seated.
     */
    public static boolean seatSoldierOnSeatEntity(SoldierEntity soldier, Entity seat) {
        initialize();
        if (!available || soldier.isPassenger() || seat.isRemoved()) {
            return false;
        }
        authorizedMounts.put(soldier.getUUID(), seat.getUUID());
        try {
            soldier.startRiding(seat, true);
        } finally {
            authorizedMounts.remove(soldier.getUUID());
        }
        if (!soldier.isPassenger() || soldier.getVehicle() != seat) {
            return false;
        }

        SoldierState state = getOrCreateState(soldier);
        state.transportAnchorId = seat.getUUID();
        state.transportOwnerId = null;
        state.transportShipId = getShipIdOf(getMountedShip(seat));
        state.transportSeatPosition = null;
        state.seatRetryCooldownTicks = 0;
        state.reboardBlockTicks = 0;
        state.crewSeated = true;

        soldier.getVehicle().positionRider(soldier);
        syncTransportState(soldier, seat, true);
        StevesArmyMod.LOGGER.info("[VS2] seatSoldierOnSeatEntity: mounted soldier={} seat={} seatClass={} shipId={}",
            soldier.getId(), seat.getId(), seat.getClass().getSimpleName(), state.transportShipId);
        return true;
    }

    /**
     * Mounts the soldier directly on a plain world-space vehicle entity (Superb
     * Warfare). The fourth seat primitive beside SeatBlock/contraption/seat-entity
     * mounts: vanilla {@code startRiding} with a pending {@code authorizedMounts}
     * entry, then the SBW seat placement (crew may take the driver seat; ordinary
     * infantry are restricted to passenger seats). Command-driven and ship-less:
     * {@code transportShipId} and {@code transportSeatPosition} both stay null —
     * that pair is the marker {@link #waitForReseat} uses to release instead of
     * re-seating when the vanilla passenger link is gone. No manual passenger
     * sync: a world-space entity is vanilla-tracked.
     */
    public static boolean seatSoldierOnEntity(SoldierEntity soldier, Entity vehicle,
                                              boolean preferGunnerSeat) {
        if (soldier.isPassenger() || vehicle == null || vehicle.isRemoved()) {
            return false;
        }
        int wanted = SbwCompat.firstFreeSeat(vehicle, preferGunnerSeat);
        if (wanted < 0 || (wanted == 0 && soldier.getRole() != SoldierRole.VEHICLE_CREW)) {
            return false;
        }
        return seatSoldierOnEntityAtSeat(soldier, vehicle, wanted);
    }

    /** Mounts on a previously reserved SBW seat after the soldier has walked up to the vehicle. */
    public static boolean seatSoldierOnEntityAtSeat(SoldierEntity soldier, Entity vehicle, int wanted) {
        if (soldier == null || soldier.isPassenger() || vehicle == null || vehicle.isRemoved()
            || wanted < 0 || wanted >= SbwCompat.maxPassengers(vehicle)
            || SbwCompat.passengerInSeat(vehicle, wanted) != null
            || (wanted == 0 && soldier.getRole() != SoldierRole.VEHICLE_CREW)) {
            return false;
        }
        Vec3 preMountPos = soldier.position();
        authorizedMounts.put(soldier.getUUID(), vehicle.getUUID());
        try {
            soldier.startRiding(vehicle, true);
        } finally {
            authorizedMounts.remove(soldier.getUUID());
        }
        if (!soldier.isPassenger() || soldier.getVehicle() != vehicle) {
            return false;
        }

        SoldierState state = getOrCreateState(soldier);
        state.transportAnchorId = vehicle.getUUID();
        state.transportOwnerId = null;
        state.transportShipId = null;
        state.transportSeatPosition = null;
        state.seatRetryCooldownTicks = 0;
        state.reseatWaitTicks = 0;
        state.reboardBlockTicks = 0;
        state.crewSeated = soldier.getRole() == SoldierRole.VEHICLE_CREW;
        // Egg-spawned / command-mounted crew never stood on foot near here: remember
        // the pre-mount spot as the recovery target if the vehicle is ever gone.
        if (isWorldPlausible(preMountPos)) {
            state.lastSafeWorldPosition = BlockPos.containing(preMountPos.x, preMountPos.y, preMountPos.z);
        }

        vehicle.positionRider(soldier);
        int seat = SbwCompat.seatIndexOf(vehicle, soldier);
        if (wanted >= 0 && wanted != seat) {
            if (!SbwCompat.changeSeat(vehicle, soldier, wanted)) {
                releaseTransport(soldier, false);
                return false;
            }
        }
        int actualSeat = SbwCompat.seatIndexOf(vehicle, soldier);
        if (actualSeat != wanted) {
            releaseTransport(soldier, false);
            return false;
        }
        StevesArmyMod.LOGGER.info("[VS2] seatSoldierOnEntity: mounted soldier={} vehicle={} vehicleClass={} seat {} -> {}",
            soldier.getId(), vehicle.getId(), vehicle.getClass().getSimpleName(), seat, actualSeat);
        return true;
    }

    /** Allows only the immediate Create seat mount initiated by tryContraptionSeat or tryStaticSeat. */
    public static boolean isAuthorizedMount(SoldierEntity soldier, Entity vehicle) {
        if (vehicle == null) {
            return false;
        }
        // Ensure reflection classes are initialized before checking them.
        // On the client (render thread), initialize() may not have been called yet.
        initialize();
        // Direct authorization: soldier has a pending authorized mount UUID.
        UUID vehicleId = authorizedMounts.get(soldier.getUUID());
        if (vehicleId != null && vehicleId.equals(vehicle.getUUID())) {
            return true;
        }
        // Static-seat authorization: the SeatEntity's block position must match the pending candidate.
        BlockPos pendingPos = authorizedStaticSeats.get(soldier.getUUID());
        if (pendingPos != null && createSeatEntityClass != null && createSeatEntityClass.isInstance(vehicle)) {
            return vehicle.blockPosition().equals(pendingPos);
        }
        // On the client side, the server is authoritative. Accept any Create seat or contraption mount.
        // Use class name string comparison as a safe fallback since reflection classes may not be
        // loaded on a remote client's render thread before the mount event fires.
        if (soldier.level().isClientSide) {
            String vehicleClassName = vehicle.getClass().getName();
            if ("com.simibubi.create.content.contraptions.actors.seat.SeatEntity".equals(vehicleClassName)
                || (createSeatEntityClass != null && createSeatEntityClass.isInstance(vehicle))) {
                return true;
            }
            if ("com.simibubi.create.content.contraptions.AbstractContraptionEntity".equals(vehicleClassName)
                || (contraptionEntityClass != null && contraptionEntityClass.isInstance(vehicle))) {
                return true;
            }
            String side = "CLIENT";
            StevesArmyMod.LOGGER.info("[AuthorizeCl] {} isAuthorizedMount returning false for soldier={} vehicle={} vehicleClass={} createSeatClass={} contraptionClass={}",
                side, soldier.getId(), vehicle.getId(), vehicle.getClass().getName(),
                createSeatEntityClass == null ? "null" : createSeatEntityClass.getName(),
                contraptionEntityClass == null ? "null" : contraptionEntityClass.getName());
        }
        return false;
    }

    public static void clearAuthorizedMount(SoldierEntity soldier) {
        authorizedMounts.remove(soldier.getUUID());
        authorizedStaticSeats.remove(soldier.getUUID());
    }

    /**
     * Directly mounts a soldier to a static Create seat at the given shipyard block position.
     * Bypasses all FOLLOW/owner/transport logic. Returns true if the soldier is now a passenger.
     * After a successful mount, records the transport state so prepareSoldierAi does not
     * immediately dismount the soldier.
     */
    public static boolean seatSoldierDirect(SoldierEntity soldier, Level level, BlockPos seatBlockPos) {
        initialize();
        if (!available) return false;
        // Mounting onto a taken seat block would stack a second SeatEntity on the
        // same shipyard position; that duplicate is what later hijacks player seat
        // clicks across ships (Create's occupant swap). Refuse and let the caller
        // fall back to another seat or the reseat timeout.
        if (!createSeatBlockClass.isInstance(level.getBlockState(seatBlockPos).getBlock())) {
            StevesArmyMod.LOGGER.info("[VS2] seatSoldierDirect: no SeatBlock at {} — refusing", seatBlockPos);
            return false;
        }
        if (level instanceof ServerLevel serverLevel && isCreateSeatOccupied(serverLevel, seatBlockPos)) {
            StevesArmyMod.LOGGER.info("[VS2] seatSoldierDirect: seat {} occupied — refusing duplicate mount", seatBlockPos);
            return false;
        }
        try {
            // Resolve the ship at the seat position for logging
            Object ship = null;
            Long shipId = null;
            org.joml.Vector3dc worldPos = null;
            try {
                ship = reflect(getShipObjectManagingPos, level, (net.minecraft.core.Vec3i) seatBlockPos);
                if (ship != null) {
                    shipId = ((Number) getShipId.invoke(ship)).longValue();
                    worldPos = (org.joml.Vector3dc) reflect(toWorldCoordinates, ship,
                        seatBlockPos.getX() + 0.5, seatBlockPos.getY(), seatBlockPos.getZ() + 0.5);
                }
            } catch (ReflectiveOperationException e) {
                StevesArmyMod.LOGGER.warn("[VS2] seatSoldierDirect: ship lookup failed for seat={}", seatBlockPos);
            }

            // Use SeatBlock.sitDown to create the seat at the shipyard block position.
            // This keeps the seat attached to the real seat block on the ship.
            // Mount the soldier after the seat entity is created.
            authorizedStaticSeats.put(soldier.getUUID(), seatBlockPos);
            try {
                createSeatSitDown.invoke(null, level, seatBlockPos, soldier);
            } finally {
                authorizedStaticSeats.remove(soldier.getUUID());
            }

            if (soldier.isPassenger() && soldier.getVehicle() != null) {
                Entity vehicle = soldier.getVehicle();

                // SeatEntity is at shipyard coordinates — VS2 handles world-space
                // tracking and rider position transforms (see MixinChunkMap$TrackedEntity,
                // MixinSeatBlock.wrapSitDownSetPos, MixinEntity.positionRider).
                // Do NOT move the seat to world-space.

                SoldierState state = getOrCreateState(soldier);
                state.transportAnchorId = vehicle.getUUID();
                state.transportOwnerId = null;
                state.transportShipId = shipId;
                state.transportSeatPosition = seatBlockPos;
                state.seatRetryCooldownTicks = 0;
                state.reboardBlockTicks = 0;
                state.crewSeated = soldier.getRole() == SoldierRole.VEHICLE_CREW;
                state.reseatWaitTicks = 0;
                // Egg-spawned crew are mounted without ever standing on foot, so the
                // on-foot safe-position memory would stay empty forever. Remember the
                // pre-mount spot (the spawn ground) as the recovery target if the ship
                // is ever gone.
                Vec3 prePos = soldier.position();
                if (isWorldPlausible(prePos)) {
                    state.lastSafeWorldPosition = BlockPos.containing(prePos.x, prePos.y, prePos.z);
                }

                soldier.getVehicle().positionRider(soldier);
                Vec3 postPos = soldier.position();

                // Synchronize the seat entity and passenger to all relevant players.
                syncTransportState(soldier, vehicle, true);

                StevesArmyMod.LOGGER.info("[VS2] seatSoldierDirect: mounted soldier={} vehicle={} vehicleClass={} seat={} shipId={} soldierPos={} -> {}",
                    soldier.getId(), vehicle.getId(), vehicle.getClass().getSimpleName(),
                    seatBlockPos, shipId,
                    formatVec3(prePos), formatVec3(postPos));

                if (worldPos != null) {
                    StevesArmyMod.LOGGER.info("[VS2] seatSoldierDirect: resolved seat worldPos=({}, {}, {})",
                        String.format("%.2f", worldPos.x()), String.format("%.2f", worldPos.y()), String.format("%.2f", worldPos.z()));
                }

                if (ship != null && level instanceof ServerLevel serverLevel) {
                    recordHandleLink(serverLevel, ship, soldier, seatBlockPos);
                }

                return true;
            }
            StevesArmyMod.LOGGER.warn("[VS2] seatSoldierDirect: mount did not persist soldier={} seat={}",
                soldier.getId(), seatBlockPos);
            return false;
        } catch (ReflectiveOperationException e) {
            StevesArmyMod.LOGGER.error("[VS2] seatSoldierDirect failed", e);
            return false;
        }
    }

    private static String formatVec3(Vec3 v) {
        return String.format("(%.2f, %.2f, %.2f)", v.x, v.y, v.z);
    }

    // ------------------------------------------------------------------
    // Player takeover of a seated soldier's seat (respawn-as-soldier)
    // ------------------------------------------------------------------

    /**
     * World-space position of a soldier. Soldiers seated on VS objects live at
     * shipyard coordinates server-side (VS2 transforms positions only for
     * client tracking), so an implausible raw position is converted through the
     * seat or ship transform. Returns the raw position when nothing converts.
     */
    public static Vec3 getSoldierWorldPosition(SoldierEntity soldier) {
        Vec3 raw = soldier.position();
        if (isWorldPlausible(raw)) {
            return raw;
        }
        if (!isEnabled()) {
            return raw;
        }
        Vec3 converted = convertShipyardPosition(soldier.level(), raw, states.get(soldier.getUUID()));
        return isWorldPlausible(converted) ? converted : raw;
    }

    /**
     * Converts a shipyard-space reference to world space: static seat block
     * position first, then the seat entity, then the raw position through the
     * ship managing it. Returns null when nothing converts.
     */
    @Nullable
    private static Vec3 convertShipyardPosition(Level level, Vec3 rawPos, @Nullable SoldierState state) {
        if (level instanceof ServerLevel serverLevel) {
            if (state != null && state.transportSeatPosition != null) {
                Vec3 world = staticSeatWorldPos(serverLevel, state.transportSeatPosition);
                if (world != null) {
                    return world;
                }
            }
            if (state != null && state.transportAnchorId != null) {
                Entity anchor = serverLevel.getEntity(state.transportAnchorId);
                if (anchor != null && !anchor.isRemoved() && isSeatLikeEntity(anchor)) {
                    Vec3 world = getSeatWorldPosition(anchor);
                    if (isWorldPlausible(world)) {
                        return world;
                    }
                }
            }
            try {
                // The soldier's own shipyard position is managed by its ship.
                Object ship = reflect(getShipObjectManagingPosDouble, serverLevel,
                    rawPos.x, rawPos.y, rawPos.z);
                Vec3 world = shipToWorldPosition(ship, rawPos);
                if (world != null) {
                    return world;
                }
            } catch (ReflectiveOperationException ignored) {
            }
        }
        return null;
    }

    /** True for entities whose position getSeatWorldPosition understands. */
    private static boolean isSeatLikeEntity(Entity entity) {
        if (shipMountedDataProviderClass != null && shipMountedDataProviderClass.isInstance(entity)) {
            return true;
        }
        return createSeatEntityClass != null && createSeatEntityClass.isInstance(entity);
    }

    /** World position of a static seat block, or null when no ship manages it. */
    @Nullable
    private static Vec3 staticSeatWorldPos(ServerLevel level, BlockPos seatPos) {
        try {
            Object ship = reflect(getShipObjectManagingPos, level, (Vec3i) seatPos);
            if (ship == null) {
                return null;
            }
            Object world = reflect(toWorldCoordinates, ship,
                seatPos.getX() + 0.5, seatPos.getY(), seatPos.getZ() + 0.5);
            if (world instanceof org.joml.Vector3dc v) {
                return new Vec3(v.x(), v.y(), v.z());
            }
        } catch (ReflectiveOperationException ignored) {
        }
        return null;
    }

    /**
     * Snapshot of a seated soldier's seat so a player can respawn into it.
     * Stable ids only — positions are re-derived at restore time because the
     * ship keeps moving between death and respawn.
     */
    public static final class SeatCapture {
        @Nullable private final UUID anchorId;
        @Nullable private final Long shipId;
        @Nullable private final BlockPos staticSeatPos;
        @Nullable private final Integer contraptionSeatIndex;
        private final Vec3 worldPos;

        private SeatCapture(@Nullable UUID anchorId, @Nullable Long shipId,
                            @Nullable BlockPos staticSeatPos, @Nullable Integer contraptionSeatIndex,
                            Vec3 worldPos) {
            this.anchorId = anchorId;
            this.shipId = shipId;
            this.staticSeatPos = staticSeatPos;
            this.contraptionSeatIndex = contraptionSeatIndex;
            this.worldPos = worldPos;
        }

        /** True when the capture names a seat a player could take over. */
        public boolean hasSeat() {
            return anchorId != null || staticSeatPos != null || contraptionSeatIndex != null;
        }

        /** World-space position of the seat when captured — the takeover fallback spot. */
        public Vec3 worldPos() {
            return worldPos;
        }
    }

    /**
     * Snapshots the seat a soldier is riding so {@link #seatPlayerInCapturedSeat}
     * can put a player in it after the soldier is discarded. Must be called
     * before the discard: the Create seat mapping and the soldier's transport
     * state are both gone after removal. Returns null when the soldier is not
     * seated on a known seat type or VS2 compat is unavailable.
     */
    @Nullable
    public static SeatCapture captureSeatForTakeover(ServerLevel level, SoldierEntity soldier) {
        if (!isEnabled()) {
            return null;
        }
        SoldierState state = states.get(soldier.getUUID());
        Entity vehicle = soldier.getVehicle();
        UUID anchorId = state != null && state.transportAnchorId != null
            ? state.transportAnchorId
            : vehicle != null ? vehicle.getUUID() : null;
        Long shipId = state == null ? null : state.transportShipId;
        BlockPos staticSeatPos = state == null ? null : state.transportSeatPosition;
        Integer seatIndex = readContraptionSeatIndex(vehicle, soldier.getUUID());

        Entity anchorEntity = anchorId == null ? null : level.getEntity(anchorId);
        boolean anchorSeatLike = anchorEntity != null && isSeatLikeEntity(anchorEntity);
        if (staticSeatPos == null && seatIndex == null && !anchorSeatLike) {
            // Not seated on a known seat type (may not even be on a ship):
            // plain takeover at the soldier's position.
            return null;
        }

        Vec3 worldPos = staticSeatPos != null ? staticSeatWorldPos(level, staticSeatPos) : null;
        if (worldPos == null && vehicle != null && isSeatLikeEntity(vehicle)) {
            Vec3 seatWorld = getSeatWorldPosition(vehicle);
            if (isWorldPlausible(seatWorld)) {
                worldPos = seatWorld;
            }
        }
        if (worldPos == null) {
            worldPos = getSoldierWorldPosition(soldier);
        }
        SeatCapture capture = new SeatCapture(anchorId, shipId, staticSeatPos, seatIndex, worldPos);
        StevesArmyMod.LOGGER.info("[Respawn] Captured seat takeover soldier={} anchor={} staticSeat={} shipId={} index={} world={}",
            soldier.getId(), anchorId, staticSeatPos, shipId, seatIndex, formatVec3(worldPos));
        return capture;
    }

    /** The Create contraption seat index a rider occupies, or null. */
    @Nullable
    private static Integer readContraptionSeatIndex(@Nullable Entity vehicle, UUID riderId) {
        if (vehicle == null || contraptionEntityClass == null || !contraptionEntityClass.isInstance(vehicle)) {
            return null;
        }
        try {
            Object contraption = getContraption.invoke(vehicle);
            if (contraption == null) {
                return null;
            }
            @SuppressWarnings("unchecked")
            java.util.Map<UUID, Integer> occupied =
                (java.util.Map<UUID, Integer>) getSeatMapping.invoke(contraption);
            return occupied.get(riderId);
        } catch (ReflectiveOperationException ignored) {
            return null;
        }
    }

    /**
     * Mounts {@code player} into the seat captured from a discarded soldier:
     * static seat block first, then the captured anchor entity, then the Create
     * contraption seat index. Soldier mounts are gated by SoldierMountHandler;
     * player mounts pass through un-gated, so no authorization is needed here.
     * Returns false when nothing worked — the caller has already placed the
     * player at the seat's captured world position.
     */
    public static boolean seatPlayerInCapturedSeat(ServerLevel level, ServerPlayer player, @Nullable SeatCapture capture) {
        if (capture == null || !capture.hasSeat() || !isEnabled() || player.isPassenger()) {
            return false;
        }

        if (capture.staticSeatPos != null && createSeatBlockClass != null
            && createSeatBlockClass.isInstance(level.getBlockState(capture.staticSeatPos).getBlock())
            && !isCreateSeatOccupied(level, capture.staticSeatPos)) {
            try {
                createSeatSitDown.invoke(null, level, capture.staticSeatPos, player);
            } catch (ReflectiveOperationException exception) {
                logReflectionFailure(exception);
            }
            if (player.isPassenger()) {
                syncPlayerSeatMount(level, player, capture);
                return true;
            }
        }

        if (capture.anchorId != null) {
            Entity anchor = level.getEntity(capture.anchorId);
            if (anchor != null && !anchor.isRemoved() && anchor.getPassengers().isEmpty()
                && isSeatLikeEntity(anchor)) {
                player.startRiding(anchor, true);
                if (player.isPassenger() && player.getVehicle() == anchor) {
                    syncPlayerSeatMount(level, player, capture);
                    return true;
                }
            }
        }

        if (capture.contraptionSeatIndex != null && capture.shipId != null && createInteractiveUtil != null) {
            try {
                Entity mappedVehicle =
                    (Entity) getContraptionEntityForShip.invoke(createInteractiveUtil, capture.shipId, false);
                Object contraption = mappedVehicle == null ? null : getContraption.invoke(mappedVehicle);
                if (mappedVehicle != null && contraption != null) {
                    @SuppressWarnings("unchecked")
                    java.util.Map<UUID, Integer> occupied =
                        (java.util.Map<UUID, Integer>) getSeatMapping.invoke(contraption);
                    if (!occupied.containsValue(capture.contraptionSeatIndex)) {
                        addSittingPassenger.invoke(mappedVehicle, player, capture.contraptionSeatIndex);
                        if (player.isPassenger() && player.getVehicle() == mappedVehicle) {
                            syncPlayerSeatMount(level, player, capture);
                            return true;
                        }
                    }
                }
            } catch (ReflectiveOperationException exception) {
                logReflectionFailure(exception);
            }
        }

        StevesArmyMod.LOGGER.info("[Respawn] Seat takeover mount failed for player {} — standing at captured seat position",
            player.getName().getString());
        return false;
    }

    /**
     * Result of classifying a player's right-click on a seat block. Ship blocks are
     * interacted with in shipyard space, and Create's SeatBlock.use scans that space
     * for seat entities — so a seat entity from ANOTHER ship sharing the clicked
     * shipyard position hijacks the click and Create ejects its occupant. The
     * classification separates the ship's own seats from foreign ones so the click
     * can be re-routed to the seat the player actually aimed at.
     */
    public static final class PlayerSeatClick {
        private final BlockPos seatPos;
        @Nullable private final Entity freeSeat;
        @Nullable private final Entity playerOccupant;
        @Nullable private final Entity soldierOccupant;
        private final boolean foreignSeatPresent;

        private PlayerSeatClick(BlockPos seatPos, @Nullable Entity freeSeat,
                                @Nullable Entity playerOccupant, @Nullable Entity soldierOccupant,
                                boolean foreignSeatPresent) {
            this.seatPos = seatPos;
            this.freeSeat = freeSeat;
            this.playerOccupant = playerOccupant;
            this.soldierOccupant = soldierOccupant;
            this.foreignSeatPresent = foreignSeatPresent;
        }

        /** The clicked seat block, in shipyard space. */
        public BlockPos seatPos() {
            return seatPos;
        }

        /** A same-ship seat entity at the clicked block with no passenger, or null. */
        @Nullable
        public Entity freeSeat() {
            return freeSeat;
        }

        /** A same-ship seat entity at the clicked block already carrying a player, or null. */
        @Nullable
        public Entity playerOccupant() {
            return playerOccupant;
        }

        /** A same-ship seat entity at the clicked block carrying an alive soldier, or null. */
        @Nullable
        public Entity soldierOccupant() {
            return soldierOccupant;
        }

        /** True when a seat entity of another ship shares the clicked shipyard position. */
        public boolean foreignSeatPresent() {
            return foreignSeatPresent;
        }
    }

    /**
     * Classifies a player click on the seat block at {@code pos} (shipyard space, as
     * Forge delivers interaction positions for ship blocks). Returns null when the
     * block is not a Create SeatBlock on a ship — the click is then none of our
     * business and Create handles it natively. Safe on both sides.
     */
    @Nullable
    public static PlayerSeatClick classifyPlayerSeatClick(Level level, BlockPos pos) {
        initialize();
        if (!available || createSeatBlockClass == null) {
            return null;
        }
        if (!createSeatBlockClass.isInstance(level.getBlockState(pos).getBlock())) {
            return null;
        }
        Object ship = getShipObjectAtBlockPos(level, pos);
        Long shipId = getShipIdOf(ship);
        if (ship == null || shipId == null) {
            return null;
        }

        Vec3 seatWorld = null;
        try {
            Object converted = reflect(toWorldCoordinates, ship,
                pos.getX() + 0.5, pos.getY() + 0.5, pos.getZ() + 0.5);
            if (converted instanceof org.joml.Vector3dc v) {
                seatWorld = new Vec3(v.x(), v.y(), v.z());
            }
        } catch (ReflectiveOperationException ignored) {
        }

        Entity freeSeat = null;
        Entity playerOccupant = null;
        Entity soldierOccupant = null;
        boolean foreignSeatPresent = false;
        for (Entity seat : scanSeatEntities(level, pos)) {
            Long seatShipId = getShipIdOf(getShipUnder(seat));
            boolean sameShip;
            if (seatShipId != null) {
                sameShip = seatShipId.equals(shipId);
            } else if (seatWorld != null) {
                // Ship lookup misses for stale/persistent seat entities; attribute by
                // where the seat actually renders in the world instead.
                Vec3 rendered = getSeatWorldPosition(seat);
                sameShip = rendered != null
                    && rendered.distanceToSqr(seatWorld) <= SEAT_CLICK_WORLD_TOLERANCE_SQR;
            } else {
                sameShip = false;
            }
            if (!sameShip) {
                foreignSeatPresent = true;
                continue;
            }
            Entity occupant = firstAlivePassenger(seat);
            if (occupant instanceof SoldierEntity) {
                if (soldierOccupant == null) {
                    soldierOccupant = seat;
                }
            } else if (occupant instanceof Player) {
                if (playerOccupant == null) {
                    playerOccupant = seat;
                }
            } else if (freeSeat == null) {
                freeSeat = seat;
            }
        }
        return new PlayerSeatClick(pos.immutable(), freeSeat, playerOccupant, soldierOccupant,
            foreignSeatPresent);
    }

    /** Create seat entities inside the block's AABB — the same scan SeatBlock.use performs. */
    @SuppressWarnings("unchecked")
    private static List<Entity> scanSeatEntities(Level level, BlockPos pos) {
        if (createSeatEntityClass == null) {
            return List.of();
        }
        return (List<Entity>) level.getEntitiesOfClass(
            (Class<? extends Entity>) createSeatEntityClass, new AABB(pos));
    }

    @Nullable
    private static Entity firstAlivePassenger(Entity entity) {
        for (Entity passenger : entity.getPassengers()) {
            if (passenger != null && passenger.isAlive()) {
                return passenger;
            }
        }
        return null;
    }

    /**
     * Seats a player on an existing seat entity. Player mounts pass through
     * SoldierMountHandler un-gated, so no authorization is needed. Returns true
     * when the player is now a passenger of {@code seat}.
     */
    public static boolean seatPlayerOnSeatEntity(ServerLevel level, ServerPlayer player, Entity seat) {
        initialize();
        if (!available || player.isPassenger() || seat.isRemoved()
            || !isCreateSeatEntity(seat) || !seat.getPassengers().isEmpty()) {
            return false;
        }
        player.startRiding(seat, true);
        if (!player.isPassenger() || player.getVehicle() != seat) {
            return false;
        }
        syncPlayerSeatMount(level, player, seat, getSeatWorldPosition(seat));
        return true;
    }

    /**
     * Seats a player on the static SeatBlock at the shipyard position by creating a
     * fresh seat entity there — the same {@code SeatBlock.sitDown} call Create's use()
     * makes. Occupancy is judged per ship: a seat entity from ANOTHER ship sharing
     * the shipyard position must not block the clicked seat, but a taken seat on the
     * same ship refuses the mount. Returns true when the player is mounted.
     */
    public static boolean sitPlayerAtShipyardSeat(ServerLevel level, ServerPlayer player, BlockPos seatPos) {
        initialize();
        if (!available || createSeatSitDown == null || createSeatBlockClass == null || player.isPassenger()) {
            return false;
        }
        if (!createSeatBlockClass.isInstance(level.getBlockState(seatPos).getBlock())) {
            return false;
        }
        Long shipId = getShipIdAt(level, seatPos.getX() + 0.5, seatPos.getY() + 0.5, seatPos.getZ() + 0.5);
        for (Entity seat : scanSeatEntities(level, seatPos)) {
            Long seatShipId = getShipIdOf(getShipUnder(seat));
            // Unattributable entities count as same-ship here: refuse the mount rather
            // than risk double-booking one seat.
            boolean sameShip = shipId == null || seatShipId == null || seatShipId.equals(shipId);
            if (sameShip && !seat.getPassengers().isEmpty()) {
                return false;
            }
        }
        try {
            createSeatSitDown.invoke(null, level, seatPos, player);
        } catch (ReflectiveOperationException exception) {
            logReflectionFailure(exception);
            return false;
        }
        if (!player.isPassenger()) {
            return false;
        }
        syncPlayerSeatMount(level, player, player.getVehicle(), Vec3.atCenterOf(seatPos));
        return true;
    }

    /**
     * syncTransportState equivalent for a player takeover: shipyard anchors are
     * not vanilla-tracked, so the mounting player and everyone near the seat
     * need the anchor's add-entity packet before the passenger packet.
     */
    private static void syncPlayerSeatMount(ServerLevel level, ServerPlayer player, SeatCapture capture) {
        Entity anchor = player.getVehicle();
        if (anchor == null) {
            return;
        }
        syncPlayerSeatMount(level, player, anchor, capture.worldPos());
    }

    private static void syncPlayerSeatMount(ServerLevel level, ServerPlayer player, Entity anchor, Vec3 refPos) {
        if (anchor == null) {
            return;
        }
        java.util.Set<ServerPlayer> recipients = new java.util.HashSet<>();
        recipients.add(player);
        for (ServerPlayer other : level.getServer().getPlayerList().getPlayers()) {
            if (other.distanceToSqr(refPos) < 16384.0) {
                recipients.add(other);
            }
        }
        net.minecraft.network.protocol.Packet<?> spawnPacket = anchor.getAddEntityPacket();
        ClientboundSetPassengersPacket passengersPacket = new ClientboundSetPassengersPacket(anchor);
        for (ServerPlayer recipient : recipients) {
            recipient.connection.send(spawnPacket);
            recipient.connection.send(passengersPacket);
        }
        StevesArmyMod.LOGGER.info("[VS2] Synced player seat mount player={} anchor={} recipients={}",
            player.getName().getString(), anchor.getId(), recipients.size());
    }

    /** Public wrapper to clear VS2 dragging state after a manual release. */
    public static void clearShipDraggingStateDirect(SoldierEntity soldier) {
        clearShipDraggingState(soldier);
    }

    /** Clears the transport state for a soldier. Used by the release command. */
    public static void clearTransportState(SoldierEntity soldier) {
        SoldierState state = states.get(soldier.getUUID());
        if (state != null) {
            clearTransportState(state);
        }
    }

    /**
     * Manual release shared by the /stevesarmy transport release command and the vehicle wheel:
     * dismount, clear VS2 dragging + transport state, and briefly block automatic re-boarding.
     * Returns true if the soldier was mounted.
     */
    public static boolean releaseTransport(SoldierEntity soldier) {
        return releaseTransport(soldier, true);
    }

    /**
     * Release with control over the handle exit. Mount-time cleanup passes false -
     * the soldier is about to be seated again and must not teleport to the hatch.
     */
    public static boolean releaseTransport(SoldierEntity soldier, boolean exitAtHandle) {
        Entity vehicle = soldier.isPassenger() ? soldier.getVehicle() : null;
        if (soldier.isPassenger()) {
            soldier.stopRiding();
        }
        clearShipDraggingStateDirect(soldier);
        clearTransportState(soldier);
        blockAutoTransport(soldier);
        // Exit at the hatch: the handle linked to this soldier's seat first, then the
        // nearest handle on their ship. The resolver runs after stopRiding so the
        // teleport lands as the final position, but the mount-time handle record
        // still resolves (it does not need the seat entity).
        if (exitAtHandle && vehicle != null && StevesArmyConfig.VEHICLE_HANDLES_ENABLED.get()
            && soldier.level() instanceof ServerLevel serverLevel) {
            AnalogWarfareCompat.exitAtNearestHandle(soldier);
        }
        if (vehicle != null) {
            // Send empty passenger list so the anchor no longer reports the soldier.
            syncTransportState(soldier, vehicle, false);
        }
        return vehicle != null;
    }

    /** Blocks FOLLOW auto-transport for a cooldown, e.g. right after a manual dismount. */
    public static void blockAutoTransport(SoldierEntity soldier) {
        int delay = StevesArmyConfig.VS2_DISMOUNT_REBOARD_DELAY.get();
        if (delay <= 0) {
            return;
        }
        getOrCreateState(soldier).reboardBlockTicks = delay;
    }

    /** The LoadedShip managing the given block position, or null. */
    @Nullable
    public static Object getShipAt(Level level, BlockPos pos) {
        initialize();
        if (!available) {
            return null;
        }
        try {
            return reflect(getShipObjectManagingPos, level, (Vec3i) pos);
        } catch (ReflectiveOperationException exception) {
            logReflectionFailure(exception);
            return null;
        }
    }

    /**
     * Ship for a free-standing shipyard-space entity (tallyho stations, seats).
     * VS2's getShipMountedTo only resolves for entities riding a vehicle; station
     * cameras aren't riding anything, so fall back to the position-based lookup
     * at the entity's (shipyard) block position.
     */
    @Nullable
    public static Object getShipUnder(@Nullable Entity entity) {
        if (entity == null) {
            return null;
        }
        Object mounted = getMountedShip(entity);
        if (mounted != null) {
            return mounted;
        }
        return getShipAt(entity.level(), entity.blockPosition());
    }

    /**
     * Ship carrying the given entity, for occupancy checks. Seated riders and
     * shipyard-space entities resolve through {@link #getShipUnder}; a world-space
     * entity standing aboard (crew on an open deck) resolves through the
     * ships-intersecting query, accepting only a ship whose real voxel hull overlaps
     * the entity — ground beside the hull does not count.
     */
    @Nullable
    public static Object resolveShipUnderEntity(Entity entity) {
        Object ship = getShipUnder(entity);
        if (ship != null || !isEnabled()
            || !(entity.level() instanceof ServerLevel serverLevel)) {
            return ship;
        }
        try {
            Object ships = reflect(getShipsIntersecting, entity.level(), entity.getBoundingBox());
            if (ships instanceof Iterable<?> iterable) {
                for (Object candidate : iterable) {
                    if (candidate != null
                        && shipOverlapsHull(serverLevel, candidate, entity.getBoundingBox(), true)) {
                        return candidate;
                    }
                }
            }
        } catch (ReflectiveOperationException exception) {
            logReflectionFailure(exception);
        }
        return null;
    }

    /**
     * Ship the vehicle-wheel MOUNT order targets when the crosshair is not on a vehicle:
     * the ship the player is mounted to, else the nearest ship within 64 blocks.
     */
    @Nullable
    public static Object resolveMountShipNearPlayer(ServerLevel level, ServerPlayer player) {
        initialize();
        if (!available) {
            return null;
        }
        try {
            Object mounted = reflect(getShipMountedTo, player);
            if (mounted != null) {
                return mounted;
            }
            for (double radius : new double[] {8.0, 16.0, 32.0, 64.0}) {
                Object ship = firstShipIntersecting(level, player.position(), radius);
                if (ship != null) {
                    return ship;
                }
            }
            return null;
        } catch (ReflectiveOperationException exception) {
            logReflectionFailure(exception);
            return null;
        }
    }

    @Nullable
    private static Object firstShipIntersecting(Level level, Vec3 center, double radius) {
        try {
            Object ships = reflect(getShipsIntersecting, level, new AABB(center, center).inflate(radius));
            if (ships instanceof Iterable<?> iterable) {
                for (Object ship : iterable) {
                    return ship;
                }
            }
        } catch (ReflectiveOperationException exception) {
            logReflectionFailure(exception);
        }
        return null;
    }

    /** Volume cap for the full-ship seat scan so huge hulls cannot stall the server thread. */
    private static final long MAX_STATIC_SCAN_VOLUME = 500_000L;

    /** Seat/occupancy counts from the most recent static seat scan (server thread only). */
    private static volatile String lastStaticScanSummary = "never-run";

    /** Summary of the most recent {@link #findFreeStaticSeats} call, for failure messages. */
    public static String getLastStaticScanSummary() {
        return lastStaticScanSummary;
    }

    /**
     * Unoccupied Create SeatBlocks belonging to the given ship, found by scanning the
     * ship's WHOLE voxel AABB in shipyard space (free seats can sit anywhere on a large
     * ship; a box around the clicked anchor misses them). Falls back to a box around
     * the converted anchor when VS2 exposes no voxel AABB. Columns in unloaded shipyard
     * chunks are skipped so the scan never forces chunk loads. Every click also logs a
     * per-ship block census and a block-type histogram of the target ship's blocks, so
     * a scan that finds no seats still identifies what the ship is built from.
     */
    public static List<BlockPos> findFreeStaticSeats(Level level, Object ship, Vec3 worldCenter, int maxSeats) {
        List<BlockPos> seats = new ArrayList<>();
        initialize();
        if (!available || ship == null || maxSeats <= 0 || !(level instanceof ServerLevel serverLevel)) {
            return seats;
        }
        try {
            long shipId = ((Number) getShipId.invoke(ship)).longValue();
            Vec3 shipLocalCenter = worldToShipLocal(ship, worldCenter);
            BlockPos anchor = BlockPos.containing(shipLocalCenter != null ? shipLocalCenter : worldCenter);

            BlockPos aabbMin = getShipyardMin(ship);
            BlockPos aabbMax = getShipyardMax(ship);
            BlockPos scanMin;
            BlockPos scanMax;
            String regionSource;
            if (aabbMin != null && aabbMax != null) {
                scanMin = aabbMin;
                scanMax = aabbMax;
                regionSource = "voxel-aabb";
            } else {
                scanMin = anchor.offset(-16, -8, -16);
                scanMax = anchor.offset(16, 8, 16);
                regionSource = "anchor-box(no-aabb)";
            }
            // Bound the work for huge hulls: clip to anchor ±48/±24 so the scan stays
            // near where the player is aiming even on ship-sized regions.
            long volume = (long) (scanMax.getX() - scanMin.getX() + 1)
                * (scanMax.getY() - scanMin.getY() + 1) * (scanMax.getZ() - scanMin.getZ() + 1);
            if (volume > MAX_STATIC_SCAN_VOLUME) {
                scanMin = new BlockPos(
                    Math.max(scanMin.getX(), anchor.getX() - 48),
                    Math.max(scanMin.getY(), anchor.getY() - 24),
                    Math.max(scanMin.getZ(), anchor.getZ() - 48));
                scanMax = new BlockPos(
                    Math.min(scanMax.getX(), anchor.getX() + 48),
                    Math.min(scanMax.getY(), anchor.getY() + 24),
                    Math.min(scanMax.getZ(), anchor.getZ() + 48));
                regionSource += "+clipped";
            }

            StevesArmyMod.LOGGER.info("[Crew] static seat scan: shipId={} anchorWorld={} anchorShipSpace={} region={} {}..{}",
                shipId, formatVec3(worldCenter), anchor, regionSource, scanMin, scanMax);

            // Ship attribution is chunk-granular in VS2, so resolve it once per chunk.
            Map<Long, Long> chunkShipIds = new HashMap<>();
            Map<Long, Integer> perShipBlocks = new HashMap<>();
            Map<String, Integer> shipBlockTypes = new HashMap<>();
            int seatBlocks = 0;
            int occupiedSeats = 0;
            int unloadedColumns = 0;
            int scannedBlocks = 0;

            for (int x = scanMin.getX(); x <= scanMax.getX(); x++) {
                for (int z = scanMin.getZ(); z <= scanMax.getZ(); z++) {
                    if (!isChunkLoaded(serverLevel, new BlockPos(x, scanMin.getY(), z))) {
                        unloadedColumns++;
                        continue;
                    }
                    for (int y = scanMin.getY(); y <= scanMax.getY(); y++) {
                        BlockPos candidate = new BlockPos(x, y, z);
                        BlockState blockState = level.getBlockState(candidate);
                        if (blockState.isAir()) {
                            continue;
                        }
                        scannedBlocks++;
                        Long chunkKey = ChunkPos.asLong(x >> 4, z >> 4);
                        Long cachedShipId = chunkShipIds.get(chunkKey);
                        if (cachedShipId == null) {
                            cachedShipId = resolveManagingShipId(level, x, scanMin.getY(), z);
                            chunkShipIds.put(chunkKey, cachedShipId);
                        }
                        long managingShipId = cachedShipId;
                        perShipBlocks.merge(managingShipId, 1, Integer::sum);
                        if (managingShipId != shipId) {
                            continue;
                        }
                        shipBlockTypes.merge(registryName(blockState), 1, Integer::sum);
                        if (!createSeatBlockClass.isInstance(blockState.getBlock())) {
                            continue;
                        }
                        seatBlocks++;
                        if (isCreateSeatOccupied(serverLevel, candidate)) {
                            occupiedSeats++;
                            continue;
                        }
                        seats.add(candidate);
                    }
                }
            }
            seats.sort(Comparator.comparingDouble(pos -> pos.distSqr(anchor)));

            int shipBlockTotal = 0;
            List<Map.Entry<String, Integer>> types = new ArrayList<>(shipBlockTypes.entrySet());
            types.sort(Map.Entry.<String, Integer>comparingByValue().reversed());
            List<String> topBlocks = new ArrayList<>();
            List<String> seatSuspects = new ArrayList<>();
            for (Map.Entry<String, Integer> type : types) {
                shipBlockTotal += type.getValue();
                if (topBlocks.size() < 8) {
                    topBlocks.add(type.getKey() + " x" + type.getValue());
                }
                String name = type.getKey();
                if ((name.contains("seat") || name.contains("chair") || name.contains("bench"))
                    && !name.equals("create:seat")) {
                    seatSuspects.add(name + " x" + type.getValue());
                }
            }

            List<String> shipCounts = new ArrayList<>();
            List<Map.Entry<Long, Integer>> ships = new ArrayList<>(perShipBlocks.entrySet());
            ships.sort(Map.Entry.<Long, Integer>comparingByValue().reversed());
            for (Map.Entry<Long, Integer> entry : ships) {
                if (shipCounts.size() >= 4) {
                    break;
                }
                shipCounts.add((entry.getKey() == -1L ? "world" : entry.getKey()) + ":" + entry.getValue());
            }

            StevesArmyMod.LOGGER.info(
                "[Crew] static seat scan result: shipId={} scannedBlocks={} unloadedColumns={} perShipBlocks=[{}] shipBlocks={} seatBlocks={} occupied={} free={} topBlocks=[{}] seatSuspects=[{}]",
                shipId, scannedBlocks, unloadedColumns, String.join(", ", shipCounts),
                shipBlockTotal, seatBlocks, occupiedSeats, seats.size(),
                String.join(", ", topBlocks), String.join(", ", seatSuspects));
            lastStaticScanSummary = "seatBlocks=" + seatBlocks + " occupied=" + occupiedSeats
                + " free=" + seats.size();
        } catch (ReflectiveOperationException exception) {
            logReflectionFailure(exception);
        }
        return seats;
    }

    /** Id of the ship managing the block at the given coords, or -1 (world/unmanaged). */
    private static long resolveManagingShipId(Level level, int x, int y, int z) {
        try {
            Object manager = reflect(getShipObjectManagingPos, level, new BlockPos(x, y, z));
            return manager == null ? -1L : ((Number) getShipId.invoke(manager)).longValue();
        } catch (ReflectiveOperationException exception) {
            return -1L;
        }
    }

    /** Compact "modid:path" name of the block held by the given state. */
    private static String registryName(BlockState state) {
        ResourceLocation key = ForgeRegistries.BLOCKS.getKey(state.getBlock());
        return key == null ? state.getBlock().toString() : key.toString();
    }

    /**
     * One-click inventory of every entity tied to the ship: entities VS2 reports as
     * mounted to it, plus any Create/tallyho seat entity whose raw (shipyard) position
     * falls inside the ship's voxel AABB. Identifies entity-based seats that a block
     * scan can never see.
     */
    public static void logShipEntityCensus(ServerLevel level, Object ship, Vec3 anchorWorld) {
        if (!available || ship == null) {
            return;
        }
        try {
            long shipId = ((Number) getShipId.invoke(ship)).longValue();
            BlockPos aabbMin = getShipyardMin(ship);
            BlockPos aabbMax = getShipyardMax(ship);
            List<String> details = new ArrayList<>();
            int matched = 0;
            for (Entity entity : level.getAllEntities()) {
                if (entity.isRemoved()) {
                    continue;
                }
                boolean mountedHere = false;
                Object mountedTo = reflect(getShipMountedTo, entity);
                if (mountedTo != null
                    && ((Number) getShipId.invoke(mountedTo)).longValue() == shipId) {
                    mountedHere = true;
                }
                boolean seatInAabb = false;
                if (!mountedHere && isCreateSeatEntity(entity) && aabbMin != null && aabbMax != null) {
                    BlockPos pos = entity.blockPosition();
                    seatInAabb = pos.getX() >= aabbMin.getX() - 2 && pos.getX() <= aabbMax.getX() + 2
                        && pos.getY() >= aabbMin.getY() - 2 && pos.getY() <= aabbMax.getY() + 2
                        && pos.getZ() >= aabbMin.getZ() - 2 && pos.getZ() <= aabbMax.getZ() + 2;
                }
                if (!mountedHere && !seatInAabb) {
                    continue;
                }
                matched++;
                if (details.size() < 10) {
                    List<String> riders = new ArrayList<>();
                    for (Entity passenger : entity.getPassengers()) {
                        riders.add(describeEntity(passenger));
                    }
                    details.add(describeEntity(entity)
                        + " pos=" + entity.blockPosition()
                        + " riders=[" + String.join(", ", riders) + "]"
                        + " vehicle=" + (entity.getVehicle() == null ? "none"
                            : describeEntity(entity.getVehicle())));
                }
            }
            StevesArmyMod.LOGGER.info("[Crew] ship entity census: shipId={} anchor={} matched={} details=[{}]",
                shipId, formatVec3(anchorWorld), matched, String.join(", ", details));
        } catch (ReflectiveOperationException exception) {
            logReflectionFailure(exception);
        }
    }

    /**
     * Short identity of an entity for the census: class, id, name, health when living,
     * and aliveness — enough to tell a seated crew member from a seat-riding-seat
     * stack or a stale tallyho seat.
     */
    private static String describeEntity(Entity entity) {
        StringBuilder description = new StringBuilder(entity.getClass().getSimpleName())
            .append('#').append(entity.getId());
        Component name = entity.getCustomName();
        description.append(" '").append(name == null ? entity.getName().getString() : name.getString()).append('\'');
        if (entity instanceof LivingEntity living) {
            description.append(" hp=").append(living.getHealth());
        }
        description.append(entity.isAlive() ? " alive" : " DEAD");
        return description.toString();
    }

    /**
     * Checks whether a single navigation node (block position) should be treated as
     * blocked because it intersects a VS2 ship. Uses the mob's collision footprint
     * for the AABB test.
     */
    public static boolean isNodeBlockedByShip(Level level, BlockPos node, Mob mob) {
        if (!isEnabled()) {
            return false;
        }
        double w = mob.getBbWidth() * 0.5 + 0.1;
        double h = mob.getBbHeight() * 0.5 + 0.1;
        AABB bounds = new AABB(node).inflate(w, h, w);
        return intersectsShipHull(level, bounds, false);
    }

    public static boolean shouldRejectNavigation(Level level, BlockPos position) {
        if (!isEnabled()) {
            return false;
        }
        AABB bounds = new AABB(position).inflate(0.35D, 0.1D, 0.35D);
        return intersectsShipHull(level, bounds, false);
    }

    public static boolean shouldRejectNavigation(Entity entity) {
        return isEnabled() && isOnShip(entity);
    }

    public static boolean isOnShip(Entity entity) {
        if (!isEnabled()) {
            return false;
        }
        try {
            return reflect(getShipMountedTo, entity) != null;
        } catch (ReflectiveOperationException exception) {
            logReflectionFailure(exception);
            return false;
        }
    }

    /**
     * One-shot diagnostic dump for crew mount failures: which ships VS thinks are at the
     * anchor (is the resolved ship the clicked one?), where the ship's voxel AABB sits in
     * ship space, the anchor's ship-space position with a shipToWorld round-trip check,
     * and whether the shipyard chunk there is loaded. Each field targets one candidate
     * root cause for "scan finds no seats".
     */
    public static void logCrewMountDiagnostics(ServerLevel level, @Nullable Object ship, Vec3 anchorWorld) {
        initialize();
        if (!available) {
            return;
        }
        try {
            StringBuilder shipsAtAnchor = new StringBuilder();
            Object ships = reflect(getShipsIntersecting, level, new AABB(anchorWorld, anchorWorld));
            if (ships instanceof Iterable<?> iterable) {
                for (Object s : iterable) {
                    shipsAtAnchor.append(getShipIdOf(s)).append(' ');
                }
            }
            Long shipId = getShipIdOf(ship);
            BlockPos voxelMin = ship == null ? null : getShipyardMin(ship);
            Vec3 converted = ship == null ? null : worldToShipLocal(ship, anchorWorld);
            String roundTrip = "n/a";
            if (converted != null) {
                Vec3 back = shipToWorldPosition(ship, converted);
                roundTrip = back == null ? "null" : String.format("%.2f", back.distanceTo(anchorWorld));
            }
            boolean chunkLoaded = converted == null || isChunkLoaded(level, BlockPos.containing(converted));
            StevesArmyMod.LOGGER.info(
                "[CrewDiag] anchor={} shipsAtAnchor=[{}] shipId={} voxelAABBmin={} anchorInShipSpace={} shipToWorldRoundTripErr={} originChunkLoaded={}",
                formatVec3(anchorWorld), shipsAtAnchor.toString().trim(), shipId, voxelMin,
                converted == null ? "null" : formatVec3(converted), roundTrip, chunkLoaded);
        } catch (Throwable t) {
            StevesArmyMod.LOGGER.warn("[CrewDiag] failed: {}", t.toString());
        }
    }

    /** True when the level chunk containing {@code pos} is currently loaded, best effort. */
    private static boolean isChunkLoaded(ServerLevel level, BlockPos pos) {
        try {
            Object chunkSource = level.getChunkSource();
            Method getChunkNow = chunkSource.getClass().getMethod("getChunkNow", int.class, int.class);
            return getChunkNow.invoke(chunkSource, pos.getX() >> 4, pos.getZ() >> 4) != null;
        } catch (ReflectiveOperationException ignored) {
            return true; // cannot tell — do not misreport
        }
    }

    /**
     * Seats a soldier on a free Create contraption seat of the given ship via the Create
     * Interactive ship mapping — Create's own seat bookkeeping (contraption-local seat
     * positions and its UUID→index occupancy map), so no shipyard block or coordinate
     * transform is involved. This is the path normal soldiers take on moving ships
     * (tryContraptionSeat). Returns the contraption vehicle when seated, or null.
     */
    @Nullable
    public static Entity seatSoldierOnShipContraption(ServerLevel level, long shipId, SoldierEntity soldier) {
        if (!isEnabled() || createInteractiveUtil == null) {
            return null;
        }
        try {
            Entity mappedVehicle = (Entity) getContraptionEntityForShip.invoke(createInteractiveUtil, shipId, false);
            if (mappedVehicle == null) {
                StevesArmyMod.LOGGER.info("[Crew] Create Interactive has no contraption for ship={}", shipId);
                return null;
            }
            StevesArmyMod.LOGGER.info("[Crew] Create Interactive mapped ship={} to contraption vehicle={}",
                shipId, mappedVehicle.getId());
            Object contraption = getContraption.invoke(mappedVehicle);
            if (contraption == null) {
                StevesArmyMod.LOGGER.info("[Crew] Contraption vehicle={} has no initialized contraption",
                    mappedVehicle.getId());
                return null;
            }
            @SuppressWarnings("unchecked")
            java.util.List<BlockPos> seats = (java.util.List<BlockPos>) getSeats.invoke(contraption);
            @SuppressWarnings("unchecked")
            java.util.Map<UUID, Integer> occupied = (java.util.Map<UUID, Integer>) getSeatMapping.invoke(contraption);
            StevesArmyMod.LOGGER.info("[Crew] Contraption vehicle={} seats={} occupied={}",
                mappedVehicle.getId(), seats.size(), occupied);
            for (int index = 0; index < seats.size(); index++) {
                if (occupied.containsValue(index)) {
                    continue;
                }
                authorizedMounts.put(soldier.getUUID(), mappedVehicle.getUUID());
                try {
                    addSittingPassenger.invoke(mappedVehicle, soldier, index);
                    if (soldier.isPassenger() && soldier.getVehicle() == mappedVehicle) {
                        SoldierState state = getOrCreateState(soldier);
                        state.transportAnchorId = mappedVehicle.getUUID();
                        state.transportOwnerId = null;
                        state.crewSeated = soldier.getRole() == SoldierRole.VEHICLE_CREW;
                        state.transportShipId = shipId;
                        state.transportSeatPosition = null;
                        state.seatRetryCooldownTicks = 0;
                        state.reboardBlockTicks = 0;
                        syncTransportState(soldier, mappedVehicle, true);
                        StevesArmyMod.LOGGER.info("[Crew] assigned soldier={} to contraption seat={} vehicle={}",
                            soldier.getId(), index, mappedVehicle.getId());
                        return mappedVehicle;
                    }
                    StevesArmyMod.LOGGER.warn("[Crew] contraption seat mount failed soldier={} seat={} vehicle={}",
                        soldier.getId(), index, mappedVehicle.getId());
                } finally {
                    authorizedMounts.remove(soldier.getUUID());
                }
            }
            StevesArmyMod.LOGGER.info("[Crew] no empty contraption seats for soldier={} vehicle={}",
                soldier.getId(), mappedVehicle.getId());
            return null;
        } catch (ReflectiveOperationException exception) {
            logReflectionFailure(exception);
            return null;
        }
    }

    /**
     * Returns the nearest block hit found by VS's ship-aware raycast. A vanilla
     * hit is harmless because VisibilityRay also checks vanilla blocks itself.
     */
    public static double getShipAwareBlockHitDistance(Level level, Vec3 from, Vec3 to,
                                                       @Nullable Entity source) {
        Vec3 hit = getShipAwareBlockHitLocation(level, from, to, source);
        return hit == null ? Double.POSITIVE_INFINITY : from.distanceTo(hit);
    }

    /**
     * Unclassified variant for callers that combine the result with their own
     * world block walk (VisibilityRay): skips the vanilla clip that rejects a
     * ship hit sitting behind a closer world block. The caller's min() against
     * its own obstruction makes the distinction immaterial, and the saved world
     * clip is the second-most expensive part of the legacy path.
     */
    public static double getShipAwareBlockHitDistance(Level level, Vec3 from, Vec3 to,
                                                       @Nullable Entity source,
                                                       boolean classifyAgainstWorld) {
        Vec3 hit = getShipAwareBlockHitLocation(level, from, to, source, classifyAgainstWorld);
        return hit == null ? Double.POSITIVE_INFINITY : from.distanceTo(hit);
    }

    /**
     * World-space location of the nearest ship-aware block hit along the ray, or null.
     * Used by the crew stick/egg to anchor on the ship the player is aiming at — the
     * soldier-flow way (ship + anchor position, never via a seat entity: empty Create
     * seats discard their entity, so ships hold SeatBlocks, not pickable entities).
     */
    @Nullable
    public static Vec3 getShipAwareBlockHitLocation(Level level, Vec3 from, Vec3 to,
                                                    @Nullable Entity source) {
        return getShipAwareBlockHitLocation(level, from, to, source, true);
    }

    /**
     * World-space location of the nearest ship-aware block hit along the ray, or null.
     * When {@code classifyAgainstWorld} is set, a hit only counts if no world block
     * lies in front of it (the legacy whole-ray contract); otherwise the caller
     * merges the result with its own world obstruction.
     */
    @Nullable
    public static Vec3 getShipAwareBlockHitLocation(Level level, Vec3 from, Vec3 to,
                                                    @Nullable Entity source,
                                                    boolean classifyAgainstWorld) {
        if (!isEnabled()) {
            return null;
        }
        // Fail closed on absurd endpoints: a clip mixing world and shipyard
        // coordinates would march through unloaded chunks with blocking loads
        // and freeze the server tick.
        if (Math.abs(from.x) > 1.0E6D || Math.abs(from.z) > 1.0E6D
            || Math.abs(to.x) > 1.0E6D || Math.abs(to.z) > 1.0E6D) {
            return null;
        }

        try {
            if (!StevesArmyConfig.VS2_SHIP_RAYCAST_GATE.get()) {
                return wholeRayShipHit(level, from, to, source);
            }

            // Gate: with no ship in the ray's bounding box the clip can only ever
            // reproduce the world result, which VisibilityRay already walks
            // block-by-block itself. Cover scoring traces hundreds of rays per
            // search, and on VS 2.3 every full clip also re-clips the whole world
            // plus every ship in the query box, so skipping it here is the bulk of
            // the saving.
            List<Object> ships = shipsIntersectingRay(level, from, to);
            if (ships.isEmpty()) {
                return null;
            }

            Vec3 best = null;
            double bestDistSqr = Double.MAX_VALUE;
            for (Object ship : ships) {
                AABB worldBox = shipWorldAABB(level, ship);
                if (worldBox == null) {
                    // No voxel AABB or transform helpers: fall back to the legacy
                    // whole-ray clip rather than guessing a span.
                    return wholeRayShipHit(level, from, to, source);
                }
                double[] span = segmentSpanInBox(from, to, worldBox);
                if (span == null) {
                    // The hull lives inside its AABB, so a segment missing the
                    // AABB cannot hit it — VS2's own per-ship check would skip it.
                    continue;
                }
                // Pad both ends so the sub-segment keeps margin around the AABB
                // pass-through and absorbs sub-block ship movement since the box
                // snapshot.
                double length = from.distanceTo(to);
                double padT = length > 1.0E-4D ? Math.min(SHIP_SPAN_PAD_BLOCKS / length, 0.5D) : 0.0D;
                Vec3 hit = shipHitOnSegment(level, from, to,
                    Math.max(0.0D, span[0] - padT), Math.min(1.0D, span[1] + padT), source);
                if (hit != null) {
                    double distSqr = from.distanceToSqr(hit);
                    if (distSqr < bestDistSqr) {
                        bestDistSqr = distSqr;
                        best = hit;
                    }
                }
            }
            if (best != null && classifyAgainstWorld && vanillaClip != null) {
                // VS 2.3 legacy contract: a world block level with or in front of
                // the ship hit means the obstruction is terrain, not hull. On the
                // VS 2.4 skipWorld path the clip is ship-only by construction and
                // the legacy code never classified it.
                BlockHitResult vanillaHit = (BlockHitResult) reflect(vanillaClip, level,
                    new ClipContext(from, best,
                        ClipContext.Block.COLLIDER, ClipContext.Fluid.NONE, source));
                if (vanillaHit.getType() == HitResult.Type.BLOCK
                    && vanillaHit.getLocation().distanceToSqr(from) <= bestDistSqr) {
                    return null;
                }
            }
            return best;
        } catch (ReflectiveOperationException | RuntimeException exception) {
            logReflectionFailure(exception);
            return null;
        }
    }

    /** Padding in blocks applied to each end of a ship-clipped sub-segment. */
    private static final double SHIP_SPAN_PAD_BLOCKS = 1.0D;
    /** Per-tick world-envelope cache: ships move slowly, rays are many. */
    private static final Map<Long, AABB> SHIP_WORLD_BOX_CACHE = new HashMap<>();
    private static long shipWorldBoxCacheTick = Long.MIN_VALUE;

    /** Ships returned by the level's ship index for the ray's bounding box. */
    private static List<Object> shipsIntersectingRay(Level level, Vec3 from, Vec3 to)
            throws ReflectiveOperationException {
        List<Object> ships = new ArrayList<>();
        Object result = reflect(getShipsIntersecting, level, new AABB(from, to));
        if (result instanceof Iterable<?> iterable) {
            for (Object ship : iterable) {
                ships.add(ship);
            }
        }
        return ships;
    }

    /**
     * World-space axis-aligned envelope of the ship's voxel hull: the shipyard
     * voxel box's eight corners transformed by shipToWorld. Conservative after
     * yaw (the envelope can exceed the hull), which is safe — a span test
     * against it only ever widens the clipped segment.
     */
    @Nullable
    private static AABB shipWorldAABB(Level level, Object ship) {
        Long shipId = getShipIdOf(ship);
        if (shipId == null) {
            return null;
        }
        long tick = level.getGameTime();
        synchronized (SHIP_WORLD_BOX_CACHE) {
            if (shipWorldBoxCacheTick != tick) {
                SHIP_WORLD_BOX_CACHE.clear();
                shipWorldBoxCacheTick = tick;
            }
            AABB cached = SHIP_WORLD_BOX_CACHE.get(shipId);
            if (cached != null) {
                return cached;
            }
        }
        BlockPos shipyardMin = getShipyardMin(ship);
        BlockPos shipyardMax = getShipyardMax(ship);
        if (shipyardMin == null || shipyardMax == null) {
            return null;
        }
        double minX = Double.POSITIVE_INFINITY;
        double minY = Double.POSITIVE_INFINITY;
        double minZ = Double.POSITIVE_INFINITY;
        double maxX = Double.NEGATIVE_INFINITY;
        double maxY = Double.NEGATIVE_INFINITY;
        double maxZ = Double.NEGATIVE_INFINITY;
        for (int cx = 0; cx <= 1; cx++) {
            for (int cy = 0; cy <= 1; cy++) {
                for (int cz = 0; cz <= 1; cz++) {
                    Vec3 corner = shipToWorldPosition(ship, new Vec3(
                        cx == 0 ? shipyardMin.getX() : shipyardMax.getX() + 1,
                        cy == 0 ? shipyardMin.getY() : shipyardMax.getY() + 1,
                        cz == 0 ? shipyardMin.getZ() : shipyardMax.getZ() + 1));
                    if (corner == null) {
                        return null;
                    }
                    minX = Math.min(minX, corner.x);
                    maxX = Math.max(maxX, corner.x);
                    minY = Math.min(minY, corner.y);
                    maxY = Math.max(maxY, corner.y);
                    minZ = Math.min(minZ, corner.z);
                    maxZ = Math.max(maxZ, corner.z);
                }
            }
        }
        AABB box = new AABB(minX, minY, minZ, maxX, maxY, maxZ);
        synchronized (SHIP_WORLD_BOX_CACHE) {
            if (SHIP_WORLD_BOX_CACHE.size() > 256) {
                SHIP_WORLD_BOX_CACHE.clear();
            }
            SHIP_WORLD_BOX_CACHE.put(shipId, box);
        }
        return box;
    }

    /**
     * Entry/exit parameters of the from..to segment through {@code box}, or null
     * when the segment misses it. Standard slab clip in segment space [0,1].
     */
    @Nullable
    private static double[] segmentSpanInBox(Vec3 from, Vec3 to, AABB box) {
        double[] span = {0.0D, 1.0D};
        if (!clipSpanAxis(from.x, to.x - from.x, box.minX, box.maxX, span)
            || !clipSpanAxis(from.y, to.y - from.y, box.minY, box.maxY, span)
            || !clipSpanAxis(from.z, to.z - from.z, box.minZ, box.maxZ, span)) {
            return null;
        }
        return span;
    }

    private static boolean clipSpanAxis(double origin, double delta, double min, double max,
                                        double[] span) {
        if (Math.abs(delta) < 1.0E-9D) {
            return origin >= min && origin <= max;
        }
        double inv = 1.0D / delta;
        double enter = (min - origin) * inv;
        double exit = (max - origin) * inv;
        if (enter > exit) {
            double swap = enter;
            enter = exit;
            exit = swap;
        }
        span[0] = Math.max(span[0], enter);
        span[1] = Math.min(span[1], exit);
        return span[0] <= span[1];
    }

    /**
     * Ship-only obstruction on the sub-segment from..to scaled to [t0,t1]. The
     * VS 2.4 path asks clipIncludeShips to skip the world entirely; on VS 2.3 the
     * combined clip also contains world blocks, so a hit only counts when it is
     * closer than a vanilla clip of the same sub-segment — the legacy whole-ray
     * classification, just over a much shorter walk. Any world block closer than
     * a ship hit is harmless anyway: VisibilityRay takes the minimum against its
     * own block walk.
     */
    @Nullable
    private static Vec3 shipHitOnSegment(Level level, Vec3 from, Vec3 to, double t0, double t1,
                                         @Nullable Entity source)
            throws ReflectiveOperationException {
        Vec3 start = lerp(from, to, t0);
        Vec3 end = lerp(from, to, t1);
        ClipContext context = new ClipContext(start, end,
            ClipContext.Block.COLLIDER, ClipContext.Fluid.NONE, source);
        BlockHitResult hit;
        if (clipIncludeShipsOnly != null) {
            hit = (BlockHitResult) reflect(clipIncludeShipsOnly, level, context, true, null, true);
        } else {
            hit = (BlockHitResult) reflect(clipIncludeShips, level, context);
            BlockHitResult vanillaHit = (BlockHitResult) reflect(vanillaClip, level, context);
            if (hit.getType() == HitResult.Type.BLOCK
                && vanillaHit.getType() == HitResult.Type.BLOCK
                && hit.getLocation().distanceToSqr(start)
                    >= vanillaHit.getLocation().distanceToSqr(start)) {
                return null;
            }
        }
        return hit.getType() == HitResult.Type.BLOCK ? hit.getLocation() : null;
    }

    /** Legacy whole-ray path: one combined clip plus a vanilla clip for classification. */
    @Nullable
    private static Vec3 wholeRayShipHit(Level level, Vec3 from, Vec3 to, @Nullable Entity source)
            throws ReflectiveOperationException {
        ClipContext context = new ClipContext(
            from,
            to,
            ClipContext.Block.COLLIDER,
            ClipContext.Fluid.NONE,
            source
        );
        BlockHitResult hit;
        if (clipIncludeShipsOnly != null) {
            hit = (BlockHitResult) reflect(clipIncludeShipsOnly, level, context, true, null, true);
        } else {
            hit = (BlockHitResult) reflect(clipIncludeShips, level, context);
            BlockHitResult vanillaHit = (BlockHitResult) reflect(vanillaClip, level, context);
            if (hit.getType() != HitResult.Type.BLOCK
                || (vanillaHit.getType() == HitResult.Type.BLOCK
                    && hit.getLocation().distanceToSqr(from)
                        >= vanillaHit.getLocation().distanceToSqr(from))) {
                return null;
            }
        }
        if (hit.getType() != HitResult.Type.BLOCK) {
            return null;
        }

        return hit.getLocation();
    }

    private static Vec3 lerp(Vec3 from, Vec3 to, double t) {
        return new Vec3(from.x + (to.x - from.x) * t,
                        from.y + (to.y - from.y) * t,
                        from.z + (to.z - from.z) * t);
    }

    private static void syncTransportState(SoldierEntity soldier, Entity anchor, boolean mounted) {
        if (!(soldier.level() instanceof ServerLevel serverLevel)) return;

        java.util.Set<ServerPlayer> recipients = new java.util.HashSet<>();

        // Use the soldier's world-space position for recipient selection.
        // The anchor is at shipyard coordinates, not world coordinates.
        Vec3 refPos = soldier.position();

        for (ServerPlayer player : serverLevel.getServer().getPlayerList().getPlayers()) {
            if (player.distanceToSqr(refPos) < 16384.0) {
                recipients.add(player);
            }
        }

        if (recipients.isEmpty()) return;

        if (mounted && anchor != null) {
            // Shipyard entities are not tracked by vanilla chunk-based tracking, so we must
            // explicitly send the add-entity packet before the passenger packet so the client
            // has the anchor entity registered.
            net.minecraft.network.protocol.Packet<?> spawnPacket = anchor.getAddEntityPacket();
            ClientboundSetPassengersPacket passengersPacket = new ClientboundSetPassengersPacket(anchor);
            for (ServerPlayer player : recipients) {
                player.connection.send(spawnPacket);
                player.connection.send(passengersPacket);
            }
            StevesArmyMod.LOGGER.info("[SyncTransport] Mounted: sent spawn+passengers for anchor={} soldier={} to {} players",
                anchor.getId(), soldier.getId(), recipients.size());
        } else if (anchor != null) {
            // Soldier has already been dismounted; anchor now has empty passenger list.
            ClientboundSetPassengersPacket passengersPacket = new ClientboundSetPassengersPacket(anchor);
            for (ServerPlayer player : recipients) {
                player.connection.send(passengersPacket);
            }
            StevesArmyMod.LOGGER.info("[SyncTransport] Unmounted: sent empty passengers for anchor={} soldier={}",
                anchor.getId(), soldier.getId());
        }
    }

    private static boolean isInsideShip(Entity entity) {
        return intersectsShipHull(entity.level(), entity.getBoundingBox(), true);
    }

    /**
     * True when {@code bounds} actually overlaps a ship's transformed voxel hull —
     * NOT the ship's world-space axis-aligned envelope. The envelope balloons when
     * a craft is yawed (45° turns wrap a hull several times its size in void), and
     * avoidance keyed on it made soldiers refuse to path anywhere near a rotated
     * ship, or stranded them after a dismount (their own node read as "blocked").
     * The envelope query survives only as the cheap pre-filter; every candidate
     * ship is then checked in ship space with the same geometric pattern
     * {@link #resolveShipAtWorldAnchor} uses for multi-ship picks.
     *
     * @param includeNeighbourBlocks when true, a point in a block adjacent to a hull
     *        block also counts as inside — the conservative read used by extraction,
     *        which must notice soldiers standing ON the deck (their feet block is
     *        air, the deck below is hull). Pathfinding passes false: counting
     *        neighbours blocks every node within ~1 block of the hull and strands
     *        soldiers standing right next to it (no path can start from a blocked
     *        node), and the callers' own box inflation already provides clearance.
     */
    public static boolean intersectsShipHull(Level level, AABB bounds, boolean includeNeighbourBlocks) {
        if (!isEnabled()) {
            return false;
        }
        Object ships;
        try {
            ships = reflect(getShipsIntersecting, level, bounds);
        } catch (ReflectiveOperationException exception) {
            logReflectionFailure(exception);
            return false;
        }
        if (!(ships instanceof Iterable<?> iterable)) {
            return false;
        }
        ServerLevel serverLevel = level instanceof ServerLevel server ? server : null;
        for (Object ship : iterable) {
            if (ship == null) {
                continue;
            }
            if (shipOverlapsHull(serverLevel, ship, bounds, includeNeighbourBlocks)) {
                return true;
            }
        }
        return false;
    }

    /** Center + 8 corners: small caller-inflated boxes are fully covered by these. */
    private static boolean shipOverlapsHull(@Nullable ServerLevel level, Object ship, AABB bounds,
                                            boolean includeNeighbourBlocks) {
        if (sampleInShipHull(level, ship, bounds.getCenter(), includeNeighbourBlocks)) {
            return true;
        }
        double[] xs = {bounds.minX, bounds.maxX};
        double[] ys = {bounds.minY, bounds.maxY};
        double[] zs = {bounds.minZ, bounds.maxZ};
        for (double x : xs) {
            for (double y : ys) {
                for (double z : zs) {
                    if (sampleInShipHull(level, ship, new Vec3(x, y, z), includeNeighbourBlocks)) {
                        return true;
                    }
                }
            }
        }
        return false;
    }

    /**
     * One hull test: the point is "inside the ship" when its ship-local position
     * lies within the ship's voxel AABB and the shipyard block there is solid
     * (optionally counting face neighbours). Unloaded chunks and unavailable
     * transforms/AABBs fail closed — avoidance must never open a hole into
     * unloaded shipyard space.
     */
    private static boolean sampleInShipHull(@Nullable ServerLevel level, Object ship, Vec3 worldPoint,
                                            boolean includeNeighbourBlocks) {
        Vec3 local = worldToShipLocal(ship, worldPoint);
        BlockPos aabbMin = local == null ? null : getShipyardMin(ship);
        BlockPos aabbMax = local == null ? null : getShipyardMax(ship);
        if (local == null || aabbMin == null || aabbMax == null) {
            return true;
        }
        BlockPos converted = BlockPos.containing(local.x, local.y, local.z);
        boolean contained = converted.getX() >= aabbMin.getX() - 1 && converted.getX() <= aabbMax.getX() + 1
            && converted.getY() >= aabbMin.getY() - 1 && converted.getY() <= aabbMax.getY() + 1
            && converted.getZ() >= aabbMin.getZ() - 1 && converted.getZ() <= aabbMax.getZ() + 1;
        if (!contained) {
            return false;
        }
        if (level == null) {
            // No block access: treat the whole voxel box as hull (conservative).
            return true;
        }
        if (!isChunkLoaded(level, converted)) {
            return true;
        }
        if (!level.getBlockState(converted).isAir()) {
            return true;
        }
        if (!includeNeighbourBlocks) {
            return false;
        }
        for (Direction direction : Direction.values()) {
            if (!level.getBlockState(converted.relative(direction)).isAir()) {
                return true;
            }
        }
        return false;
    }

    private static boolean isBeingDraggedByShip(Entity entity) {
        try {
            Method getter = entity.getClass().getMethod("getDraggingInformation");
            Object draggingInfo = getter.invoke(entity);
            return draggingInfo != null && (boolean) draggingInfo.getClass()
                .getMethod("isEntityBeingDraggedByAShip").invoke(draggingInfo);
        } catch (ReflectiveOperationException ignored) {
            return false;
        }
    }

    private static void rememberSafeWorldPosition(SoldierEntity soldier, SoldierState state) {
        if (soldier.onGround() && isSafeWorldPosition(soldier, soldier.blockPosition())) {
            state.lastSafeWorldPosition = soldier.blockPosition();
        }
    }

    private static boolean tryStartTransport(SoldierEntity soldier, SoldierState state) {
        if (!StevesArmyConfig.VS2_AUTO_TRANSPORT.get() || soldier.getSquadMode() != SquadMode.FOLLOW) {
            return false;
        }
        // Vehicle crew board ships only through the explicit crew paths (egg on seat,
        // crew assign stick, wheel mount-crew, API). Auto-transport would make them
        // owner-linked passengers that get released the moment the player leaves.
        if (soldier.getRole() == SoldierRole.VEHICLE_CREW) {
            return false;
        }
        // A recent manual dismount suppresses automatic re-boarding for a short while.
        if (state.reboardBlockTicks > 0) {
            return false;
        }
        LivingEntity owner = soldier.getOwner();
        if (owner == null || !owner.isAlive() || owner.getVehicle() == null || !isOnShip(owner)) {
            state.seatRetryCooldownTicks = 0;
            return false;
        }
        if (state.seatRetryCooldownTicks > 0) {
            state.seatRetryCooldownTicks--;
            return false;
        }
        logSeatAttempt(soldier, state, owner);
        if (countTransportedFor(owner.getUUID()) >= StevesArmyConfig.VS2_MAX_TRANSPORTED_SOLDIERS.get()) {
            StevesArmyMod.LOGGER.info("[VS2] Seat attempt skipped: transport limit reached for owner={}", owner.getId());
            return false;
        }

        if (tryContraptionSeat(soldier, owner, state) || tryStaticSeat(soldier, owner, state)) {
            stopMovement(soldier);
            return true;
        }
        return false;
    }

    private static boolean tryContraptionSeat(SoldierEntity soldier, LivingEntity owner, SoldierState state) {
        try {
            Object ship = reflect(getShipMountedTo, owner);
            if (ship != null && createInteractiveUtil != null) {
                long shipId = ((Number) getShipId.invoke(ship)).longValue();
                Entity mappedVehicle = (Entity) getContraptionEntityForShip.invoke(createInteractiveUtil, shipId, false);
                if (mappedVehicle != null) {
                    StevesArmyMod.LOGGER.info("[VS2] Create Interactive mapped ship={} to contraption vehicle={}",
                        shipId, mappedVehicle.getId());
                    if (tryAssignContraptionSeat(soldier, owner, state, mappedVehicle)) {
                        return true;
                    }
                } else {
                    StevesArmyMod.LOGGER.info("[VS2] Create Interactive has no contraption for ship={}", shipId);
                }
            }
        } catch (ReflectiveOperationException exception) {
            logReflectionFailure(exception);
        }

        Entity vehicle = owner.getVehicle();
        while (vehicle != null) {
            if (contraptionEntityClass.isInstance(vehicle)) {
                try {
                    Object contraption = getContraption.invoke(vehicle);
                    if (contraption == null) {
                        StevesArmyMod.LOGGER.info("[VS2] Contraption vehicle={} has no initialized contraption", vehicle.getId());
                        return false;
                    }
                    @SuppressWarnings("unchecked")
                    java.util.List<BlockPos> seats = (java.util.List<BlockPos>) getSeats.invoke(contraption);
                    @SuppressWarnings("unchecked")
                    Map<UUID, Integer> occupied = (Map<UUID, Integer>) getSeatMapping.invoke(contraption);
                    StevesArmyMod.LOGGER.info("[VS2] Contraption vehicle={} seats={} occupied={}",
                        vehicle.getId(), seats.size(), occupied);
                    for (int index = 0; index < seats.size(); index++) {
                        if (occupied.containsValue(index)) {
                            continue;
                        }
                        authorizedMounts.put(soldier.getUUID(), vehicle.getUUID());
                        try {
                            StevesArmyMod.LOGGER.info("[VS2] Trying contraption seat={} soldier={} vehicle={}",
                                index, soldier.getId(), vehicle.getId());
                            addSittingPassenger.invoke(vehicle, soldier, index);
                            if (soldier.isPassenger() && soldier.getVehicle() == vehicle) {
                                state.transportAnchorId = vehicle.getUUID();
                                state.transportOwnerId = owner.getUUID();
                                state.crewSeated = soldier.getRole() == SoldierRole.VEHICLE_CREW;
                                state.transportShipId = getShipId.invoke(reflect(getShipMountedTo, owner)) instanceof Number id
                                    ? id.longValue() : null;
                                state.seatRetryCooldownTicks = 0;
                                state.reboardBlockTicks = 0;

                                syncTransportState(soldier, vehicle, true);

                                StevesArmyMod.LOGGER.info("[VS2] Assigned soldier={} to Create contraption seat={} vehicle={}",
                                    soldier.getId(), index, vehicle.getId());
                                return true;
                            }
                            StevesArmyMod.LOGGER.warn("[VS2] Create seat mount failed soldier={} seat={} vehicle={} passenger={} actualVehicle={}",
                                soldier.getId(), index, vehicle.getId(), soldier.isPassenger(),
                                soldier.getVehicle() == null ? "none" : soldier.getVehicle().getId());
                        } finally {
                            authorizedMounts.remove(soldier.getUUID());
                        }
                    }
                    StevesArmyMod.LOGGER.info("[VS2] No empty contraption seats for soldier={} vehicle={}",
                        soldier.getId(), vehicle.getId());
                    return false;
                } catch (ReflectiveOperationException exception) {
                    logReflectionFailure(exception);
                    return false;
                }
            }
            StevesArmyMod.LOGGER.info("[VS2] Seat chain vehicle={} class={}",
                vehicle.getId(), vehicle.getClass().getName());
            vehicle = vehicle.getVehicle();
        }
        StevesArmyMod.LOGGER.info("[VS2] No AbstractContraptionEntity found in owner vehicle chain owner={}", owner.getId());
        return false;
    }

    private static boolean tryAssignContraptionSeat(SoldierEntity soldier, LivingEntity owner,
        SoldierState state, Entity vehicle) {
        try {
            Object contraption = getContraption.invoke(vehicle);
            if (contraption == null) {
                return false;
            }
            @SuppressWarnings("unchecked")
            java.util.List<BlockPos> seats = (java.util.List<BlockPos>) getSeats.invoke(contraption);
            @SuppressWarnings("unchecked")
            Map<UUID, Integer> occupied = (Map<UUID, Integer>) getSeatMapping.invoke(contraption);
            StevesArmyMod.LOGGER.info("[VS2] Contraption vehicle={} seats={} occupied={}",
                vehicle.getId(), seats.size(), occupied);
            for (int index = 0; index < seats.size(); index++) {
                if (occupied.containsValue(index)) {
                    continue;
                }
                authorizedMounts.put(soldier.getUUID(), vehicle.getUUID());
                try {
                    StevesArmyMod.LOGGER.info("[VS2] Trying contraption seat={} soldier={} vehicle={}",
                        index, soldier.getId(), vehicle.getId());
                    addSittingPassenger.invoke(vehicle, soldier, index);
                    if (soldier.isPassenger() && soldier.getVehicle() == vehicle) {
                        state.transportAnchorId = vehicle.getUUID();
                        state.transportOwnerId = owner.getUUID();
                        state.transportShipId = getShipId.invoke(reflect(getShipMountedTo, owner)) instanceof Number id
                            ? id.longValue() : null;
                        state.seatRetryCooldownTicks = 0;

                        syncTransportState(soldier, vehicle, true);

                        StevesArmyMod.LOGGER.info("[VS2] Assigned soldier={} to Create contraption seat={} vehicle={}",
                            soldier.getId(), index, vehicle.getId());
                        return true;
                    }
                    StevesArmyMod.LOGGER.warn("[VS2] Create seat mount failed soldier={} seat={} vehicle={} passenger={} actualVehicle={}",
                        soldier.getId(), index, vehicle.getId(), soldier.isPassenger(),
                        soldier.getVehicle() == null ? "none" : soldier.getVehicle().getId());
                } finally {
                    authorizedMounts.remove(soldier.getUUID());
                }
            }
        } catch (ReflectiveOperationException exception) {
            logReflectionFailure(exception);
        }
        return false;
    }

    private static boolean tryStaticSeat(SoldierEntity soldier, LivingEntity owner, SoldierState state) {
        // Crew soldiers board shipyard seats exactly like riflemen; once seated,
        // crewSeated keeps their crew AI ticking so they still man their station.
        try {
            Object ownerShip = reflect(getShipMountedTo, owner);
            if (ownerShip == null) {
                StevesArmyMod.LOGGER.info("[VS2] Static seat fallback: owner={} has no mounted ship", owner.getId());
                return false;
            }
            long ownerShipId = ((Number) getShipId.invoke(ownerShip)).longValue();
            Object mountedData = reflect(getShipMountedToData, owner, (Object) null);
            Object mountPosition = mountedData == null ? null : getMountPosInShip.invoke(mountedData);
            if (!(mountPosition instanceof org.joml.Vector3dc localPosition)) {
                StevesArmyMod.LOGGER.info("[VS2] Static seat fallback has no ship-local owner position owner={}", owner.getId());
                return false;
            }
            BlockPos origin = BlockPos.containing(localPosition.x(), localPosition.y(), localPosition.z());
            StevesArmyMod.LOGGER.info("[VS2] Static seat scan owner={} shipOrigin={} worldVehiclePos={}",
                owner.getId(), origin, owner.getVehicle().position());
            int seatBlocks = 0;
            int rejectedShip = 0;
            int occupiedSeats = 0;
            for (int radius = 0; radius <= 10; radius++) {
                for (int x = -radius; x <= radius; x++) {
                    for (int z = -radius; z <= radius; z++) {
                        if (Math.max(Math.abs(x), Math.abs(z)) != radius) {
                            continue;
                        }
                        for (int y = -2; y <= 2; y++) {
                            BlockPos candidate = origin.offset(x, y, z);
                            BlockState blockState = owner.level().getBlockState(candidate);
                            if (!createSeatBlockClass.isInstance(blockState.getBlock())) {
                                continue;
                            }
                            seatBlocks++;
                            Object seatShip = reflect(getShipObjectManagingPos, owner.level(), candidate);
                            if (seatShip == null || ((Number) getShipId.invoke(seatShip)).longValue() != ownerShipId) {
                                rejectedShip++;
                                continue;
                            }
                            if (isCreateSeatOccupied(owner.level(), candidate)) {
                                occupiedSeats++;
                                continue;
                            }
                            StevesArmyMod.LOGGER.info("[VS2] Static seat candidate soldier={} pos={} shipId={}",
                                soldier.getId(), candidate, ownerShipId);
                            authorizedStaticSeats.put(soldier.getUUID(), candidate);
                            try {
                                // SeatBlock.sitDown creates the SeatEntity at the shipyard block position
                                // and mounts the soldier without requiring the soldier to be moved there first.
                                // VS2's own rider/rendering mixins handle the world-space transform.
                                createSeatSitDown.invoke(null, owner.level(), candidate, soldier);
                            } finally {
                                authorizedStaticSeats.remove(soldier.getUUID());
                            }
                            if (soldier.isPassenger() && soldier.getVehicle() != null) {
                                Entity vehicle = soldier.getVehicle();

                                // SeatEntity is at shipyard coordinates — VS2 handles world-space
                                // tracking and rider position transforms.
                                // Do NOT move the seat to world-space.

                                state.transportAnchorId = vehicle.getUUID();
                                state.transportOwnerId = owner.getUUID();
                                state.crewSeated = soldier.getRole() == SoldierRole.VEHICLE_CREW;
                                state.transportShipId = ownerShipId;
                                state.transportSeatPosition = candidate;
                                state.seatRetryCooldownTicks = 0;
                                state.reboardBlockTicks = 0;

                                syncTransportState(soldier, soldier.getVehicle(), true);

                                StevesArmyMod.LOGGER.info("[VS2] Static seat attached soldier={} seat={} vehicle={} soldierPos={} vehiclePos={}",
                                    soldier.getId(), candidate, soldier.getVehicle().getId(), soldier.position(),
                                    soldier.getVehicle().position());
                                if (owner.level() instanceof ServerLevel serverLevel) {
                                    recordHandleLink(serverLevel, ownerShip, soldier, candidate);
                                }
                                return true;
                            }
                            StevesArmyMod.LOGGER.warn("[VS2] Static seat mount did not persist soldier={} seat={} passenger={} vehicle={}",
                                soldier.getId(), candidate, soldier.isPassenger(),
                                soldier.getVehicle() == null ? "none" : soldier.getVehicle().getId());
                        }
                    }
                }
            }
            if (seatBlocks > 0 && occupiedSeats == seatBlocks) {
                state.seatRetryCooldownTicks = FULL_SEAT_RETRY_TICKS;
            }
            StevesArmyMod.LOGGER.info("[VS2] Static seat fallback found no usable seat soldier={} owner={} blocks={} shipRejected={} occupied={}",
                soldier.getId(), owner.getId(), seatBlocks, rejectedShip, occupiedSeats);
        } catch (ReflectiveOperationException exception) {
            logReflectionFailure(exception);
        }
        return false;
    }

    /**
     * Occupied only when a seat entity at {@code position} actually carries an alive
     * rider: Create's empty SeatEntities self-discard, but tallyho FlexibleSeatEntities
     * persist forever when empty, and a bare entity at the block coords must not block
     * a seat block. Seat entities riding each other (leftover from raw-mount tests)
     * count as unoccupied too — the census logs the rider stack so false negatives
     * stay diagnosable.
     */
    private static boolean isCreateSeatOccupied(Level level, BlockPos position) {
        if (!(level instanceof ServerLevel serverLevel)) {
            return false;
        }
        for (Entity seat : serverLevel.getAllEntities()) {
            if (!createSeatEntityClass.isInstance(seat) || !seat.blockPosition().equals(position)) {
                continue;
            }
            for (Entity passenger : seat.getPassengers()) {
                if (passenger != null && passenger.isAlive()) {
                    return true;
                }
            }
        }
        return false;
    }

    /**
     * True when {@code pos} holds a free Create SeatBlock on the given ship — the
     * precondition for {@link #seatSoldierDirect} to mount there (the same checks
     * {@link #findFreeStaticSeats} applies, for a single position).
     */
    public static boolean isValidStaticSeat(ServerLevel level, @Nullable Object ship, BlockPos pos) {
        initialize();
        if (!available || ship == null || createSeatBlockClass == null) {
            return false;
        }
        try {
            if (!createSeatBlockClass.isInstance(level.getBlockState(pos).getBlock())) {
                return false;
            }
            Long shipId = getShipIdOf(ship);
            if (shipId == null) {
                return false;
            }
            Object seatShip = reflect(getShipObjectManagingPos, level, (Vec3i) pos);
            Long seatShipId = seatShip == null ? null : getShipIdOf(seatShip);
            if (!shipId.equals(seatShipId)) {
                return false;
            }
            return !isCreateSeatOccupied(level, pos);
        } catch (ReflectiveOperationException exception) {
            logReflectionFailure(exception);
            return false;
        }
    }

    /**
     * Seated crew soldiers freeze (their goals never tick), so they can never run
     * the unmounted duty scan in VehicleCrewGoal. Throttled hook that hands the
     * soldier to StationGunnerAI.assignSeatedSoldier, which finds it a station on
     * the same ship and activates the station-side gun AI.
     */
    private static void tickSeatedCrewDuty(SoldierEntity soldier, SoldierState state) {
        if (!state.crewSeated) {
            return;
        }
        if (state.crewDutyScanCooldown > 0) {
            state.crewDutyScanCooldown--;
            return;
        }
        state.crewDutyScanCooldown = CREW_DUTY_SCAN_INTERVAL_TICKS;
        StationGunnerAI.assignSeatedSoldier(soldier, state.transportShipId);
    }

    /**
     * Keeps a transported soldier seated and returns true while its AI must stay
     * frozen (seated, held, or pinned during a reseat wait); false once released.
     */
    private static boolean updateTransport(SoldierEntity soldier, SoldierState state) {
        // Command-driven mounts (transportOwnerId == null) are kept regardless of owner state.
        if (state.transportOwnerId == null) {
            if (soldier.isPassenger() && state.transportAnchorId != null
                && state.transportAnchorId.equals(soldier.getVehicle().getUUID())) {
                soldier.getVehicle().positionRider(soldier);
                stopMovement(soldier);
                tickSeatedCrewDuty(soldier, state);
                return true;
            }
            // The seat entity did not survive the reload (Create SeatEntities discard
            // on their first tick when vanilla's passenger link has not resolved yet)
            // or was removed mid-session. Command-driven crew must stay aboard: re-seat
            // on the same ship instead of releasing - a release leaves the soldier
            // wherever the load-time ship transform left it (observed: the seat's
            // world y minus the ship's y-offset a second time, well into the void).
            return waitForReseat(soldier, state);
        }

        Entity anchor = getEntity(soldier, state.transportAnchorId);
        if (anchor == null || !soldier.isPassenger() || soldier.getVehicle() != anchor) {
            StevesArmyMod.LOGGER.info("[VS2] Releasing transport soldier={} anchor={} passenger={}",
                soldier.getId(), anchor == null ? "missing" : anchor.getId(), soldier.isPassenger());
            // Owner-linked infantry release back to the owner - but never from a
            // void position left by the load-time transform.
            if (!isSaneWorldPos(soldier.level(), soldier.position())) {
                Vec3 converted = convertShipyardPosition(soldier.level(), soldier.position(), state);
                if (converted != null && isSaneWorldPos(soldier.level(), converted)) {
                    pinToPosition(soldier, converted);
                }
            }
            releaseAndClear(soldier, state);
            return false;
        }

        // Keep the rider's stored position on its seat. Seats on VS objects live in
        // shipyard space, and a soldier whose stored position stays at its stale
        // world spot (where it stood when seated) makes every AI query straddle the
        // two spaces - VS2 rejects the mixed box and the physics thread starves.
        // Non-player entities are allowed to live at shipyard coords (VS2 only
        // intercepts setPosRaw for players). Mirrors the command-driven branch.
        anchor.positionRider(soldier);
        tickSeatedCrewDuty(soldier, state);

        // HOLD soldiers stay seated regardless of owner state.
        // FOLLOW soldiers release when the owner is no longer on the ship.
        if (soldier.getSquadMode() == SquadMode.HOLD) {
            stopMovement(soldier);
            return true;
        }

        // Vehicle crew seats are command-driven: they stay aboard regardless of where
        // the owner is, even if a legacy owner-linked state somehow exists.
        if (soldier.getRole() == SoldierRole.VEHICLE_CREW) {
            stopMovement(soldier);
            return true;
        }

        LivingEntity owner = getOwner(soldier, state.transportOwnerId);
        boolean ownerOnShip = owner != null && owner.isAlive() && isTransportOwnerOnShip(owner, state);
        if (ownerOnShip) {
            state.ownerOffShipCount = 0;
            stopMovement(soldier);
            return true;
        }

        // The owner-on-ship check flickers false for a couple of ticks while VS2
        // oscillates the rider's seat position between shipyard and world during its
        // physics pass. Releasing on the first false would drop the soldier off the
        // ship to the sea floor, so hold through short dips and only release once the
        // owner has been confirmed off-ship for a sustained window.
        state.ownerOffShipCount++;
        if (state.ownerOffShipCount < RELEASE_DEBOUNCE_TICKS) {
            stopMovement(soldier);
            return true;
        }

        StevesArmyMod.LOGGER.info("[VS2] Releasing transport soldier={} anchor={} passenger={} owner={} ownerOnShip={} offShipStreak={}",
            soldier.getId(), anchor.getId(), soldier.isPassenger(),
            owner == null ? "missing" : owner.getId(), ownerOnShip, state.ownerOffShipCount);
        releaseAndClear(soldier, state);
        return false;
    }

    /**
     * Holds a command-driven soldier whose seat vanished (reload race or removed
     * seat) at its seat's current world position while re-seating it on the same
     * ship. Returns true while waiting or re-seated; false once the soldier was
     * extracted and its AI may run again.
     */
    private static boolean waitForReseat(SoldierEntity soldier, SoldierState state) {
        // Plain-entity anchor (Superb Warfare mount: ship id and seat position are
        // both null). There is no ship to re-seat on, so a lost vanilla passenger
        // link — the vehicle was destroyed, or the rider was evicted — ends the
        // mount immediately instead of pinning the soldier for the wait timeout.
        if (state.transportShipId == null && state.transportSeatPosition == null) {
            StevesArmyMod.LOGGER.info("[VS2] Vehicle anchor lost soldier={} vehicle={} - releasing",
                soldier.getId(), state.transportAnchorId);
            releaseAndClear(soldier, state);
            return false;
        }
        boolean firstDetection = state.reseatWaitTicks == 0;
        state.reseatWaitTicks++;
        Level level = soldier.level();
        Vec3 pinTarget = state.transportSeatPosition != null && level instanceof ServerLevel serverLevel
            ? staticSeatWorldPos(serverLevel, state.transportSeatPosition) : null;

        // Re-pin every tick: a reload can leave the position double-transformed
        // (ship y-offset applied twice - observed y=-246 over a void world with the
        // floor at -60), and only the seat's live world position is trustworthy.
        if (pinTarget != null && soldier.position().distanceTo(pinTarget) > RESEAT_PIN_EPSILON) {
            if (firstDetection) {
                StevesArmyMod.LOGGER.info("[VS2] Transport seat lost soldier={} passenger={} expectedAnchor={} shipId={} seatPos={} - reseat wait, pin {} -> {}",
                    soldier.getId(), soldier.isPassenger(), state.transportAnchorId, state.transportShipId,
                    state.transportSeatPosition, formatVec3(soldier.position()), formatVec3(pinTarget));
                clearShipDraggingState(soldier);
            }
            pinToPosition(soldier, pinTarget);
        } else if (firstDetection) {
            StevesArmyMod.LOGGER.info("[VS2] Transport seat lost soldier={} passenger={} expectedAnchor={} shipId={} seatPos={} - reseat wait, pinTarget={}",
                soldier.getId(), soldier.isPassenger(), state.transportAnchorId, state.transportShipId,
                state.transportSeatPosition, pinTarget == null ? "none" : formatVec3(pinTarget));
            clearShipDraggingState(soldier);
        }

        // No seat to pin to and the current position is already lethal (below the
        // world floor): do not leave the soldier falling for the whole wait window.
        if (pinTarget == null && !isSaneWorldPos(level, soldier.position())) {
            StevesArmyMod.LOGGER.warn("[VS2] Reseat wait has no pin target and soldier={} is at an unsafe position - extracting",
                soldier.getId());
            extractFromReseatWait(soldier, state, pinTarget);
            return false;
        }

        if (state.reseatWaitTicks > RESEAT_WAIT_TIMEOUT_TICKS) {
            StevesArmyMod.LOGGER.warn("[VS2] Reseat wait timed out soldier={} shipId={} - extracting at {}",
                soldier.getId(), state.transportShipId, formatVec3(soldier.position()));
            extractFromReseatWait(soldier, state, pinTarget);
            return false;
        }

        if (state.reseatWaitTicks % RESEAT_RETRY_INTERVAL_TICKS == 0) {
            tryReseat(soldier, state, pinTarget);
        }
        stopMovement(soldier);
        return true;
    }

    /** Gives up the reseat wait: land the soldier on a sane position, then clear the transport state. */
    private static void extractFromReseatWait(SoldierEntity soldier, SoldierState state, @Nullable Vec3 pinTarget) {
        clearShipDraggingState(soldier);
        Vec3 converted = pinTarget != null ? pinTarget
            : convertShipyardPosition(soldier.level(), soldier.position(), state);
        if (converted != null && isSaneWorldPos(soldier.level(), converted)) {
            pinToPosition(soldier, converted);
        } else {
            extractToSafeWorldPosition(soldier, state);
        }
        clearTransportState(state);
    }

    /** One re-seat attempt: the original seat block, any free static seat, then a contraption seat. */
    private static boolean tryReseat(SoldierEntity soldier, SoldierState state, @Nullable Vec3 anchorWorld) {
        if (!(soldier.level() instanceof ServerLevel serverLevel) || state.transportShipId == null) {
            return false;
        }
        if (state.transportSeatPosition != null && isChunkLoaded(serverLevel, state.transportSeatPosition)
            && seatSoldierDirect(soldier, serverLevel, state.transportSeatPosition)) {
            logReseat(soldier, state, state.transportSeatPosition);
            return true;
        }
        Object ship = state.transportSeatPosition != null
            ? shipAtShipyardPos(serverLevel, state.transportSeatPosition) : null;
        if (ship != null && anchorWorld != null) {
            for (BlockPos seat : findFreeStaticSeats(serverLevel, ship, anchorWorld, 1)) {
                if (seatSoldierDirect(soldier, serverLevel, seat)) {
                    logReseat(soldier, state, seat);
                    return true;
                }
            }
        }
        // Contraption/handle mounts have no seat-block position to fall back to.
        if (state.transportSeatPosition == null
            && seatSoldierOnShipContraption(serverLevel, state.transportShipId, soldier) != null) {
            logReseat(soldier, state, null);
            return true;
        }
        return false;
    }

    private static void logReseat(SoldierEntity soldier, SoldierState state, @Nullable BlockPos seat) {
        StevesArmyMod.LOGGER.info("[VS2] Re-seated reloaded soldier={} seat={} after {} ticks",
            soldier.getId(), seat, state.reseatWaitTicks);
        state.reseatWaitTicks = 0;
    }

    /** Teleports the soldier to a world position and kills its momentum. */
    private static void pinToPosition(SoldierEntity soldier, Vec3 position) {
        soldier.moveTo(position.x, position.y, position.z, soldier.getYRot(), soldier.getXRot());
        soldier.setDeltaMovement(Vec3.ZERO);
    }

    @Nullable
    private static Object shipAtShipyardPos(ServerLevel level, BlockPos shipyardPos) {
        try {
            return reflect(getShipObjectManagingPos, level, (Vec3i) shipyardPos);
        } catch (ReflectiveOperationException exception) {
            logReflectionFailure(exception);
            return null;
        }
    }

    private static void releaseAndClear(SoldierEntity soldier, SoldierState state) {
        Vec3 preDismountPos = soldier.position();
        Entity vehicle = soldier.isPassenger() ? soldier.getVehicle() : null;
        clearShipDraggingState(soldier);
        if (soldier.isPassenger()) {
            soldier.stopRiding();
        }
        clearShipDraggingState(soldier);
        Vec3 postReleasePos = soldier.position();
        // Send empty passenger list after dismount so the anchor now reports no passengers.
        if (vehicle != null) {
            syncTransportState(soldier, vehicle, false);
        }
        StevesArmyMod.LOGGER.info("[VS2] Transport release soldier={} prePos={} postPos={} dist={}",
            soldier.getId(), formatVec3(preDismountPos), formatVec3(postReleasePos),
            String.format("%.2f", preDismountPos.distanceTo(postReleasePos)));
        clearTransportState(state);
        // Automatic releases (owner left the ship, lost anchor) also exit at the
        // hatch: linked handle first, then the nearest handle on the ship.
        if (StevesArmyConfig.VEHICLE_HANDLES_ENABLED.get()) {
            AnalogWarfareCompat.exitAtNearestHandle(soldier);
        }
    }

    private static void clearTransportState(SoldierState state) {
        state.transportAnchorId = null;
        state.transportOwnerId = null;
        state.transportShipId = null;
        state.transportSeatPosition = null;
        state.crewSeated = false;
        state.reseatWaitTicks = 0;
    }

    private static boolean isTransported(SoldierEntity soldier, SoldierState state) {
        return state.transportAnchorId != null && soldier.isPassenger()
            && state.transportAnchorId.equals(soldier.getVehicle().getUUID());
    }

    private static boolean isTransportOwnerOnShip(LivingEntity owner, SoldierState state) {
        // Seated owner: the seat's position resolves to the transport ship.
        Entity vehicle = owner.getVehicle();
        while (vehicle != null) {
            if (createSeatEntityClass.isInstance(vehicle)) {
                try {
                    Vec3 seatWorldPos = vehicle.position();
                    Object ship = reflect(getShipObjectManagingPosDouble, owner.level(), seatWorldPos.x, seatWorldPos.y, seatWorldPos.z);
                    boolean found = ship != null && state.transportShipId != null
                        && ((Number) getShipId.invoke(ship)).longValue() == state.transportShipId;
                    // Throttle diagnostic logging to once per 100 ticks
                    if (found && owner.tickCount % 100 == 0) {
                        StevesArmyMod.LOGGER.info("[VS2] ownerOnShip owner={} seatPos={} shipFound={} expectedShipId={}",
                            owner.getId(), seatWorldPos, ship != null, state.transportShipId);
                    }
                    if (found) return true;
                } catch (ReflectiveOperationException exception) {
                    logReflectionFailure(exception);
                }
            }
            vehicle = vehicle.getVehicle();
        }
        // Walking owner: seat-chain checks can't see someone standing on the deck.
        // A world-space bounding-box intersect is the only reliable test then;
        // without it the transport releases soldiers the moment the owner stands up.
        if (state.transportShipId != null) {
            Object ship = firstShipIntersecting(owner.level(), owner.position(), 3.0D);
            return ship != null && state.transportShipId.equals(getShipIdOf(ship));
        }
        return false;
    }

    private static boolean isMountedToStaticCreateSeat(Entity entity) {
        Entity vehicle = entity.getVehicle();
        while (vehicle != null) {
            if (createSeatEntityClass.isInstance(vehicle)) {
                try {
                    Vec3 seatWorldPos = vehicle.position();
                    return reflect(getShipObjectManagingPosDouble, entity.level(), seatWorldPos.x, seatWorldPos.y, seatWorldPos.z) != null;
                } catch (ReflectiveOperationException exception) {
                    logReflectionFailure(exception);
                    return false;
                }
            }
            vehicle = vehicle.getVehicle();
        }
        return false;
    }

    private static int countTransportedFor(UUID ownerId) {
        int count = 0;
        for (SoldierState state : states.values()) {
            if (ownerId.equals(state.transportOwnerId) && state.transportAnchorId != null) {
                count++;
            }
        }
        return count;
    }

    private static void extractToSafeWorldPosition(SoldierEntity soldier, SoldierState state) {
        stopMovement(soldier);
        if (soldier.isPassenger()) {
            soldier.stopRiding();
        }
        BlockPos destination = findSafePositionOutsideShip(soldier);
        if (destination == null && state.lastSafeWorldPosition != null
            && isSafeWorldPosition(soldier, state.lastSafeWorldPosition)) {
            destination = state.lastSafeWorldPosition;
        }
        if (destination != null) {
            moveToWorldPosition(soldier, destination);
            state.lastSafeWorldPosition = destination;
        }
    }

    @Nullable
    private static BlockPos findSafePositionOutsideShip(SoldierEntity soldier) {
        BlockPos origin = soldier.blockPosition();
        for (int radius : ESCAPE_RADII) {
            for (int x = -radius; x <= radius; x++) {
                for (int z = -radius; z <= radius; z++) {
                    if (Math.max(Math.abs(x), Math.abs(z)) != radius) {
                        continue;
                    }
                    int worldX = origin.getX() + x;
                    int worldZ = origin.getZ() + z;
                    BlockPos surface = new BlockPos(worldX,
                        soldier.level().getHeight(Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, worldX, worldZ), worldZ);
                    if (isSafeWorldPosition(soldier, surface)) {
                        return surface;
                    }
                    for (int y = -3; y <= 3; y++) {
                        BlockPos candidate = origin.offset(x, y, z);
                        if (isSafeWorldPosition(soldier, candidate)) {
                            return candidate;
                        }
                    }
                }
            }
        }
        return null;
    }

    @Nullable
    private static BlockPos findSafePositionNear(SoldierEntity soldier, BlockPos center) {
        for (int[] offset : new int[][] {{0, 0}, {1, 0}, {-1, 0}, {0, 1}, {0, -1}, {2, 0}, {-2, 0}, {0, 2}, {0, -2}}) {
            for (int y = -1; y <= 1; y++) {
                BlockPos candidate = center.offset(offset[0], y, offset[1]);
                if (isSafeWorldPosition(soldier, candidate)) {
                    return candidate;
                }
            }
        }
        return null;
    }

    /** Head clearance a dismount spot must have above it: no hull blocks overhead. */
    private static final double EXTRACTION_HEAD_CLEARANCE = 2.0;

    private static boolean isSafeWorldPosition(SoldierEntity soldier, BlockPos position) {
        BlockState floor = soldier.level().getBlockState(position.below());
        if (floor.getCollisionShape(soldier.level(), position.below()).isEmpty()) {
            return false;
        }
        Vec3 location = Vec3.atBottomCenterOf(position);
        AABB bounds = soldier.getDimensions(Pose.STANDING).makeBoundingBox(location);
        // Ship blocks don't register in the world heightmap, so without the
        // upward extension the extraction spiral happily accepts the seabed
        // directly under the keel. Require open space overhead too.
        AABB clearance = bounds.expandTowards(0.0, EXTRACTION_HEAD_CLEARANCE, 0.0);
        return !intersectsShipHull(soldier.level(), clearance, true)
            && soldier.level().noCollision(soldier, bounds);
    }

    private static void moveToWorldPosition(SoldierEntity soldier, BlockPos position) {
        soldier.moveTo(position.getX() + 0.5, position.getY(), position.getZ() + 0.5, soldier.getYRot(), soldier.getXRot());
        soldier.setDeltaMovement(Vec3.ZERO);
    }

    private static void stopMovement(SoldierEntity soldier) {
        soldier.getNavigation().stop();
        soldier.cancelCoverMovement();
        soldier.setDeltaMovement(Vec3.ZERO);
    }

    /** Clears VS2's per-entity dragging state so the soldier is not dragged by the ship after dismount. */
    private static void clearShipDraggingState(SoldierEntity soldier) {
        try {
            Method getter = soldier.getClass().getMethod("getDraggingInformation");
            Object draggingInfo = getter.invoke(soldier);
            if (draggingInfo != null) {
                Class<?> dc = draggingInfo.getClass();
                try {
                    dc.getMethod("setLastShipStoodOn", Long.class).invoke(draggingInfo, (Long) null);
                } catch (NoSuchMethodException e1) {
                    dc.getMethod("setLastShipStoodOn", Object.class).invoke(draggingInfo, (Object) null);
                }
                dc.getMethod("setAddedMovementLastTick", org.joml.Vector3dc.class)
                    .invoke(draggingInfo, new org.joml.Vector3d());
                try {
                    dc.getMethod("setAddedYawRotLastTick", double.class).invoke(draggingInfo, 0.0);
                } catch (NoSuchMethodException e2) {
                    dc.getMethod("setAddedYawRotLastTick", Double.class).invoke(draggingInfo, 0.0);
                }
            }
        } catch (ReflectiveOperationException e) {
            StevesArmyMod.LOGGER.warn("[VS2] Failed to clear dragging state for soldier {}: {}", soldier.getId(), e.getMessage());
        }
    }

    @Nullable
    private static Entity getEntity(SoldierEntity soldier, @Nullable UUID id) {
        return id == null || !(soldier.level() instanceof ServerLevel level) ? null : level.getEntity(id);
    }

    @Nullable
    private static LivingEntity getOwner(SoldierEntity soldier, @Nullable UUID id) {
        Entity entity = getEntity(soldier, id);
        return entity instanceof LivingEntity living ? living : null;
    }

    private static synchronized void initialize() {
        if (initialized) {
            return;
        }
        initialized = true;
        if (!ModList.get().isLoaded(VS2_MOD_ID)) {
            return;
        }
        try {
            Class<?> utils = Class.forName(VS_UTILS_CLASS);
            Class<?> loadedShipClass = Class.forName("org.valkyrienskies.core.api.ships.LoadedShip");
            Class<?> mountedDataClass = Class.forName("org.valkyrienskies.mod.common.entity.ShipMountedToData");
            Class<?> shipClass = Class.forName("org.valkyrienskies.core.api.ships.Ship");
            Class<?> vector3dClass = Class.forName("org.joml.Vector3d");
            MethodHandles.Lookup lookup = MethodHandles.publicLookup();
            // Use MethodHandles to avoid JVM enumerating the entire Kotlin facade method table,
            // which would trigger ClientLevel class loading on dedicated server.
            getShipMountedTo = lookup.findStatic(utils, "getShipMountedTo",
                MethodType.methodType(loadedShipClass, Entity.class));
            getShipsIntersecting = lookup.findStatic(utils, "getShipsIntersecting",
                MethodType.methodType(Iterable.class, Level.class, AABB.class));
            getShipObjectManagingPos = lookup.findStatic(utils, "getShipObjectManagingPos",
                MethodType.methodType(loadedShipClass, Level.class, Vec3i.class));
            getShipObjectManagingPosDouble = lookup.findStatic(utils, "getShipObjectManagingPos",
                MethodType.methodType(loadedShipClass, Level.class, double.class, double.class, double.class));
            getShipMountedToData = lookup.findStatic(utils, "getShipMountedToData",
                MethodType.methodType(mountedDataClass, Entity.class, Float.class));
            toWorldCoordinates = lookup.findStatic(utils, "toWorldCoordinates",
                MethodType.methodType(vector3dClass, shipClass, double.class, double.class, double.class));
            Class<?> raycastUtils = Class.forName(
                "org.valkyrienskies.mod.common.world.RaycastUtilsKt");
            clipIncludeShips = lookup.findStatic(raycastUtils, "clipIncludeShips",
                MethodType.methodType(BlockHitResult.class, Level.class, ClipContext.class));
            try {
                // VS 2.4 added skipWorld, which lets us avoid classifying the
                // vanilla result when looking for a ship-only obstruction.
                clipIncludeShipsOnly = lookup.findStatic(raycastUtils, "clipIncludeShips",
                    MethodType.methodType(BlockHitResult.class, Level.class, ClipContext.class,
                        boolean.class, Long.class, boolean.class));
            } catch (NoSuchMethodException ignored) {
                // VS 2.3 has no skipWorld overload; the fallback below uses the
                // vanilla-only result to identify a ship hit.
                vanillaClip = lookup.findStatic(raycastUtils, "vanillaClip",
                    MethodType.methodType(BlockHitResult.class, BlockGetter.class, ClipContext.class));
            }

            createSeatBlockClass = Class.forName("com.simibubi.create.content.contraptions.actors.seat.SeatBlock");
            createSeatEntityClass = Class.forName("com.simibubi.create.content.contraptions.actors.seat.SeatEntity");
            try {
                createSeatSitDown = createSeatBlockClass.getMethod("sitDown",
                    Level.class, BlockPos.class, Entity.class);
            } catch (NoSuchMethodException ignored) {
                // MCP name fallback
                createSeatSitDown = createSeatBlockClass.getDeclaredMethod("m_7600_",
                    Level.class, BlockPos.class, Entity.class);
            }
            getMountPosInShip = mountedDataClass.getMethod("getMountPosInShip");
            try {
                shipMountedDataProviderClass = Class.forName(
                    "org.valkyrienskies.mod.common.entity.ShipMountedToDataProvider");
                shipGetShipToWorld = lookup.findVirtual(shipClass, "getShipToWorld",
                    MethodType.methodType(org.joml.Matrix4dc.class));
                shipGetWorldToShip = lookup.findVirtual(shipClass, "getWorldToShip",
                    MethodType.methodType(org.joml.Matrix4dc.class));
                // VS2 replaced the old ShipAABB type with JOML's AABBic voxel box;
                // the minX/minY/minZ accessor lookups in getShipyardMin are generic by class.
                Class<?> shipAabbClass = Class.forName("org.joml.primitives.AABBic");
                shipGetAABB = lookup.findVirtual(shipClass, "getShipVoxelAABB",
                    MethodType.methodType(shipAabbClass));
            } catch (ReflectiveOperationException | LinkageError crewHelpers) {
                // Non-fatal: ship transform helpers fall back to raw positions.
                StevesArmyMod.LOGGER.warn("[VS2] Ship-transform helper unavailable: {}",
                    crewHelpers.toString());
            }
            contraptionEntityClass = Class.forName(CONTRAPTION_ENTITY_CLASS);
            getContraption = contraptionEntityClass.getMethod("getContraption");
            Class<?> contraptionClass = Class.forName("com.simibubi.create.content.contraptions.Contraption");
            getSeats = contraptionClass.getMethod("getSeats");
            getSeatMapping = contraptionClass.getMethod("getSeatMapping");
            addSittingPassenger = contraptionEntityClass.getMethod("addSittingPassenger", Entity.class, int.class);
            getShipId = shipClass.getMethod("getId");
            if (ModList.get().isLoaded("create_interactive")) {
                Class<?> interactive = Class.forName("org.valkyrienskies.create_interactive.CreateInteractiveUtil");
                createInteractiveUtil = interactive.getField("INSTANCE").get(null);
                getContraptionEntityForShip = interactive.getMethod("getContraptionEntityForShip", long.class, boolean.class);
                StevesArmyMod.LOGGER.info("[VS2] Create Interactive ship-to-contraption lookup enabled");
            }
            available = true;
            StevesArmyMod.LOGGER.info("[VS2] Enabled soldier ship avoidance and transport compatibility");
        } catch (ReflectiveOperationException | LinkageError exception) {
            logReflectionFailure(exception);
        }
    }

    private static Object reflect(MethodHandle handle, Object... args) throws ReflectiveOperationException {
        try {
            return handle.invokeWithArguments(args);
        } catch (ReflectiveOperationException e) {
            throw e;
        } catch (RuntimeException e) {
            // MethodHandle may wrap the real cause
            Throwable cause = e.getCause();
            if (cause instanceof ReflectiveOperationException roe) {
                throw roe;
            }
            throw e;
        } catch (Throwable e) {
            throw new RuntimeException(e);
        }
    }

    private static void logReflectionFailure(Throwable exception) {
        available = false;
        if (!reflectionFailureLogged) {
            reflectionFailureLogged = true;
            StevesArmyMod.LOGGER.warn("[VS2] Soldier compatibility is unavailable: {}", exception.toString());
        }
    }

    private static void logSeatAttempt(SoldierEntity soldier, SoldierState state, LivingEntity owner) {
        long now = System.currentTimeMillis();
        if (now - state.lastSeatAttemptLog < 5000L) {
            return;
        }
        state.lastSeatAttemptLog = now;
        StevesArmyMod.LOGGER.info("[VS2] Seat attempt soldier={} owner={} ownerVehicle={} ownerVehicleId={}",
            soldier.getId(), owner.getId(), owner.getVehicle().getClass().getSimpleName(), owner.getVehicle().getId());
    }

    private static SoldierState getOrCreateState(SoldierEntity soldier) {
        return states.computeIfAbsent(soldier.getUUID(), ignored -> new SoldierState());
    }

    private static final class SoldierState {
        @Nullable private BlockPos lastSafeWorldPosition;
        @Nullable private UUID transportAnchorId;
        @Nullable private UUID transportOwnerId;
        @Nullable private Long transportShipId;
        @Nullable private BlockPos transportSeatPosition;
        private int seatRetryCooldownTicks;
        private int reboardBlockTicks;
        private long lastSeatAttemptLog;
        /** Crew soldiers seated on a station seat keep ticking their AI. */
        private boolean crewSeated;
        /** Ticks the has been off-ship consecutively (release debounce). */
        private int ownerOffShipCount;
        /** Ticks a soldier may stand inside the ship after a mount-handle dismount. */
        private int handleDismountGraceTicks;
        /** Throttle for the seated-crew station duty scan. */
        private int crewDutyScanCooldown;
        /** Throttle for the implausible-position recovery WARN log. */
        private long lastRecoveryLog;
        /** Ticks spent waiting for a re-seat after the transport seat vanished. */
        private int reseatWaitTicks;
    }
}
