package com.stevesarmy.compat.sbw;

import net.minecraft.world.entity.Entity;
import net.minecraft.world.phys.Vec3;

/**
 * Turret aiming helper.
 *
 * {@link SbwVehicles#aimWeapon} only knows one SBW helper name. When that name
 * is absent on a given vehicle class the call silently does nothing, which is
 * why an idle tank turret never moved. This wrapper keeps the existing call as
 * the primary path and adds direct turret rotation setters as a fallback, so
 * the gun actually traverses on every SBW hull.
 */
public final class SbwTurret {

    private static final String UTILS = "com.atsuishio.superbwarfare.entity.vehicle.utils.VehicleWeaponUtils";

    private SbwTurret() {
    }

    /** Aim the given seat's weapon along a direction vector. */
    public static void aim(Entity vehicle, int seatIndex, Vec3 direction) {
        if (vehicle == null || direction == null) return;
        SbwVehicles.aimWeapon(vehicle, seatIndex, direction);

        if (seatIndex != SbwVehicles.turretControllerIndex(vehicle)) return;
        Class<?> utils = SbwReflection.cls(UTILS);
        if (utils != null) {
            SbwReflection.callStatic(utils,
                new String[]{"turretAutoAimFromVector", "turretAutoAim", "autoAimFromVector"},
                vehicle, direction);
        }
    }

    /** Aim the turret at absolute world angles, degrees. */
    public static void aimAngles(Entity vehicle, int seatIndex, float yaw, float pitch) {
        if (vehicle == null) return;
        aim(vehicle, seatIndex, Vec3.directionFromRotation(pitch, yaw));
        // Direct setters, present on SBW turret vehicles. A missing method is a
        // silent no op in the reflection layer, so this is safe everywhere.
        SbwReflection.call(vehicle, new String[]{"setTurretYRot", "setTurretYaw"}, yaw);
        SbwReflection.call(vehicle, new String[]{"setTurretXRot", "setTurretPitch"}, pitch);
    }

    public static float turretYaw(Entity vehicle) {
        return SbwReflection.asFloat(
            SbwReflection.get(vehicle, "turretYRot", "getTurretYRot"), vehicle.getYRot());
    }

    public static float turretPitch(Entity vehicle) {
        return SbwReflection.asFloat(
            SbwReflection.get(vehicle, "turretXRot", "getTurretXRot"), 0.0f);
    }
}
